-- Add DM privacy column to users table
ALTER TABLE users ADD COLUMN dm_privacy TEXT DEFAULT 'everyone';
