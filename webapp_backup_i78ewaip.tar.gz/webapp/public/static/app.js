// =============================================
// さとっち v25 - Full Featured · Engagement Engine · Protected Admin
// Editorial · Sophisticated · Minimalist
// =============================================
'use strict';

const S = {
  user: window.__USER__,
  lang: window.__LANG__ || 'ja',
  theme: null,
  currentPage: null,
  currentParams: {},
  cache: { posts: [], feedCursor: null, feedTab: 'global', feedDone: false, latestTs: null, vrPromos: [] },
  voiceStream: null, voiceRoomId: null, voicePollId: null,
  dmPoll: null, crewPoll: null, crewVoicePoll: null, vrChatPoll: null,
  scrollPositions: {}, newPostsAvailable: false, crewCreating: false,
  peer: null, peerConnections: {}, remoteAudios: {},
  crewVoicePeer: null, crewVoiceStream: null, crewVoiceConns: {}, crewVoiceAudios: {}, crewVoiceChannelId: null,
  joinSound: null, leaveSound: null,
  musicAudio: null, musicPlaying: false,
  _errCount: 0,
  // WebSocket connections
  ws: null, wsChannel: null, wsReconnectTimer: null, wsReconnectDelay: 500,
  // Whiteboard state
  wbZoom: 1, wbPanX: 0, wbPanY: 0, wbIsPanning: false,
  // Seen posts tracking
  seenPostIds: new Set(),
  seenFlushTimer: null,
  _signalBuf: [], _signalTimer: null, _dwellTimers: {}, _dwellObserver: null,
  // Floating voice bubble
  voiceBubbleVisible: false,
  // Ably realtime client
  ably: null, ablyChannel: null, ablyConnected: false
};

// Lazy-load sounds only when needed (saves ~576KB on initial load)
function _loadSound(key, path) {
  if (S[key]) return S[key];
  try { S[key] = new Audio(path); S[key].volume = 0.4; S[key].preload = 'none'; return S[key]; } catch(e) { return null; }
}
function playJoinSound() { try { const s = _loadSound('joinSound', '/static/join.wav'); if(s){s.currentTime=0;s.play().catch(()=>{});} } catch(e){} }
function playLeaveSound() { try { const s = _loadSound('leaveSound', '/static/leave.wav'); if(s){s.currentTime=0;s.play().catch(()=>{});} } catch(e){} }

// ===== ABLY REALTIME =====
function initAbly() {
  const key = window.__ABLY_KEY__;
  if (!key || !S.user || !window.Ably) return;
  try {
    S.ably = new Ably.Realtime({ key: key, clientId: S.user.id, autoConnect: true, recover: function(_, cb) { cb(true); } });
    S.ably.connection.on('connected', () => { S.ablyConnected = true; console.log('[Ably] Connected'); });
    S.ably.connection.on('disconnected', () => { S.ablyConnected = false; });
    S.ably.connection.on('failed', (err) => { S.ablyConnected = false; console.warn('[Ably] Failed:', err); });
  } catch (e) { console.warn('[Ably] Init error:', e); }
}
function ablySubscribe(channelName, callback) {
  if (!S.ably) return null;
  try {
    const ch = S.ably.channels.get(channelName);
    ch.subscribe(callback);
    return ch;
  } catch (e) { console.warn('[Ably] Subscribe error:', e); return null; }
}
function ablyPublish(channelName, eventName, data) {
  if (!S.ably) return;
  try {
    const ch = S.ably.channels.get(channelName);
    ch.publish(eventName, data);
  } catch (e) { console.warn('[Ably] Publish error:', e); }
}
function ablyUnsubscribe(channelName) {
  if (!S.ably) return;
  try { S.ably.channels.get(channelName).unsubscribe(); S.ably.channels.get(channelName).detach(); } catch {}
}
// Initialize Ably when idle (deferred to not block initial render)
if (window.requestIdleCallback) { requestIdleCallback(() => { if (S.user) initAbly(); }, { timeout: 2000 }); }
else { setTimeout(() => { if (S.user) initAbly(); }, 1500); }

// ===== RESILIENCE =====
window.onerror = (msg, src, line, col, err) => { S._errCount++; console.warn('Caught:', msg); return true; };
window.onunhandledrejection = (e) => { e.preventDefault(); S._errCount++; console.warn('Unhandled:', e.reason); };
window.addEventListener('beforeunload', (e) => { if (S.voiceStream || S.crewVoiceStream) { e.preventDefault(); e.returnValue = ''; } });

// ===== INDEXEDDB CACHE =====
const IDB_NAME = 'satocchi-cache';
const IDB_STORE = 'api';
let _idb = null;
function openIDB() {
  if (_idb) return Promise.resolve(_idb);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(IDB_STORE); };
    req.onsuccess = () => { _idb = req.result; resolve(_idb); };
    req.onerror = () => resolve(null);
  });
}
async function idbGet(key) {
  try {
    const db = await openIDB(); if (!db) return null;
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch { return null; }
}
async function idbSet(key, val) {
  try {
    const db = await openIDB(); if (!db) return;
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(val, key);
  } catch {}
}

// ===== HAPTICS (iOS Safari via hidden checkbox switch trick + vibrate API) =====
let _hapticEl = null, _hapticLabel = null;
function haptic(style = 'light') {
  try {
    // Android/Chrome: use navigator.vibrate
    if (navigator.vibrate) {
      const patterns = { light: [8], medium: [15], heavy: [30], success: [10, 50, 10], error: [30, 50, 30] };
      navigator.vibrate(patterns[style] || [8]);
      return;
    }
    // iOS Safari: use hidden <input type="checkbox" switch> trick
    if (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)) {
      if (!_hapticEl) {
        _hapticEl = document.createElement('input');
        _hapticEl.type = 'checkbox';
        _hapticEl.setAttribute('switch', '');
        _hapticEl.id = 'ios-haptic-cb';
        _hapticEl.style.cssText = 'position:fixed;top:-100px;left:-100px;opacity:0;pointer-events:none;width:0;height:0';
        _hapticLabel = document.createElement('label');
        _hapticLabel.setAttribute('for', 'ios-haptic-cb');
        _hapticLabel.style.cssText = 'position:fixed;top:-100px;left:-100px;opacity:0;pointer-events:none;width:0;height:0';
        document.body.appendChild(_hapticEl);
        document.body.appendChild(_hapticLabel);
      }
      _hapticLabel.click();
    }
  } catch {}
}

// ===== VISUAL VIEWPORT (keyboard handling) =====
function initVisualViewport() {
  if (!window.visualViewport) return;
  const vv = window.visualViewport;
  let lastHeight = vv.height;
  let keyboardVisible = false;
  function onResize() {
    const diff = window.innerHeight - vv.height;
    const isKeyboard = diff > 100;
    const wasKeyboard = keyboardVisible;
    keyboardVisible = isKeyboard;
    document.documentElement.style.setProperty('--vv-offset', isKeyboard ? `${diff}px` : '0px');
    document.documentElement.style.setProperty('--vv-bottom', isKeyboard ? `${vv.offsetTop + vv.height}px` : '');
    // Keep bottom nav hidden when keyboard is open
    const mn = document.getElementById('mobile-nav');
    if (mn) mn.style.transform = isKeyboard ? 'translateY(100%)' : '';
    // Pin chat inputs above keyboard for DM, Crew, and VoiceRoom
    const chatSelectors = ['.dm-chat-input', '.crew-input-area', '.vr-chat-input'];
    // Message container selectors that match the chat input selectors
    const msgContainerIds = ['dm-msgs', 'crew-msgs', 'vr-chat-msgs'];
    if (isKeyboard && document.activeElement) {
      const tag = document.activeElement.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') {
        chatSelectors.forEach((sel, idx) => {
          const chatInput = document.activeElement.closest(sel) || document.querySelector(sel);
          if (chatInput) {
            chatInput.classList.add('keyboard-pinned');
            chatInput.style.bottom = `${diff}px`;
            // Also adjust the message container to shrink so messages stay visible above keyboard
            const msgsEl = document.getElementById(msgContainerIds[idx]);
            if (msgsEl) {
              const inputHeight = chatInput.offsetHeight || 60;
              msgsEl.style.paddingBottom = `${diff + inputHeight}px`;
              // Scroll messages to bottom so latest messages are visible
              requestAnimationFrame(() => { msgsEl.scrollTop = msgsEl.scrollHeight; });
            }
          }
        });
        // Scroll input into view
        const el = document.activeElement;
        const rect = el.getBoundingClientRect();
        const keyboardTop = vv.offsetTop + vv.height;
        if (rect.bottom > keyboardTop - 10) {
          const scrollBy = rect.bottom - keyboardTop + 60;
          window.scrollBy({ top: scrollBy, behavior: 'smooth' });
        }
      }
    } else {
      // Keyboard hidden - restore chat input positions and message padding
      chatSelectors.forEach((sel, idx) => {
        document.querySelectorAll(sel).forEach(el => {
          el.classList.remove('keyboard-pinned');
          el.style.bottom = '';
        });
        const msgsEl = document.getElementById(msgContainerIds[idx]);
        if (msgsEl) { msgsEl.style.paddingBottom = ''; }
      });
    }
    lastHeight = vv.height;
  }
  vv.addEventListener('resize', onResize);
}

// ===== SCROLL-AWARE HEADER/NAV (hide on scroll up, show on scroll down) =====
let _scrollState = { lastY: 0, hidden: false, ticking: false };
function initScrollAwareUI() {
  window.addEventListener('scroll', () => {
    if (_scrollState.ticking) return;
    _scrollState.ticking = true;
    requestAnimationFrame(() => {
      _scrollState.ticking = false;
      if (S.currentPage !== 'home') return;
      const y = window.scrollY;
      const delta = y - _scrollState.lastY;
      const header = document.querySelector('.page-header');
      const mn = document.getElementById('mobile-nav');
      // Only hide when scrolling DOWN past threshold
      if (delta > 8 && y > 120 && !_scrollState.hidden) {
        _scrollState.hidden = true;
        if (header) { header.style.transform = 'translateY(-100%)'; header.style.transition = 'transform 0.3s cubic-bezier(0.22,1,0.36,1)'; }
        if (mn) { mn.classList.add('nav-hidden'); }
      } else if (delta < -5 && _scrollState.hidden) {
        _scrollState.hidden = false;
        if (header) { header.style.transform = ''; }
        if (mn) { mn.classList.remove('nav-hidden'); }
      }
      _scrollState.lastY = y;
    });
  }, { passive: true });
}

// ===== PULL TO REFRESH (redesigned, works everywhere, deduplicates) =====
let _ptr = { startY: 0, pulling: false, el: null, threshold: 80 };
function initPullToRefresh() {
  const mainContent = document.querySelector('.main-content') || document.body;
  
  mainContent.addEventListener('touchstart', (e) => {
    if (window.scrollY > 5) return;
    // Work on all pages that have feeds
    const allowedPages = ['home', 'voice', 'profile', 'crew', 'notifications'];
    if (!allowedPages.includes(S.currentPage)) return;
    _ptr.startY = e.touches[0].clientY;
    _ptr.pulling = true;
  }, { passive: true });

  mainContent.addEventListener('touchmove', (e) => {
    if (!_ptr.pulling) return;
    const dy = e.touches[0].clientY - _ptr.startY;
    if (dy < 0) { _ptr.pulling = false; return; }
    if (dy > 10 && !_ptr.el) {
      _ptr.el = document.getElementById('ptr-indicator');
      if (!_ptr.el) {
        _ptr.el = document.createElement('div');
        _ptr.el.id = 'ptr-indicator';
        _ptr.el.className = 'ptr-indicator';
        _ptr.el.innerHTML = '<div class="ptr-spinner-ring"><svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="88" stroke-dashoffset="88" stroke-linecap="round"/></svg></div>';
        const page = document.getElementById('page');
        if (page) page.parentNode.insertBefore(_ptr.el, page);
      }
    }
    if (_ptr.el && dy > 0) {
      const progress = Math.min(dy / _ptr.threshold, 1);
      _ptr.el.style.height = Math.min(dy * 0.5, 60) + 'px';
      _ptr.el.style.opacity = progress;
      const circle = _ptr.el.querySelector('circle');
      if (circle) {
        const dashOffset = 88 - (88 * progress);
        circle.setAttribute('stroke-dashoffset', dashOffset);
      }
      if (progress >= 1) {
        _ptr.el.classList.add('ptr-ready');
      } else {
        _ptr.el.classList.remove('ptr-ready');
      }
    }
  }, { passive: true });

  mainContent.addEventListener('touchend', () => {
    if (!_ptr.pulling) return;
    _ptr.pulling = false;
    if (_ptr.el) {
      const isTriggered = _ptr.el.classList.contains('ptr-ready');
      if (isTriggered) {
        haptic('medium');
        _ptr.el.classList.add('ptr-refreshing');
        _ptr.el.style.height = '50px';
        // Route to correct refresh function
        const refreshFn = getPageRefreshFn();
        if (refreshFn) {
          refreshFn().then(() => {
            if (_ptr.el) { _ptr.el.style.height = '0'; _ptr.el.style.opacity = '0'; _ptr.el.classList.remove('ptr-refreshing', 'ptr-ready'); }
          });
        } else {
          setTimeout(() => {
            if (_ptr.el) { _ptr.el.style.height = '0'; _ptr.el.style.opacity = '0'; _ptr.el.classList.remove('ptr-refreshing', 'ptr-ready'); }
          }, 500);
        }
      } else {
        _ptr.el.style.height = '0';
        _ptr.el.style.opacity = '0';
        _ptr.el.classList.remove('ptr-ready');
      }
    }
  }, { passive: true });
}

function getPageRefreshFn() {
  switch(S.currentPage) {
    case 'home': return async () => { _apiCache.clear(); await refreshFeedAsync(); };
    case 'voice': return async () => { _apiCache.clear(); await loadVoiceRooms(); };
    case 'notifications': return async () => { _apiCache.clear(); await pageNotifications(document.getElementById('page')); };
    case 'profile': return async () => { _apiCache.clear(); const params = S.currentParams; if (params?.username) { const el = document.getElementById('page'); if (el) { el.innerHTML = '<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>'; await pageProfile(el, params.username); } } };
    case 'crew': return async () => { _apiCache.clear(); const el = document.getElementById('page'); if (el) await pageCrew(el); };
    case 'shop': return async () => { _apiCache.clear(); await loadShopStore(); };
    case 'postDetail': return async () => { _apiCache.clear(); const params = S.currentParams; if (params?.id) { const el = document.getElementById('page'); if (el) await pagePostDetail(el, params.id); } };
    default: return null;
  }
}
async function refreshFeedAsync() {
  const banner = $('#new-posts-banner'); if (banner) banner.classList.remove('visible');
  S.newPostsAvailable = false; S.cache.vrPromos = [];
  // Clear old feed state to prevent duplicates
  S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false;
  _apiCache.clear(); // Clear API cache to get fresh data
  await loadFeed(true);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ===== CUSTOM CONTEXT MENU =====
function initContextMenu() {
  let longPressTimer = null;
  let longPressTarget = null;
  
  document.addEventListener('contextmenu', (e) => {
    // Disable default context menu on images and links
    if (e.target.closest('img.post-image') || e.target.closest('a[href]')) {
      e.preventDefault();
    }
  });

  document.addEventListener('touchstart', (e) => {
    const target = e.target.closest('img.post-image') || e.target.closest('.post');
    if (!target) return;
    longPressTarget = target;
    longPressTimer = setTimeout(() => {
      haptic('medium');
      showCustomContextMenu(e, longPressTarget);
    }, 500);
  }, { passive: true });

  document.addEventListener('touchmove', () => {
    if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
  }, { passive: true });

  document.addEventListener('touchend', () => {
    if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
  }, { passive: true });
}

function showCustomContextMenu(e, target) {
  // Remove any existing menu
  document.querySelectorAll('.ctx-menu').forEach(m => m.remove());
  
  const menu = document.createElement('div');
  menu.className = 'ctx-menu anim-scale-in';
  
  if (target.tagName === 'IMG') {
    const src = target.src;
    menu.innerHTML = `
      <button class="ctx-item" onclick="viewImage('${src}');this.closest('.ctx-menu').remove()"><i class="fas fa-expand"></i>${S.lang==='ja'?'画像を表示':'View Image'}</button>
      <button class="ctx-item" onclick="navigator.clipboard?.writeText('${src}');toast('Copied');this.closest('.ctx-menu').remove()"><i class="fas fa-copy"></i>${S.lang==='ja'?'URLをコピー':'Copy URL'}</button>
      <button class="ctx-item" onclick="window.open('${src}','_blank');this.closest('.ctx-menu').remove()"><i class="fas fa-external-link"></i>${S.lang==='ja'?'新しいタブで開く':'Open in new tab'}</button>
    `;
  } else {
    const postEl = target.closest('.post');
    const postId = postEl?.id?.replace('post-', '');
    if (postId) {
      menu.innerHTML = `
        <button class="ctx-item" onclick="navigator.clipboard?.writeText(location.origin+'/post/${postId}');toast('Copied');this.closest('.ctx-menu').remove()"><i class="fas fa-link"></i>${S.lang==='ja'?'リンクをコピー':'Copy Link'}</button>
        <button class="ctx-item" onclick="navigate('/post/${postId}');this.closest('.ctx-menu').remove()"><i class="fas fa-arrow-right"></i>${S.lang==='ja'?'投稿を見る':'View Post'}</button>
        <button class="ctx-item" onclick="showKoremiteModal('${postId}');this.closest('.ctx-menu').remove()"><i class="fas fa-retweet"></i>${S.lang==='ja'?'コレミテ':'Quote'}</button>
      `;
    }
  }
  
  menu.innerHTML += `<button class="ctx-item" onclick="this.closest('.ctx-menu').remove()"><i class="fas fa-times"></i>${S.lang==='ja'?'閉じる':'Close'}</button>`;
  
  document.body.appendChild(menu);
  // Position near touch
  const touch = e.touches?.[0] || e;
  const x = Math.min(touch.clientX || touch.pageX, window.innerWidth - 200);
  const y = Math.min(touch.clientY || touch.pageY, window.innerHeight - 200);
  menu.style.left = x + 'px';
  menu.style.top = y + 'px';
  
  // Close on outside click
  setTimeout(() => {
    const close = (ev) => { if (!ev.target.closest('.ctx-menu')) { menu.remove(); document.removeEventListener('click', close); } };
    document.addEventListener('click', close);
  }, 100);
}

// ===== SITE IMAGES (admin-configurable) =====
const SITE_IMG = window.__SITE_IMAGES__ || {};
function siteImg(key, fallback) { return SITE_IMG[key] || fallback || ''; }

// ===== HELPERS =====
const $ = (s, p) => (p || document).querySelector(s);
const $$ = (s, p) => [...(p || document).querySelectorAll(s)];
const h = (tag, cls, html) => { const el = document.createElement(tag); if (cls) el.className = cls; if (html !== undefined) el.innerHTML = html; return el; };
function esc(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
// Global smooth modal close
function closeModalSmooth(el) { if (!el) return; const ov = el.closest('.modal-overlay') || el; ov.style.opacity = '0'; ov.style.transition = 'opacity 0.2s ease'; setTimeout(() => ov.remove(), 200); }

// API cache for GET requests (reduces server load)
const _apiCache = new Map();
const API_CACHE_TTL = 8000; // 8 seconds - slightly shorter for faster updates
const _inflight = new Map(); // Deduplicate in-flight requests

async function api(path, opts = {}) {
  try {
    const isGet = !opts.method || opts.method === 'GET';
    // Use memory cache for GET requests
    if (isGet && _apiCache.has(path)) {
      const cached = _apiCache.get(path);
      if (Date.now() - cached.ts < API_CACHE_TTL) return cached.data;
    }
    // Deduplicate in-flight GET requests
    if (isGet && _inflight.has(path)) return _inflight.get(path);
    const promise = (async () => {
      const r = await fetch(path, { headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', ...opts, body: opts.body ? JSON.stringify(opts.body) : undefined });
      const data = await r.json();
      if (isGet && !data.error) {
        _apiCache.set(path, { data, ts: Date.now() });
        // Persist key data to IndexedDB for near-instant reload (debounced)
        const idbPaths = ['/api/posts', '/api/me', '/api/voice-rooms', '/api/crews'];
        if (idbPaths.some(p => path.startsWith(p))) {
          requestIdleCallback ? requestIdleCallback(() => idbSet('api:' + path, { data, ts: Date.now() })) : setTimeout(() => idbSet('api:' + path, { data, ts: Date.now() }), 100);
        }
      }
      // Invalidate related caches on mutations
      if (!isGet) {
        for (const k of _apiCache.keys()) {
          if (k.startsWith(path.split('?')[0].replace(/\/[^/]+$/, ''))) _apiCache.delete(k);
        }
      }
      return data;
    })();
    if (isGet) { _inflight.set(path, promise); promise.finally(() => _inflight.delete(path)); }
    return await promise;
  } catch(e) {
    // Try IndexedDB fallback for GET requests (offline support)
    if (!opts.method || opts.method === 'GET') {
      const cached = await idbGet('api:' + path);
      if (cached && cached.data) return cached.data;
    }
    return { error: 'Network error' };
  }
}
// Clear stale cache entries (less frequent = less CPU)
setInterval(() => { const now = Date.now(); for (const [k,v] of _apiCache) { if (now - v.ts > 60000) _apiCache.delete(k); } }, 60000);

function timeAgo(d) {
  const s = Math.floor((Date.now() - new Date(d + (d.includes('Z') ? '' : 'Z')).getTime()) / 1000);
  if (s < 10) return t('general.just_now');
  if (s < 60) return s + (S.lang === 'ja' ? '秒前' : 's');
  if (s < 3600) return Math.floor(s/60) + (S.lang === 'ja' ? '分前' : 'm');
  if (s < 86400) return Math.floor(s/3600) + (S.lang === 'ja' ? '時間前' : 'h');
  return Math.floor(s/86400) + (S.lang === 'ja' ? '日前' : 'd');
}

function avatar(url, name, size = 40) {
  if (url) return `<img src="${esc(url)}" class="avatar" style="width:${size}px;height:${size}px" loading="lazy" decoding="async" alt="">`;
  const i = (name || '?')[0].toUpperCase();
  const colors = ['#c8553d','#5b8fa8','#6b8f71','#c2b280','#8b7eb8','#c47a8a','#d4855c','#7a8f6b'];
  const c = colors[i.charCodeAt(0) % colors.length];
  return `<div class="avatar-placeholder" style="width:${size}px;height:${size}px;font-size:${Math.round(size*0.36)}px;background:${c}10;color:${c}">${i}</div>`;
}

function tagHTML(tag) { if (!tag) return ''; return `<span class="tag tag-${tag}">${t('tag.'+tag)}</span>`; }
function isAdmin(u) { return u && (u.role === 'admin' || u.role === 'superadmin'); }

// Format content with @mentions and #hashtags
// @mentions can be by username or by sid (permanent ID)
function formatContent(text) {
  let html = esc(text)
    .replace(/@([a-zA-Z0-9_]+)/g, '<a href="/profile/$1" style="color:var(--accent);font-weight:600" class="hover-underline" onclick="event.stopPropagation()">@$1</a>')
    .replace(/#([a-zA-Z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF_]+)/g, '<a href="/hashtag/$1" style="color:var(--sky);font-weight:600" class="hover-underline" onclick="event.stopPropagation()">#$1</a>');
  // Make URLs clickable
  html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:var(--sky);text-decoration:underline;text-underline-offset:2px" onclick="event.stopPropagation()">$1</a>');
  return html;
}

// ===== LINK PREVIEW =====
const _linkPreviewCache = new Map();
async function fetchLinkPreview(url) {
  if (_linkPreviewCache.has(url)) return _linkPreviewCache.get(url);
  try {
    const res = await api(`/api/ogp?url=${encodeURIComponent(url)}`);
    _linkPreviewCache.set(url, res);
    return res;
  } catch { return null; }
}
function renderLinkPreviews(containerEl, text) {
  const urls = (text || '').match(/https?:\/\/[^\s]+/g);
  if (!urls || urls.length === 0) return;
  const uniqueUrls = [...new Set(urls)].slice(0, 3);
  uniqueUrls.forEach(url => {
    fetchLinkPreview(url).then(ogp => {
      if (!ogp || (!ogp.title && !ogp.image)) return;
      const previewEl = document.createElement('a');
      previewEl.href = url;
      previewEl.target = '_blank';
      previewEl.rel = 'noopener';
      previewEl.className = 'link-preview';
      previewEl.onclick = e => e.stopPropagation();
      previewEl.innerHTML = `${ogp.image ? `<div class="link-preview-img"><img src="${esc(ogp.image)}" loading="lazy" onerror="this.parentElement.remove()"></div>` : ''}
        <div class="link-preview-body"><div class="link-preview-site">${esc(ogp.site_name || new URL(url).hostname)}</div>${ogp.title ? `<div class="link-preview-title">${esc(ogp.title)}</div>` : ''}${ogp.description ? `<div class="link-preview-desc">${esc(ogp.description).substring(0,120)}</div>` : ''}</div>`;
      containerEl.appendChild(previewEl);
    });
  });
}

// ===== QR CODE SHARING =====
// QR Scanner using camera
function openQRScanner() {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;text-align:center" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-qrcode" style="margin-right:8px;color:var(--accent)"></i>${S.lang==='ja'?'QRコード読み取り':'Scan QR Code'}</h3>
    <video id="qr-video" style="width:100%;max-width:320px;border-radius:var(--radius-lg);background:#000" playsinline autoplay></video>
    <div id="qr-status" style="margin-top:12px;font-size:13px;color:var(--text-tertiary)">${S.lang==='ja'?'カメラを起動中...':'Starting camera...'}</div>
    <button class="btn btn-secondary btn-sm" style="margin-top:16px" onclick="stopQRScanner();this.closest('.modal-overlay').remove()"><i class="fas fa-times" style="margin-right:4px"></i>${S.lang==='ja'?'閉じる':'Close'}</button>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) { stopQRScanner(); ov.remove(); } });
  document.body.appendChild(ov);
  startQRScanner();
}
let qrStream = null, qrAnimId = null;
function stopQRScanner() { if (qrStream) { qrStream.getTracks().forEach(t => t.stop()); qrStream = null; } if (qrAnimId) { cancelAnimationFrame(qrAnimId); qrAnimId = null; } }
async function startQRScanner() {
  try {
    qrStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    const video = document.getElementById('qr-video');
    if (!video) { stopQRScanner(); return; }
    video.srcObject = qrStream;
    const status = document.getElementById('qr-status');
    if (status) status.textContent = S.lang==='ja'?'QRコードをかざしてください':'Point at a QR code';
    // Use BarcodeDetector API if available
    if ('BarcodeDetector' in window) {
      const detector = new BarcodeDetector({ formats: ['qr_code'] });
      const scan = async () => {
        if (!qrStream) return;
        try {
          const codes = await detector.detect(video);
          if (codes.length > 0) {
            const url = codes[0].rawValue;
            stopQRScanner();
            document.querySelector('.modal-overlay')?.remove();
            handleQRResult(url);
            return;
          }
        } catch (e) {}
        qrAnimId = requestAnimationFrame(scan);
      };
      qrAnimId = requestAnimationFrame(scan);
    } else {
      // Fallback: use jsQR library for browsers without BarcodeDetector (e.g. iPhone Safari)
      if (status) status.textContent = S.lang==='ja'?'QRスキャナーを準備中...':'Loading QR scanner...';
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js';
      script.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (status) status.textContent = S.lang==='ja'?'QRコードをかざしてください':'Point at a QR code';
        const scanFrame = () => {
          if (!qrStream) return;
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = video.videoWidth; canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imgData.data, imgData.width, imgData.height, { inversionAttempts: 'dontInvert' });
            if (code) {
              stopQRScanner();
              document.querySelector('.modal-overlay')?.remove();
              handleQRResult(code.data);
              return;
            }
          }
          qrAnimId = requestAnimationFrame(scanFrame);
        };
        qrAnimId = requestAnimationFrame(scanFrame);
      };
      script.onerror = () => { if (status) status.textContent = S.lang==='ja'?'QRスキャナーの読み込みに失敗':'Failed to load QR scanner'; };
      document.head.appendChild(script);
    }
  } catch (e) {
    const status = document.getElementById('qr-status');
    if (status) status.textContent = S.lang==='ja'?'カメラへのアクセスが拒否されました':'Camera access denied';
  }
}
function handleQRResult(url) {
  if (url.startsWith(location.origin)) { navigate(url.replace(location.origin, '')); }
  else if (url.startsWith('http')) { window.open(url, '_blank'); }
  else { toast(url, 'info'); }
}

function showQRModal(url, title) {
  const ov = h('div', 'modal-overlay');
  const qrSize = 200;
  ov.innerHTML = `<div class="modal-content" style="padding:32px;text-align:center" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:20px">${title || 'QR Code'}</h3>
    <div id="qr-canvas-wrap" style="display:inline-block;padding:20px;background:white;border-radius:var(--radius-lg);margin-bottom:16px"></div>
    <div style="font-size:13px;color:var(--text-tertiary);word-break:break-all;margin-bottom:16px">${esc(url)}</div>
    <div style="display:flex;gap:12px;justify-content:center">
      <button class="btn btn-secondary btn-sm" onclick="navigator.clipboard?.writeText('${esc(url)}');toast('Copied')"><i class="fas fa-copy"></i> ${S.lang==='ja'?'コピー':'Copy'}</button>
      <button class="btn btn-secondary btn-sm" onclick="this.closest('.modal-overlay').remove()"><i class="fas fa-times"></i> ${S.lang==='ja'?'閉じる':'Close'}</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
  // Generate QR using canvas
  generateQRCanvas(url, document.getElementById('qr-canvas-wrap'), qrSize);
}

function generateQRCanvas(text, container, size) {
  // Minimal QR placeholder: use a CDN library dynamically
  const script = document.createElement('script');
  script.src = 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js';
  script.onload = () => {
    try {
      const qr = qrcode(0, 'M');
      qr.addData(text);
      qr.make();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const moduleCount = qr.getModuleCount();
      const cellSize = Math.floor(size / moduleCount);
      canvas.width = canvas.height = cellSize * moduleCount;
      canvas.style.borderRadius = '12px';
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#1a1a2e';
      for (let row = 0; row < moduleCount; row++) {
        for (let col = 0; col < moduleCount; col++) {
          if (qr.isDark(row, col)) {
            ctx.beginPath();
            ctx.roundRect(col * cellSize, row * cellSize, cellSize, cellSize, cellSize * 0.3);
            ctx.fill();
          }
        }
      }
      container.innerHTML = '';
      container.appendChild(canvas);
    } catch(e) { container.innerHTML = '<div style="color:var(--text-tertiary)">QR generation failed</div>'; }
  };
  script.onerror = () => { container.innerHTML = '<div style="color:var(--text-tertiary)">QR library load failed</div>'; };
  document.head.appendChild(script);
}

// ===== BeReal DUAL CAMERA =====
async function showDualCameraModal() {
  if (!S.user) return navigate('/login');
  const ov = h('div', 'modal-overlay');
  ov.style.background = '#000';
  ov.innerHTML = `<div style="width:100%;height:100%;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center" onclick="event.stopPropagation()">
    <video id="cam-back" autoplay playsinline muted style="width:100%;max-height:70vh;object-fit:cover;border-radius:var(--radius-lg)"></video>
    <video id="cam-front" autoplay playsinline muted style="position:absolute;top:20px;right:20px;width:120px;height:160px;object-fit:cover;border-radius:var(--radius-md);border:3px solid white;z-index:2"></video>
    <div style="display:flex;gap:20px;margin-top:20px;z-index:2">
      <button class="btn btn-secondary" onclick="closeDualCamera()" style="background:rgba(255,255,255,0.15);color:white;border:none"><i class="fas fa-times"></i></button>
      <button id="cam-capture-btn" class="btn btn-primary" onclick="captureDualPhoto()" style="width:64px;height:64px;border-radius:50%;font-size:20px"><i class="fas fa-camera"></i></button>
      <button class="btn btn-secondary" onclick="switchCameras()" style="background:rgba(255,255,255,0.15);color:white;border:none"><i class="fas fa-arrows-rotate"></i></button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  try {
    const backStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
    const frontStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
    const backV = document.getElementById('cam-back');
    const frontV = document.getElementById('cam-front');
    if (backV) backV.srcObject = backStream;
    if (frontV) frontV.srcObject = frontStream;
    window._dualCamStreams = [backStream, frontStream];
  } catch(e) { toast(S.lang==='ja'?'カメラを許可してください':'Camera access needed','error'); ov.remove(); }
}

function closeDualCamera() {
  if (window._dualCamStreams) { window._dualCamStreams.forEach(s => s.getTracks().forEach(t => t.stop())); window._dualCamStreams = null; }
  document.querySelector('.modal-overlay')?.remove();
}

function captureDualPhoto() {
  const backV = document.getElementById('cam-back');
  const frontV = document.getElementById('cam-front');
  if (!backV || !frontV) return;
  const canvas = document.createElement('canvas');
  canvas.width = backV.videoWidth || 640;
  canvas.height = backV.videoHeight || 480;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(backV, 0, 0, canvas.width, canvas.height);
  // Draw front camera as inset
  const fw = canvas.width * 0.25;
  const fh = fw * (frontV.videoHeight / frontV.videoWidth || 1.33);
  const fx = canvas.width - fw - 16;
  const fy = 16;
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(fx, fy, fw, fh, 12);
  ctx.clip();
  ctx.drawImage(frontV, fx, fy, fw, fh);
  ctx.restore();
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(fx, fy, fw, fh, 12);
  ctx.stroke();
  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
  closeDualCamera();
  composeImgData = dataUrl;
  const p = document.getElementById('compose-preview');
  if (p) { p.style.display = 'block'; p.innerHTML = `<div style="position:relative;display:inline-block"><img src="${dataUrl}" style="max-height:160px;border-radius:var(--radius-md);border:1px solid var(--border)"><button onclick="removeComposeImage()" style="position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;background:rgba(0,0,0,0.5);color:white;display:flex;align-items:center;justify-content:center;font-size:10px"><i class="fas fa-times"></i></button></div>`; }
  onComposeInput();
  toast(S.lang==='ja'?'撮影しました！':'Photo captured!');
}

// ===== REPORT POST/USER =====
function showReportModal(targetType, targetId) {
  if (!S.user) return navigate('/login');
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-flag" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'通報':'Report'}</h3>
    <p style="font-size:14px;color:var(--text-tertiary);margin-bottom:14px">${S.lang==='ja'?'通報理由を入力してください（必須）':'Please enter a reason (required)'}</p>
    <textarea id="report-reason" class="input" style="min-height:80px" placeholder="${S.lang==='ja'?'理由を入力...':'Enter reason...'}" maxlength="500"></textarea>
    <div style="display:flex;gap:12px;margin-top:16px">
      <button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'キャンセル':'Cancel'}</button>
      <button class="btn btn-danger" style="flex:1" onclick="submitReport('${targetType}','${targetId}')"><i class="fas fa-flag"></i> ${S.lang==='ja'?'通報する':'Report'}</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}
async function submitReport(targetType, targetId) {
  const reason = document.getElementById('report-reason')?.value.trim();
  if (!reason || reason.length < 3) return toast(S.lang==='ja'?'理由を入力してください':'Reason required','error');
  const res = await api('/api/reports', { method: 'POST', body: { target_type: targetType, target_id: targetId, reason } });
  if (res.success) { document.querySelector('.modal-overlay')?.remove(); toast(S.lang==='ja'?'通報しました':'Reported'); }
  else toast(res.error || 'Error', 'error');
}

// ===== ACCOUNT DELETION =====
function showDeleteAccountModal() {
  confirmDialog(S.lang==='ja'?'本当にアカウントを削除しますか？この操作は取り消せません。':'Are you sure you want to delete your account? This cannot be undone.', async () => {
    const res = await api('/api/account/delete', { method: 'POST' });
    if (res.success) { S.user = null; toast(S.lang==='ja'?'アカウントが削除されました':'Account deleted'); navigate('/login', true); }
    else toast(res.error || 'Error', 'error');
  });
}

// ===== MEDIA SESSION API =====
function updateMediaSession(roomName) {
  if (!('mediaSession' in navigator)) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: roomName || 'Voice Room',
    artist: 'さとっち',
    album: 'Voice Chat',
  });
  navigator.mediaSession.setActionHandler('pause', () => { if (S.voiceRoomId) toggleVoiceMute(); });
  navigator.mediaSession.setActionHandler('stop', () => { if (S.voiceRoomId) leaveVoiceRoom(S.voiceRoomId); });
}

// ===== PWA NOTIFICATION PROMPT =====
const CURRENT_APP_VERSION = 'v13';
function showNotificationPrompt() {
  if (!('Notification' in window) || Notification.permission !== 'default') return;
  const stored = localStorage.getItem('notif-prompt-dismissed');
  if (stored) return;
  setTimeout(() => {
    try {
      const banner = h('div', '');
      banner.id = 'notif-prompt-banner';
      banner.style.cssText = 'position:fixed;bottom:90px;left:16px;right:16px;z-index:80;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-lg);padding:16px;box-shadow:var(--shadow-lg);animation:slide-up-spring 0.4s var(--ease-physics) both';
      banner.innerHTML = `<div style="display:flex;align-items:center;gap:12px"><i class="fas fa-bell" style="font-size:24px;color:var(--accent)"></i><div style="flex:1"><div style="font-weight:600;font-size:14px">${S.lang==='ja'?'通知を受け取る':'Enable Notifications'}</div><div style="font-size:12px;color:var(--text-tertiary)">${S.lang==='ja'?'いいね、リプライ、DMの通知':'Get notified for likes, replies, DMs'}</div></div><button class="btn btn-primary btn-xs" onclick="requestNotifPermission()">${S.lang==='ja'?'許可':'Allow'}</button><button class="btn-icon" onclick="dismissNotifPrompt()" style="flex-shrink:0"><i class="fas fa-times"></i></button></div>`;
      document.body.appendChild(banner);
    } catch(e) { console.warn('Notif prompt error:', e); }
  }, 3000);
}
function requestNotifPermission() {
  try {
    const banner = document.getElementById('notif-prompt-banner');
    if (banner) { banner.style.transition = 'opacity 0.3s, transform 0.3s'; banner.style.opacity = '0'; banner.style.transform = 'translateY(20px)'; setTimeout(() => banner.remove(), 300); }
  } catch(e) {}
  try {
    if (typeof Notification !== 'undefined' && Notification.requestPermission) {
      const result = Notification.requestPermission();
      if (result && typeof result.then === 'function') {
        result.then(function(perm) { console.log('[Notif] Permission:', perm); }).catch(function(err) { console.warn('[Notif] Error:', err); });
      }
    }
  } catch(e) { console.warn('[Notif] requestPermission error:', e); }
}
function dismissNotifPrompt() {
  localStorage.setItem('notif-prompt-dismissed', '1');
  try {
    const banner = document.getElementById('notif-prompt-banner');
    if (banner) { banner.style.transition = 'opacity 0.3s, transform 0.3s'; banner.style.opacity = '0'; banner.style.transform = 'translateY(20px)'; setTimeout(() => banner.remove(), 300); }
  } catch(e) {}
}

// ===== AGE VERIFICATION =====
function checkAgeVerification() {
  if (!S.user) return;
  // Check if age not verified, or app updated
  const needsVerify = !S.user.age_verified || (S.user.app_version !== CURRENT_APP_VERSION && !localStorage.getItem('age-verified-' + CURRENT_APP_VERSION));
  if (needsVerify) showAgeVerificationModal();
}
function showAgeVerificationModal() {
  const ov = h('div', 'modal-overlay');
  ov.style.zIndex = '9999';
  ov.innerHTML = `<div class="modal-content" style="padding:32px;max-width:400px;text-align:center" onclick="event.stopPropagation()">
    <div style="font-size:48px;margin-bottom:16px">🔞</div>
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700;margin-bottom:12px">${S.lang==='ja'?'年齢確認':'Age Verification'}</h3>
    <p style="font-size:14px;color:var(--text-tertiary);margin-bottom:8px;line-height:1.6">${S.lang==='ja'?'ユーザーに適切なコンテンツを表示するための質問です。':'This question helps us show you appropriate content.'}</p>
    <p style="font-size:16px;font-weight:600;margin-bottom:24px;color:var(--text-primary)">${S.lang==='ja'?'あなたは18歳以上ですか？':'Are you 18 years or older?'}</p>
    <div style="display:flex;flex-direction:column;gap:12px">
      <button class="btn btn-primary" style="width:100%;padding:14px;font-size:16px" onclick="submitAgeVerification(true)">
        ${S.lang==='ja'?'うん！':'Yes!'}
      </button>
      <button class="btn btn-secondary" style="width:100%;padding:14px;font-size:16px" onclick="submitAgeVerification(false)">
        ${S.lang==='ja'?'まだ未成年だよ！':'I\'m still a minor!'}
      </button>
    </div>
  </div>`;
  document.body.appendChild(ov);
}
async function submitAgeVerification(isAdult) {
  const res = await api('/api/age-verify', { method: 'POST', body: { is_adult: isAdult } });
  if (res.success) {
    S.user.age_verified = 1;
    S.user.is_adult = isAdult ? 1 : 0;
    localStorage.setItem('age-verified-' + CURRENT_APP_VERSION, '1');
    // Update app version
    api('/api/app-version', { method: 'POST', body: { version: CURRENT_APP_VERSION } });
    S.user.app_version = CURRENT_APP_VERSION;
    document.querySelector('.modal-overlay')?.remove();
    if (isAdult) {
      // Ask if they want to see R18 content
      showR18PreferenceModal();
    } else {
      toast(S.lang==='ja'?'設定しました！':'Settings saved!');
    }
  }
}
function showR18PreferenceModal() {
  const ov = h('div', 'modal-overlay');
  ov.style.zIndex = '9999';
  ov.innerHTML = `<div class="modal-content" style="padding:32px;max-width:400px;text-align:center" onclick="event.stopPropagation()">
    <div style="font-size:40px;margin-bottom:16px">🔞</div>
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:12px">${S.lang==='ja'?'センシティブコンテンツ':'Sensitive Content'}</h3>
    <p style="font-size:14px;color:var(--text-tertiary);margin-bottom:24px;line-height:1.6">${S.lang==='ja'?'R18コンテンツ（性的なコンテンツ）を表示しますか？':'Do you want to see R18 (sexual) content?'}</p>
    <div style="display:flex;flex-direction:column;gap:12px">
      <button class="btn btn-primary" style="width:100%;padding:14px" onclick="setR18Preference(true)">${S.lang==='ja'?'表示する':'Show R18'}</button>
      <button class="btn btn-secondary" style="width:100%;padding:14px" onclick="setR18Preference(false)">${S.lang==='ja'?'表示しない':'Hide R18'}</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
}
async function setR18Preference(show) {
  await api('/api/r18-preference', { method: 'POST', body: { show_r18: show } });
  S.user.show_r18 = show ? 1 : 0;
  document.querySelector('.modal-overlay')?.remove();
  toast(S.lang==='ja'?'設定しました！':'Settings saved!');
}

// ===== WEBSOCKET =====
let wsMsgCounter = 0;
let wsRecentIds = new Set(); // Track recently received message client_ids to prevent duplicates
let typingTimeout = null;
let typingUsers = new Map(); // userId -> {name, timer}

function connectWS(channel) {
  disconnectWS();
  S.wsChannel = channel;
  
  // Try Ably first (much more reliable for realtime)
  if (S.ably && S.ablyConnected) {
    console.log('[Ably] Subscribing to channel:', channel);
    S.ablyChannel = ablySubscribe('satocchi:' + channel, (msg) => {
      try {
        const data = msg.data;
        if (data && data.senderId !== S.user?.id) {
          handleWSMessage(data);
        }
      } catch (e) { console.warn('[Ably] Message error:', e); }
    });
    updateWSStatus(true);
    // Also subscribe to typing
    ablySubscribe('satocchi:' + channel + ':typing', (msg) => {
      try {
        const data = msg.data;
        if (data && data.user_id !== S.user?.id) {
          handleWSMessage({ type: 'typing', ...data });
        }
      } catch {}
    });
  }
  
  // Also try native WebSocket as fallback
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${proto}//${location.host}/api/ws?channel=${encodeURIComponent(channel)}`;
  try {
    const ws = new WebSocket(url);
    S.ws = ws;
    S.wsReconnectDelay = 200;
    ws.onopen = () => {
      console.log('[WS] Connected:', channel);
      S.wsReconnectDelay = 200;
      updateWSStatus(true);
    };
    ws.onmessage = (e) => {
      try { handleWSMessage(JSON.parse(e.data)); } catch {}
    };
    ws.onclose = (ev) => {
      S.ws = null;
      if (!S.ablyConnected) updateWSStatus(false);
      if (S.wsChannel === channel) {
        S.wsReconnectTimer = setTimeout(() => {
          if (S.wsChannel === channel) {
            // Only reconnect WS if Ably isn't available
            if (!S.ablyConnected) connectWS(channel);
          }
        }, S.wsReconnectDelay);
        S.wsReconnectDelay = Math.min(S.wsReconnectDelay * 1.3, 3000);
      }
    };
    ws.onerror = () => {};
    const pingInterval = setInterval(() => {
      if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'ping' }));
      else clearInterval(pingInterval);
    }, 20000);
  } catch { /* fallback to polling */ }
}

function disconnectWS() {
  const prevChannel = S.wsChannel;
  S.wsChannel = null;
  if (S.wsReconnectTimer) { clearTimeout(S.wsReconnectTimer); S.wsReconnectTimer = null; }
  if (S.ws) { try { S.ws.close(); } catch {} S.ws = null; }
  // Clean up Ably channel
  if (prevChannel && S.ably) {
    try { ablyUnsubscribe('satocchi:' + prevChannel); } catch {}
    try { ablyUnsubscribe('satocchi:' + prevChannel + ':typing'); } catch {}
  }
  S.ablyChannel = null;
  typingUsers.clear();
  wsRecentIds.clear();
}

function sendWS(data) {
  if (data.type === 'chat' && !data.client_id) {
    data.client_id = 'c_' + S.user.id.slice(0,6) + '_' + (++wsMsgCounter) + '_' + Date.now();
  }
  
  // Publish via Ably for instant delivery to all clients
  if (S.ably && S.ablyConnected && S.wsChannel) {
    const channel = S.wsChannel;
    if (data.type === 'chat') {
      const msgId = 'a_' + Date.now() + '_' + Math.random().toString(36).substring(7);
      ablyPublish('satocchi:' + channel, 'chat', {
        type: 'chat',
        senderId: S.user.id,
        message: {
          id: msgId, sender_id: S.user.id, content: data.content,
          created_at: new Date().toISOString(),
          sender_username: S.user.username,
          sender_display_name: S.user.display_name,
          sender_avatar_url: S.user.avatar_url,
          sender_is_official: S.user.is_official || 0,
          client_id: data.client_id
        }
      });
    } else if (data.type === 'typing') {
      ablyPublish('satocchi:' + channel + ':typing', 'typing', {
        user_id: S.user.id,
        username: S.user.username,
        display_name: S.user.display_name
      });
    }
  }
  
  // Also send via WS for DB persistence
  if (S.ws && S.ws.readyState === 1) {
    S.ws.send(JSON.stringify(data));
    if (data.client_id) wsRecentIds.add(data.client_id);
    return true;
  }
  
  // If WS not available, use API fallback for persistence
  if (S.ably && S.ablyConnected) {
    // Persist via API
    const channel = S.wsChannel;
    if (channel && data.type === 'chat') {
      const [type, id] = channel.split(':');
      if (type === 'dm') {
        api(`/api/conversations/${id}/messages`, { method: 'POST', body: { content: data.content } }).catch(() => {});
      } else if (type === 'crew') {
        api(`/api/channels/${id}/messages`, { method: 'POST', body: { content: data.content } }).catch(() => {});
      } else if (type === 'vr') {
        api(`/api/voice-rooms/${id}/messages`, { method: 'POST', body: { content: data.content } }).catch(() => {});
      }
    }
    return true; // Ably delivered it
  }
  
  return false;
}

function sendTypingIndicator() {
  if (typingTimeout) return;
  sendWS({ type: 'typing' });
  typingTimeout = setTimeout(() => { typingTimeout = null; }, 2000);
}

function updateWSStatus(connected) {
  // Could show a small indicator in the chat header
  const el = document.getElementById('ws-status');
  if (el) {
    el.style.background = connected ? 'var(--sage)' : 'var(--accent)';
    el.title = connected ? 'Connected' : 'Reconnecting...';
  }
}

function showTypingIndicator() {
  const el = document.getElementById('typing-indicator');
  if (!el) return;
  const names = [...typingUsers.values()].map(v => v.name).slice(0, 3);
  if (names.length === 0) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  el.innerHTML = `<span style="font-size:12px;color:var(--text-tertiary);font-style:italic">${names.join(', ')} ${S.lang==='ja'?'が入力中...':'typing...'}</span>`;
}

function handleWSMessage(data) {
  if (data.type === 'chat') {
    const m = data.message;
    if (!m) return;
    
    // Dedup: if we sent this message (via client_id), skip it
    if (m.client_id && wsRecentIds.has(m.client_id)) {
      wsRecentIds.delete(m.client_id);
      return; // This is our own message echoed back
    }
    // Also skip if sender is us (optimistic already shown)
    if (m.sender_id === S.user?.id) return;
    
    // Clear typing indicator for this user
    if (typingUsers.has(m.sender_id)) {
      clearTimeout(typingUsers.get(m.sender_id).timer);
      typingUsers.delete(m.sender_id);
      showTypingIndicator();
    }
    
    const page = S.currentPage;
    if (page === 'dmChat') {
      appendDMMessage(m);
    } else if (page === 'crewDetail') {
      appendCrewMessage(m);
    } else if (page === 'voiceRoom' && vrActivePanel === 'chat') {
      appendVRChatMessage(m);
    }
  } else if (data.type === 'typing') {
    if (data.user_id === S.user?.id) return;
    // Show typing indicator
    if (typingUsers.has(data.user_id)) clearTimeout(typingUsers.get(data.user_id).timer);
    const timer = setTimeout(() => { typingUsers.delete(data.user_id); showTypingIndicator(); }, 3000);
    typingUsers.set(data.user_id, { name: data.display_name || data.username, timer });
    showTypingIndicator();
  } else if (data.type === 'user_join' || data.type === 'user_leave') {
    const onlineEl = document.getElementById('ws-online-count');
    if (onlineEl && data.online !== undefined) onlineEl.textContent = data.online;
  } else if (data.type === 'stroke') {
    if (S.currentPage === 'voiceRoom' && vrActivePanel === 'whiteboard' && data.stroke?.user_id !== S.user?.id) {
      try { drawStroke(JSON.parse(data.stroke.stroke_data), data.stroke.color, data.stroke.width, data.stroke.tool); } catch {}
    }
  } else if (data.type === 'wb_clear') {
    if (wbCtx && wbCanvas) {
      const dpr = window.devicePixelRatio || 1;
      wbCtx.save(); wbCtx.setTransform(1,0,0,1,0,0);
      wbCtx.clearRect(0, 0, wbCanvas.width, wbCanvas.height);
      wbCtx.restore();
    }
  } else if (data.type === 'connected') {
    console.log('[WS] Confirmed connected, online:', data.online);
  }
}

// ===== TOAST =====
function toast(msg, type = 'success') {
  let c = document.getElementById('toast-container');
  if (!c) { c = h('div', 'toast-container'); c.id = 'toast-container'; document.body.appendChild(c); }
  const icons = { success: 'check', error: 'exclamation-triangle', info: 'info' };
  const el = h('div', `toast toast-${type}`, `<i class="fas fa-${icons[type]||icons.info}" style="font-size:13px"></i><span>${esc(msg)}</span>`);
  c.appendChild(el);
  requestAnimationFrame(() => el.classList.add('toast-visible'));
  setTimeout(() => { el.classList.add('leaving'); setTimeout(() => el.remove(), 300); }, 3000);
}

function confirmDialog(message, onConfirm) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="confirm-dialog" onclick="event.stopPropagation()">
    <p style="font-size:15px;color:var(--text-secondary);margin-bottom:24px;line-height:1.7">${esc(message)}</p>
    <div style="display:flex;gap:12px;justify-content:center">
      <button class="btn btn-secondary" style="min-width:100px" id="cd-cancel">${t('general.cancel')}</button>
      <button class="btn btn-danger" style="min-width:100px" id="cd-confirm">${t('general.delete')}</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const closeModal = () => { ov.style.opacity = '0'; ov.style.transition = 'opacity 0.2s ease'; setTimeout(() => ov.remove(), 200); };
  ov.addEventListener('click', e => { if (e.target === ov) closeModal(); });
  $('#cd-cancel', ov).onclick = closeModal;
  $('#cd-confirm', ov).onclick = () => { closeModal(); onConfirm(); };
}

// ===== THEME =====
const THEMES = ['light','gray','warm','ocean','forest','noir'];
function initTheme() {
  S.theme = localStorage.getItem('satocchi-theme') || (S.user?.theme) || 'light';
  if (!THEMES.includes(S.theme)) S.theme = 'light';
  applyTheme(S.theme);
}
function applyTheme(th) {
  S.theme = th;
  document.documentElement.setAttribute('data-theme', th);
  const mc = th === 'noir' ? '#0e0e12' : '#fafaf8';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', mc);
  localStorage.setItem('satocchi-theme', th);
}
function setTheme(th) { applyTheme(th); if (S.user) api('/api/profile', { method: 'PUT', body: { theme: th } }); }

// ===== ROUTER =====
function navigate(path, replace = false) {
  // Save scroll position with page+path key for accurate restoration
  const pageKey = S.currentPage + ':' + location.pathname;
  S.scrollPositions[pageKey] = window.scrollY;
  S.scrollPositions[S.currentPage] = window.scrollY;
  if (replace) history.replaceState({ scrollY: window.scrollY, page: S.currentPage }, '', path); else history.pushState({ scrollY: 0 }, '', path);
  route();
}

function route(isPopState = false) {
  const path = location.pathname;
  let page, params = {};
  if (path === '/' || path === '') page = 'home';
  else if (path === '/login') page = 'login';
  else if (path === '/register') page = 'register';
  else if (path === '/voice') page = 'voice';
  else if (path.startsWith('/voice/')) { page = 'voiceRoom'; params.id = path.split('/')[2]; }
  else if (path.startsWith('/profile/')) { page = 'profile'; params.username = path.split('/')[2]; }
  else if (path === '/dm') page = 'dm';
  else if (path.startsWith('/dm/')) { page = 'dmChat'; params.id = path.split('/')[2]; }
  else if (path.startsWith('/post/')) { page = 'postDetail'; params.id = path.split('/')[2]; }
  else if (path === '/crew') page = 'crew';
  else if (path.startsWith('/crew/')) { const parts = path.split('/'); page = 'crewDetail'; params.id = parts[2]; if (parts[3]) params.channelId = parts[3]; }
  else if (path === '/notifications') page = 'notifications';
  else if (path === '/settings') page = 'settings';
  else if (path === '/shop') page = 'shop';
  else if (path === '/help' || path.startsWith('/help/')) page = 'help';
  else if (path === '/terms') page = 'terms';
  else if (path === '/privacy') page = 'privacy';
  else if (path === '/admin' || path.startsWith('/admin/')) page = 'admin';
  else if (path === '/casino' || path.startsWith('/casino/')) { page = 'casino'; const gp = path.replace('/casino','').replace('/',''); if (gp) params.gameId = gp; }
  else if (path.startsWith('/hashtag/')) { page = 'hashtag'; params.tag = decodeURIComponent(path.split('/')[2]); }
  else if (path.startsWith('/search')) { page = 'search'; params.q = new URLSearchParams(location.search).get('q') || ''; }
  else if (path === '/line-callback') page = 'lineCallback';
  else if (path === '/404') page = '404';
  else page = '404';

  if (page !== S.currentPage || JSON.stringify(params) !== JSON.stringify(S.currentParams || {})) {
    cleanupPolling();
    // Show floating bubble if leaving voice room while still connected
    if (S.currentPage === 'voiceRoom' && S.voiceStream && page !== 'voiceRoom') {
      showVoiceBubble(S.currentParams.id, '');
    }
    // Don't disconnect WS for voice if we have an active stream (bubble mode)
    if (!(S.voiceStream && S.currentPage === 'voiceRoom' && page !== 'voiceRoom')) {
      disconnectWS();
    }
    // Save home DOM before navigating away (for instant back)
    if (S.currentPage === 'home' && page !== 'home') {
      const feed = document.getElementById('feed');
      if (feed && S.cache.posts.length > 0) {
        S._savedHomeHTML = document.getElementById('page')?.innerHTML || '';
        S._savedHomeScrollY = window.scrollY;
      }
    }
    S.currentPage = page;
    S.currentParams = params;
    renderShell();
    // Restore cached home page on popstate (back button)
    if (isPopState && page === 'home' && S._savedHomeHTML && S.cache.posts.length > 0) {
      const el = document.getElementById('page');
      if (el) {
        el.className = 'page-container';
        el.innerHTML = S._savedHomeHTML;
        S._savedHomeHTML = null;
        updateTabIndicator();
        setupInfiniteScroll();
        startNewPostsCheck();
        checkUnread();
        const ci = $('#compose-input');
        if (ci) { ci.addEventListener('input', onComposeInput); ci.addEventListener('keydown', e => { if ((e.metaKey||e.ctrlKey) && e.key==='Enter') submitPost(); }); }
        const savedY = S._savedHomeScrollY || S.scrollPositions['home'] || 0;
        // Aggressive scroll restore: triple-RAF + setTimeout fallback
        const doScroll = () => window.scrollTo(0, savedY);
        requestAnimationFrame(() => { requestAnimationFrame(() => { requestAnimationFrame(doScroll); }); });
        setTimeout(doScroll, 50);
        setTimeout(doScroll, 150);
      }
    } else {
      renderPage(page, params);
      // Reset scroll position on every page transition
      if (page !== 'home') {
        window.scrollTo(0, 0);
      } else {
        const savedY = S.scrollPositions['home'] || 0;
        requestAnimationFrame(() => window.scrollTo(0, savedY));
      }
    }
  }
}

function cleanupPolling() {
  if (S.dmPoll) { clearInterval(S.dmPoll); S.dmPoll = null; }
  if (S.crewPoll) { clearInterval(S.crewPoll); S.crewPoll = null; }
  if (S.voicePollId) { clearInterval(S.voicePollId); S.voicePollId = null; }
  if (S.crewVoicePoll) { clearInterval(S.crewVoicePoll); S.crewVoicePoll = null; }
  if (S.vrChatPoll) { clearInterval(S.vrChatPoll); S.vrChatPoll = null; }
  // Stop casino canvas animations when navigating away
  if (typeof csStopAnimation === 'function') try { csStopAnimation(); } catch {}
}

document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href]');
  if (a && a.href.startsWith(location.origin) && !a.hasAttribute('data-external') && !e.metaKey && !e.ctrlKey) { e.preventDefault(); navigate(a.getAttribute('href')); }
});
window.addEventListener('popstate', (e) => {
  // Save current page scroll position before navigating
  const pageKey = S.currentPage + ':' + location.pathname;
  S.scrollPositions[pageKey] = window.scrollY;
  S.scrollPositions[S.currentPage] = window.scrollY;
  route(true);
});

// ===== SPLASH SCREEN =====
function dismissSplash() {
  const splash = document.getElementById('splash');
  if (splash) { splash.style.opacity = '0'; splash.style.transition = 'opacity 0.4s ease'; setTimeout(() => splash.remove(), 500); }
}

// ===== TOP LOADING BAR =====
function showTopLoading() {
  let bar = document.getElementById('top-loading-bar');
  if (!bar) { bar = document.createElement('div'); bar.id = 'top-loading-bar'; bar.className = 'top-loading-bar'; document.body.appendChild(bar); }
  bar.classList.add('active');
}
function hideTopLoading() {
  const bar = document.getElementById('top-loading-bar');
  if (bar) bar.classList.remove('active');
}

// ===== SHELL =====
let shellRendered = false;
function renderShell() {
  if (shellRendered) { updateNav(); return; }
  shellRendered = true;
  const app = document.getElementById('app');
  // Check if server-rendered skeleton shell already exists
  const existingShell = app.querySelector('.app-shell');
  if (!existingShell) {
    app.innerHTML = `<div class="app-shell"><nav class="sidebar" id="sidebar"></nav><div class="main-content"><div class="page-container" id="page"></div></div></div><nav class="mobile-nav" id="mobile-nav"></nav>`;
  } else if (!document.getElementById('mobile-nav')) {
    app.insertAdjacentHTML('beforeend', '<nav class="mobile-nav" id="mobile-nav"></nav>');
  }
  updateNav(); checkUnread(); setInterval(() => { if (!document.hidden) checkUnread(); }, 30000);
  dismissSplash();
}

function updateNav() {
  const isDmChat = S.currentPage === 'dmChat';
  const isCrewDetail = S.currentPage === 'crewDetail';
  const items = [
    { id: 'home', icon: 'fa-house', label: t('nav.home'), href: '/' },
    { id: 'voice', icon: 'fa-headphones', label: t('nav.voice'), href: '/voice' },
    { id: 'crew', icon: 'fa-users', label: t('nav.crew'), href: '/crew' },
    { id: 'casino', icon: 'fa-dice', label: S.lang==='ja'?'カジノ':'Casino', href: '/casino' },
    { id: 'dm', icon: 'fa-paper-plane', label: 'DM', href: '/dm', badge: 'dm-badge' },
    { id: 'profile', icon: 'fa-circle-user', label: S.lang==='ja'?'自分':'Me', href: S.user ? `/profile/${S.user.username}` : '/login' },
  ];
  const mobileItems = [
    { id: 'home', icon: 'fa-house', label: t('nav.home'), href: '/' },
    { id: 'voice', icon: 'fa-headphones', label: t('nav.voice'), href: '/voice' },
    { id: 'casino', icon: 'fa-dice', label: S.lang==='ja'?'カジノ':'Casino', href: '/casino' },
    { id: 'crew', icon: 'fa-users', label: 'Crew', href: '/crew' },
    { id: 'dm', icon: 'fa-paper-plane', label: 'DM', href: '/dm', badge: 'dm-badge' },
    { id: 'profile', icon: 'fa-circle-user', label: S.lang==='ja'?'自分':'Me', href: S.user ? `/profile/${S.user.username}` : '/login' },
  ];
  const sb = document.getElementById('sidebar');
  if (sb) sb.innerHTML = `
    <a href="/" class="sidebar-logo">さ</a>
    <div style="display:flex;flex-direction:column;gap:4px;flex:1">
      ${items.map(i => `<a href="${i.href}" class="nav-icon ${getActiveNav() === i.id ? 'active' : ''}" title="${i.label}"><i class="fas ${i.icon}"></i>${i.badge ? `<span class="nav-badge" id="${i.badge}-d" style="display:none">0</span>` : ''}</a>`).join('')}
      ${S.user ? `<a href="/notifications" class="nav-icon ${getActiveNav() === 'notifications' ? 'active' : ''}" title="${t('notif.title')}"><i class="fas fa-bell"></i><span class="nav-badge" id="notif-badge-d" style="display:none">0</span></a>` : ''}
    </div>
    <div style="display:flex;flex-direction:column;gap:4px;align-items:center">
      ${S.user && (S.user.role === 'admin' || S.user.role === 'superadmin') ? `<a href="/admin" class="nav-icon ${getActiveNav() === 'admin' ? 'active' : ''}" title="Admin"><i class="fas fa-shield-halved"></i></a>` : ''}
      ${S.user ? `<a href="/settings" class="nav-icon ${getActiveNav() === 'settings' ? 'active' : ''}" title="${t('nav.settings')}"><i class="fas fa-gear"></i></a>` : ''}
      <a href="/help" class="nav-icon ${getActiveNav() === 'help' ? 'active' : ''}" title="Help"><i class="fas fa-circle-question"></i></a>
      ${S.user ? `<button class="nav-icon" onclick="logout()" title="${t('nav.logout')}"><i class="fas fa-right-from-bracket"></i></button>` : ''}
    </div>`;
  const mn = document.getElementById('mobile-nav');
  if (mn) {
    if (isDmChat || isCrewDetail || S.currentPage === 'login' || S.currentPage === 'register') { mn.style.display = 'none'; }
    else {
      mn.style.display = '';
      mn.innerHTML = mobileItems.map(i => `<a href="${i.href}" class="mob-nav-item ${getActiveNav() === i.id ? 'active' : ''}"><i class="fas ${i.icon}"></i><span>${i.label}</span>${i.badge ? `<span class="nav-badge" id="${i.badge}-m" style="display:none">0</span>` : ''}</a>`).join('');
    }
  }
}

function getActiveNav() {
  const p = location.pathname;
  if (p === '/') return 'home'; if (p.startsWith('/voice')) return 'voice'; if (p.startsWith('/crew')) return 'crew';
  if (p.startsWith('/casino')) return 'casino'; if (p.startsWith('/dm')) return 'dm'; if (p.startsWith('/profile')) return 'profile';
  if (p === '/notifications') return 'notifications'; if (p === '/settings') return 'settings'; if (p.startsWith('/help')) return 'help'; if (p.startsWith('/admin')) return 'admin'; return '';
}

async function checkUnread() {
  if (!S.user) return;
  try {
    const [dmR, notifR] = await Promise.all([api('/api/dm/unread'), api('/api/notifications/unread')]);
    const dc = dmR.count || 0;
    ['dm-badge-d', 'dm-badge-m'].forEach(id => { const el = document.getElementById(id); if (el) { el.style.display = dc > 0 ? 'flex' : 'none'; el.textContent = dc > 9 ? '9+' : dc; } });
    const nc = notifR.count || 0;
    const nb = document.getElementById('notif-badge-d'); if (nb) { nb.style.display = nc > 0 ? 'flex' : 'none'; nb.textContent = nc > 9 ? '9+' : nc; }
    // Mobile notification badge
    const nbm = document.getElementById('notif-badge-m'); if (nbm) { nbm.style.display = nc > 0 ? 'flex' : 'none'; nbm.textContent = nc > 9 ? '9+' : nc; }
    // Home page notification badge
    const hnb = document.getElementById('home-notif-badge'); if (hnb) { hnb.style.display = nc > 0 ? 'flex' : 'none'; hnb.textContent = nc > 9 ? '9+' : nc; }
  } catch (e) {}
}

// ===== SEEN POSTS TRACKING =====
function trackPostView(postId) {
  if (!S.user) return;
  S.seenPostIds.add(postId);
  if (!S.seenFlushTimer) {
    S.seenFlushTimer = setTimeout(flushSeenPosts, 3000);
  }
}
function flushSeenPosts() {
  S.seenFlushTimer = null;
  if (S.seenPostIds.size === 0) return;
  const ids = [...S.seenPostIds];
  S.seenPostIds.clear();
  api('/api/posts/view', { method: 'POST', body: { post_ids: ids } });
}

// ===== PAGES =====
function renderPage(page, params) {
  const el = document.getElementById('page'); if (!el) return;
  el.innerHTML = ''; el.className = 'page-container page-enter';
  showTopLoading();
  const hideOnDone = () => setTimeout(hideTopLoading, 100);
  switch (page) {
    case 'home': pageHome(el); hideOnDone(); break;
    case 'login': pageAuth(el, false); hideOnDone(); break;
    case 'register': pageAuth(el, true); hideOnDone(); break;
    case 'voice': pageVoice(el); hideOnDone(); break;
    case 'voiceRoom': pageVoiceRoom(el, params.id); hideOnDone(); break;
    case 'profile': pageProfile(el, params.username).then(hideOnDone).catch(hideOnDone); break;
    case 'dm': pageDM(el); hideOnDone(); break;
    case 'dmChat': pageDMChat(el, params.id); hideOnDone(); break;
    case 'postDetail': pagePostDetail(el, params.id).then(hideOnDone).catch(hideOnDone); break;
    case 'crew': pageCrew(el); hideOnDone(); break;
    case 'crewDetail': pageCrewDetail(el, params.id, params.channelId); hideOnDone(); break;
    case 'notifications': pageNotifications(el); hideOnDone(); break;
    case 'settings': pageSettings(el); hideOnDone(); break;
    case 'shop': pageShop(el); hideOnDone(); break;
    case 'help': pageHelp(el); hideOnDone(); break;
    case 'terms': pageLegal(el, 'terms').then(hideOnDone).catch(hideOnDone); break;
    case 'privacy': pageLegal(el, 'privacy').then(hideOnDone).catch(hideOnDone); break;
    case 'admin': pageAdmin(el); hideOnDone(); break;
    case 'casino': loadCasinoPage(el); hideOnDone(); break;
    case 'hashtag': pageHashtag(el, params.tag); hideOnDone(); break;
    case 'search': pageSearch(el, params.q).then(hideOnDone).catch(hideOnDone); break;
    case 'lineCallback': handleLineCallback(); hideOnDone(); break;
    case '404': page404(el); hideOnDone(); break;
    default: hideOnDone();
  }
}

// ===== 404 =====
let game404 = null;
function page404(el) {
  el.innerHTML = `<div style="min-height:100dvh;display:flex;align-items:center;justify-content:center;padding:32px;text-align:center"><div class="anim-fade-up" style="max-width:480px;width:100%">
    <div style="font-family:'Cormorant Garamond',serif;font-size:96px;font-weight:700;color:var(--accent);line-height:1;letter-spacing:-0.04em">404</div>
    <p style="font-size:18px;font-weight:500;margin-top:8px;color:var(--text-secondary)">${S.lang==='ja'?'ページが見つかりません':'Page not found'}</p>
    <div style="display:flex;gap:10px;justify-content:center;margin-top:28px"><a href="/" class="btn btn-primary"><i class="fas fa-house" style="margin-right:6px"></i>${t('nav.home')}</a><button class="btn btn-secondary" onclick="history.back()"><i class="fas fa-arrow-left" style="margin-right:6px"></i>${S.lang==='ja'?'戻る':'Back'}</button></div>
  </div></div>`;
}

// ===== SETTINGS =====
function pageSettings(el) {
  if (!S.user) return navigate('/login');
  const themeSwatches = [
    {id:'light',label:S.lang==='ja'?'ライト':'Light',bg:'#fafaf8',fg:'#1a1a2e'},
    {id:'gray',label:S.lang==='ja'?'グレー':'Gray',bg:'#e8e8e8',fg:'#2a2a2e'},
    {id:'warm',label:S.lang==='ja'?'ウォーム':'Warm',bg:'#faf5ef',fg:'#b85c38'},
    {id:'ocean',label:S.lang==='ja'?'オーシャン':'Ocean',bg:'#f5f8fa',fg:'#3a7ca5'},
    {id:'forest',label:S.lang==='ja'?'フォレスト':'Forest',bg:'#f5f8f5',fg:'#4a7c59'},
    {id:'noir',label:S.lang==='ja'?'ノワール':'Noir',bg:'#0e0e12',fg:'#d4715c'},
  ];
  el.innerHTML = `
    <div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px">
      <button class="btn-icon mobile-only" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
      <span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${t('settings.title')}</span>
    </div>

    <!-- Profile Section -->
    <div class="settings-section">
      <div style="display:flex;align-items:center;gap:14px;padding:8px 0">
        ${avatar(S.user.avatar_url, S.user.display_name, 48)}
        <div style="flex:1">
          <div style="font-weight:600;font-size:16px">${esc(S.user.display_name)}</div>
          <div style="font-size:13px;color:var(--text-tertiary)">@${esc(S.user.username)}</div>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="navigate('/profile/${S.user.username}')">${t('profile.edit')}</button>
      </div>
      ${S.user.coins !== undefined ? `<div style="margin-top:8px"><div class="coin-badge"><i class="fas fa-coins" style="font-size:11px"></i> ${S.user.coins} ${S.lang==='ja'?'コイン':'coins'}</div></div>` : ''}
    </div>

    <!-- Appearance Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-palette" style="margin-right:6px;color:var(--accent)"></i>${S.lang==='ja'?'外観':'APPEARANCE'}
      </h3>
      <div style="margin-bottom:16px">
        <div style="font-size:13px;font-weight:600;margin-bottom:10px">${S.lang==='ja'?'テーマ':'Theme'}</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">${themeSwatches.map(ts => `<div onclick="setTheme('${ts.id}');pageSettings(document.getElementById('page'))" style="cursor:pointer;text-align:center"><div class="theme-swatch ${S.theme===ts.id?'active':''}" style="background:${ts.bg};border:1px solid var(--border)"><div style="width:12px;height:12px;border-radius:50%;background:${ts.fg};margin:auto;position:relative;top:50%;transform:translateY(-50%)"></div></div><div style="font-size:11px;color:var(--text-tertiary);margin-top:4px">${ts.label}</div></div>`).join('')}</div>
      </div>
      <div class="settings-item" style="padding:0"><div><div class="settings-label"><i class="fas fa-globe" style="margin-right:6px;color:var(--sky)"></i>${S.lang === 'ja' ? '言語: 日本語' : 'Language: English'}</div></div><button class="btn btn-secondary btn-sm" onclick="toggleLang()">${S.lang==='ja'?'English':'日本語'}</button></div>
    </div>

    <!-- Nickname Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-pen" style="margin-right:6px;color:var(--sky)"></i>${S.lang==='ja'?'ニックネーム変更':'CHANGE DISPLAY NAME'}
      </h3>
      <div style="display:flex;flex-direction:column;gap:12px">
        <div style="font-size:13px;color:var(--text-tertiary)">${S.lang==='ja'?'現在':'Current'}: <strong>${esc(S.user.display_name)}</strong></div>
        <input type="text" id="set-nickname" class="input" placeholder="${S.lang==='ja'?'新しいニックネーム':'New display name'}" maxlength="30" value="${esc(S.user.display_name)}">
        <button class="btn btn-primary btn-sm" onclick="changeNickname()" style="align-self:flex-start">${S.lang==='ja'?'変更する':'Update'}</button>
      </div>
    </div>

    <!-- Notifications Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-bell" style="margin-right:6px;color:var(--sky)"></i>${S.lang==='ja'?'通知設定':'NOTIFICATIONS'}
      </h3>
      <div id="notif-settings-area"><div style="padding:20px;text-align:center"><div class="orbit-spinner" style="margin:0 auto"></div></div></div>
    </div>

    <!-- Privacy Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-lock" style="margin-right:6px;color:var(--violet)"></i>${S.lang==='ja'?'プライバシー':'PRIVACY'}
      </h3>
      <div class="settings-item" style="padding:8px 0;display:flex;align-items:center;justify-content:space-between">
        <div><div class="settings-label">${S.lang==='ja'?'非公開アカウント':'Private Account'}</div><div class="settings-desc">${S.lang==='ja'?'ONにするとフォロワー以外にはフィードに投稿が表示されません':'When enabled, only followers can see your posts in feeds'}</div></div>
        <label style="position:relative;display:inline-block;width:48px;height:26px;flex-shrink:0"><input type="checkbox" id="setting-is-private" ${S.user.is_private?'checked':''} onchange="updatePrivacySetting(this.checked)" style="opacity:0;width:0;height:0"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <!-- Age & R18 Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        🔞 ${S.lang==='ja'?'年齢・R18設定':'Age & R18 Settings'}
      </h3>
      <div class="settings-item" style="padding:8px 0;display:flex;align-items:center;justify-content:space-between">
        <div><div class="settings-label">${S.lang==='ja'?'18歳以上です':'I am 18 or older'}</div><div class="settings-desc">${S.lang==='ja'?'R18コンテンツの投稿・閲覧に必要':'Required to post/view R18 content'}</div></div>
        <label style="position:relative;display:inline-block;width:48px;height:26px;flex-shrink:0"><input type="checkbox" id="setting-is-adult" ${S.user.is_adult?'checked':''} onchange="updateR18Setting('is_adult',this.checked)" style="opacity:0;width:0;height:0"><span class="toggle-slider"></span></label>
      </div>
      <div class="settings-item" style="padding:8px 0;display:flex;align-items:center;justify-content:space-between">
        <div><div class="settings-label">${S.lang==='ja'?'R18コンテンツを表示':'Show R18 content'}</div><div class="settings-desc">${S.lang==='ja'?'OFFにするとR18投稿が非表示になります':'Hide R18 posts when off'}</div></div>
        <label style="position:relative;display:inline-block;width:48px;height:26px;flex-shrink:0"><input type="checkbox" id="setting-show-r18" ${S.user.show_r18?'checked':''} onchange="updateR18Setting('show_r18',this.checked)" style="opacity:0;width:0;height:0"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <!-- Share Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-share-nodes" style="margin-right:6px;color:var(--sage)"></i>${S.lang==='ja'?'シェア':'SHARE'}
      </h3>
      <div class="settings-item" style="padding:0"><div><div class="settings-label">${S.lang==='ja'?'プロフィールQR':'Profile QR'}</div><div class="settings-desc">${S.lang==='ja'?'QRコードであなたのプロフィールをシェア':'Share your profile via QR code'}</div></div><button class="btn btn-secondary btn-sm" onclick="showQRModal(location.origin+'/profile/${S.user.username}','${S.lang==='ja'?'プロフィール':'Profile'}')"><i class="fas fa-qrcode"></i></button></div>
    </div>

    <!-- Security Section -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-shield-halved" style="margin-right:6px;color:var(--sage)"></i>${S.lang==='ja'?'セキュリティ':'SECURITY'}
      </h3>
      <div id="pw-error" style="display:none;margin-bottom:12px;padding:10px 14px;border-radius:var(--radius-sm);background:rgba(200,85,61,0.04);border:1px solid rgba(200,85,61,0.08);color:var(--accent);font-size:13px"></div>
      <div style="display:flex;flex-direction:column;gap:12px">
        <input type="password" id="set-cur-pw" class="input" placeholder="${t('settings.current_password')}">
        <input type="password" id="set-new-pw" class="input" placeholder="${t('settings.new_password')}">
        <input type="password" id="set-confirm-pw" class="input" placeholder="${t('settings.confirm_password')}">
        <button class="btn btn-primary btn-sm" onclick="changePassword()" style="align-self:flex-start">${t('general.save')}</button>
      </div>
    </div>

    <!-- Block Management -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-ban" style="margin-right:6px;color:var(--accent)"></i>${S.lang==='ja'?'ブロック管理':'BLOCKED USERS'}
      </h3>
      <div id="blocked-users-area"><div style="padding:20px;text-align:center"><div class="orbit-spinner" style="margin:0 auto"></div></div></div>
    </div>

    <!-- Danger Zone -->
    <div class="settings-section">
      <h3 style="font-size:13px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
        <i class="fas fa-triangle-exclamation" style="margin-right:6px"></i>${S.lang==='ja'?'危険ゾーン':'DANGER ZONE'}
      </h3>
      <div class="settings-item" style="padding:0"><div><div class="settings-label" style="color:var(--accent)">${S.lang==='ja'?'アカウント削除':'Delete Account'}</div><div class="settings-desc">${S.lang==='ja'?'この操作は取り消せません':'This action cannot be undone'}</div></div><button class="btn btn-danger btn-sm" onclick="showDeleteAccountModal()"><i class="fas fa-trash"></i></button></div>
    </div>
    <div class="mobile-nav-spacer"></div>`;
  // Load notification settings asynchronously
  loadNotificationSettings();
  // Load blocked users asynchronously
  loadBlockedUsers();
}

async function updateR18Setting(field, value) {
  const res = await api('/api/profile', { method: 'PUT', body: { [field]: value ? 1 : 0 } });
  if (res.success) {
    S.user[field] = value ? 1 : 0;
    toast(S.lang==='ja'?'設定を更新しました':'Setting updated');
    // If turning off is_adult, also turn off show_r18
    if (field === 'is_adult' && !value) {
      S.user.show_r18 = 0;
      const showR18 = document.getElementById('setting-show-r18');
      if (showR18) showR18.checked = false;
    }
  } else { toast(res.error || 'Error', 'error'); }
}

async function loadNotificationSettings() {
  const area = document.getElementById('notif-settings-area'); if (!area) return;
  try {
    const res = await api('/api/notification-settings');
    const s = res.settings || {};
    const dmMutes = res.dm_mutes || [];
    const crewMutes = res.crew_mutes || [];
    const items = [
      { key: 'notif_follow', icon: 'fa-user-plus', label: S.lang==='ja'?'フォロー通知':'Follow', desc: S.lang==='ja'?'フォローされた時':'When someone follows you', color: 'var(--sky)' },
      { key: 'notif_like', icon: 'fa-heart', label: S.lang==='ja'?'いいね通知':'Likes', desc: S.lang==='ja'?'投稿にいいねされた時':'When someone likes your post', color: 'var(--accent)' },
      { key: 'notif_reply', icon: 'fa-reply', label: S.lang==='ja'?'リプライ通知':'Replies', desc: S.lang==='ja'?'投稿にリプライされた時':'When someone replies', color: 'var(--sage)' },
      { key: 'notif_quote', icon: 'fa-quote-right', label: S.lang==='ja'?'引用通知':'Quotes', desc: S.lang==='ja'?'投稿が引用された時':'When someone quotes your post', color: 'var(--violet)' },
      { key: 'notif_coin', icon: 'fa-coins', label: S.lang==='ja'?'コイン通知':'Coins', desc: S.lang==='ja'?'コインを受け取った時':'When you receive coins', color: 'var(--sand)' },
      { key: 'notif_koremite', icon: 'fa-bullhorn', label: S.lang==='ja'?'コレミテ通知':'Koremite', desc: S.lang==='ja'?'コレミテされた時':'Koremite notifications', color: 'var(--accent)' },
      { key: 'notif_dm_global', icon: 'fa-paper-plane', label: S.lang==='ja'?'DM通知':'DM', desc: S.lang==='ja'?'ダイレクトメッセージ':'Direct messages', color: 'var(--sky)' },
      { key: 'notif_crew_global', icon: 'fa-users', label: S.lang==='ja'?'Crew通知':'Crew', desc: S.lang==='ja'?'クルーメッセージ':'Crew messages', color: 'var(--sage)' },
    ];
    area.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:8px">
        ${items.map(item => `
          <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);transition:all 0.2s">
            <i class="fas ${item.icon}" style="font-size:16px;color:${item.color};width:24px;text-align:center;flex-shrink:0"></i>
            <div style="flex:1;min-width:0">
              <div style="font-weight:600;font-size:13px">${item.label}</div>
              <div style="font-size:11px;color:var(--text-tertiary)">${item.desc}</div>
            </div>
            <label class="toggle-switch" style="flex-shrink:0">
              <input type="checkbox" id="ns-${item.key}" ${s[item.key] !== 0 ? 'checked' : ''} onchange="updateNotifSetting('${item.key}',this.checked)">
              <span class="toggle-slider"></span>
            </label>
          </div>
        `).join('')}
      </div>
      ${dmMutes.length > 0 ? `
        <div style="margin-top:16px">
          <div style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">${S.lang==='ja'?'DMミュート中のユーザー':'Muted DM Users'}</div>
          <div style="display:flex;flex-direction:column;gap:4px">
            ${dmMutes.map(m => `<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm)">
              ${avatar(m.avatar_url, m.display_name, 28)}
              <span style="flex:1;font-size:13px;font-weight:500">${esc(m.display_name)} <span style="color:var(--text-tertiary)">@${esc(m.username)}</span></span>
              <button class="btn btn-secondary btn-xs" onclick="unmuteDMUser('${m.muted_user_id}')"><i class="fas fa-bell" style="margin-right:3px"></i>${S.lang==='ja'?'解除':'Unmute'}</button>
            </div>`).join('')}
          </div>
        </div>
      ` : ''}
      ${crewMutes.length > 0 ? `
        <div style="margin-top:16px">
          <div style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">${S.lang==='ja'?'通知ミュート中のCrew':'Muted Crews'}</div>
          <div style="display:flex;flex-direction:column;gap:4px">
            ${crewMutes.map(m => `<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm)">
              <i class="fas fa-users" style="color:var(--text-tertiary)"></i>
              <span style="flex:1;font-size:13px;font-weight:500">${esc(m.name)}</span>
              <button class="btn btn-secondary btn-xs" onclick="unmuteCrewNotif('${m.crew_id}')"><i class="fas fa-bell" style="margin-right:3px"></i>${S.lang==='ja'?'解除':'Unmute'}</button>
            </div>`).join('')}
          </div>
        </div>
      ` : ''}
      <div style="margin-top:14px;padding:12px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);font-size:12px;color:var(--text-secondary);line-height:1.5">
        <i class="fas fa-info-circle" style="color:var(--accent);margin-right:4px"></i>
        ${S.lang==='ja'?'DM・Crewの個別ミュートはチャット画面のメニューから設定できます。':'You can mute individual DMs/Crews from their chat menu.'}
      </div>
    `;
  } catch(e) {
    area.innerHTML = `<div style="color:var(--text-tertiary);padding:16px;font-size:13px">${S.lang==='ja'?'読み込みエラー':'Load error'}</div>`;
  }
}

async function updateNotifSetting(key, value) {
  // Get all current settings from UI
  const fields = ['notif_follow', 'notif_like', 'notif_reply', 'notif_quote', 'notif_coin', 'notif_koremite', 'notif_dm_global', 'notif_crew_global'];
  const body = {};
  for (const f of fields) {
    const el = document.getElementById('ns-' + f);
    body[f] = el ? el.checked : true;
  }
  body[key] = value;
  const res = await api('/api/notification-settings', { method: 'PUT', body });
  if (res.success) toast(S.lang==='ja'?'通知設定を更新':'Notification updated');
  else toast(res.error || 'Error', 'error');
}

async function unmuteDMUser(userId) {
  await api(`/api/notification-settings/dm-mute/${userId}`, { method: 'DELETE' });
  toast(S.lang==='ja'?'ミュート解除':'Unmuted');
  loadNotificationSettings();
}

async function unmuteCrewNotif(crewId) {
  await api(`/api/notification-settings/crew-mute/${crewId}`, { method: 'DELETE' });
  toast(S.lang==='ja'?'ミュート解除':'Unmuted');
  loadNotificationSettings();
}

async function changePassword() {
  const cur = $('#set-cur-pw')?.value, newP = $('#set-new-pw')?.value, conf = $('#set-confirm-pw')?.value;
  const err = $('#pw-error');
  if (!cur || !newP || !conf) { err.textContent = S.lang==='ja'?'すべて入力してください':'Fill all fields'; err.style.display = 'block'; return; }
  if (newP !== conf) { err.textContent = S.lang==='ja'?'パスワードが一致しません':'Passwords do not match'; err.style.display = 'block'; return; }
  if (newP.length < 6) { err.textContent = S.lang==='ja'?'6文字以上':'Min 6 chars'; err.style.display = 'block'; return; }
  err.style.display = 'none';
  const res = await api('/api/change-password', { method: 'POST', body: { current_password: cur, new_password: newP } });
  if (res.success) { toast(S.lang==='ja'?'パスワードを変更しました':'Password changed'); $('#set-cur-pw').value='';$('#set-new-pw').value='';$('#set-confirm-pw').value=''; }
  else { err.textContent = res.error === 'Current password is incorrect' ? (S.lang==='ja'?'現在のパスワードが違います':'Wrong password') : (res.error||'Error'); err.style.display = 'block'; }
}

// ===== NICKNAME CHANGE =====
async function changeNickname() {
  const input = $('#set-nickname');
  if (!input) return;
  const newName = input.value.trim();
  if (!newName) { toast(S.lang==='ja'?'ニックネームを入力してください':'Enter a display name', 'error'); return; }
  if (newName.length > 30) { toast(S.lang==='ja'?'30文字以内にしてください':'Max 30 characters', 'error'); return; }
  if (newName === S.user.display_name) { toast(S.lang==='ja'?'現在と同じです':'Same as current', 'error'); return; }
  const res = await api('/api/profile', { method: 'PUT', body: { display_name: newName } });
  if (res.success) {
    S.user.display_name = newName;
    toast(S.lang==='ja'?'ニックネームを変更しました':'Display name updated');
    // Refresh settings page to reflect change
    const el = document.getElementById('page');
    if (el) pageSettings(el);
  } else { toast(res.error || 'Error', 'error'); }
}

// ===== PRIVACY TOGGLE =====
async function updatePrivacySetting(value) {
  const res = await api('/api/profile', { method: 'PUT', body: { is_private: value ? 1 : 0 } });
  if (res.success) {
    S.user.is_private = value ? 1 : 0;
    toast(S.lang==='ja'?'プライバシー設定を更新しました':'Privacy setting updated');
  } else {
    toast(res.error || 'Error', 'error');
    const el = document.getElementById('setting-is-private');
    if (el) el.checked = !value;
  }
}

// ===== BLOCK MANAGEMENT =====
async function loadBlockedUsers() {
  const area = document.getElementById('blocked-users-area');
  if (!area) return;
  try {
    const res = await api('/api/blocks');
    const blocks = res.blocks || [];
    if (blocks.length === 0) {
      area.innerHTML = `<div style="padding:16px;text-align:center;color:var(--text-tertiary);font-size:13px"><i class="fas fa-check-circle" style="margin-right:4px;color:var(--sage)"></i>${S.lang==='ja'?'ブロックしているユーザーはいません':'No blocked users'}</div>`;
      return;
    }
    area.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:6px">
        ${blocks.map(b => `<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
          ${avatar(b.avatar_url, b.display_name, 32)}
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;font-size:13px">${esc(b.display_name)}</div>
            <div style="font-size:11px;color:var(--text-tertiary)">@${esc(b.username)}${b.is_ghost ? ` <span style="color:var(--violet)"><i class="fas fa-ghost" style="font-size:10px"></i> ${S.lang==='ja'?'ゴーストブロック':'Ghost'}</span>` : ''}</div>
          </div>
          <button class="btn btn-secondary btn-xs" onclick="unblockUser('${b.blocked_id}','${esc(b.display_name)}')"><i class="fas fa-unlock" style="margin-right:3px"></i>${S.lang==='ja'?'解除':'Unblock'}</button>
        </div>`).join('')}
      </div>
      <div style="margin-top:10px;font-size:11px;color:var(--text-tertiary)">
        <i class="fas fa-info-circle" style="margin-right:3px"></i>${S.lang==='ja'?'ブロックは各ユーザーのプロフィールページからも設定できます':'You can also block users from their profile page'}
      </div>
    `;
  } catch(e) {
    area.innerHTML = `<div style="color:var(--text-tertiary);padding:16px;font-size:13px">${S.lang==='ja'?'読み込みエラー':'Load error'}</div>`;
  }
}

async function unblockUser(userId, displayName) {
  if (!confirm(S.lang==='ja'?`${displayName}のブロックを解除しますか？`:`Unblock ${displayName}?`)) return;
  const res = await api(`/api/block/${userId}`, { method: 'DELETE' });
  if (res.success) {
    toast(S.lang==='ja'?'ブロックを解除しました':'User unblocked');
    loadBlockedUsers();
  } else { toast(res.error || 'Error', 'error'); }
}

// ===== HOME =====
function pageHome(el) {
  el.innerHTML = `
    <div class="page-header" style="padding:16px 24px 0">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <span style="font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:700;letter-spacing:-0.02em">さとっち</span>
        <div style="display:flex;gap:4px;align-items:center">
          ${(!window.matchMedia('(display-mode: standalone)').matches && /Mobi|Android|iPhone/i.test(navigator.userAgent)) ? `<button class="btn-icon" onclick="pwaInstall()" title="${S.lang==='ja'?'アプリを入れる':'Install App'}" style="color:var(--accent)"><i class="fas fa-download" style="font-size:15px"></i></button>` : ''}
          ${S.user ? `<a href="/notifications" class="btn-icon" style="position:relative" title="${t('notif.title')}"><i class="fas fa-bell" style="font-size:15px"></i><span class="nav-badge" id="home-notif-badge" style="display:none;top:2px;right:2px">0</span></a>` : ''}
          <button class="btn-icon" onclick="refreshFeed()" title="Refresh"><i class="fas fa-arrow-rotate-right" style="font-size:15px"></i></button>
        </div>
      </div>
      <div id="search-bar" style="margin-bottom:12px;position:relative">
        <div style="position:relative;display:flex;gap:6px;align-items:center">
          <div style="position:relative;flex:1">
            <i class="fas fa-search" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:13px;color:var(--text-tertiary);pointer-events:none"></i>
            <input type="text" id="home-search" class="input" style="padding:10px 14px 10px 38px;font-size:14px;border-radius:var(--radius-full);background:var(--bg-elevated);width:100%" placeholder="${S.lang==='ja'?'投稿やユーザーを検索...':'Search posts & users...'}" oninput="debounceSearch(this.value)" onkeydown="if(event.key==='Enter'){event.preventDefault();openSearchPage(this.value)}" onfocus="showSearchPanel()" autocomplete="off">
            <button id="search-clear" class="btn-icon" style="position:absolute;right:4px;top:50%;transform:translateY(-50%);width:28px;height:28px;display:none" onclick="clearSearch()"><i class="fas fa-times" style="font-size:12px"></i></button>
          </div>
          <button class="btn-icon" onclick="openQRScanner()" title="${S.lang==='ja'?'QR読み取り':'Scan QR'}" style="width:40px;height:40px;flex-shrink:0;border-radius:var(--radius-full);background:var(--bg-elevated)"><i class="fas fa-qrcode" style="font-size:15px;color:var(--accent)"></i></button>
        </div>
        <div id="search-results" class="search-results-panel" style="display:none"></div>
      </div>
      <div class="tab-bar" id="feed-tabs" style="position:relative">
        <div class="tab-item ${S.cache.feedTab==='global'?'active':''}" onclick="switchFeedTab('global')">${S.lang==='ja'?'おすすめ':'For You'}</div>
        <div class="tab-item ${S.cache.feedTab==='following'?'active':''}" onclick="switchFeedTab('following')">${t('feed.following')}</div>
        <div class="tab-item ${S.cache.feedTab==='latest'?'active':''}" onclick="switchFeedTab('latest')">${S.lang==='ja'?'新着':'Latest'}</div>
        <div class="tab-indicator" id="tab-indicator"></div>
      </div>
    </div>
    <div class="new-posts-banner" id="new-posts-banner"><button onclick="refreshFeed()"><i class="fas fa-arrow-up"></i> ${t('feed.new_posts')}</button></div>
    ${S.user ? renderComposer() : ''}
    <div id="feed"><div class="feed-skeleton" style="padding:0 24px">${Array(4).fill(0).map((_,i) => `<div class="post-skeleton anim-fade-up" style="animation-delay:${i*0.08}s;padding:20px 0;border-bottom:1px solid var(--border)"><div style="display:flex;gap:12px"><div class="sk-avatar feed-sk-shimmer"></div><div class="sk-body"><div class="sk-line feed-sk-shimmer" style="height:14px;width:${35+i*10}%;margin-bottom:10px"></div><div class="sk-line feed-sk-shimmer" style="height:12px;width:90%;margin-bottom:6px"></div><div class="sk-line feed-sk-shimmer" style="height:12px;width:${55+i*8}%;margin-bottom:14px"></div><div class="sk-actions"><div class="sk-btn feed-sk-shimmer"></div><div class="sk-btn feed-sk-shimmer"></div><div class="sk-btn feed-sk-shimmer"></div></div></div></div></div>`).join('')}</div>
    <div id="feed-loader" style="display:none;padding:32px;text-align:center"><div class="feed-loading"><div class="feed-loading-dot"></div><div class="feed-loading-dot"></div><div class="feed-loading-dot"></div></div></div>
    <div class="mobile-nav-spacer"></div>`;
  updateTabIndicator(); loadFeed(true).then(() => {
    // Ensure content is visible after first feed load (fix initial blank state)
    const feed = $('#feed'); if (feed && feed.children.length === 0 && S.cache.posts.length > 0) {
      S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false; loadFeed(true);
    }
  }); setupInfiniteScroll(); startNewPostsCheck();
  const ci = $('#compose-input', el);
  if (ci) { ci.addEventListener('input', onComposeInput); ci.addEventListener('keydown', e => { if ((e.metaKey||e.ctrlKey) && e.key==='Enter') submitPost(); }); }
  checkUnread();
}

function renderComposer() {
  return `<div style="padding:24px;border-bottom:1px solid var(--border)">
    <div style="display:flex;gap:14px">
      ${avatar(S.user.avatar_url, S.user.display_name, 42)}
      <div style="flex:1;min-width:0">
        <textarea id="compose-input" class="input" style="border:none;background:transparent;padding:0;min-height:52px;font-size:16px;line-height:1.6" placeholder="${t('post.placeholder')}" maxlength="500"></textarea>
        <div id="compose-preview" style="display:none;margin:10px 0"></div>
        <div id="compose-video-preview" style="display:none;margin:10px 0"></div>
        <div id="compose-colors" style="display:none;margin:10px 0;padding:10px 0;border-top:1px solid var(--border)">
          <div style="display:flex;gap:7px;flex-wrap:wrap">
            ${[{k:'',bg:'var(--text-primary)'},{k:'rose',bg:'#c8553d'},{k:'amber',bg:'#c2b280'},{k:'green',bg:'#6b8f71'},{k:'sky',bg:'#5b8fa8'},{k:'violet',bg:'#8b7eb8'},{k:'pink',bg:'#e6388e'},{k:'orange',bg:'#ff6b35'},{k:'tc-cyan',bg:'#06b6d4'},{k:'tc-lime',bg:'#84cc16'},{k:'tc-indigo',bg:'#6366f1'},{k:'tc-warm',bg:'#b45309'}].map(c => `<div class="color-dot ${c.k===''?'active':''}" data-color="${c.k}" style="background:${c.bg}" onclick="selectTextColor('${c.k}',this)"></div>`).join('')}
          </div>
        </div>
        <div id="compose-flags" style="display:none;margin:8px 0;padding:10px 0;border-top:1px solid var(--border)">
          <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
            ${S.user.is_adult ? `<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;color:var(--text-secondary)"><input type="checkbox" id="compose-r18" style="accent-color:var(--accent)"><span>🔞 R18</span></label>` : ''}
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;color:var(--text-secondary)"><input type="checkbox" id="compose-ai" style="accent-color:var(--sky)"><span>🤖 ${S.lang==='ja'?'AI生成':'AI Generated'}</span></label>
          </div>
        </div>
        <div id="compose-poll" style="display:none;margin:10px 0;padding:12px;border:1px solid var(--border);border-radius:var(--radius-md);background:var(--bg-secondary)">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
            <span style="font-size:13px;font-weight:600;color:var(--text-secondary)"><i class="fas fa-chart-bar" style="color:var(--sky);margin-right:6px"></i>${S.lang==='ja'?'投票を追加':'Add Poll'}</span>
            <span style="font-size:11px;color:var(--text-tertiary)" id="poll-option-count">${S.lang==='ja'?'最大4選択肢':'Max 4 options'}</span>
          </div>
          <div id="poll-options-list">
            <input type="text" class="input poll-opt-input" placeholder="${S.lang==='ja'?'選択肢 1':'Option 1'}" maxlength="50" style="margin-bottom:6px;font-size:14px;padding:10px 12px">
            <input type="text" class="input poll-opt-input" placeholder="${S.lang==='ja'?'選択肢 2':'Option 2'}" maxlength="50" style="margin-bottom:6px;font-size:14px;padding:10px 12px">
          </div>
          <div style="display:flex;gap:6px;margin-top:4px"><button class="btn btn-secondary btn-xs" onclick="addPollOption()" id="add-poll-opt-btn"><i class="fas fa-plus" style="margin-right:4px"></i>${S.lang==='ja'?'選択肢追加':'Add option'}</button><button class="btn btn-secondary btn-xs" onclick="toggleComposePoll()" style="color:var(--accent)"><i class="fas fa-times" style="margin-right:4px"></i>${S.lang==='ja'?'投票を削除':'Remove poll'}</button></div>
        </div>
        <div id="char-counter" style="display:none;font-size:12px;color:var(--text-tertiary);text-align:right;margin-bottom:4px"></div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding-top:12px;border-top:1px solid var(--border)">
          <div style="display:flex;gap:2px;align-items:center">
            <label class="btn-icon" style="cursor:pointer;width:36px;height:36px" title="${S.lang==='ja'?'写真/動画':'Photo/Video'}"><i class="fas fa-image" style="color:var(--accent);font-size:15px"></i><input type="file" accept="image/*,video/*" style="display:none" onchange="composeMedia(this)"></label>
            <button class="btn-icon" style="width:36px;height:36px" onclick="toggleColorPicker()"><i class="fas fa-palette" style="color:var(--sand);font-size:15px"></i></button>
            <button class="btn-icon" style="width:36px;height:36px" onclick="toggleComposePoll()" title="${S.lang==='ja'?'投票':'Poll'}"><i class="fas fa-chart-bar" style="color:var(--sky);font-size:14px"></i></button>
            <div class="compose-more-wrap" style="position:relative">
              <button class="btn-icon" style="width:36px;height:36px" onclick="toggleComposeMore(this)" title="${S.lang==='ja'?'その他':'More'}"><i class="fas fa-ellipsis" style="color:var(--text-tertiary);font-size:14px"></i></button>
              <div class="compose-more-menu">
                <button onclick="showDualCameraModal();closeComposeMore()"><i class="fas fa-camera-rotate"></i><span>${S.lang==='ja'?'デュアルカメラ':'Dual Camera'}</span></button>
                <button onclick="toggleComposeFlags();closeComposeMore()"><i class="fas fa-tags"></i><span>${S.lang==='ja'?'タグ設定':'Post tags'}</span></button>
                <button onclick="saveDraftFromComposer();closeComposeMore()"><i class="fas fa-floppy-disk"></i><span>${S.lang==='ja'?'下書き保存':'Save Draft'}</span></button>
                <button onclick="showDraftsModal();closeComposeMore()"><i class="fas fa-file-lines"></i><span>${S.lang==='ja'?'下書き一覧':'Drafts'}</span></button>
              </div>
            </div>
          </div>
          <button class="btn btn-primary btn-sm" id="post-btn" onclick="submitPost()" disabled style="flex-shrink:0">${t('post.submit')}</button>
        </div>
      </div>
    </div>
  </div>`;
}

let composeImgData = null, composeTextColor = '', composeVideoData = null;

// Compose more menu
function toggleComposeMore(btn) {
  const wrap = btn.closest('.compose-more-wrap');
  const menu = wrap.querySelector('.compose-more-menu');
  const isOpen = menu.classList.contains('open');
  if (!isOpen) {
    menu.classList.add('open');
    const close = (e) => { if (!wrap.contains(e.target)) { menu.classList.remove('open'); document.removeEventListener('click', close, true); } };
    setTimeout(() => document.addEventListener('click', close, true), 0);
  } else { menu.classList.remove('open'); }
}
function closeComposeMore() { document.querySelectorAll('.compose-more-menu.open').forEach(m => m.classList.remove('open')); }

// Unified media picker (image or video)
function composeMedia(input) {
  const f = input.files[0]; if (!f) return;
  if (f.type.startsWith('video/')) { composeVideo(input); }
  else { composeImage(input); }
}
function toggleComposeFlags() { const el = $('#compose-flags'); if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none'; }
function toggleComposePoll() { const el = $('#compose-poll'); if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none'; }
function addPollOption() {
  const list = $('#poll-options-list'); if (!list) return;
  const existing = list.querySelectorAll('.poll-opt-input');
  if (existing.length >= 4) { toast(S.lang==='ja'?'最大4つまで':'Max 4 options','error'); return; }
  const idx = existing.length + 1;
  const inp = document.createElement('input');
  inp.type = 'text'; inp.className = 'input poll-opt-input';
  inp.placeholder = `${S.lang==='ja'?'選択肢':'Option'} ${idx}`;
  inp.maxLength = 50; inp.style.cssText = 'margin-bottom:6px;font-size:14px;padding:10px 12px';
  list.appendChild(inp);
  if (existing.length + 1 >= 4) { const btn = $('#add-poll-opt-btn'); if (btn) btn.style.display = 'none'; }
}
function composeVideo(input) {
  const f = input.files[0]; if (!f) return;
  if (f.size > 20*1024*1024) { toast(S.lang==='ja'?'20MB以下':'Max 20MB','error'); return; }
  const r = new FileReader();
  r.onload = e => {
    composeVideoData = e.target.result;
    composeImgData = null; // Clear image if video selected
    const p = $('#compose-preview'); if (p) { p.style.display = 'none'; p.innerHTML = ''; }
    const vp = $('#compose-video-preview');
    if (vp) { vp.style.display = 'block'; vp.innerHTML = `<div style="position:relative;display:inline-block"><video src="${composeVideoData}" style="max-height:160px;border-radius:var(--radius-md);border:1px solid var(--border)" controls></video><button onclick="removeComposeVideo()" style="position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;background:rgba(0,0,0,0.5);color:white;display:flex;align-items:center;justify-content:center;font-size:10px"><i class="fas fa-times"></i></button></div>`; }
    onComposeInput();
  };
  r.readAsDataURL(f);
}
function removeComposeVideo() { composeVideoData = null; const vp = $('#compose-video-preview'); if (vp) { vp.style.display = 'none'; vp.innerHTML = ''; } }
function onComposeInput() {
  const input = $('#compose-input'), btn = $('#post-btn'), counter = $('#char-counter');
  if (!input) return;
  const len = input.value.length;
  // Validate: disallow only-whitespace content
  const hasContent = input.value.trim().replace(/\s/g, '').length > 0;
  if (btn) btn.disabled = !hasContent;
  if (counter) { counter.style.display = len > 100 ? 'block' : 'none'; counter.textContent = `${len}/500`; counter.style.color = len > 450 ? 'var(--accent)' : 'var(--text-tertiary)'; }
}
function composeImage(input) { const f = input.files[0]; if (!f) return; if (f.size > 5*1024*1024) { toast(S.lang==='ja'?'5MB以下':'Max 5MB','error'); return; } const r = new FileReader(); r.onload = e => { composeImgData = e.target.result; const p = $('#compose-preview'); if (p) { p.style.display = 'block'; p.innerHTML = `<div style="position:relative;display:inline-block"><img src="${composeImgData}" style="max-height:160px;border-radius:var(--radius-md);border:1px solid var(--border)"><button onclick="removeComposeImage()" style="position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;background:rgba(0,0,0,0.5);color:white;display:flex;align-items:center;justify-content:center;font-size:10px"><i class="fas fa-times"></i></button></div>`; } onComposeInput(); }; r.readAsDataURL(f); }
function removeComposeImage() { composeImgData = null; const p = $('#compose-preview'); if (p) { p.style.display = 'none'; p.innerHTML = ''; } }
function toggleColorPicker() { const el = $('#compose-colors'); if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none'; }
function selectTextColor(color, dot) { composeTextColor = color; $$('.color-dot').forEach(d => d.classList.remove('active')); dot.classList.add('active'); }

// Sanitize content: collapse 3+ consecutive newlines, strip blank-only lines
function sanitizeContent(text) {
  // Remove lines that are only whitespace
  let lines = text.split('\n');
  // Collapse runs of empty/whitespace-only lines to max 2
  let result = [], emptyCount = 0;
  for (const line of lines) {
    if (line.trim() === '') {
      emptyCount++;
      if (emptyCount <= 2) result.push('');
    } else {
      emptyCount = 0;
      result.push(line);
    }
  }
  // Trim leading/trailing empty lines
  while (result.length > 0 && result[0].trim() === '') result.shift();
  while (result.length > 0 && result[result.length-1].trim() === '') result.pop();
  return result.join('\n');
}

async function submitPost(replyTo) {
  const input = $(replyTo ? '#reply-input' : '#compose-input');
  let content = input?.value.trim(); if (!content) return;
  // Sanitize: collapse excessive newlines, disallow blank-only
  content = sanitizeContent(content);
  if (!content || !content.replace(/\s/g, '')) { toast(S.lang==='ja'?'内容を入力してください':'Content required', 'error'); return; }
  const textStyle = composeTextColor ? `tc-${composeTextColor}` : '';
  const isR18 = $('#compose-r18')?.checked || false;
  const isAI = $('#compose-ai')?.checked || false;
  // Collect poll options
  const pollOptInputs = document.querySelectorAll('#poll-options-list .poll-opt-input');
  const pollOpts = [];
  if ($('#compose-poll')?.style.display !== 'none') {
    pollOptInputs.forEach(inp => { const v = inp.value.trim(); if (v) pollOpts.push(v); });
  }
  const body = { content, image_url: composeImgData || '', reply_to_id: replyTo || '', text_style: textStyle, is_r18: isR18, is_ai_generated: isAI, video_url: composeVideoData || '' };
  if (pollOpts.length >= 2) body.poll_options = pollOpts;
  if (input) input.value = '';
  if (!replyTo) { removeComposeImage(); removeComposeVideo(); composeTextColor = ''; onComposeInput(); const pollEl = $('#compose-poll'); if (pollEl) { pollEl.style.display = 'none'; const pl = $('#poll-options-list'); if (pl) pl.innerHTML = `<input type="text" class="input poll-opt-input" placeholder="${S.lang==='ja'?'選択肢 1':'Option 1'}" maxlength="50" style="margin-bottom:6px;font-size:14px;padding:10px 12px"><input type="text" class="input poll-opt-input" placeholder="${S.lang==='ja'?'選択肢 2':'Option 2'}" maxlength="50" style="margin-bottom:6px;font-size:14px;padding:10px 12px">`; const addBtn = $('#add-poll-opt-btn'); if (addBtn) addBtn.style.display = ''; } }
  const res = await api('/api/posts', { method: 'POST', body });
  if (res.success && res.post) {
    // Ensure own post has full user decoration data (badge, rainbow name, official)
    if (S.user) {
      res.post.is_official = S.user.is_official || 0;
      res.post.name_color = S.user.name_color || '';
      res.post.badge = S.user.badge || '';
    }
    if (!replyTo) {
      const feed = $('#feed');
      if (feed) { const wrapper = h('div', ''); wrapper.innerHTML = renderPostHTML(res.post, 0); const postEl = wrapper.firstElementChild; postEl.style.animation = 'fade-down 0.3s ease-out'; const firstPost = feed.querySelector('.post'); if (firstPost) feed.insertBefore(postEl, firstPost); else feed.appendChild(postEl); S.cache.posts.unshift(res.post); S.cache.latestTs = res.post.created_at; }
    } else {
      const parentEl = document.getElementById('post-' + replyTo); if (parentEl) _pushSignal(replyTo, 'reply', 1, parentEl.dataset.authorId);
      const pg = $('#page'); if (pg) pagePostDetail(pg, replyTo);
    }
    toast(S.lang==='ja'?'投稿しました':'Posted');
  } else toast(res.error || 'Error', 'error');
}

// ===== Feed =====
// Search functionality
let searchTimer = null;
let searchActive = false;
function debounceSearch(q) {
  const clearBtn = $('#search-clear');
  if (clearBtn) clearBtn.style.display = q.length > 0 ? 'flex' : 'none';
  if (searchTimer) clearTimeout(searchTimer);
  if (!q.trim()) { hideSearchPanel(); return; }
  searchTimer = setTimeout(() => performSearch(q.trim()), 250);
}
function showSearchPanel() {
  const panel = $('#search-results');
  const input = $('#home-search');
  if (panel && input?.value.trim()) { panel.style.display = 'block'; searchActive = true; }
}
function hideSearchPanel() {
  const panel = $('#search-results');
  if (panel) { panel.style.display = 'none'; panel.innerHTML = ''; }
  searchActive = false;
}
function clearSearch() {
  const input = $('#home-search');
  if (input) input.value = '';
  hideSearchPanel();
  const clearBtn = $('#search-clear');
  if (clearBtn) clearBtn.style.display = 'none';
}
async function performSearch(q) {
  const panel = $('#search-results');
  if (!panel) return;
  panel.style.display = 'block';
  searchActive = true;
  panel.innerHTML = '<div style="padding:16px;text-align:center"><div class="spinner" style="margin:0 auto;width:18px;height:18px"></div></div>';
  const [usersRes, postsRes] = await Promise.all([
    api(`/api/search/users?q=${encodeURIComponent(q)}`),
    api(`/api/search/posts?q=${encodeURIComponent(q)}&limit=5`)
  ]);
  const users = usersRes.users || [];
  const posts = postsRes.posts || [];
  if (users.length === 0 && posts.length === 0) {
    panel.innerHTML = `<div style="padding:24px;text-align:center;color:var(--text-tertiary);font-size:13px">${S.lang==='ja'?'結果が見つかりません':'No results'}</div>`;
    return;
  }
  let html = '';
  if (users.length > 0) {
    html += `<div style="padding:8px 14px;font-size:10px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em">${S.lang==='ja'?'ユーザー':'USERS'}</div>`;
    html += users.slice(0, 5).map(u => `<a href="/profile/${esc(u.username)}" class="search-result-item" onclick="clearSearch()">
      ${avatar(u.avatar_url, u.display_name, 32)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(u.display_name)}</div>
        <div style="font-size:11px;color:var(--text-tertiary)">@${esc(u.username)}</div>
      </div>
    </a>`).join('');
  }
  if (posts.length > 0) {
    html += `<div style="padding:8px 14px;font-size:10px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;${users.length?'margin-top:4px;border-top:1px solid var(--border)':''}">${S.lang==='ja'?'投稿':'POSTS'}</div>`;
    html += posts.map(p => `<a href="/post/${p.id}" class="search-result-item" onclick="clearSearch()">
      ${avatar(p.avatar_url, p.display_name, 28)}
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px"><span style="font-weight:600;font-size:12px">${esc(p.display_name)}</span><span style="font-size:11px;color:var(--text-tertiary)">${timeAgo(p.created_at)}</span></div>
        <div style="font-size:12px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((p.content||'').substring(0,80))}</div>
      </div>
    </a>`).join('');
  }
  panel.innerHTML = html;
}
// Close search on click outside
document.addEventListener('click', (e) => { if (searchActive && !e.target.closest('#search-bar')) hideSearchPanel(); });

// Open dedicated search results page on Enter
function openSearchPage(q) {
  if (!q || !q.trim()) return;
  hideSearchPanel();
  navigate('/search?q=' + encodeURIComponent(q.trim()));
}

// ===== SEARCH RESULTS PAGE =====
async function pageSearch(el, q) {
  el.innerHTML = `
    <div class="page-header" style="padding:16px 24px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
        <button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
        <span style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700">${S.lang==='ja'?'検索結果':'Search Results'}</span>
      </div>
      <div style="position:relative">
        <i class="fas fa-search" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:13px;color:var(--text-tertiary);pointer-events:none"></i>
        <input type="text" id="search-page-input" class="input" style="padding:10px 14px 10px 38px;font-size:14px;border-radius:var(--radius-full);background:var(--bg-elevated)" value="${esc(q)}" placeholder="${S.lang==='ja'?'検索...':'Search...'}" onkeydown="if(event.key==='Enter'){event.preventDefault();navigate('/search?q='+encodeURIComponent(this.value))}" autocomplete="off">
      </div>
    </div>
    <div id="search-page-results"><div class="page-loader"><div class="orbit-spinner"></div></div></div>
    <div class="mobile-nav-spacer"></div>`;
  if (!q) return;
  const [usersRes, postsRes] = await Promise.all([
    api('/api/search/users?q=' + encodeURIComponent(q)),
    api('/api/search/posts?q=' + encodeURIComponent(q) + '&limit=30')
  ]);
  const users = usersRes.users || [];
  const posts = postsRes.posts || [];
  const container = $('#search-page-results');
  if (!container) return;
  let html = '';
  if (users.length > 0) {
    html += `<div style="padding:12px 24px;font-size:11px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid var(--border)">${S.lang==='ja'?'ユーザー':'USERS'} (${users.length})</div>`;
    html += `<div style="padding:8px 16px">${users.map(u => `<a href="/profile/${esc(u.username)}" style="display:flex;align-items:center;gap:12px;padding:10px 8px;border-radius:var(--radius-md);transition:background var(--t-fast)" onmouseenter="this.style.background='var(--bg-card)'" onmouseleave="this.style.background=''">
      ${avatar(u.avatar_url, u.display_name, 40)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:14px">${esc(u.display_name)}</div>
        <div style="font-size:12px;color:var(--text-tertiary)">@${esc(u.username)}</div>
      </div>
    </a>`).join('')}</div>`;
  }
  if (posts.length > 0) {
    html += `<div style="padding:12px 24px;font-size:11px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid var(--border);${users.length?'border-top:1px solid var(--border)':''}">${S.lang==='ja'?'投稿':'POSTS'} (${posts.length})</div>`;
    html += posts.map((p, i) => renderPostHTML(p, i)).join('');
  }
  if (users.length === 0 && posts.length === 0) {
    html = `<div style="padding:80px 24px;text-align:center;color:var(--text-tertiary)"><i class="fas fa-search" style="font-size:40px;margin-bottom:16px;opacity:0.3;display:block"></i><p style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:600;margin-bottom:8px">${S.lang==='ja'?'結果なし':'No Results'}</p><p style="font-size:14px">${S.lang==='ja'?'別のキーワードをお試しください':'Try a different keyword'}</p></div>`;
  }
  container.innerHTML = html;
}

let feedLoading = false;
function switchFeedTab(tab) {
  if (tab === S.cache.feedTab) return;
  S.cache.feedTab = tab;
  S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false; S.cache.latestTs = null; S.cache.vrPromos = []; S.cache._prefetchedData = null; S.cache._prefetching = false;
  $$('.tab-item').forEach((t2, i) => t2.classList.toggle('active', i === (['global','following','latest'].indexOf(tab))));
  updateTabIndicator(); loadFeed(true);
}
function updateTabIndicator() { requestAnimationFrame(() => { const ind = $('#tab-indicator'), active = $('.tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } }); }

async function loadFeed(fresh = false) {
  if (feedLoading || (!fresh && S.cache.feedDone)) return;
  feedLoading = true;
  const feed = $('#feed');
  if (!feed) { feedLoading = false; return; }
  if (fresh) { 
    // Clear skeleton only if we have no cached posts
    feed.innerHTML = '<div class="feed-loading"><div class="feed-loading-dot"></div><div class="feed-loading-dot"></div><div class="feed-loading-dot"></div></div>'; 
    S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false; S.cache._prefetchedData = null; 
  }

  // Show loading indicator
  const loader = $('#feed-loader');
  if (loader) { loader.style.display = 'block'; loader.classList.add('active'); }

  // Map UI tabs to API tabs: global=recommended(algo), latest=global(chrono), following=following
  const apiTab = S.cache.feedTab === 'global' ? 'recommended' : (S.cache.feedTab === 'latest' ? 'global' : S.cache.feedTab);

  let res;
  try {
    // Use splash-preloaded data for first load
    if (fresh && _splashFeedData && S.cache.feedTab === 'global') {
      try { res = await _splashFeedData; } catch { res = null; }
      _splashFeedData = null;
      if (!res || !res.posts) {
        const url = `/api/posts?tab=${apiTab}${S.cache.feedCursor ? '&cursor=' + encodeURIComponent(S.cache.feedCursor) : ''}`;
        res = await api(url);
      }
    }
    // Use prefetched data if available (seamless scroll)
    else if (!fresh && S.cache._prefetchedData) {
      res = S.cache._prefetchedData;
      S.cache._prefetchedData = null;
    } else {
      const url = `/api/posts?tab=${apiTab}${S.cache.feedCursor ? '&cursor=' + encodeURIComponent(S.cache.feedCursor) : ''}`;
      res = await api(url);
    }
  } catch(e) {
    res = { posts: [], error: true };
  }

  if (loader) { loader.style.display = 'none'; loader.classList.remove('active'); }
  feedLoading = false;
  
  if (!res || !res.posts) {
    // API error - show error state
    if (fresh && feed) {
      feed.innerHTML = `<div style="padding:60px 24px;text-align:center;color:var(--text-tertiary)"><i class="fas fa-wifi" style="font-size:32px;opacity:0.3;display:block;margin-bottom:12px"></i><p style="font-size:15px;margin-bottom:12px">${S.lang==='ja'?'読み込みに失敗しました':'Failed to load'}</p><button class="btn btn-secondary btn-sm" onclick="refreshFeed()">${S.lang==='ja'?'再試行':'Retry'}</button></div>`;
    }
    return;
  }
  
  if (fresh && S.cache.feedTab === 'global' && S.cache.vrPromos.length === 0) { try { const vrRes = await api('/api/voice-rooms'); S.cache.vrPromos = (vrRes.rooms || []).slice(0, 2); } catch (e) {} }
  if (res.posts.length === 0 && S.cache.posts.length === 0) { feed.innerHTML = `<div style="padding:80px 24px;text-align:center;color:var(--text-tertiary)"><p style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:600;margin-bottom:8px">${S.lang==='ja'?'まだ何もない':'Nothing here yet'}</p><p style="font-size:14px">${t('post.empty')}</p>${S.user ? '' : `<a href="/login" class="btn btn-primary btn-sm" style="margin-top:16px">${S.lang==='ja'?'ログインして始める':'Login to start'}</a>`}</div>`; return; }
  const startIdx = S.cache.posts.length; S.cache.posts.push(...res.posts); S.cache.feedCursor = res.next_cursor;
  if (!res.next_cursor) S.cache.feedDone = true;
  if (fresh && res.posts.length > 0) S.cache.latestTs = res.posts[0].created_at;
  const fragment = document.createDocumentFragment(); let promoIdx = 0;
  res.posts.forEach((p, i) => {
    if (fresh && (startIdx + i === 3 || startIdx + i === 8)) { const promo = S.cache.vrPromos[promoIdx++]; if (promo) { const promoEl = h('div', ''); promoEl.innerHTML = renderVRPromo(promo); fragment.appendChild(promoEl.firstElementChild); } }
    const wrapper = h('div', ''); wrapper.innerHTML = renderPostHTML(p, startIdx + i); const postEl = wrapper.firstElementChild; fragment.appendChild(postEl);
    setTimeout(() => { trackPostView(p.id); observePost(document.getElementById('post-' + p.id)); }, 100);
  });
  // Clear loading skeleton before appending content
  if (fresh) feed.innerHTML = '';
  feed.appendChild(fragment);
  // Record impressions for recommendation engine
  _recordImpressions(res.posts);

  // Start prefetching next page immediately after appending
  if (!S.cache.feedDone && S.cache.feedCursor) {
    _prefetchNextPage();
  }
}

function renderVRPromo(room) {
  return `<div class="vr-promo anim-fade-up" onclick="navigate('/voice/${room.id}')"><div style="display:flex;align-items:center;gap:12px"><div style="position:relative">${avatar(room.owner_avatar_url, room.owner_display_name, 40)}<div class="live-dot" style="position:absolute;bottom:-1px;right:-1px;width:7px;height:7px"></div></div><div style="flex:1;min-width:0"><div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap"><span style="font-size:12px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em">Live</span>${room.name ? `<span style="font-size:14px;font-weight:600">${esc(room.name)}</span>` : ''}${tagHTML(room.tag)}</div><div style="font-size:13px;color:var(--text-tertiary);margin-top:2px">${esc(room.owner_display_name)} · ${room.member_count}${t('voice.members')}</div></div><div class="voice-wave"><span></span><span></span><span></span></div></div></div>`;
}

function refreshFeed() {
  const banner = $('#new-posts-banner'); if (banner) banner.classList.remove('visible');
  S.newPostsAvailable = false; S.cache.vrPromos = []; S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false; S.cache._prefetchedData = null; S.cache._prefetching = false;
  S._savedHomeHTML = null; // Clear cached home so back-nav gets fresh data
  _apiCache.clear(); _splashFeedData = null;
  // Spin animation on refresh button
  const refreshBtn = document.querySelector('[onclick="refreshFeed()"]');
  if (refreshBtn) { refreshBtn.classList.add('refresh-spinning'); setTimeout(() => refreshBtn.classList.remove('refresh-spinning'), 600); }
  loadFeed(true); window.scrollTo({ top: 0, behavior: 'smooth' });
}

let newPostsCheckInterval = null;
function startNewPostsCheck() {
  if (newPostsCheckInterval) clearInterval(newPostsCheckInterval);
  newPostsCheckInterval = setInterval(async () => {
    if (S.currentPage !== 'home' || !S.cache.latestTs) return;
    try { const res = await api(`/api/posts?tab=recommended&limit=1`); if (res.posts?.length && res.posts[0].created_at > S.cache.latestTs && res.posts[0].user_id !== S.user?.id) { S.newPostsAvailable = true; const banner = $('#new-posts-banner'); if (banner) banner.classList.add('visible'); } } catch (e) {}
  }, 15000);
}

function setupInfiniteScroll() {
  let ticking = false;
  window.addEventListener('scroll', () => { if (ticking) return; ticking = true; requestAnimationFrame(() => { ticking = false; if (S.currentPage !== 'home') return;
    const distToBottom = document.documentElement.scrollHeight - (window.innerHeight + window.scrollY);
    // Start prefetching when 1800px from bottom
    if (distToBottom < 1800 && !S.cache._prefetchedData && !S.cache.feedDone) {
      _prefetchNextPage();
    }
    // Trigger actual load when 800px from bottom (prefetched data ready = instant)
    if (distToBottom < 800) loadFeed();
  }); }, { passive: true });
}

// ===== Post Rendering with 4-line collapse + Quote Embed =====
const MAX_LINES = 4;
function renderPostHTML(p, idx) {
  const isOwn = S.user && S.user.id === p.user_id;
  const liked = p.liked > 0;
  const d = Math.min(idx, 8) * 0.04;
  const textCls = p.text_style || '';
  
  // 4-line collapse: split by newline, check line count
  const rawContent = p.content || '';
  const lines = rawContent.split('\n');
  const needsCollapse = lines.length > MAX_LINES || rawContent.length > 200;
  let displayContent, fullContent;
  
  if (needsCollapse) {
    const firstLines = lines.slice(0, MAX_LINES).join('\n');
    displayContent = rawContent.length > 200 ? rawContent.substring(0, 200) : firstLines;
    if (!displayContent.endsWith('...') && displayContent !== rawContent) displayContent += '…';
    fullContent = rawContent;
  } else {
    displayContent = rawContent;
    fullContent = null;
  }
  
  const contentHTML = `<span class="${esc(textCls)}" id="post-text-${p.id}">${formatContent(displayContent)}</span>${needsCollapse ? `<span class="read-more-btn" onclick="toggleReadMore('${p.id}',this,event)" data-expanded="0"> ${S.lang==='ja'?'続きを見る':'Read more'}</span>` : ''}`;
  
  const nameStyle = p.name_color ? (p.name_color === 'rainbow' ? 'background:linear-gradient(90deg,#c8553d,#c2b280,#6b8f71,#5b8fa8,#8b7eb8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text' : `color:${p.name_color}`) : '';
  const officialBadge = p.is_official ? '<span class="official-badge" title="Official"><i class="fas fa-check-circle"></i></span>' : '';
  const userBadge = p.badge ? `<span class="user-badge">${{'star':'&#11088;','fire':'&#128293;','diamond':'&#128142;','crown':'&#128081;','heart':'&#10084;','lightning':'&#9889;'}[p.badge]||''}</span>` : '';
  const r18Badge = p.is_r18 ? '<span style="font-size:10px;padding:1px 6px;border-radius:var(--radius-full);background:rgba(200,85,61,0.12);color:var(--accent);font-weight:700;margin-left:4px">🔞 R18</span>' : '';
  const aiBadge = p.is_ai_generated ? '<span style="font-size:10px;padding:1px 6px;border-radius:var(--radius-full);background:rgba(91,143,168,0.12);color:var(--sky);font-weight:700;margin-left:4px">🤖 AI</span>' : '';
  
  // Video support
  let videoHTML = '';
  if (p.video_url) {
    videoHTML = `<div class="custom-video-wrap" style="margin-top:12px" onclick="event.stopPropagation()">
      <video src="${esc(p.video_url)}" class="custom-video" playsinline preload="metadata" onclick="toggleVideoPlay(this)"></video>
      <div class="video-play-btn" onclick="toggleVideoPlay(this.previousElementSibling)"><i class="fas fa-play"></i></div>
      <div class="video-controls">
        <button class="video-ctrl-btn" onclick="toggleVideoPlay(this.closest('.custom-video-wrap').querySelector('video'))"><i class="fas fa-play"></i></button>
        <span class="video-time">0:00</span>
        <div class="video-progress" onclick="seekVideo(event,this)"><div class="video-progress-fill"></div></div>
        <button class="video-ctrl-btn" onclick="toggleVideoMute(this.closest('.custom-video-wrap').querySelector('video'))"><i class="fas fa-volume-up"></i></button>
        <button class="video-ctrl-btn" onclick="toggleVideoFullscreen(this.closest('.custom-video-wrap'))"><i class="fas fa-expand"></i></button>
      </div>
    </div>`;
  }
  
  // Quote embed (コレミテ) - Twitter-style embedded quote
  let quoteHTML = '';
  if (p.quote_of_id && p.quoted_post) {
    const q = p.quoted_post;
    const qContent = (q.content || '').substring(0, 140);
    quoteHTML = `<a href="/post/${q.id}" class="quote-embed" onclick="event.stopPropagation()" style="display:block;text-decoration:none;margin-top:10px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        ${avatar(q.avatar_url, q.display_name, 20)}
        <span style="font-weight:600;font-size:13px">${esc(q.display_name)}</span>
        <span style="font-size:12px;color:var(--text-tertiary)">@${esc(q.username)}</span>
        <span style="font-size:11px;color:var(--text-tertiary);margin-left:auto">${timeAgo(q.created_at)}</span>
      </div>
      <div style="font-size:14px;line-height:1.6;color:var(--text-secondary);white-space:pre-wrap;word-break:break-word">${formatContent(qContent)}${qContent.length < (q.content||'').length ? '…' : ''}</div>
      ${q.image_url ? `<img src="${esc(q.image_url)}" style="margin-top:8px;max-height:120px;width:100%;object-fit:cover;border-radius:var(--radius-sm);border:1px solid var(--border)" loading="lazy">` : ''}
    </a>`;
  } else if (p.quote_of_id && !p.quoted_post) {
    // Quote exists but post wasn't loaded - show a placeholder
    quoteHTML = `<a href="/post/${p.quote_of_id}" class="quote-embed" onclick="event.stopPropagation()" style="display:block;text-decoration:none;margin-top:10px">
      <div style="display:flex;align-items:center;gap:6px;color:var(--text-tertiary);font-size:13px">
        <i class="fas fa-retweet" style="font-size:12px"></i>
        <span>${S.lang==='ja'?'引用元の投稿を見る':'View quoted post'}</span>
        <i class="fas fa-arrow-right" style="font-size:10px"></i>
      </div>
    </a>`;
  }
  
  const _hashtags = (rawContent.match(/#[^\s#]+/g)||[]).map(h=>h.slice(1).toLowerCase()).join(',');
  return `<div class="post anim-fade-up" style="animation-delay:${d}s;cursor:pointer" id="post-${p.id}" onclick="navigateToPost('${p.id}',event)" data-author-id="${p.user_id}" data-hashtags="${_hashtags}" data-content-len="${rawContent.length}" data-has-media="${p.image_url||p.video_url?'1':'0'}" data-full="${needsCollapse ? esc(fullContent) : ''}" data-short="${needsCollapse ? esc(displayContent) : ''}">
    <div style="display:flex;gap:14px">
      <a href="/profile/${esc(p.username)}" style="flex-shrink:0" onclick="event.stopPropagation()">${avatar(p.avatar_url, p.display_name, 42)}</a>
      <div style="flex:1;min-width:0">
        ${p.quote_of_id ? `<div style="display:flex;align-items:center;gap:5px;margin-bottom:6px;font-size:12px;color:var(--text-tertiary)"><i class="fas fa-retweet" style="font-size:11px"></i><span>${S.lang==='ja'?'コレミテ':'Quoted'}</span></div>` : ''}
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:4px;flex-wrap:wrap">
          <a href="/profile/${esc(p.username)}" style="font-weight:600;font-size:15px;${nameStyle}" class="hover-underline" onclick="event.stopPropagation()">${esc(p.display_name)}</a>
          ${officialBadge}${userBadge}${r18Badge}${aiBadge}
          <span style="font-size:13px;color:var(--text-tertiary)">@${esc(p.username)}</span>
          <span style="font-size:12px;color:var(--text-tertiary);margin-left:auto">${timeAgo(p.created_at)}</span>
        </div>
        <div style="font-size:15px;line-height:1.7;color:var(--text-secondary);white-space:pre-wrap;word-break:break-word" id="post-content-${p.id}">${contentHTML}</div>
        ${p.image_url ? `<img src="${esc(p.image_url)}" class="post-image" style="margin-top:12px" onclick="event.stopPropagation();viewImage('${esc(p.image_url)}')" loading="lazy">` : ''}
        ${videoHTML}
        ${quoteHTML}
        <div class="post-actions" onclick="event.stopPropagation()">
          <button class="post-action ${liked?'liked':''}" onclick="toggleLike('${p.id}',this)"><i class="${liked?'fas':'far'} fa-heart"></i><span>${p.like_count||''}</span></button>
          <a href="/post/${p.id}" class="post-action"><i class="far fa-comment"></i><span>${p.reply_count||''}</span></a>
          <button class="post-action" onclick="showKoremiteModal('${p.id}')"><i class="fas fa-retweet"></i></button>
          ${S.user ? `<button class="post-action" onclick="showPostTipModal('${p.id}','${p.user_id}')"><i class="fas fa-coins" style="color:var(--sand)"></i></button>` : ''}
          <div class="post-more-wrap" style="margin-left:auto;position:relative">
            <button class="post-action" onclick="togglePostMore(this)"><i class="fas fa-ellipsis"></i></button>
            <div class="post-more-menu">
              ${S.user ? `<button onclick="toggleBookmark('${p.id}',this)" data-bookmarked="0"><i class="far fa-bookmark"></i><span>${S.lang==='ja'?'ブックマーク':'Bookmark'}</span></button>` : ''}
              <button onclick="showQRModal(location.origin+'/post/${p.id}','${S.lang==='ja'?'投稿をシェア':'Share Post'}')"><i class="fas fa-qrcode"></i><span>${S.lang==='ja'?'QRシェア':'QR Share'}</span></button>
              ${!isOwn ? `<button onclick="ratePost('${p.id}',-1)"><i class="far fa-thumbs-down"></i><span>${S.lang==='ja'?'低評価':'Downvote'}</span></button>` : ''}
              <button onclick="showReportModal('post','${p.id}')"><i class="far fa-flag"></i><span>${S.lang==='ja'?'報告':'Report'}</span></button>
              ${isOwn ? `<button onclick="deletePost('${p.id}')" style="color:var(--accent)"><i class="fas fa-trash"></i><span>${S.lang==='ja'?'削除':'Delete'}</span></button>` : ''}
              ${S.user && isAdmin(S.user) ? `<button onclick="showAdminPostFlagsModal('${p.id}')"><i class="fas fa-shield-halved" style="color:var(--accent)"></i><span>Admin Flags</span></button>` : ''}
              ${S.user && isAdmin(S.user) && !isOwn ? `<button onclick="adminDeleteFeedPost('${p.id}')" style="color:var(--accent)"><i class="fas fa-trash-can"></i><span>${S.lang==='ja'?'この投稿を削除（管理者）':'Delete (Admin)'}</span></button>` : ''}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function toggleReadMore(postId, btn, ev) {
  if (ev) { ev.stopPropagation(); ev.preventDefault(); }
  const postEl = document.getElementById('post-' + postId);
  const textEl = document.getElementById('post-text-' + postId);
  if (!textEl || !btn || !postEl) return;
  const expanded = btn.dataset.expanded === '1';
  if (expanded) {
    textEl.innerHTML = formatContent(postEl.dataset.short);
    btn.textContent = ' ' + (S.lang==='ja'?'続きを見る':'Read more');
    btn.dataset.expanded = '0';
  } else {
    textEl.innerHTML = formatContent(postEl.dataset.full);
    btn.textContent = ' ' + (S.lang==='ja'?'閉じる':'Show less');
    btn.dataset.expanded = '1';
  }
}

// ===== Post More Menu =====
function togglePostMore(btn) {
  // Use bottom sheet on mobile for reliable display
  const wrap = btn.closest('.post-more-wrap');
  const menu = wrap.querySelector('.post-more-menu');
  if (!menu) return;
  // Clone menu items into bottom sheet
  const items = menu.innerHTML;
  const ov = h('div', 'bottom-sheet-overlay');
  ov.innerHTML = `<div class="bottom-sheet" onclick="event.stopPropagation()">
    <div class="bottom-sheet-handle"></div>
    <div class="bottom-sheet-items">${items}</div>
  </div>`;
  // Close on overlay click
  ov.addEventListener('click', e => { if (e.target === ov) closeBottomSheet(ov); });
  document.body.appendChild(ov);
  // Animate in
  requestAnimationFrame(() => {
    ov.classList.add('active');
    ov.querySelector('.bottom-sheet').classList.add('active');
  });
  // Attach close to each button inside
  ov.querySelectorAll('.bottom-sheet-items button').forEach(b => {
    const origClick = b.getAttribute('onclick');
    b.setAttribute('onclick', `closeBottomSheet(document.querySelector('.bottom-sheet-overlay'));${origClick||''}`);
  });
}
function closeBottomSheet(ov) {
  if (!ov) return;
  const sheet = ov.querySelector('.bottom-sheet');
  if (sheet) sheet.classList.remove('active');
  ov.classList.remove('active');
  setTimeout(() => ov.remove(), 250);
}

async function ratePost(id, rating) { if (!S.user) return navigate('/login'); await api(`/api/posts/${id}/rate`, { method: 'POST', body: { rating } }); toast(S.lang==='ja'?'評価しました':'Rated', 'info'); }

async function toggleLike(id, btn) { if (!S.user) return navigate('/login'); const icon = $('i', btn); const cnt = $('span', btn); const liked = icon.classList.contains('fas'); icon.className = liked ? 'far fa-heart' : 'fas fa-heart'; btn.classList.toggle('liked', !liked); const n = parseInt(cnt.textContent || '0') + (liked ? -1 : 1); cnt.textContent = n > 0 ? n : ''; if (!liked) { icon.style.animation = 'heart-burst 0.4s ease-out'; const el = document.getElementById('post-' + id); if (el) _pushSignal(id, 'like', 1, el.dataset.authorId); } setTimeout(() => icon.style.animation = '', 400); await api(`/api/posts/${id}/like`, { method: liked ? 'DELETE' : 'POST' }); }
async function deletePost(id) { confirmDialog(S.lang==='ja'?'この投稿を削除しますか？':'Delete this post?', async () => { const post = document.getElementById('post-' + id); if (post) { post.style.transition = 'all 0.3s ease'; post.style.opacity = '0'; setTimeout(() => post.remove(), 300); } toast(S.lang==='ja'?'削除しました':'Deleted'); await api(`/api/posts/${id}`, { method: 'DELETE' }); S.cache.posts = S.cache.posts.filter(p => p.id !== id); }); }
// ===== Custom Video Player =====
function toggleVideoPlay(video) {
  if (!video) return;
  const wrap = video.closest('.custom-video-wrap');
  const playBtn = wrap?.querySelector('.video-play-btn');
  const ctrlIcon = wrap?.querySelector('.video-controls .video-ctrl-btn:first-child i');
  if (video.paused) {
    video.play();
    if (playBtn) playBtn.style.opacity = '0';
    if (ctrlIcon) ctrlIcon.className = 'fas fa-pause';
  } else {
    video.pause();
    if (playBtn) playBtn.style.opacity = '1';
    if (ctrlIcon) ctrlIcon.className = 'fas fa-play';
  }
}
function toggleVideoMute(video) {
  if (!video) return;
  video.muted = !video.muted;
  const wrap = video.closest('.custom-video-wrap');
  const icon = wrap?.querySelector('.video-controls .video-ctrl-btn:nth-last-child(2) i');
  if (icon) icon.className = video.muted ? 'fas fa-volume-mute' : 'fas fa-volume-up';
}
function seekVideo(e, bar) {
  const video = bar.closest('.custom-video-wrap')?.querySelector('video');
  if (!video || !video.duration) return;
  const rect = bar.getBoundingClientRect();
  const pct = (e.clientX - rect.left) / rect.width;
  video.currentTime = pct * video.duration;
}
function toggleVideoFullscreen(wrap) {
  if (!wrap) return;
  if (document.fullscreenElement) document.exitFullscreen?.();
  else wrap.requestFullscreen?.();
}
// Auto-setup video events via MutationObserver
const videoObserver = new MutationObserver(muts => {
  muts.forEach(m => m.addedNodes.forEach(n => {
    if (n.nodeType !== 1) return;
    n.querySelectorAll?.('.custom-video-wrap video')?.forEach(setupVideoEvents);
  }));
});
videoObserver.observe(document.body, { childList: true, subtree: true });
function setupVideoEvents(video) {
  if (video._eventsSet) return;
  video._eventsSet = true;
  const wrap = video.closest('.custom-video-wrap');
  if (!wrap) return;
  const fill = wrap.querySelector('.video-progress-fill');
  const timeEl = wrap.querySelector('.video-time');
  const playBtn = wrap.querySelector('.video-play-btn');
  const ctrlIcon = wrap.querySelector('.video-controls .video-ctrl-btn:first-child i');
  video.addEventListener('timeupdate', () => {
    if (fill && video.duration) fill.style.width = (video.currentTime / video.duration * 100) + '%';
    if (timeEl) { const t = Math.floor(video.currentTime); timeEl.textContent = Math.floor(t/60) + ':' + String(t%60).padStart(2,'0'); }
  });
  video.addEventListener('ended', () => {
    if (playBtn) playBtn.style.opacity = '1';
    if (ctrlIcon) ctrlIcon.className = 'fas fa-play';
  });
  video.addEventListener('play', () => { if (playBtn) playBtn.style.opacity = '0'; if (ctrlIcon) ctrlIcon.className = 'fas fa-pause'; });
  video.addEventListener('pause', () => { if (playBtn) playBtn.style.opacity = '1'; if (ctrlIcon) ctrlIcon.className = 'fas fa-play'; });
}

function viewImage(src) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<img src="${src}" style="max-width:92vw;max-height:90vh;object-fit:contain;border-radius:var(--radius-md)" class="anim-scale-in">`;
  ov.onclick = () => {
    const img = ov.querySelector('img');
    if (img) {
      img.style.transition = 'transform 0.25s cubic-bezier(0.22,1,0.36,1), opacity 0.25s ease';
      img.style.transform = 'scale(0.85)';
      img.style.opacity = '0';
    }
    ov.style.transition = 'opacity 0.25s ease';
    ov.style.opacity = '0';
    setTimeout(() => ov.remove(), 260);
  };
  document.body.appendChild(ov);
}

function showKoremiteModal(postId) {
  if (!S.user) return navigate('/login');
  // Find the original post to show preview
  const origPost = (S.cache.posts || []).find(p => p.id === postId);
  let previewHTML = '';
  if (origPost) {
    const prevContent = (origPost.content || '').substring(0, 120);
    previewHTML = `<div class="quote-embed" style="margin-bottom:16px;pointer-events:none">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        ${avatar(origPost.avatar_url, origPost.display_name, 20)}
        <span style="font-weight:600;font-size:13px">${esc(origPost.display_name || '')}</span>
        <span style="font-size:12px;color:var(--text-tertiary)">@${esc(origPost.username || '')}</span>
      </div>
      <div style="font-size:13px;line-height:1.5;color:var(--text-secondary);white-space:pre-wrap;word-break:break-word">${formatContent(prevContent)}${prevContent.length < (origPost.content||'').length ? '…' : ''}</div>
      ${origPost.image_url ? `<img src="${esc(origPost.image_url)}" style="margin-top:6px;max-height:80px;width:100%;object-fit:cover;border-radius:var(--radius-sm)" loading="lazy">` : ''}
    </div>`;
  }
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-retweet" style="margin-right:8px;font-size:18px;color:var(--accent)"></i>${S.lang==='ja'?'コレミテ':'Quote'}</h3><textarea id="koremite-input" class="input" style="min-height:80px" placeholder="${S.lang==='ja'?'コメントを追加...':'Add a comment...'}" maxlength="500"></textarea>${previewHTML}<div style="display:flex;gap:12px;margin-top:16px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="submitKoremite('${postId}')">${S.lang==='ja'?'コレミテする':'Quote'}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov); $('#koremite-input')?.focus();
}
let koremiteSubmitting = false;
async function submitKoremite(quotedId) {
  if (koremiteSubmitting) return;
  koremiteSubmitting = true;
  const input = $('#koremite-input'); const content = input?.value.trim(); if (!content) { koremiteSubmitting = false; return; }
  // Disable button visually
  const btn = document.querySelector('.modal-overlay .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = S.lang==='ja'?'送信中...':'Sending...'; }
  try {
  // Find the quoted post to embed in the new post object
  const origPost = (S.cache.posts || []).find(p => p.id === quotedId);
  const res = await api('/api/posts', { method: 'POST', body: { content, image_url: '', reply_to_id: '', text_style: '', quote_of_id: quotedId } });
  if (res.success && res.post) {
    if (S.user) { res.post.is_official = S.user.is_official || 0; res.post.name_color = S.user.name_color || ''; res.post.badge = S.user.badge || ''; }
    // Attach quoted_post data so it renders immediately in the feed
    if (origPost) {
      res.post.quoted_post = { id: origPost.id, content: origPost.content, image_url: origPost.image_url, created_at: origPost.created_at, username: origPost.username, display_name: origPost.display_name, avatar_url: origPost.avatar_url };
    }
    S.cache.posts.unshift(res.post);
    $('.modal-overlay')?.remove();
    toast(S.lang==='ja'?'コレミテしました':'Quoted');
    // Refresh current page to show the new quote post
    if (S.currentPage === 'home') { const feed = $('#feed'); if (feed) { feed.insertAdjacentHTML('afterbegin', renderPostHTML(res.post, 0)); } }
  } else toast(res.error || 'Error', 'error');
  } finally { koremiteSubmitting = false; }
}

// ===== POST DETAIL with Thread Backtrack =====
async function pagePostDetail(el, id) {
  // Check if post is already in cache for instant display
  const cached = (S.cache.posts || []).find(p => p.id === id);
  if (cached) {
    renderPostDetailView(el, cached, null, [], [], null);
    // Load replies and full data in background
    loadPostDetailData(el, id);
  } else {
    el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button><span style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700">${S.lang==='ja'?'投稿':'Post'}</span></div><div class="page-loader"><div class="orbit-spinner"></div></div>`;
    loadPostDetailData(el, id);
  }
}

async function loadPostDetailData(el, id) {
  const [res, threadRes] = await Promise.all([api(`/api/posts/${id}`), api(`/api/posts/${id}/thread`)]);
  if (res.error) { el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button><span style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700">${S.lang==='ja'?'投稿':'Post'}</span></div><div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'投稿が見つかりません':'Post not found'}</div>`; return; }
  const p = res.post, replies = res.replies || [], poll = res.poll;
  const thread = (threadRes.thread || []).filter(t => t.id !== id);
  renderPostDetailView(el, p, res.quoted_post, replies, thread, poll);
  trackPostView(p.id);
}

function renderPostDetailView(el, p, quotedPost, replies, thread, poll) {
  const textCls = p.text_style || '';
  let pollHTML = '';
  if (poll) {
    const hasVoted = !!poll.my_vote;
    pollHTML = `<div style="margin-top:14px" class="poll-container">${poll.options.map(o => {
      const pct = poll.total_votes > 0 ? Math.round((o.vote_count / poll.total_votes) * 100) : 0;
      const voted = poll.my_vote === o.id;
      if (!hasVoted) {
        // Before voting: show clean options without results
        return `<div class="poll-option poll-option-unvoted" onclick="votePoll('${poll.id}','${o.id}')" style="cursor:pointer;padding:14px 16px;border:2px solid var(--border);border-radius:var(--radius-md);margin-bottom:8px;transition:all 0.25s cubic-bezier(0.22,1,0.36,1);position:relative;overflow:hidden;background:var(--bg-secondary)" onmouseenter="this.style.borderColor='var(--accent)';this.style.background='var(--accent-bg)'" onmouseleave="this.style.borderColor='var(--border)';this.style.background='var(--bg-secondary)'">
          <div style="position:relative;z-index:1;font-size:15px;font-weight:500">${esc(o.text)}</div>
        </div>`;
      } else {
        // After voting: show animated results
        return `<div class="poll-option ${voted?'voted':''}" style="padding:14px 16px;border:2px solid ${voted?'var(--accent)':'var(--border)'};border-radius:var(--radius-md);margin-bottom:8px;position:relative;overflow:hidden;background:var(--bg-secondary)">
          <div class="poll-bar" style="width:0%;background:${voted?'rgba(200,85,61,0.12)':'rgba(0,0,0,0.04)'};position:absolute;top:0;left:0;height:100%;border-radius:var(--radius-md);transition:width 0.8s cubic-bezier(0.22,1,0.36,1)" data-target-width="${pct}%"></div>
          <div style="position:relative;z-index:1;display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:15px;font-weight:${voted?'600':'500'}">${voted?'✓ ':''}${esc(o.text)}</span>
            <span style="font-weight:700;font-size:14px;color:${voted?'var(--accent)':'var(--text-secondary)'};min-width:40px;text-align:right">${pct}%</span>
          </div>
        </div>`;
      }
    }).join('')}<div style="font-size:12px;color:var(--text-tertiary);margin-top:6px;display:flex;align-items:center;gap:8px"><i class="fas fa-chart-bar" style="font-size:11px"></i>${poll.total_votes} ${S.lang==='ja'?'票':'votes'}${!hasVoted?` · ${S.lang==='ja'?'タップして投票':'Tap to vote'}`:''}</div></div>`;
    // Animate poll bars after render
    if (hasVoted) {
      setTimeout(() => {
        document.querySelectorAll('.poll-bar[data-target-width]').forEach(bar => {
          bar.style.width = bar.dataset.targetWidth;
        });
      }, 100);
    }
  }
  // Thread backtrack (parent posts)
  let threadHTML = '';
  if (thread.length > 0) {
    threadHTML = `<div style="padding:0 24px"><div style="font-size:11px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;padding:16px 0 8px"><i class="fas fa-arrow-up" style="margin-right:4px"></i>${S.lang==='ja'?'スレッド元':'Thread'}</div>` +
      thread.map(tp => `<a href="/post/${tp.id}" style="display:flex;gap:10px;padding:10px;margin-bottom:4px;border-radius:var(--radius-md);background:var(--bg-card);border:1px solid var(--border);border-left:3px solid var(--accent);transition:background var(--t-fast)">
        ${avatar(tp.avatar_url, tp.display_name, 28)}
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px"><span style="font-weight:600;font-size:12px">${esc(tp.display_name)}</span><span style="font-size:11px;color:var(--text-tertiary)">@${esc(tp.username)}</span></div>
          <div style="font-size:13px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((tp.content||'').substring(0,80))}</div>
        </div>
      </a>`).join('') + `</div>`;
  }
  const isOwn = S.user && S.user.id === p.user_id;
  const pinBtn = isOwn ? `<button class="post-action" onclick="togglePinPost('${p.id}')" title="${S.lang==='ja'?'ピン留め':'Pin'}"><i class="fas fa-thumbtack"></i></button>` : '';
  // Build quoted post HTML for detail view
  let detailQuoteHTML = '';
  const qp = quotedPost;
  if (qp) {
    const qContent = (qp.content || '').substring(0, 200);
    detailQuoteHTML = `<a href="/post/${qp.id}" class="quote-embed" onclick="event.stopPropagation()" style="display:block;text-decoration:none;margin:14px 0">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        ${avatar(qp.avatar_url, qp.display_name, 22)}
        <span style="font-weight:600;font-size:13px">${esc(qp.display_name)}</span>
        <span style="font-size:12px;color:var(--text-tertiary)">@${esc(qp.username)}</span>
        <span style="font-size:11px;color:var(--text-tertiary);margin-left:auto">${timeAgo(qp.created_at)}</span>
      </div>
      <div style="font-size:14px;line-height:1.6;color:var(--text-secondary);white-space:pre-wrap;word-break:break-word">${formatContent(qContent)}${qContent.length < (qp.content||'').length ? '…' : ''}</div>
      ${qp.image_url ? `<img src="${esc(qp.image_url)}" style="margin-top:8px;max-height:120px;width:100%;object-fit:cover;border-radius:var(--radius-sm);border:1px solid var(--border)" loading="lazy">` : ''}
    </a>`;
  } else if (p.quote_of_id) {
    detailQuoteHTML = `<a href="/post/${p.quote_of_id}" class="quote-embed" onclick="event.stopPropagation()" style="display:block;text-decoration:none;margin:14px 0">
      <div style="display:flex;align-items:center;gap:6px;color:var(--text-tertiary);font-size:13px"><i class="fas fa-retweet" style="font-size:12px"></i><span>${S.lang==='ja'?'引用元の投稿を見る':'View quoted post'}</span><i class="fas fa-arrow-right" style="font-size:10px"></i></div>
    </a>`;
  }
  const koremiteLabel = p.quote_of_id ? `<div style="display:flex;align-items:center;gap:5px;margin-bottom:10px;font-size:12px;color:var(--text-tertiary)"><i class="fas fa-retweet" style="font-size:11px"></i><span>${S.lang==='ja'?'コレミテ':'Quoted'}</span></div>` : '';
  el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button><span style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700">${S.lang==='ja'?'投稿':'Post'}</span></div>
    ${threadHTML}
    <div class="post anim-fade-up" style="border-bottom:1px solid var(--border)">${koremiteLabel}<div style="display:flex;gap:14px;margin-bottom:16px"><a href="/profile/${esc(p.username)}">${avatar(p.avatar_url, p.display_name, 48)}</a><div><a href="/profile/${esc(p.username)}" style="font-weight:600;font-size:17px" class="hover-underline">${esc(p.display_name)}</a><div style="font-size:13px;color:var(--text-tertiary)">@${esc(p.username)}</div></div></div><div style="font-size:17px;line-height:1.7;margin-bottom:14px;white-space:pre-wrap;word-break:break-word"><span class="${esc(textCls)}">${formatContent(p.content)}</span></div>${p.image_url ? `<img src="${esc(p.image_url)}" class="post-image" style="margin-bottom:14px" onclick="viewImage('${esc(p.image_url)}')">` : ''}${p.video_url ? `<div class="custom-video-wrap" style="margin-bottom:14px"><video src="${esc(p.video_url)}" class="custom-video" playsinline preload="metadata" onclick="toggleVideoPlay(this)"></video><div class="video-play-btn" onclick="toggleVideoPlay(this.previousElementSibling)"><i class="fas fa-play"></i></div><div class="video-controls"><button class="video-ctrl-btn" onclick="toggleVideoPlay(this.closest('.custom-video-wrap').querySelector('video'))"><i class="fas fa-play"></i></button><span class="video-time">0:00</span><div class="video-progress" onclick="seekVideo(event,this)"><div class="video-progress-fill"></div></div><button class="video-ctrl-btn" onclick="toggleVideoMute(this.closest('.custom-video-wrap').querySelector('video'))"><i class="fas fa-volume-up"></i></button><button class="video-ctrl-btn" onclick="toggleVideoFullscreen(this.closest('.custom-video-wrap'))"><i class="fas fa-expand"></i></button></div></div>` : ''}${detailQuoteHTML}${pollHTML}<div style="font-size:13px;color:var(--text-tertiary);padding:14px 0;border-top:1px solid var(--border)">${timeAgo(p.created_at)}</div><div class="post-actions" style="padding:14px 0;border-top:1px solid var(--border);margin:0"><button class="post-action ${p.liked>0?'liked':''}" onclick="toggleLike('${p.id}',this)"><i class="${p.liked>0?'fas':'far'} fa-heart"></i><span>${p.like_count||0}</span></button><span class="post-action"><i class="far fa-comment"></i><span>${p.reply_count||0}</span></span><button class="post-action" onclick="showKoremiteModal('${p.id}')"><i class="fas fa-retweet"></i></button>${pinBtn}<div class="post-more-wrap" style="margin-left:auto;position:relative"><button class="post-action" onclick="togglePostMore(this)"><i class="fas fa-ellipsis"></i></button><div class="post-more-menu">${S.user ? `<button onclick="toggleBookmark('${p.id}',this)" data-bookmarked="0"><i class="far fa-bookmark"></i><span>${S.lang==='ja'?'ブックマーク':'Bookmark'}</span></button>` : ''}<button onclick="showQRModal(location.origin+'/post/${p.id}','${S.lang==='ja'?'投稿をシェア':'Share Post'}')"><i class="fas fa-qrcode"></i><span>${S.lang==='ja'?'QRシェア':'QR Share'}</span></button><button onclick="showReportModal('post','${p.id}')"><i class="far fa-flag"></i><span>${S.lang==='ja'?'報告':'Report'}</span></button>${isOwn ? `<button onclick="deletePost('${p.id}')" style="color:var(--accent)"><i class="fas fa-trash"></i><span>${S.lang==='ja'?'削除':'Delete'}</span></button>` : ''}${S.user && isAdmin(S.user) && !isOwn ? `<button onclick="adminDeleteFeedPost('${p.id}')" style="color:var(--accent)"><i class="fas fa-trash-can"></i><span>${S.lang==='ja'?'削除（管理者）':'Delete (Admin)'}</span></button>` : ''}</div></div></div></div>
    ${S.user ? `<div style="padding:18px 24px;border-bottom:1px solid var(--border);display:flex;gap:12px">${avatar(S.user.avatar_url, S.user.display_name, 36)}<div style="flex:1;display:flex;gap:10px;align-items:flex-end"><textarea id="reply-input" class="input" style="border:none;background:transparent;padding:0;min-height:36px;font-size:15px;flex:1" placeholder="${S.lang==='ja'?'返信を投稿':'Reply'}" maxlength="500"></textarea><button class="btn btn-primary btn-sm" onclick="submitPost('${p.id}')">${S.lang==='ja'?'返信':'Reply'}</button></div></div>` : ''}
    <div id="replies">${replies.length > 0 ? replies.map((r, i) => renderPostHTML(r, i)).join('') : (replies.length === 0 && thread.length === 0 ? '' : '')}</div>${replies.length === 0 ? `<div id="replies-loader" style="padding:24px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>` : ''}<div class="mobile-nav-spacer"></div>`;
  // Remove loader if replies loaded
  const loader = document.getElementById('replies-loader');
  if (loader && replies.length >= 0) loader.remove();
}

async function votePoll(pollId, optionId) { if (!S.user) return navigate('/login'); const res = await api(`/api/polls/${pollId}/vote`, { method: 'POST', body: { option_id: optionId } }); if (res.success) { toast(S.lang==='ja'?'投票しました':'Voted'); pagePostDetail($('#page'), S.currentParams.id); } else toast(res.error || 'Error', 'error'); }

// ===== AUTH =====
function pageAuth(el, isRegister) {
  if (S.user) return navigate('/', true);
  el.innerHTML = `<div style="min-height:100dvh;display:flex;align-items:center;justify-content:center;padding:32px 32px 200px 32px;padding-bottom:max(200px, calc(80px + env(safe-area-inset-bottom)))"><div style="width:100%;max-width:380px" class="anim-fade-up">
    <div style="text-align:center;margin-bottom:40px"><div class="auth-logo-anim">さ</div><h1 style="font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:700;margin-bottom:6px">${isRegister ? t('auth.create_welcome') : t('auth.welcome')}</h1><p style="font-size:14px;color:var(--text-tertiary)">${t('site.tagline')}</p></div>
    <div id="auth-error" style="display:none;margin-bottom:16px;padding:12px 16px;border-radius:var(--radius-md);background:rgba(200,85,61,0.04);border:1px solid rgba(200,85,61,0.08);color:var(--accent);font-size:14px"></div>
    <div style="display:flex;flex-direction:column;gap:16px">
      ${isRegister ? `<div><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;margin-bottom:5px;display:block;text-transform:uppercase;letter-spacing:0.06em">${t('auth.username')}</label><input type="text" id="reg-username" class="input" placeholder="username" maxlength="20" autocomplete="username"></div><div><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;margin-bottom:5px;display:block;text-transform:uppercase;letter-spacing:0.06em">${t('auth.display_name')}</label><input type="text" id="reg-displayname" class="input" placeholder="${S.lang==='ja'?'表示名':'Display name'}" maxlength="30"></div>` : ''}
      <div><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;margin-bottom:5px;display:block;text-transform:uppercase;letter-spacing:0.06em">${t('auth.email')}</label><input type="email" id="${isRegister?'reg-':'login-'}email" class="input" placeholder="you@example.com" autocomplete="email"></div>
      <div><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;margin-bottom:5px;display:block;text-transform:uppercase;letter-spacing:0.06em">${t('auth.password')}</label><input type="password" id="${isRegister?'reg-':'login-'}password" class="input" placeholder="••••••" autocomplete="${isRegister?'new-':'current-'}password"></div>
      <button class="btn btn-primary" style="width:100%;padding:14px;font-size:15px" onclick="${isRegister?'doRegister':'doLogin'}()" id="${isRegister?'reg':'login'}-btn">${isRegister ? t('auth.register') : t('auth.login')}</button>
    </div>
    <div style="margin-top:20px;border-top:1px solid var(--border);padding-top:20px;text-align:center">
      <p style="font-size:12px;color:var(--text-tertiary);margin-bottom:12px">${S.lang==='ja'?'または':'or'}</p>
      <button class="btn" style="width:100%;padding:14px;font-size:14px;background:#06C755;color:white;border-radius:var(--radius-full)" onclick="showLineLogin()">
        <i class="fab fa-line" style="margin-right:8px;font-size:18px"></i>${S.lang==='ja'?'LINEで' + (isRegister?'登録':'ログイン') : (isRegister?'Sign up':'Log in') + ' with LINE'}
      </button>
    </div>
    <p style="text-align:center;font-size:14px;color:var(--text-tertiary);margin-top:24px">${isRegister ? t('auth.have_account') : t('auth.no_account')} <a href="${isRegister?'/login':'/register'}" style="color:var(--accent);font-weight:600">${isRegister ? t('nav.login') : t('nav.register')}</a></p>
    <div style="text-align:center;margin-top:16px;display:flex;justify-content:center;gap:16px;font-size:12px"><a href="/terms" style="color:var(--text-tertiary)">${S.lang==='ja'?'利用規約':'Terms'}</a><a href="/privacy" style="color:var(--text-tertiary)">${S.lang==='ja'?'プライバシー':'Privacy'}</a></div>
  </div></div>`;
  const pw = $(`#${isRegister?'reg':'login'}-password`);
  if (pw) pw.addEventListener('keydown', e => { if (e.key === 'Enter') isRegister ? doRegister() : doLogin(); });
}

async function doLogin() { const btn = $('#login-btn'), err = $('#auth-error'); btn.disabled = true; btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0 auto"></div>'; err.style.display = 'none'; const email = $('#login-email')?.value.trim(), password = $('#login-password')?.value; if (!email || !password) { err.textContent = S.lang==='ja'?'すべて入力してください':'Fill all fields'; err.style.display = 'block'; btn.disabled = false; btn.textContent = t('auth.login'); return; } const res = await api('/api/login', { method: 'POST', body: { email, password } }); if (res.error) { err.textContent = S.lang==='ja'?'メールアドレスまたはパスワードが違います':'Invalid credentials'; err.style.display = 'block'; btn.disabled = false; btn.textContent = t('auth.login'); return; } S.user = res.user; shellRendered = false; navigate('/', true); }
async function doRegister() { const btn = $('#reg-btn'), err = $('#auth-error'); btn.disabled = true; btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0 auto"></div>'; err.style.display = 'none'; const username = $('#reg-username')?.value.trim().toLowerCase(), display_name = $('#reg-displayname')?.value.trim(), email = $('#reg-email')?.value.trim(), password = $('#reg-password')?.value; if (!username || !display_name || !email || !password) { err.textContent = S.lang==='ja'?'すべて入力してください':'Fill all fields'; err.style.display = 'block'; btn.disabled = false; btn.textContent = t('auth.register'); return; } const res = await api('/api/register', { method: 'POST', body: { username, display_name, email, password } }); if (res.error) { err.textContent = res.error.includes('taken') ? (S.lang==='ja'?'既に使われています':'Already taken') : res.error; err.style.display = 'block'; btn.disabled = false; btn.textContent = t('auth.register'); return; } S.user = res.user; shellRendered = false; navigate('/', true); }
async function logout() { await api('/api/logout', { method: 'POST' }); S.user = null; shellRendered = false; navigate('/login', true); }

// ===== LEGAL PAGES (Terms / Privacy) =====
async function pageLegal(el, type) {
  const isTerms = type === 'terms';
  const title = isTerms 
    ? (S.lang==='ja'?'利用規約':'Terms of Service') 
    : (S.lang==='ja'?'プライバシーポリシー':'Privacy Policy');
  const icon = isTerms ? 'fa-file-contract' : 'fa-shield-halved';
  
  el.innerHTML = `<div class="legal-page anim-fade-up">
    <div class="page-header" style="padding:20px 0;display:flex;align-items:center;gap:12px">
      <button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
      <span style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700"><i class="fas ${icon}" style="color:var(--accent);margin-right:8px"></i>${title}</span>
    </div>
    <div class="page-loader"><div class="orbit-spinner"></div><div class="page-loader-text">${S.lang==='ja'?'読み込み中...':'Loading...'}</div></div>
  </div>`;
  
  try {
    const res = await api('/api/legal/' + type);
    const content = res.content || '';
    const updatedAt = res.updated_at || '';
    const container = el.querySelector('.legal-page');
    if (!container) return;
    
    if (!content.trim()) {
      container.innerHTML = `
        <div class="page-header" style="padding:20px 0;display:flex;align-items:center;gap:12px">
          <button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
          <span style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700"><i class="fas ${icon}" style="color:var(--accent);margin-right:8px"></i>${title}</span>
        </div>
        <div style="padding:60px 0;text-align:center;color:var(--text-tertiary)">
          <i class="fas ${icon}" style="font-size:48px;opacity:0.2;display:block;margin-bottom:16px"></i>
          <p style="font-size:16px;font-weight:600">${S.lang==='ja'?'まだ内容がありません':'No content yet'}</p>
          <p style="font-size:13px;margin-top:8px">${S.lang==='ja'?'管理者が設定中です':'The administrator is setting this up'}</p>
        </div>`;
      return;
    }
    
    // Parse simple markdown-like content to HTML
    const htmlContent = content
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h2>$1</h2>')
      .replace(/^\- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>');
    
    container.innerHTML = `
      <div class="page-header" style="padding:20px 0;display:flex;align-items:center;gap:12px">
        <button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
        <span style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700"><i class="fas ${icon}" style="color:var(--accent);margin-right:8px"></i>${title}</span>
      </div>
      <div class="legal-content anim-fade-up stagger-1">
        <p>${htmlContent}</p>
      </div>
      ${updatedAt ? `<div style="margin-top:32px;padding-top:16px;border-top:1px solid var(--border);font-size:12px;color:var(--text-tertiary)"><i class="fas fa-clock" style="margin-right:4px"></i>${S.lang==='ja'?'最終更新':'Last updated'}: ${new Date(updatedAt).toLocaleDateString(S.lang==='ja'?'ja-JP':'en-US')}</div>` : ''}
      <div class="mobile-nav-spacer"></div>`;
  } catch (e) {
    el.querySelector('.legal-page').innerHTML = `<div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'読み込みエラー':'Failed to load'}</div>`;
  }
}

// ===== HELP =====
function pageHelp(el) {
  const sections = [
    { 
      icon: 'fa-pen', 
      title: S.lang==='ja'?'投稿のルール':'Posting Rules', 
      desc: S.lang==='ja'?'テキストや画像を使って自由に表現しましょう。長い投稿は自動で折りたたまれ、読みやすく表示されます。引用機能（コレミテ）や投票を使って、みんなと交流を深めることができます。':'Express yourself with text and images. Long posts are neatly collapsed for better readability. Connect with others using the Quote (Koremite) and Poll features.' 
    },
    { 
      icon: 'fa-fire', 
      title: S.lang==='ja'?'おすすめフィード':'For You Feed', 
      desc: S.lang==='ja'?'「おすすめ」タブでは、あなたの興味関心や新しい発見につながる投稿を、独自のアルゴリズムでリアルタイムにお届けします。反応した投稿やフォロー状況に基づき、あなたにぴったりのコンテンツが優先的に表示されます。':'The "For You" tab delivers real-time posts tailored to your interests and new discoveries. Our smart algorithm prioritizes content based on your interactions and who you follow to create a personalized experience.' 
    },
    { 
      icon: 'fa-bolt', 
      title: S.lang==='ja'?'リアルタイム交流':'Real-time Interaction', 
      desc: S.lang==='ja'?'DMやクルー、ボイスルームのチャットは瞬時に届きます。相手が入力中かどうかもわかるので、スムーズな会話を楽しめます。オフラインの間に届いたメッセージは、再接続時に自動で同期されます。':'Messages in DMs, Crews, and Voice Rooms arrive instantly. Typing indicators help keep conversations fluid. Any missed messages while offline are automatically synced when you return.' 
    },
    { 
      icon: 'fa-headphones', 
      title: S.lang==='ja'?'ボイスルーム':'Voice Rooms', 
      desc: S.lang==='ja'?'最大20人でリアルタイムの通話を楽しめます。雑談、ゲーム、音楽、勉強など、目的に合わせたタグで部屋を検索できます。ホワイトボードや音楽プレイヤーを使って、リッチな時間を過ごしましょう。':'Join real-time voice chats with up to 20 people. Browse rooms by tags like Chat, Gaming, Music, or Study. Enhance your experience with the built-in whiteboard and music player.' 
    },
    { 
      icon: 'fa-paintbrush', 
      title: S.lang==='ja'?'お絵かき機能':'Whiteboard', 
      desc: S.lang==='ja'?'ボイスルーム内で使える共有ホワイトボードです。ペンや消しゴムを使って、リアルタイムに絵や文字を書けます。ズームや移動も自由自在なので、広いキャンバスをみんなで活用しましょう。':'A shared whiteboard for Voice Rooms. Draw or write in real-time with various tools and colors. Use zoom and pan gestures to navigate the canvas freely with your friends.' 
    },
    { 
      icon: 'fa-coins', 
      title: S.lang==='ja'?'コインとギフト':'Coins & Gifts', 
      desc: S.lang==='ja'?'ログインや投稿でコインを獲得できます。貯まったコインは、お気に入りのユーザーへの投げ銭に使ったり、ショップで特別なデコレーションアイテムと交換したりできます。':'Earn coins by staying active and posting. Use your coins to support your favorite creators with tips, or exchange them for exclusive decorative items in the Shop.' 
    },
    { 
      icon: 'fa-users', 
      title: S.lang==='ja'?'クルー（コミュニティ）':'Crews', 
      desc: S.lang==='ja'?'共通の趣味を持つ仲間と「クルー」を作ることができます。専用のテキストチャットやボイスチャンネルを作成し、ロール（役割）を割り当てて自分たちのコミュニティを運営しましょう。':'Create or join "Crews" to connect with like-minded people. Set up dedicated text and voice channels, and manage your community using a flexible role system.' 
    },
    { 
      icon: 'fa-shield-halved', 
      title: S.lang==='ja'?'安心・安全への取り組み':'Safety & Moderation', 
      desc: S.lang==='ja'?'すべてのユーザーが安心して利用できるよう、管理者による24時間の監視とスパム対策を行っています。迷惑なユーザーの報告機能や、公式アカウントの認証バッジ制度を導入しています。':'To ensure a safe environment, we employ active moderation and anti-spam measures. Features include user reporting, official account verification, and real-time community guidelines enforcement.' 
    },
    { 
      icon: 'fa-palette', 
      title: S.lang==='ja'?'テーマカスタマイズ':'Themes', 
      desc: S.lang==='ja'?'気分に合わせてアプリの見た目を変えられます。ライト、グレー、ウォーム、オーシャン、フォレスト、そして目に優しいダークモード（ノワール）の6種類から選択可能です。':'Personalize your app with six beautiful themes: Light, Gray, Warm, Ocean, Forest, and Noir (Dark Mode). Choose the style that best fits your mood in the settings.' 
    },
    { 
      icon: 'fa-store', 
      title: S.lang==='ja'?'ショップ':'Shop', 
      desc: S.lang==='ja'?'個性を出したいならショップへ！名前の色、プロフィールの背景、特別なバッジなど、様々なデコレーションアイテムをコインで購入できます。期間限定のレアアイテムもチェックしましょう。':'Stand out from the crowd! Visit the Shop to buy name colors, profile backgrounds, and unique badges with your coins. Don’t miss out on special items like rainbow effects!' 
    },
  ];

  // UI描画処理
  el.innerHTML = `
    <div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px">
      <button class="btn-icon mobile-only" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
      <span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${S.lang==='ja'?'ヘルプ':'Help'}</span>
    </div>
    <div id="help-announcements"></div>
    ${sections.map(s => `
      <div class="help-section">
        <h3 style="display:flex;align-items:center;margin-bottom:8px;">
          <i class="fas ${s.icon}" style="color:var(--accent);margin-right:10px;font-size:18px"></i>
          ${s.title}
        </h3>
        <p style="line-height:1.6; opacity:0.9;">${s.desc}</p>
      </div>
    `).join('')}
    <div style="padding:0 24px 24px;display:flex;flex-direction:column;gap:8px">
      <a href="/terms" style="display:flex;align-items:center;gap:12px;padding:16px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-md);text-decoration:none;color:var(--text-primary);transition:all var(--t-fast)"><i class="fas fa-file-contract" style="color:var(--accent);font-size:16px"></i><span style="font-weight:500;font-size:14px">${S.lang==='ja'?'利用規約':'Terms of Service'}</span><i class="fas fa-chevron-right" style="margin-left:auto;color:var(--text-tertiary);font-size:12px"></i></a>
      <a href="/privacy" style="display:flex;align-items:center;gap:12px;padding:16px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-md);text-decoration:none;color:var(--text-primary);transition:all var(--t-fast)"><i class="fas fa-shield-halved" style="color:var(--sky);font-size:16px"></i><span style="font-weight:500;font-size:14px">${S.lang==='ja'?'プライバシーポリシー':'Privacy Policy'}</span><i class="fas fa-chevron-right" style="margin-left:auto;color:var(--text-tertiary);font-size:12px"></i></a>
    </div>
    <div class="mobile-nav-spacer"></div>
  `;
  // Load announcements
  loadHelpAnnouncements();
}
async function loadHelpAnnouncements() {
  const el = $('#help-announcements'); if (!el) return;
  const res = await api('/api/admin/announcements');
  const anns = res.announcements || [];
  if (anns.length === 0) return;
  el.innerHTML = `<div style="padding:0 24px"><div style="margin-bottom:4px">
    <h3 style="font-size:12px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px;padding-top:20px"><i class="fas fa-bullhorn" style="margin-right:6px"></i>${S.lang==='ja'?'お知らせ':'ANNOUNCEMENTS'}</h3>
    ${anns.slice(0,5).map(a => `<div style="padding:14px 16px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);margin-bottom:8px"><div style="font-weight:700;font-size:14px;margin-bottom:4px">${esc(a.title)}</div><div style="font-size:13px;color:var(--text-secondary);line-height:1.6;white-space:pre-wrap">${esc(a.content)}</div><div style="font-size:11px;color:var(--text-tertiary);margin-top:6px">${timeAgo(a.created_at)}</div></div>`).join('')}
  </div></div>`;
}

// ===== ADMIN (lazy-loaded for admin users only) =====
async function pageAdmin(el) {
  if (!S.user || (S.user.role !== "admin" && S.user.role !== "superadmin")) { navigate("/"); return; }
  el.innerHTML = '<div class="page-loader"><div class="orbit-spinner"></div><div class="page-loader-text">Loading admin panel...</div></div>';
  try {
    if (!window._adminLoaded) {
      // Remove any previous failed script tags
      document.querySelectorAll('script[data-admin-module]').forEach(s => s.remove());
      await new Promise((resolve, reject) => {
        const s = document.createElement("script");
        s.src = "/api/modules/admin.js?_t=" + Date.now();
        s.setAttribute('data-admin-module', '1');
        s.onload = () => { window._adminLoaded = true; resolve(); };
        s.onerror = () => reject(new Error("Admin module access denied"));
        document.head.appendChild(s);
      });
    }
    if (typeof window._pageAdmin === "function") window._pageAdmin(el);
    else { el.innerHTML = '<div style="padding:40px;text-align:center;color:var(--accent)"><i class="fas fa-exclamation-triangle" style="font-size:32px;margin-bottom:12px;display:block"></i>Admin module failed to load<br><button class="btn btn-secondary btn-sm" style="margin-top:12px" onclick="window._adminLoaded=false;pageAdmin(document.getElementById(\'page\'))">Retry</button></div>'; }
  } catch(e) {
    console.error('Admin load error:', e);
    window._adminLoaded = false;
    el.innerHTML = `<div style="padding:40px;text-align:center;color:var(--accent)"><i class="fas fa-lock" style="font-size:32px;margin-bottom:12px;display:block"></i>${e.message || 'Access denied'}<br><button class="btn btn-secondary btn-sm" style="margin-top:12px" onclick="window._adminLoaded=false;pageAdmin(document.getElementById('page'))">Retry</button></div>`;
  }
}
function switchAdminTab(){}
function loadAdminTab(){}
function loadAdminDashboard(){}
// ===== ADMIN: Official Mark Management (rebuilt from scratch) =====
function loadAdminOfficialUsers(){}
function loadOfficialUsersList(){}
function showGrantOfficialModal(){}
function searchUsersForOfficial(){}
function grantOfficialMark(){}
function confirmRemoveOfficial(){}
function loadAdminUsers(){}
function debounceAdminUserSearch(){}
function searchAdminUsers(){}
function adminBanUser(){}
function confirmAdminBan(){}
function adminUnbanUser(){}
function adminSuspendUser(){}
function confirmAdminSuspend(){}
function adminUnsuspendUser(){}
function adminSetRole(){}
function confirmAdminSetRole(){}
function loadAdminAnnouncements(){}
function createAnnouncement(){}
function deleteAnnouncement(){}
function loadAdminConfig(){}
function saveContentPolicy(){}
function saveAblyKey(){}
function loadAdminSpamWords(){}
function addSpamWord(){}
function deleteSpamWord(){}
function loadAdminIPMonitor(){}
function loadAdminImages(){}
function uploadSiteImage(){}
function saveSiteImage(){}
function deleteSiteImage(){}
function updateRateLimit(){}
// ===== POST TIP =====
function showPostTipModal(postId, userId) {
  if (!S.user) return navigate('/login');
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-coins" style="color:var(--sand);margin-right:8px"></i>${S.lang==='ja'?'投げ銭':'Tip'}</h3><div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">${[1,5,10,25,50].map(n => `<button class="pill" onclick="document.getElementById('tip-amount').value=${n}">${n}</button>`).join('')}</div><input type="number" id="tip-amount" class="input" placeholder="${S.lang==='ja'?'枚数':'Amount'}" min="1" value="5"><input type="text" id="tip-msg" class="input" placeholder="${S.lang==='ja'?'メッセージ（任意）':'Message'}" maxlength="100" style="margin-top:10px"><div style="display:flex;gap:12px;margin-top:16px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="sendPostTip('${userId}')">${S.lang==='ja'?'送る':'Send'}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function sendPostTip(userId) { const amount = parseInt($('#tip-amount')?.value || '0'); const message = $('#tip-msg')?.value || ''; if (amount < 1) return toast(S.lang==='ja'?'1枚以上':'Min 1','error'); const res = await api('/api/coins/send', { method: 'POST', body: { target_user_id: userId, amount, message } }); if (res.success) { $('.modal-overlay')?.remove(); toast(`${amount} ${S.lang==='ja'?'コイン送信！':'coins sent!'}`); if (S.user) S.user.coins = res.new_balance; } else toast(res.error || 'Error', 'error'); }

// ===== ENHANCED ADMIN =====
function adminSetOfficial(){}
function adminTransfer(){}
function adminDeleteAllPosts(){}
// ===== LANGUAGE =====
async function toggleLang() { const nl = S.lang === 'ja' ? 'en' : 'ja'; await api('/api/lang', { method: 'POST', body: { lang: nl } }); location.reload(); }

// ===== PWA =====
if ('serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('/static/sw.js').catch(() => {}); }); }

// ===== PWA Install Prompt =====
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', function(event) {
  event.preventDefault();
  deferredPrompt = event;
  console.log('[PWA] Install prompt captured');
});

function pwaInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(result => {
      console.log('[PWA] User choice:', result.outcome);
      deferredPrompt = null;
    });
  } else {
    // Show fallback for iOS/unsupported
    showPWAFallbackModal();
  }
}

function showPWAFallbackModal() {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px;text-align:center">
      <i class="fas fa-mobile-screen" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'アプリをインストール':'Install App'}
    </h3>
    ${isIOS ? `
      <div style="text-align:center;margin-bottom:16px">
        <img src="https://imobie-resource.com/jp/support/img/add-website-icon-to-iphone-home-screen-1.png" style="max-width:100%;border-radius:var(--radius-md);border:1px solid var(--border)" alt="ホーム画面に追加" onerror="this.style.display='none'">
      </div>
      <div style="font-size:14px;color:var(--text-secondary);line-height:1.8;margin-bottom:16px">
        <p style="margin-bottom:12px"><strong>${S.lang==='ja'?'iPhoneの場合:':'For iPhone:'}</strong></p>
        <div style="display:flex;flex-direction:column;gap:8px">
          <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-elevated);border-radius:var(--radius-sm)">
            <span style="width:24px;height:24px;border-radius:50%;background:var(--accent);color:white;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0">1</span>
            <span>${S.lang==='ja'?'<strong>Safari</strong>で開いてください（Chrome不可）':'Open in <strong>Safari</strong> (not Chrome)'}</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-elevated);border-radius:var(--radius-sm)">
            <span style="width:24px;height:24px;border-radius:50%;background:var(--accent);color:white;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0">2</span>
            <span>${S.lang==='ja'?'下部の<i class="fas fa-arrow-up-from-bracket" style="color:var(--accent)"></i>共有ボタンをタップ':'Tap <i class="fas fa-arrow-up-from-bracket" style="color:var(--accent)"></i> Share button'}</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-elevated);border-radius:var(--radius-sm)">
            <span style="width:24px;height:24px;border-radius:50%;background:var(--accent);color:white;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0">3</span>
            <span>${S.lang==='ja'?'「ホーム画面に追加」をタップ':'Tap "Add to Home Screen"'}</span>
          </div>
        </div>
      </div>
    ` : `
      <div style="font-size:14px;color:var(--text-secondary);line-height:1.8;margin-bottom:16px">
        <p>${S.lang==='ja'?'ブラウザのメニューから「ホーム画面に追加」または「アプリをインストール」を選択してください。':'Select "Add to Home Screen" or "Install App" from the browser menu.'}</p>
      </div>
    `}
    <button class="btn btn-primary" style="width:100%" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'わかった':'Got it'}</button>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}

// ===== PIN POSTS =====
async function togglePinPost(postId) {
  if (!S.user) return navigate('/login');
  const res = await api(`/api/posts/${postId}/pin`, { method: 'POST' });
  if (res.success) toast(S.lang==='ja'?'ピン留めしました':'Pinned');
  else if (res.error === 'Max 3 pinned posts') {
    // Try unpin
    const res2 = await api(`/api/posts/${postId}/pin`, { method: 'DELETE' });
    if (res2.success) toast(S.lang==='ja'?'ピン解除':'Unpinned');
    else toast(res.error, 'error');
  } else toast(res.error || 'Error', 'error');
}

// ===== HASHTAG PAGE =====
async function pageHashtag(el, tag) {
  el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700;color:var(--sky)">#${esc(tag)}</span><span id="ht-count" style="font-size:13px;color:var(--text-tertiary)"></span></div><div id="ht-posts"><div class="page-loader"><div class="orbit-spinner"></div></div></div><div class="mobile-nav-spacer"></div>`;
  const res = await api(`/api/hashtags/${encodeURIComponent(tag)}/posts`);
  const posts = res.posts || [];
  const htInfo = res.hashtag;
  const list = $('#ht-posts');
  if (!list) return;
  // Show post count
  const countEl = $('#ht-count');
  if (countEl && htInfo) countEl.textContent = `${htInfo.post_count || posts.length} ${S.lang==='ja'?'件の投稿':'posts'}`;
  if (posts.length === 0) { list.innerHTML = `<div style="padding:60px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'投稿がありません':'No posts'}</div>`; return; }
  list.innerHTML = posts.map((p, i) => renderPostHTML(p, i)).join('');
}

// ===== CASINO PAGE (lazy-loaded from casino.js) =====
let _casinoLoaded = false;
function loadCasinoPage(el) {
  if (!S.user) return navigate('/login');
  // Stop any previous casino animation
  if (typeof csStopAnimation === 'function') csStopAnimation();
  if (_casinoLoaded) { pageCasino(el); return; }
  el.innerHTML = '<div style="min-height:100dvh;background:#0a0a14;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px"><div class="orbit-spinner" style="--accent:#d4a017;--accent-light:#e6c84d"></div><div style="color:rgba(212,160,23,0.6);font-size:13px;animation:loading-pulse 2s ease infinite">Loading Casino...</div></div>';
  const script = document.createElement('script');
  script.src = '/static/casino.js';
  script.onload = () => { _casinoLoaded = true; pageCasino(el); };
  script.onerror = () => { el.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-tertiary)">Failed to load casino</div>'; };
  document.head.appendChild(script);
}

// ===== LINE LOGIN =====
function showLineLogin() {
  const redirectUri = encodeURIComponent(location.origin + '/line-callback');
  const state = Math.random().toString(36).substring(7);
  localStorage.setItem('line_state', state);
  const url = `https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id=2009635496&redirect_uri=${redirectUri}&state=${state}&scope=profile%20openid`;
  location.href = url;
}

async function handleLineCallback() {
  const params = new URLSearchParams(location.search);
  const code = params.get('code');
  const state = params.get('state');
  if (!code) return navigate('/login');
  const savedState = localStorage.getItem('line_state');
  if (state && savedState && state !== savedState) { toast('Invalid state', 'error'); return navigate('/login'); }
  const res = await api('/api/auth/line', { method: 'POST', body: { code, redirect_uri: location.origin + '/line-callback' } });
  if (res.success) {
    S.user = res.user; shellRendered = false;
    toast(res.action === 'register' ? (S.lang==='ja'?'LINE登録完了！':'Registered via LINE!') : (S.lang==='ja'?'LINEログイン成功':'Logged in via LINE'));
    navigate('/', true);
  } else { toast(res.error || 'LINE login failed', 'error'); navigate('/login'); }
}

// ===== POST CLICK NAVIGATION =====
function navigateToPost(postId, event) {
  // Don't navigate if clicking interactive elements
  const t = event.target;
  if (t.closest('a') || t.closest('button') || t.closest('.post-action') || t.closest('img.post-image') || t.closest('.quote-embed') || t.closest('.read-more-btn') || t.classList.contains('read-more-btn') || t.tagName === 'A' || t.tagName === 'BUTTON') return;
  haptic('light');
  const postEl = document.getElementById('post-' + postId);
  if (postEl) {
    postEl.style.transition = 'transform 0.15s ease, opacity 0.15s ease';
    postEl.style.transform = 'scale(0.98)';
    postEl.style.opacity = '0.7';
    setTimeout(() => { postEl.style.transform = ''; postEl.style.opacity = ''; navigate('/post/' + postId); }, 150);
  } else { navigate('/post/' + postId); }
}

// ===== LINK PREVIEWS ON FEED (optimized with IntersectionObserver) =====
const _lpIO = window.IntersectionObserver ? new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const postEl = entry.target;
    _lpIO.unobserve(postEl);
    postEl.setAttribute('data-link-preview-done', '1');
    const contentEl = postEl.querySelector('[id^="post-content-"]');
    if (!contentEl) return;
    const text = contentEl.textContent || '';
    if (text.match(/https?:\/\//)) {
      const previewContainer = document.createElement('div');
      previewContainer.style.marginTop = '8px';
      contentEl.parentElement.insertBefore(previewContainer, contentEl.nextSibling);
      renderLinkPreviews(previewContainer, text);
    }
  });
}, { rootMargin: '300px' }) : null;

function attachLinkPreviews() {
  document.querySelectorAll('.post:not([data-link-preview-done])').forEach(postEl => {
    if (_lpIO) {
      _lpIO.observe(postEl);
    } else {
      postEl.setAttribute('data-link-preview-done', '1');
      const contentEl = postEl.querySelector('[id^="post-content-"]');
      if (!contentEl) return;
      const text = contentEl.textContent || '';
      if (text.match(/https?:\/\//)) {
        const previewContainer = document.createElement('div');
        previewContainer.style.marginTop = '8px';
        contentEl.parentElement.insertBefore(previewContainer, contentEl.nextSibling);
        renderLinkPreviews(previewContainer, text);
      }
    }
  });
}

// ===== ADMIN REPORTS MANAGEMENT =====
function loadAdminReports(){}
function reviewReport(){}
function adminDeleteReportedPost(){}
function adminDeleteAccount(){}
function adminRemoveOfficial(){}
function adminDeleteFeedPost(){}
function loadAdminDBOps(){}
function executeDBQuery(){}
// ===== DRAFTS (localStorage) =====
const DRAFT_KEY = 'satocchi-drafts';
function getDrafts() { try { return JSON.parse(localStorage.getItem(DRAFT_KEY) || '[]'); } catch { return []; } }
function saveDraft(content, imageData, videoData, textStyle, isR18, isAI) {
  if (!content?.trim()) return;
  const drafts = getDrafts();
  drafts.unshift({ id: Date.now(), content, imageData: imageData || '', videoData: videoData || '', textStyle: textStyle || '', isR18: !!isR18, isAI: !!isAI, savedAt: new Date().toISOString() });
  // Keep max 10 drafts
  while (drafts.length > 10) drafts.pop();
  localStorage.setItem(DRAFT_KEY, JSON.stringify(drafts));
  toast(S.lang==='ja'?'下書き保存しました':'Draft saved');
}
function deleteDraft(id) {
  const drafts = getDrafts().filter(d => d.id !== id);
  localStorage.setItem(DRAFT_KEY, JSON.stringify(drafts));
}
function restoreDraft(draft) {
  const input = $('#compose-input');
  if (input) { input.value = draft.content; onComposeInput(); }
  if (draft.imageData) { composeImgData = draft.imageData; const p = $('#compose-preview'); if (p) { p.style.display = 'block'; p.innerHTML = `<div style="position:relative;display:inline-block"><img src="${draft.imageData}" style="max-height:160px;border-radius:var(--radius-md);border:1px solid var(--border)"><button onclick="removeComposeImage()" style="position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;background:rgba(0,0,0,0.5);color:white;display:flex;align-items:center;justify-content:center;font-size:10px"><i class="fas fa-times"></i></button></div>`; } }
  if (draft.videoData) { composeVideoData = draft.videoData; const vp = $('#compose-video-preview'); if (vp) { vp.style.display = 'block'; vp.innerHTML = `<div style="position:relative;display:inline-block"><video src="${draft.videoData}" style="max-height:160px;border-radius:var(--radius-md);border:1px solid var(--border)" controls></video><button onclick="removeComposeVideo()" style="position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;background:rgba(0,0,0,0.5);color:white;display:flex;align-items:center;justify-content:center;font-size:10px"><i class="fas fa-times"></i></button></div>`; } }
  if (draft.textStyle) composeTextColor = draft.textStyle.replace('tc-', '');
  const r18 = $('#compose-r18'); if (r18 && draft.isR18) r18.checked = true;
  const ai = $('#compose-ai'); if (ai && draft.isAI) ai.checked = true;
  deleteDraft(draft.id);
  document.querySelector('.modal-overlay')?.remove();
  toast(S.lang==='ja'?'下書きを復元しました':'Draft restored');
}
function showDraftsModal() {
  const drafts = getDrafts();
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;max-height:80vh;overflow-y:auto" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-file-lines" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'下書き':'Drafts'} (${drafts.length})</h3>
    ${drafts.length === 0 ? `<div style="padding:30px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'下書きはありません':'No drafts'}</div>` : 
    drafts.map(d => `<div style="padding:14px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);margin-bottom:10px">
      <div style="font-size:14px;color:var(--text-secondary);line-height:1.6;margin-bottom:8px;white-space:pre-wrap;word-break:break-word;max-height:80px;overflow:hidden">${esc(d.content.substring(0,200))}</div>
      ${d.isR18 ? '<span style="font-size:10px;padding:1px 6px;border-radius:var(--radius-full);background:rgba(200,85,61,0.12);color:var(--accent);font-weight:700;margin-right:4px">R18</span>' : ''}
      ${d.isAI ? '<span style="font-size:10px;padding:1px 6px;border-radius:var(--radius-full);background:rgba(91,143,168,0.12);color:var(--sky);font-weight:700;margin-right:4px">AI</span>' : ''}
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px">
        <span style="font-size:11px;color:var(--text-tertiary)">${timeAgo(d.savedAt)}</span>
        <div style="display:flex;gap:6px">
          <button class="btn btn-primary btn-xs" onclick="restoreDraft(${JSON.stringify(d).replace(/"/g,'&quot;')})"><i class="fas fa-rotate-left" style="margin-right:3px"></i>${S.lang==='ja'?'復元':'Restore'}</button>
          <button class="btn btn-danger btn-xs" onclick="deleteDraft(${d.id});this.closest('.modal-overlay').remove();showDraftsModal()"><i class="fas fa-trash"></i></button>
        </div>
      </div>
    </div>`).join('')}
    <button class="btn btn-secondary" style="width:100%;margin-top:8px" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'閉じる':'Close'}</button>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}
function saveDraftFromComposer() {
  const input = $('#compose-input');
  const content = input?.value.trim();
  if (!content) { toast(S.lang==='ja'?'内容がありません':'No content','error'); return; }
  const isR18 = $('#compose-r18')?.checked || false;
  const isAI = $('#compose-ai')?.checked || false;
  saveDraft(content, composeImgData, composeVideoData, composeTextColor ? 'tc-' + composeTextColor : '', isR18, isAI);
}

// ===== BOOKMARKS =====
async function toggleBookmark(postId, btn) {
  if (!S.user) return navigate('/login');
  const isBookmarked = btn.dataset.bookmarked === '1';
  const icon = $('i', btn);
  if (isBookmarked) {
    btn.dataset.bookmarked = '0';
    if (icon) { icon.className = 'far fa-bookmark'; }
    btn.classList.remove('bookmarked');
    await api(`/api/bookmarks/${postId}`, { method: 'DELETE' });
    toast(S.lang==='ja'?'ブックマーク解除':'Removed bookmark');
  } else {
    btn.dataset.bookmarked = '1';
    if (icon) { icon.className = 'fas fa-bookmark'; icon.style.animation = 'heart-burst 0.4s ease-out'; setTimeout(() => icon.style.animation = '', 400); }
    btn.classList.add('bookmarked');
    const pel = document.getElementById('post-' + postId); if (pel) _pushSignal(postId, 'bookmark', 1, pel.dataset.authorId);
    await api(`/api/bookmarks/${postId}`, { method: 'POST' });
    toast(S.lang==='ja'?'ブックマークしました':'Bookmarked');
  }
}
async function showBookmarks() {
  if (!S.user) return navigate('/login');
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;max-height:85vh;overflow-y:auto;max-width:600px;width:95%" onclick="event.stopPropagation()">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
      <h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700"><i class="fas fa-bookmark" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'ブックマーク':'Bookmarks'}</h3>
      <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()"><i class="fas fa-times"></i></button>
    </div>
    <div id="bookmarks-list"><div style="padding:30px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
  const res = await api('/api/bookmarks');
  const posts = res.posts || [];
  const list = document.getElementById('bookmarks-list');
  if (!list) return;
  if (posts.length === 0) { list.innerHTML = `<div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'ブックマークはありません':'No bookmarks'}</div>`; return; }
  list.innerHTML = posts.map((p, i) => renderPostHTML(p, i)).join('');
}

// ===== ADMIN: Set R18/AI on posts =====
function showAdminPostFlagsModal(){}
function submitAdminPostFlags(){}

// ===== ENGAGEMENT SIGNAL ENGINE =====
const _sig = {
  queue: [], dwellTimers: {}, observer: null, flushTimer: null,
  FLUSH_MS: 8000, MIN_DWELL: 1.5, BATCH_MAX: 25
};

function _pushSignal(postId, type, value, authorId, hashtags, contentLen, hasMedia) {
  if (!S.user || !postId) return;
  _sig.queue.push({ post_id: postId, type, value: value || 1.0, author_id: authorId || '', hashtags: hashtags || [], content_length: contentLen || 0, has_media: !!hasMedia });
  if (_sig.queue.length >= _sig.BATCH_MAX) { _flushSignals(); return; }
  if (!_sig.flushTimer) _sig.flushTimer = setTimeout(_flushSignals, _sig.FLUSH_MS);
}

function _flushSignals() {
  if (_sig.flushTimer) { clearTimeout(_sig.flushTimer); _sig.flushTimer = null; }
  if (_sig.queue.length === 0) return;
  const batch = _sig.queue.splice(0, _sig.BATCH_MAX);
  api('/api/signals', { method: 'POST', body: { signals: batch } });
}

// Dwell time via IntersectionObserver
function _initDwellObserver() {
  if (_sig.observer || typeof IntersectionObserver === 'undefined') return;
  _sig.observer = new IntersectionObserver((entries) => {
    for (const e of entries) {
      const el = e.target, pid = el.id?.replace('post-', '');
      if (!pid) continue;
      if (e.isIntersecting) {
        if (!_sig.dwellTimers[pid]) _sig.dwellTimers[pid] = { start: Date.now(), sent: false };
        else if (!_sig.dwellTimers[pid].sent) _sig.dwellTimers[pid].start = Date.now();
      } else {
        const t = _sig.dwellTimers[pid];
        if (t && !t.sent && t.start) {
          const sec = (Date.now() - t.start) / 1000;
          if (sec >= _sig.MIN_DWELL) {
            _pushSignal(pid, 'dwell', Math.round(sec * 10) / 10, el.dataset.authorId, (el.dataset.hashtags||'').split(',').filter(Boolean), parseInt(el.dataset.contentLen||'0'), el.dataset.hasMedia==='1');
            t.sent = true;
          }
        }
      }
    }
  }, { threshold: 0.5 });
}

function observePost(el) {
  if (!_sig.observer) _initDwellObserver();
  if (_sig.observer && el) _sig.observer.observe(el);
}

// Scroll speed tracking + scroll_skip detection
let _scrollRaf = false, _lastScrollY = 0, _lastScrollT = 0, _scrollSpeeds = [];
const _skipDetected = new Set();
window.addEventListener('scroll', () => {
  if (_scrollRaf) return; _scrollRaf = true;
  requestAnimationFrame(() => {
    _scrollRaf = false;
    const now = Date.now(), y = window.scrollY;
    if (_lastScrollT > 0) {
      const dt = (now - _lastScrollT) / 1000;
      if (dt > 0 && dt < 1) {
        const speed = Math.abs(y - _lastScrollY) / dt;
        _scrollSpeeds.push(speed);
        if (_scrollSpeeds.length > 10) _scrollSpeeds.shift();
        // HIGH-SPEED SCROLL SKIP DETECTION: >2500px/s = user is skipping content
        if (speed > 2500 && S.currentPage === 'home') {
          const posts = document.querySelectorAll('.post[id^="post-"]');
          const viewTop = window.scrollY, viewBot = viewTop + window.innerHeight;
          for (const p of posts) {
            const rect = p.getBoundingClientRect();
            const absTop = rect.top + window.scrollY;
            // Posts that were scrolled past at high speed
            if (absTop < viewTop && absTop > viewTop - 800) {
              const pid = p.id.replace('post-','');
              if (pid && !_skipDetected.has(pid)) {
                _skipDetected.add(pid);
                _pushSignal(pid, 'scroll_skip', speed / 1000, p.dataset.authorId, (p.dataset.hashtags||'').split(',').filter(Boolean), parseInt(p.dataset.contentLen||'0'), p.dataset.hasMedia==='1');
                // Subtle visual indicator for fast-skipped posts
                p.classList.add('scroll-skipped');
              }
            }
          }
        }
      }
    }
    _lastScrollY = y; _lastScrollT = now;
  });
}, { passive: true });

// Not-interested action with smooth multi-stage dismiss
async function markNotInterested(postId, reason) {
  if (!S.user) return;
  haptic('medium');
  const el = document.getElementById('post-' + postId);
  if (el) {
    // Stage 1: fade + slide
    el.style.transition = 'opacity 0.2s ease, transform 0.25s var(--ease)';
    el.style.opacity = '0.3';
    el.style.transform = 'translateX(-20px) scale(0.97)';
    // Stage 2: collapse
    setTimeout(() => {
      el.style.maxHeight = el.scrollHeight + 'px';
      requestAnimationFrame(() => {
        el.classList.add('post-dismiss');
        el.style.maxHeight = '0';
      });
    }, 200);
    setTimeout(() => el.remove(), 600);
  }
  toast(S.lang === 'ja' ? 'この投稿を非表示にしました' : 'Post hidden', 'success');
  S.cache.posts = S.cache.posts.filter(p => p.id !== postId);
  api(`/api/posts/${postId}/not-interested`, { method: 'POST', body: { reason: reason || '' } });
}

function signalDetailView(pid, aid) { _pushSignal(pid, 'detail_view', 1, aid); }
function signalProfileClick(pid, aid) { _pushSignal(pid, 'profile_click', 1, aid); }

// Flush on page unload
window.addEventListener('beforeunload', () => {
  for (const [pid, t] of Object.entries(_sig.dwellTimers)) {
    if (!t.sent && t.start) {
      const sec = (Date.now() - t.start) / 1000;
      if (sec >= _sig.MIN_DWELL) _sig.queue.push({ post_id: pid, type: 'dwell', value: Math.round(sec * 10) / 10 });
    }
  }
  if (_sig.queue.length > 0) {
    try { navigator.sendBeacon('/api/signals', new Blob([JSON.stringify({ signals: _sig.queue.splice(0, 25) })], { type: 'application/json' })); } catch {}
  }
});

function _cleanupDwellTimers() {
  for (const [pid, t] of Object.entries(_sig.dwellTimers)) {
    if (!t.sent && t.start) {
      const sec = (Date.now() - t.start) / 1000;
      if (sec >= _sig.MIN_DWELL) _pushSignal(pid, 'dwell', Math.round(sec * 10) / 10);
    }
  }
  _sig.dwellTimers = {};
}

function _recordImpressions(posts) {
  if (!S.user || posts.length === 0) return;
  api('/api/feed/impressions', { method: 'POST', body: { impressions: posts.map((p, i) => ({ post_id: p.id, position: i })) } });
}

// === V23 FEED IMPROVEMENTS ===
let _splashFeedData = null;

function preloadFeedDuringSplash() {
  _splashFeedData = api('/api/posts?tab=recommended');
}

function _prefetchNextPage() {
  if (S.cache.feedDone || !S.cache.feedCursor || S.cache._prefetchedData || S.cache._prefetching) return;
  S.cache._prefetching = true;
  const apiTab = S.cache.feedTab === 'global' ? 'recommended' : (S.cache.feedTab === 'latest' ? 'global' : S.cache.feedTab);
  api(`/api/posts?tab=${apiTab}&cursor=${encodeURIComponent(S.cache.feedCursor)}`)
    .then(data => { S.cache._prefetchedData = data; })
    .catch(() => {})
    .finally(() => { S.cache._prefetching = false; });
}



// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => { 
  preloadFeedDuringSplash();
  initTheme(); 
  route(); 
  // Dismiss splash after a brief delay to let first paint complete
  setTimeout(() => dismissSplash(), 300);
  setTimeout(() => { const s = document.getElementById('splash'); if (s) s.remove(); }, 2000);
  initVisualViewport();
  initPullToRefresh();
  initContextMenu();
  initScrollAwareUI();
  // Age verification check
  if (S.user) checkAgeVerification();
  // PWA notification prompt for first-time users  
  if (S.user) setTimeout(() => showNotificationPrompt(), 5000);
  // Safety: force feed render if still blank after 2s (handles slow networks)
  setTimeout(() => {
    const feed = $('#feed');
    if (feed && S.currentPage === 'home') {
      const hasPosts = feed.querySelector('.post');
      const hasEmpty = feed.querySelector('[style*="text-align:center"]');
      if (!hasPosts && !hasEmpty && !feedLoading) {
        _splashFeedData = null;
        _apiCache.clear();
        S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false;
        loadFeed(true);
      }
    }
  }, 2000);
  // Additional safety: try again at 4s
  setTimeout(() => {
    const feed = $('#feed');
    if (feed && S.currentPage === 'home') {
      const hasPosts = feed.querySelector('.post');
      const hasEmpty = feed.querySelector('[style*="text-align:center"]');
      if (!hasPosts && !hasEmpty && !feedLoading) {
        _splashFeedData = null;
        _apiCache.clear();
        S.cache.posts = []; S.cache.feedCursor = null; S.cache.feedDone = false;
        loadFeed(true);
      }
    }
  }, 4000);
  // Attach link previews via IntersectionObserver (replaces expensive setInterval)
  if (window.IntersectionObserver) {
    const _lpObserver = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) attachLinkPreviews(); });
    }, { rootMargin: '200px' });
    const _lpTarget = document.getElementById('app');
    if (_lpTarget) _lpObserver.observe(_lpTarget);
  } else { setInterval(attachLinkPreviews, 3000); }
  // Check online status
  window.addEventListener('online', () => { toast(S.lang==='ja'?'オンラインに復帰':'Back online', 'success'); });
  window.addEventListener('offline', () => { toast(S.lang==='ja'?'オフラインです':'You are offline', 'error'); });
});

Object.assign(window, {
  navigate, setTheme, toggleLang, logout,
  switchFeedTab, submitPost, composeImage, removeComposeImage, toggleColorPicker, selectTextColor,
  toggleComposePoll, addPollOption,
  toggleLike, deletePost, viewImage, refreshFeed, toggleReadMore, ratePost,
  showKoremiteModal, submitKoremite, votePoll,
  doLogin, doRegister, onComposeInput,
  changePassword, pageSettings,
  sanitizeContent, changeNickname, updatePrivacySetting, unblockUser,
  // Admin (stubs, overridden by admin.js)
  switchAdminTab, searchAdminUsers, debounceAdminUserSearch,
  adminBanUser, confirmAdminBan, adminUnbanUser,
  adminSuspendUser, confirmAdminSuspend, adminUnsuspendUser,
  adminSetRole, confirmAdminSetRole,
  createAnnouncement, deleteAnnouncement, updateRateLimit, loadHelpAnnouncements,
  adminSetOfficial, adminTransfer, adminDeleteAllPosts,
  addSpamWord, deleteSpamWord, loadAdminImages, uploadSiteImage, saveSiteImage, deleteSiteImage,
  // PWA
  pwaInstall, showPWAFallbackModal,
  // Casino (lazy-loaded)
  loadCasinoPage,
  // Pin, Hashtag, LINE
  togglePinPost, showLineLogin, handleLineCallback,
  formatContent, pageLegal,
  // Search
  debounceSearch, performSearch, showSearchPanel, hideSearchPanel, clearSearch,
  // Features
  haptic, showCustomContextMenu,
  openSearchPage, pageSearch, refreshFeedAsync,
  initScrollAwareUI,
  // Navigation & QR & Reporting
  navigateToPost, showQRModal, showDualCameraModal, closeDualCamera, captureDualPhoto,
  showReportModal, submitReport, showDeleteAccountModal,
  showNotificationPrompt, requestNotifPermission, dismissNotifPrompt,
  loadAdminReports, reviewReport, adminDeleteReportedPost, adminDeleteAccount, adminRemoveOfficial,
  attachLinkPreviews, updateMediaSession,
  // Age/R18/Video
  checkAgeVerification, submitAgeVerification, showAgeVerificationModal,
  showR18PreferenceModal, setR18Preference,
  composeVideo, removeComposeVideo, toggleComposeFlags, composeMedia, toggleComposeMore, closeComposeMore,
  toggleVideoPlay, toggleVideoMute, seekVideo, toggleVideoFullscreen,
  openQRScanner, stopQRScanner, updateR18Setting,
  executeDBQuery, loadAdminDBOps,
  // Drafts/Bookmarks/Admin flags
  saveDraft, deleteDraft, restoreDraft, showDraftsModal, saveDraftFromComposer,
  toggleBookmark, showBookmarks, togglePostMore, closeBottomSheet,
  showAdminPostFlagsModal, submitAdminPostFlags,
  saveContentPolicy, saveAblyKey, adminDeleteFeedPost,
  // Official mark management
  loadAdminOfficialUsers, loadOfficialUsersList, showGrantOfficialModal, searchUsersForOfficial,
  grantOfficialMark, confirmRemoveOfficial,
  // Notification settings
  loadNotificationSettings, updateNotifSetting, unmuteDMUser, unmuteCrewNotif,
  // v25 Engagement engine
  preloadFeedDuringSplash, _prefetchNextPage, _splashFeedData,
  trackPostView, flushSeenPosts, observePost, signalDetailView, signalProfileClick,
  markNotInterested, _pushSignal, _flushSignals, _initDwellObserver, _cleanupDwellTimers, _recordImpressions,
});
