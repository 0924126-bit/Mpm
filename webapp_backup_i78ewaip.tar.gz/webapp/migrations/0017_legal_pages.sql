-- Legal pages (Terms of Service, Privacy Policy) stored in site_settings
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('legal_terms_ja', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('legal_terms_en', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('legal_privacy_ja', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('legal_privacy_en', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('legal_updated_at', '');
