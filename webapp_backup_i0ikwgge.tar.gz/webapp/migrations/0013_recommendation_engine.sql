-- Recommendation Engine Tables
-- 1. Engagement signals (dwell time, scroll skip, etc.)
CREATE TABLE IF NOT EXISTS engagement_signals (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  signal_type TEXT NOT NULL,
  signal_value REAL DEFAULT 1.0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_signals_user ON engagement_signals(user_id, signal_type);
CREATE INDEX IF NOT EXISTS idx_signals_post ON engagement_signals(post_id, signal_type);
CREATE INDEX IF NOT EXISTS idx_signals_created ON engagement_signals(created_at);

-- 2. User topic interests (hashtag-based)
CREATE TABLE IF NOT EXISTS user_topic_interests (
  user_id TEXT NOT NULL,
  topic TEXT NOT NULL,
  score REAL DEFAULT 0.0,
  interaction_count INTEGER DEFAULT 0,
  last_interaction DATETIME,
  PRIMARY KEY (user_id, topic)
);

-- 3. Post quality cache
CREATE TABLE IF NOT EXISTS post_quality_cache (
  post_id TEXT PRIMARY KEY,
  like_count INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  bookmark_count INTEGER DEFAULT 0,
  avg_dwell_time REAL DEFAULT 0,
  total_views INTEGER DEFAULT 0,
  engagement_rate REAL DEFAULT 0,
  negative_signals INTEGER DEFAULT 0,
  quality_score REAL DEFAULT 0,
  has_media INTEGER DEFAULT 0,
  has_hashtags INTEGER DEFAULT 0,
  content_length INTEGER DEFAULT 0,
  updated_at DATETIME
);

-- 4. User similarity (collaborative filtering)
CREATE TABLE IF NOT EXISTS user_similarity (
  user_a TEXT NOT NULL,
  user_b TEXT NOT NULL,
  similarity_score REAL DEFAULT 0.0,
  common_interactions INTEGER DEFAULT 0,
  updated_at DATETIME,
  PRIMARY KEY (user_a, user_b)
);

-- 5. Feed impressions
CREATE TABLE IF NOT EXISTS feed_impressions (
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  position INTEGER DEFAULT 0,
  was_engaged INTEGER DEFAULT 0,
  shown_at DATETIME,
  PRIMARY KEY (user_id, post_id)
);

-- 6. Trending cache
CREATE TABLE IF NOT EXISTS trending_cache (
  topic TEXT PRIMARY KEY,
  post_count INTEGER DEFAULT 0,
  engagement_sum REAL DEFAULT 0,
  trending_score REAL DEFAULT 0,
  window_start DATETIME,
  updated_at DATETIME
);

-- 7. Not interested
CREATE TABLE IF NOT EXISTS not_interested (
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  author_id TEXT DEFAULT '',
  reason TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_ni_user ON not_interested(user_id);

-- 8. Blacklist for real-time topic exclusion
CREATE TABLE IF NOT EXISTS user_blacklist (
  user_id TEXT NOT NULL,
  blacklist_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, blacklist_type, target_id)
);
CREATE INDEX IF NOT EXISTS idx_bl_user ON user_blacklist(user_id, blacklist_type);

-- 9. Extend user_interests with granular scores
ALTER TABLE user_interests ADD COLUMN like_score REAL DEFAULT 0.0;
ALTER TABLE user_interests ADD COLUMN reply_score REAL DEFAULT 0.0;
ALTER TABLE user_interests ADD COLUMN dwell_score REAL DEFAULT 0.0;
ALTER TABLE user_interests ADD COLUMN negative_score REAL DEFAULT 0.0;

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_posts_created_user ON posts(created_at DESC, user_id);
CREATE INDEX IF NOT EXISTS idx_quality_score ON post_quality_cache(quality_score DESC);
CREATE INDEX IF NOT EXISTS idx_trending ON trending_cache(trending_score DESC);
CREATE INDEX IF NOT EXISTS idx_topic_user ON user_topic_interests(user_id, score DESC);
CREATE INDEX IF NOT EXISTS idx_sim_user ON user_similarity(user_a, similarity_score DESC);
