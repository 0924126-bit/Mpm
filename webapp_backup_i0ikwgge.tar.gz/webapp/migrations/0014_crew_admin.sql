-- Crew member bans
CREATE TABLE IF NOT EXISTS crew_bans (
  id TEXT PRIMARY KEY,
  crew_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  banned_by TEXT NOT NULL,
  reason TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(crew_id, user_id)
);

-- Crew member timeouts
CREATE TABLE IF NOT EXISTS crew_timeouts (
  id TEXT PRIMARY KEY,
  crew_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  timed_out_by TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  reason TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Crew audit log
CREATE TABLE IF NOT EXISTS crew_audit_log (
  id TEXT PRIMARY KEY,
  crew_id TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target_id TEXT DEFAULT '',
  details TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_crew_bans_crew ON crew_bans(crew_id);
CREATE INDEX IF NOT EXISTS idx_crew_timeouts_crew ON crew_timeouts(crew_id);
CREATE INDEX IF NOT EXISTS idx_crew_audit_crew ON crew_audit_log(crew_id);
CREATE INDEX IF NOT EXISTS idx_crew_timeouts_expires ON crew_timeouts(expires_at);
