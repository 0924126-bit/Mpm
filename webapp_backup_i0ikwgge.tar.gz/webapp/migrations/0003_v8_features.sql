-- v8: Pinned posts, coins, koremite (quote-retweet), post edits, timed posts, polls, blocks, ghost blocks, profile URL/media

-- Add profile URL and coin balance to users
ALTER TABLE users ADD COLUMN profile_url TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN coins INTEGER DEFAULT 0;

-- Pinned posts (max 3 per user)
CREATE TABLE IF NOT EXISTS pinned_posts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  position INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (post_id) REFERENCES posts(id)
);
CREATE INDEX IF NOT EXISTS idx_pinned_user ON pinned_posts(user_id);

-- Koremite (quote-retweet)
ALTER TABLE posts ADD COLUMN quote_of_id TEXT DEFAULT '';

-- Timed posts (auto-delete)
ALTER TABLE posts ADD COLUMN expires_at DATETIME DEFAULT NULL;

-- Post edits history
CREATE TABLE IF NOT EXISTS post_edits (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  old_content TEXT NOT NULL,
  new_content TEXT NOT NULL,
  edited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES posts(id)
);
CREATE INDEX IF NOT EXISTS idx_edits_post ON post_edits(post_id);

-- Polls
CREATE TABLE IF NOT EXISTS polls (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  expires_at DATETIME DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES posts(id)
);

CREATE TABLE IF NOT EXISTS poll_options (
  id TEXT PRIMARY KEY,
  poll_id TEXT NOT NULL,
  text TEXT NOT NULL,
  position INTEGER DEFAULT 0,
  FOREIGN KEY (poll_id) REFERENCES polls(id)
);

CREATE TABLE IF NOT EXISTS poll_votes (
  poll_id TEXT NOT NULL,
  option_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (poll_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_pv_poll ON poll_votes(poll_id);
CREATE INDEX IF NOT EXISTS idx_pv_option ON poll_votes(option_id);

-- Blocks and ghost blocks
CREATE TABLE IF NOT EXISTS blocks (
  blocker_id TEXT NOT NULL,
  blocked_id TEXT NOT NULL,
  is_ghost INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (blocker_id, blocked_id)
);
CREATE INDEX IF NOT EXISTS idx_blocks_blocker ON blocks(blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON blocks(blocked_id);

-- DM message deletion notifications
ALTER TABLE messages ADD COLUMN deleted_at DATETIME DEFAULT NULL;
ALTER TABLE messages ADD COLUMN delete_notified INTEGER DEFAULT 0;

-- Coin transactions
CREATE TABLE IF NOT EXISTS coin_transactions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  type TEXT NOT NULL,
  ref_id TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_coins_user ON coin_transactions(user_id);
