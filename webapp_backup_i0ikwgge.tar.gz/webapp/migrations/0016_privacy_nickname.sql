-- Add is_private column to users table (0 = public, 1 = private account)
ALTER TABLE users ADD COLUMN is_private INTEGER DEFAULT 0;
