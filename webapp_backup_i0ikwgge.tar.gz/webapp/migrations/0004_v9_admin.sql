-- v9: Admin system, post ratings, coin throws, admin actions

-- Add admin columns to users
ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user';
ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN ban_reason TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN is_suspended INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN suspended_until DATETIME DEFAULT NULL;

-- Admin announcements
CREATE TABLE IF NOT EXISTS admin_announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  author_id TEXT NOT NULL,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id)
);

-- Rate limit configuration
CREATE TABLE IF NOT EXISTS rate_limit_config (
  key TEXT PRIMARY KEY,
  value INTEGER NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO rate_limit_config (key, value) VALUES ('posts_per_minute', 5);
INSERT OR IGNORE INTO rate_limit_config (key, value) VALUES ('messages_per_minute', 30);
INSERT OR IGNORE INTO rate_limit_config (key, value) VALUES ('dm_per_minute', 20);

-- Post ratings (for downvote/hide algorithm)
CREATE TABLE IF NOT EXISTS post_ratings (
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  rating INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_pr_post ON post_ratings(post_id);

-- Coin throws
CREATE TABLE IF NOT EXISTS coin_throws (
  id TEXT PRIMARY KEY,
  sender_id TEXT NOT NULL,
  receiver_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  message TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sender_id) REFERENCES users(id),
  FOREIGN KEY (receiver_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_ct_receiver ON coin_throws(receiver_id);

-- Admin action log
CREATE TABLE IF NOT EXISTS admin_actions (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL,
  action_type TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  reason TEXT DEFAULT '',
  details TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_aa_admin ON admin_actions(admin_id);
CREATE INDEX IF NOT EXISTS idx_aa_target ON admin_actions(target_type, target_id);
