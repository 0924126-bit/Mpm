-- v20: Reports, Account Deletion, Voice Room Icons, Shop Inventory, Link Previews

-- Reports table
CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  reporter_id TEXT NOT NULL,
  target_type TEXT NOT NULL DEFAULT 'post', -- 'post' or 'user'
  target_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, reviewed, dismissed
  admin_note TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME,
  reviewed_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_target ON reports(target_type, target_id);

-- Soft-delete columns for users
-- ALTER TABLE users ADD COLUMN is_deleted INTEGER DEFAULT 0;
-- ALTER TABLE users ADD COLUMN deleted_at DATETIME;
-- Using CREATE TABLE IF NOT EXISTS approach instead of ALTER to be safe
-- We'll handle these columns in the app code

-- Shop inventory (purchased items persist across sessions)
CREATE TABLE IF NOT EXISTS user_inventory (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  item_type TEXT NOT NULL,
  item_value TEXT NOT NULL,
  purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, item_type, item_value)
);
CREATE INDEX IF NOT EXISTS idx_inventory_user ON user_inventory(user_id);

-- Voice room icon
-- voice_rooms already has columns, we add icon_url if not present

-- Link preview cache
CREATE TABLE IF NOT EXISTS link_previews (
  url TEXT PRIMARY KEY,
  title TEXT,
  description TEXT,
  image TEXT,
  site_name TEXT,
  fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
