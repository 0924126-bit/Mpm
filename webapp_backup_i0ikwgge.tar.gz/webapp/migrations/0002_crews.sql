-- Crews
CREATE TABLE IF NOT EXISTS crews (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  icon_url TEXT DEFAULT '',
  banner_url TEXT DEFAULT '',
  owner_id TEXT NOT NULL,
  is_public INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS crew_members (
  crew_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT DEFAULT 'member',
  nickname TEXT DEFAULT '',
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (crew_id, user_id)
);

CREATE TABLE IF NOT EXISTS crew_channels (
  id TEXT PRIMARY KEY,
  crew_id TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT DEFAULT 'text',
  position INTEGER DEFAULT 0,
  topic TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (crew_id) REFERENCES crews(id)
);

CREATE TABLE IF NOT EXISTS crew_messages (
  id TEXT PRIMARY KEY,
  channel_id TEXT NOT NULL,
  sender_id TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (channel_id) REFERENCES crew_channels(id),
  FOREIGN KEY (sender_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS crew_roles (
  id TEXT PRIMARY KEY,
  crew_id TEXT NOT NULL,
  name TEXT NOT NULL,
  color TEXT DEFAULT '#ff6b9d',
  position INTEGER DEFAULT 0,
  permissions TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (crew_id) REFERENCES crews(id)
);

CREATE TABLE IF NOT EXISTS crew_voice_members (
  channel_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  is_muted INTEGER DEFAULT 0,
  peer_id TEXT DEFAULT '',
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (channel_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_crews_owner ON crews(owner_id);
CREATE INDEX IF NOT EXISTS idx_cm_user ON crew_members(user_id);
CREATE INDEX IF NOT EXISTS idx_cm_crew ON crew_members(crew_id);
CREATE INDEX IF NOT EXISTS idx_cc_crew ON crew_channels(crew_id);
CREATE INDEX IF NOT EXISTS idx_cmsg_channel ON crew_messages(channel_id, created_at);
CREATE INDEX IF NOT EXISTS idx_cmsg_sender ON crew_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_cr_crew ON crew_roles(crew_id);
