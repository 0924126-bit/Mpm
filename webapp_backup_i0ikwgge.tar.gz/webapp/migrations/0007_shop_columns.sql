-- Add shop and cosmetic columns to users table
ALTER TABLE users ADD COLUMN is_official INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN name_color TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN bg_color TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN badge TEXT DEFAULT '';

-- Shop purchases table
CREATE TABLE IF NOT EXISTS shop_purchases (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  item_type TEXT NOT NULL,
  item_value TEXT NOT NULL,
  cost INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sp_user ON shop_purchases(user_id);

-- Coin throws table
CREATE TABLE IF NOT EXISTS coin_throws (
  id TEXT PRIMARY KEY,
  sender_id TEXT NOT NULL,
  receiver_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  message TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ct_recv ON coin_throws(receiver_id, created_at DESC);
