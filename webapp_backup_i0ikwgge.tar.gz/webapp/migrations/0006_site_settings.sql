-- Site settings table for admin-configurable images and settings
CREATE TABLE IF NOT EXISTS site_settings (
  key TEXT PRIMARY KEY,
  value TEXT DEFAULT '',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Seed default image settings
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('img_splash_image', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('img_auth_logo', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('img_sidebar_logo', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('img_empty_state', '');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('img_pwa_icon', '');
