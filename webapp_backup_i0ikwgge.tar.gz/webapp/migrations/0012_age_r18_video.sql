-- v12: Age verification, R18 content, AI-generated flag, Video support, Admin DB operations

-- Age verification columns on users
ALTER TABLE users ADD COLUMN age_verified INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN is_adult INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN show_r18 INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN app_version TEXT DEFAULT '';

-- Post content flags
ALTER TABLE posts ADD COLUMN is_r18 INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN is_ai_generated INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN video_url TEXT DEFAULT '';

-- Voice room icon (ensure column exists)
-- Already handled via ALTER in app code, but ensure migration-safe

-- Admin DB query log
CREATE TABLE IF NOT EXISTS admin_db_queries (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL,
  query_text TEXT NOT NULL,
  result_text TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_admin_db_queries_admin ON admin_db_queries(admin_id);

-- Notification improvements: track which post was liked
-- notifications table already has target_id which stores the post_id for 'like' type

-- Index for faster R18 filtering
CREATE INDEX IF NOT EXISTS idx_posts_r18 ON posts(is_r18);
CREATE INDEX IF NOT EXISTS idx_users_age ON users(age_verified, is_adult);
