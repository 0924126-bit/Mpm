-- v15: Thread backtrack, pinned posts, mentions, hashtags, casino, LINE auth

-- Pinned posts table (max 3 per user)
CREATE TABLE IF NOT EXISTS pinned_posts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  position INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_pp_user ON pinned_posts(user_id, position);

-- Hashtags table
CREATE TABLE IF NOT EXISTS hashtags (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  post_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ht_name ON hashtags(name);

-- Post-hashtag association
CREATE TABLE IF NOT EXISTS post_hashtags (
  post_id TEXT NOT NULL,
  hashtag_id TEXT NOT NULL,
  PRIMARY KEY(post_id, hashtag_id)
);
CREATE INDEX IF NOT EXISTS idx_ph_ht ON post_hashtags(hashtag_id);

-- Mentions
CREATE TABLE IF NOT EXISTS mentions (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  mentioned_user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mentions_user ON mentions(mentioned_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mentions_post ON mentions(post_id);

-- LINE login
ALTER TABLE users ADD COLUMN line_user_id TEXT DEFAULT '';

-- Casino game records
CREATE TABLE IF NOT EXISTS casino_bets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  game TEXT NOT NULL,
  bet_amount INTEGER NOT NULL,
  win_amount INTEGER DEFAULT 0,
  result TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_casino_user ON casino_bets(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_casino_game ON casino_bets(game, created_at DESC);
