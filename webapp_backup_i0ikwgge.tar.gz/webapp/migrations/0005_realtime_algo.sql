-- v10: Post views tracking for recommendation algorithm, WebSocket support

-- Track which posts each user has seen (for lowering priority of seen posts)
CREATE TABLE IF NOT EXISTS post_views (
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  view_count INTEGER DEFAULT 1,
  last_viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_pv_user ON post_views(user_id, last_viewed_at DESC);

-- Track user engagement patterns for better recommendations
CREATE TABLE IF NOT EXISTS user_interests (
  user_id TEXT NOT NULL,
  interest_user_id TEXT NOT NULL,
  score INTEGER DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, interest_user_id)
);
CREATE INDEX IF NOT EXISTS idx_ui_user ON user_interests(user_id, score DESC);
