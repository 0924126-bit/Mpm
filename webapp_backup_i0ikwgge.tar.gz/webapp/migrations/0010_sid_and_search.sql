-- Add permanent stable ID (sid) to users - never changes even if username changes
ALTER TABLE users ADD COLUMN sid TEXT DEFAULT '';

-- Populate sid for existing users using their id (first 12 chars)
UPDATE users SET sid = SUBSTR(id, 1, 12) WHERE sid = '' OR sid IS NULL;

-- Create index for sid lookups
CREATE INDEX IF NOT EXISTS idx_users_sid ON users(sid);

-- Full-text search support: Create search index table for posts
CREATE TABLE IF NOT EXISTS post_search_index (
  post_id TEXT PRIMARY KEY,
  content_lower TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Index for search
CREATE INDEX IF NOT EXISTS idx_post_search_content ON post_search_index(content_lower);
CREATE INDEX IF NOT EXISTS idx_post_search_time ON post_search_index(created_at DESC);
