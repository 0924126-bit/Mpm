-- Notification settings per user
CREATE TABLE IF NOT EXISTS notification_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  -- Global notification types
  notif_follow INTEGER DEFAULT 1,
  notif_like INTEGER DEFAULT 1,
  notif_reply INTEGER DEFAULT 1,
  notif_quote INTEGER DEFAULT 1,
  notif_coin INTEGER DEFAULT 1,
  notif_koremite INTEGER DEFAULT 1,
  -- DM notifications
  notif_dm_global INTEGER DEFAULT 1,
  -- Crew notifications
  notif_crew_global INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id)
);

-- Per-user DM mute (mute specific user DMs)
CREATE TABLE IF NOT EXISTS dm_notification_mutes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  muted_user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, muted_user_id)
);

-- Per-crew notification mute
CREATE TABLE IF NOT EXISTS crew_notification_mutes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  crew_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, crew_id)
);
