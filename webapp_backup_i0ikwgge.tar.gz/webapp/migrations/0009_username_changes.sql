-- v16: Username change tracking for user ID edit feature

CREATE TABLE IF NOT EXISTS username_changes (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  old_username TEXT NOT NULL,
  new_username TEXT NOT NULL,
  changed_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_uc_user ON username_changes(user_id, changed_at DESC);
