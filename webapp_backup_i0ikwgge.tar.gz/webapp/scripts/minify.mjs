#!/usr/bin/env node
/**
 * Post-build minification script for Satocchi
 * Minifies JS and CSS files in public/static/ for production
 */
import { readFileSync, writeFileSync, readdirSync, statSync } from 'fs';
import { resolve, extname } from 'path';
import { minify } from 'terser';

const staticDir = resolve(process.cwd(), 'dist/static');

async function minifyJS(filePath) {
  const code = readFileSync(filePath, 'utf-8');
  const originalSize = Buffer.byteLength(code, 'utf-8');
  
  const result = await minify(code, {
    compress: {
      dead_code: true,
      drop_console: false,
      drop_debugger: true,
      passes: 3,
      pure_funcs: ['console.log'],
      unsafe_math: true,
      collapse_vars: true,
      reduce_vars: true,
      hoist_funs: true,
      hoist_vars: false,
      join_vars: true,
      sequences: true,
      conditionals: true,
      comparisons: true,
      evaluate: true,
      booleans: true,
      typeofs: true,
      if_return: true,
      loops: true,
      unused: true,
      toplevel: false,
      arrows: true,
      ecma: 2020,
      module: false,
    },
    mangle: {
      toplevel: false,
      properties: false,
      eval: false,
    },
    output: {
      comments: false,
      semicolons: true,
      wrap_iife: false,
      ecma: 2020,
      beautify: false,
      max_line_len: false,
    },
    ecma: 2020,
    module: false,
  });
  
  if (result.code) {
    writeFileSync(filePath, result.code);
    const newSize = Buffer.byteLength(result.code, 'utf-8');
    const savings = ((1 - newSize / originalSize) * 100).toFixed(1);
    console.log(`  JS: ${filePath.split('/').pop()} ${(originalSize/1024).toFixed(1)}KB -> ${(newSize/1024).toFixed(1)}KB (${savings}% smaller)`);
  }
}

function minifyCSS(filePath) {
  const css = readFileSync(filePath, 'utf-8');
  const originalSize = Buffer.byteLength(css, 'utf-8');
  
  // Simple but effective CSS minification
  let minified = css
    // Remove comments
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // Remove whitespace around selectors and properties
    .replace(/\s*([{}:;,>~+])\s*/g, '$1')
    // Remove unnecessary semicolons
    .replace(/;}/g, '}')
    // Remove leading/trailing whitespace per line
    .replace(/^\s+|\s+$/gm, '')
    // Collapse multiple spaces
    .replace(/\s{2,}/g, ' ')
    // Remove newlines
    .replace(/\n/g, '')
    // Optimize colors
    .replace(/#([0-9a-fA-F])\1([0-9a-fA-F])\2([0-9a-fA-F])\3/g, '#$1$2$3')
    // Remove units from zero values
    .replace(/(:|\s)0(px|em|rem|%|vh|vw|vmin|vmax)/g, '${1}0')
    // Trim
    .trim();
    
  writeFileSync(filePath, minified);
  const newSize = Buffer.byteLength(minified, 'utf-8');
  const savings = ((1 - newSize / originalSize) * 100).toFixed(1);
  console.log(`  CSS: ${filePath.split('/').pop()} ${(originalSize/1024).toFixed(1)}KB -> ${(newSize/1024).toFixed(1)}KB (${savings}% smaller)`);
}

async function main() {
  console.log('[Minify] Starting minification...');
  
  const files = readdirSync(staticDir);
  for (const file of files) {
    const filePath = resolve(staticDir, file);
    const stat = statSync(filePath);
    if (!stat.isFile()) continue;
    
    const ext = extname(file);
    if (ext === '.js') {
      await minifyJS(filePath);
    } else if (ext === '.css') {
      minifyCSS(filePath);
    }
  }
  
  console.log('[Minify] Done!');
}

main().catch(e => { console.error(e); process.exit(1); });
