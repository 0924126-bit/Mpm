// ===== ADMIN MODULE (loaded only for admin users) =====
// Served via /api/modules/admin.js with authentication check

// ===== ADMIN =====
var adminTab = 'dashboard';
async function _pageAdmin(el) {
  if (!S.user || (S.user.role !== 'admin' && S.user.role !== 'superadmin')) { navigate('/'); return; }
  el.innerHTML = `
    <div class="page-header" style="padding:20px 24px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
        <button class="btn-icon mobile-only" onclick="history.back()"><i class="fas fa-arrow-left"></i></button>
        <span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700"><i class="fas fa-shield-halved" style="color:var(--accent);margin-right:8px"></i>Admin</span>
      </div>
      <div class="tab-bar" id="admin-tabs" style="overflow-x:auto;flex-wrap:nowrap;-webkit-overflow-scrolling:touch">
        <div class="tab-item ${adminTab==='dashboard'?'active':''}" onclick="switchAdminTab('dashboard')">Dashboard</div>
        <div class="tab-item ${adminTab==='users'?'active':''}" onclick="switchAdminTab('users')">${S.lang==='ja'?'ユーザー':'Users'}</div>
        <div class="tab-item ${adminTab==='official'?'active':''}" onclick="switchAdminTab('official')" style="white-space:nowrap">${S.lang==='ja'?'<i class="fas fa-check-circle" style="color:var(--sky);margin-right:3px"></i>公式':'<i class="fas fa-check-circle" style="color:var(--sky);margin-right:3px"></i>Official'}</div>
        <div class="tab-item ${adminTab==='announce'?'active':''}" onclick="switchAdminTab('announce')">${S.lang==='ja'?'アナウンス':'Announce'}</div>
        <div class="tab-item ${adminTab==='config'?'active':''}" onclick="switchAdminTab('config')">${S.lang==='ja'?'設定':'Config'}</div>
        <div class="tab-item ${adminTab==='spam'?'active':''}" onclick="switchAdminTab('spam')">${S.lang==='ja'?'スパム':'Spam'}</div>
        <div class="tab-item ${adminTab==='ipmon'?'active':''}" onclick="switchAdminTab('ipmon')">IP</div>
        <div class="tab-item ${adminTab==='images'?'active':''}" onclick="switchAdminTab('images')">${S.lang==='ja'?'画像':'Images'}</div>
        <div class="tab-item ${adminTab==='reports'?'active':''}" onclick="switchAdminTab('reports')">${S.lang==='ja'?'通報':'Reports'}</div>
        <div class="tab-item ${adminTab==='legal'?'active':''}" onclick="switchAdminTab('legal')">${S.lang==='ja'?'規約':'Legal'}</div>
        ${S.user.role==='superadmin'?`<div class="tab-item ${adminTab==='dbops'?'active':''}" onclick="switchAdminTab('dbops')">DB</div>`:''}
        <div class="tab-indicator" id="admin-tab-indicator"></div>
      </div>
    </div>
    <div id="admin-content"><div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div>
    <div class="mobile-nav-spacer"></div>`;
  requestAnimationFrame(() => { const ind = $('#admin-tab-indicator'), active = $('#admin-tabs .tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } });
  loadAdminTab(adminTab);
}

function switchAdminTab(tab) {
  adminTab = tab;
  $$('#admin-tabs .tab-item').forEach((t2) => { const txt = t2.textContent.toLowerCase(); t2.classList.toggle('active', t2.getAttribute('onclick')?.includes("'"+tab+"'") ); });
  requestAnimationFrame(() => { const ind = $('#admin-tab-indicator'), active = $('#admin-tabs .tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } });
  loadAdminTab(tab);
}

async function loadAdminTab(tab) {
  const el = $('#admin-content'); if (!el) return;
  el.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`;
  if (tab === 'dashboard') await loadAdminDashboard(el);
  else if (tab === 'users') await loadAdminUsers(el);
  else if (tab === 'official') await loadAdminOfficialUsers(el);
  else if (tab === 'announce') await loadAdminAnnouncements(el);
  else if (tab === 'config') await loadAdminConfig(el);
  else if (tab === 'spam') await loadAdminSpamWords(el);
  else if (tab === 'ipmon') await loadAdminIPMonitor(el);
  else if (tab === 'images') await loadAdminImages(el);
  else if (tab === 'reports') await loadAdminReports(el);
  else if (tab === 'legal') await loadAdminLegal(el);
  else if (tab === 'dbops') await loadAdminDBOps(el);
}

async function loadAdminDashboard(el) {
  const res = await api('/api/admin/dashboard');
  if (res.error) { el.innerHTML = `<div style="padding:24px;color:var(--accent)">${res.error}</div>`; return; }
  const s = res.stats || {};
  el.innerHTML = `<div style="padding:24px">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px;margin-bottom:28px">
      ${[['Users',s.users,'fa-users','var(--sky)'],['Posts',s.posts,'fa-pen','var(--accent)'],['Rooms',s.active_rooms,'fa-headphones','var(--sage)'],['Crews',s.crews,'fa-users','var(--violet)'],['Banned',s.banned,'fa-ban','var(--accent)'],['Downvotes',s.reports,'fa-thumbs-down','var(--sand)']].map(([l,v,i,c]) =>
        `<div style="padding:18px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);text-align:center"><i class="fas ${i}" style="font-size:22px;color:${c};margin-bottom:8px;display:block"></i><div style="font-size:28px;font-weight:700">${v||0}</div><div style="font-size:11px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em">${l}</div></div>`).join('')}
    </div>
    <h3 style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'最近のユーザー':'RECENT USERS'}</h3>
    <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:28px">${(res.recent_users||[]).slice(0,8).map(u =>
      `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm)">
        ${avatar(u.avatar_url, u.display_name, 32)}
        <div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(u.display_name)} <span style="color:var(--text-tertiary);font-weight:400;font-size:12px">@${esc(u.username)}</span></div></div>
        ${u.is_banned ? '<span style="font-size:10px;color:white;background:var(--accent);padding:2px 8px;border-radius:var(--radius-full);font-weight:700">BAN</span>' : ''}
        <span style="font-size:11px;color:var(--text-tertiary);font-weight:600">${u.role||'user'}</span>
        <span style="font-size:11px;color:var(--text-tertiary)">${timeAgo(u.created_at)}</span>
      </div>`).join('')}
    </div>
    <h3 style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'最近の操作':'RECENT ACTIONS'}</h3>
    <div style="display:flex;flex-direction:column;gap:4px">${(res.recent_actions||[]).slice(0,10).map(a =>
      `<div style="padding:8px 12px;font-size:13px;color:var(--text-secondary);background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm)">
        <span style="font-weight:600">${esc(a.admin_display_name||a.admin_username)}</span>
        <span style="color:var(--accent);font-weight:600;margin:0 4px">${a.action_type}</span>
        <span>${a.target_type} ${a.target_id?.substring(0,8)}</span>
        ${a.reason ? `<span style="color:var(--text-tertiary)"> — ${esc(a.reason)}</span>` : ''}
        <span style="float:right;color:var(--text-tertiary);font-size:11px">${timeAgo(a.created_at)}</span>
      </div>`).join('') || `<div style="padding:20px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'なし':'None'}</div>`}
    </div>
  </div>`;
}


// ===== ADMIN: Official Mark Management (rebuilt from scratch) =====
async function loadAdminOfficialUsers(el) {
  el.innerHTML = `<div style="padding:24px">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px">
      <div style="flex:1">
        <h3 style="font-size:16px;font-weight:700;margin-bottom:4px"><i class="fas fa-check-circle" style="color:var(--sky);margin-right:6px"></i>${S.lang==='ja'?'公式マーク管理':'Official Mark Management'}</h3>
        <p style="font-size:12px;color:var(--text-tertiary)">${S.lang==='ja'?'公式マークの付与・解除をここで管理します':'Manage official verification badges here'}</p>
      </div>
      <button class="btn btn-primary btn-sm" onclick="showGrantOfficialModal()"><i class="fas fa-plus" style="margin-right:4px"></i>${S.lang==='ja'?'公式を付与':'Grant Official'}</button>
    </div>
    <div id="official-users-list"><div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div>
  </div>`;
  loadOfficialUsersList();
}

async function loadOfficialUsersList() {
  const list = document.getElementById('official-users-list'); if (!list) return;
  const res = await api('/api/admin/official-users');
  const users = res.users || [];
  const total = res.total || 0;
  if (users.length === 0) {
    list.innerHTML = `<div style="padding:40px;text-align:center;color:var(--text-tertiary)"><i class="fas fa-user-check" style="font-size:36px;margin-bottom:12px;display:block;opacity:0.3"></i>${S.lang==='ja'?'公式ユーザーはいません':'No official users'}</div>`;
    return;
  }
  list.innerHTML = `<div style="font-size:12px;color:var(--text-tertiary);margin-bottom:12px;font-weight:600">${S.lang==='ja'?'公式ユーザー':'Official Users'}: ${total}${S.lang==='ja'?'人':''}  </div>` + users.map(u => `
    <div style="display:flex;align-items:center;gap:12px;padding:14px 16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);margin-bottom:8px;animation:shopItemIn 0.3s ease-out both">
      ${avatar(u.avatar_url, u.display_name, 42)}
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-weight:600;font-size:14px">${esc(u.display_name)}</span>
          <span class="official-badge" title="Official"><i class="fas fa-check-circle"></i></span>
        </div>
        <div style="font-size:12px;color:var(--text-tertiary)">@${esc(u.username)} · ${u.role||'user'} · ${S.lang==='ja'?'付与日':'Since'}: ${timeAgo(u.created_at)}</div>
      </div>
      <button class="btn btn-danger btn-xs" style="white-space:nowrap;min-width:100px" onclick="confirmRemoveOfficial('${u.id}','${esc(u.display_name)}')">
        <i class="fas fa-times-circle" style="margin-right:4px"></i>${S.lang==='ja'?'公式解除':'Remove Official'}
      </button>
    </div>
  `).join('');
}

function showGrantOfficialModal() {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;max-width:480px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700;margin-bottom:16px"><i class="fas fa-check-circle" style="color:var(--sky);margin-right:8px"></i>${S.lang==='ja'?'公式マークを付与':'Grant Official Mark'}</h3>
    <div style="margin-bottom:16px">
      <input type="text" id="official-search" class="input" placeholder="${S.lang==='ja'?'ユーザー名で検索...':'Search by username...'}" oninput="searchUsersForOfficial(this.value)" autocomplete="off">
    </div>
    <div id="official-search-results" style="max-height:300px;overflow-y:auto;margin-bottom:16px"></div>
    <button class="btn btn-secondary" style="width:100%" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'閉じる':'Close'}</button>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}

let _officialSearchTimer = null;
async function searchUsersForOfficial(q) {
  if (_officialSearchTimer) clearTimeout(_officialSearchTimer);
  _officialSearchTimer = setTimeout(async () => {
    const results = document.getElementById('official-search-results'); if (!results) return;
    if (q.length < 1) { results.innerHTML = `<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:13px">${S.lang==='ja'?'ユーザー名を入力してください':'Enter a username'}</div>`; return; }
    results.innerHTML = '<div style="padding:20px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>';
    const res = await api(`/api/search/users?q=${encodeURIComponent(q)}`);
    const users = res.users || [];
    if (users.length === 0) { results.innerHTML = `<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:13px">${S.lang==='ja'?'ユーザーが見つかりません':'No users found'}</div>`; return; }
    results.innerHTML = users.map(u => `
      <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--border);cursor:pointer;transition:background 0.15s" onmouseenter="this.style.background='var(--bg-elevated)'" onmouseleave="this.style.background=''">
        ${avatar(u.avatar_url, u.display_name, 34)}
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:13px">${esc(u.display_name)}</div>
          <div style="font-size:11px;color:var(--text-tertiary)">@${esc(u.username)}</div>
        </div>
        <button class="btn btn-primary btn-xs" onclick="grantOfficialMark('${u.id}','${esc(u.display_name)}')"><i class="fas fa-check-circle" style="margin-right:3px"></i>${S.lang==='ja'?'公式に設定':'Set Official'}</button>
      </div>
    `).join('');
  }, 300);
}

async function grantOfficialMark(userId, name) {
  const res = await api(`/api/admin/official/${userId}`, { method: 'POST', body: { is_official: 1 } });
  if (res.success) {
    toast(`${name} ${S.lang==='ja'?'を公式に設定しました':'is now official'}`);
    document.querySelector('.modal-overlay')?.remove();
    loadOfficialUsersList();
  } else toast(res.error || 'Error', 'error');
}

function confirmRemoveOfficial(userId, name) {
  confirmDialog(`${name} ${S.lang==='ja'?'の公式マークを解除しますか？':'- Remove official mark?'}`, async () => {
    const res = await api(`/api/admin/official/${userId}`, { method: 'POST', body: { is_official: 0 } });
    if (res.success) {
      toast(`${name} ${S.lang==='ja'?'の公式マークを解除しました':'official mark removed'}`);
      loadOfficialUsersList();
    } else toast(res.error || 'Error', 'error');
  });
}

async function loadAdminUsers(el) {
  el.innerHTML = `<div style="padding:16px 24px"><input type="text" id="admin-user-search" class="input" placeholder="${S.lang==='ja'?'ユーザー検索...':'Search users...'}" oninput="debounceAdminUserSearch()" style="margin-bottom:16px"><div id="admin-users-list"><div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div></div>`;
  searchAdminUsers('');
}
let adminSearchTimer = null;
function debounceAdminUserSearch() { if (adminSearchTimer) clearTimeout(adminSearchTimer); adminSearchTimer = setTimeout(() => { const q = $('#admin-user-search')?.value || ''; searchAdminUsers(q); }, 300); }

async function searchAdminUsers(q) {
  const list = $('#admin-users-list'); if (!list) return;
  const res = await api(`/api/admin/users?q=${encodeURIComponent(q)}`);
  const users = res.users || [];
  list.innerHTML = users.length ? users.map(u => `
    <div class="admin-user-row" style="display:flex;align-items:center;gap:10px;padding:14px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);margin-bottom:8px">
      ${avatar(u.avatar_url, u.display_name, 38)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:14px">${esc(u.display_name)}</div>
        <div style="font-size:12px;color:var(--text-tertiary)">@${esc(u.username)} · ${esc(u.email||'')} · ${u.coins||0} coins</div>
        ${u.is_banned ? `<div style="font-size:11px;color:var(--accent);margin-top:2px"><i class="fas fa-ban"></i> BANNED${u.ban_reason ? ': '+esc(u.ban_reason) : ''}</div>` : ''}
        ${u.is_suspended ? `<div style="font-size:11px;color:var(--sand);margin-top:2px"><i class="fas fa-clock"></i> Suspended until ${u.suspended_until||'?'}</div>` : ''}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;max-width:300px">
        <span style="font-size:11px;padding:3px 8px;border-radius:var(--radius-full);background:var(--bg-elevated);color:var(--text-secondary);font-weight:600">${u.role||'user'}</span>
        ${!u.is_banned ?
          `<button class="btn btn-danger btn-xs" onclick="adminBanUser('${u.id}')"><i class="fas fa-ban" style="margin-right:3px"></i>Ban</button>
           <button class="btn btn-secondary btn-xs" onclick="adminSuspendUser('${u.id}')"><i class="fas fa-clock" style="margin-right:3px"></i>Suspend</button>`
          : `<button class="btn btn-secondary btn-xs" onclick="adminUnbanUser('${u.id}')"><i class="fas fa-unlock" style="margin-right:3px"></i>Unban</button>`}
        ${u.is_suspended ? `<button class="btn btn-secondary btn-xs" onclick="adminUnsuspendUser('${u.id}')">Unsuspend</button>` : ''}
        <button class="btn ${u.is_official?'btn-danger':'btn-primary'} btn-xs" style="min-width:90px;${u.is_official?'background:var(--accent);border-color:var(--accent);color:white;':''}" onclick="adminSetOfficial('${u.id}',${u.is_official?0:1})" title="${u.is_official?'Remove official':'Set official'}"><i class="fas fa-${u.is_official?'times-circle':'check-circle'}" style="margin-right:4px"></i>${u.is_official?(S.lang==='ja'?'✕ 公式解除':'✕ Unverify'):(S.lang==='ja'?'✓ 公式に設定':'✓ Verify')}</button>
        <button class="btn btn-secondary btn-xs" onclick="adminDeleteAllPosts('${u.id}')" title="Delete all posts"><i class="fas fa-trash" style="color:var(--accent)"></i></button>
        <button class="btn btn-danger btn-xs" onclick="adminDeleteAccount('${u.id}')" title="Delete account"><i class="fas fa-user-slash"></i></button>
        ${S.user.role === 'superadmin' ? `<button class="btn btn-secondary btn-xs" onclick="adminSetRole('${u.id}','${u.role}')">${S.lang==='ja'?'ロール':'Role'}</button><button class="btn btn-secondary btn-xs" onclick="adminTransfer('${u.id}')" title="Transfer admin"><i class="fas fa-crown" style="color:var(--sand)"></i></button>` : ''}
      </div>
    </div>
  `).join('') : `<div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'ユーザーがいません':'No users found'}</div>`;
}

function adminBanUser(userId) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-weight:700;margin-bottom:14px">${S.lang==='ja'?'ユーザーをBANする':'Ban User'}</h3><input type="text" id="ban-reason" class="input" placeholder="${S.lang==='ja'?'理由（任意）':'Reason (optional)'}" maxlength="200"><div style="display:flex;gap:12px;margin-top:16px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-danger" style="flex:1" onclick="confirmAdminBan('${userId}')">${S.lang==='ja'?'BANする':'Ban'}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function confirmAdminBan(userId) { const reason = $('#ban-reason')?.value || ''; await api(`/api/admin/ban/${userId}`, { method: 'POST', body: { reason } }); $('.modal-overlay')?.remove(); toast(S.lang==='ja'?'BANしました':'Banned'); searchAdminUsers($('#admin-user-search')?.value || ''); }
async function adminUnbanUser(userId) { await api(`/api/admin/unban/${userId}`, { method: 'POST' }); toast(S.lang==='ja'?'BAN解除':'Unbanned'); searchAdminUsers($('#admin-user-search')?.value || ''); }

function adminSuspendUser(userId) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-weight:700;margin-bottom:14px">${S.lang==='ja'?'ユーザーを一時停止':'Suspend User'}</h3><div style="margin-bottom:12px"><label style="font-size:12px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:4px">${S.lang==='ja'?'停止時間（時間）':'Hours'}</label><input type="number" id="suspend-hours" class="input" value="24" min="1" max="8760"></div><input type="text" id="suspend-reason" class="input" placeholder="${S.lang==='ja'?'理由（任意）':'Reason'}" maxlength="200"><div style="display:flex;gap:12px;margin-top:16px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-danger" style="flex:1" onclick="confirmAdminSuspend('${userId}')">${S.lang==='ja'?'停止する':'Suspend'}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function confirmAdminSuspend(userId) { const hours = parseInt($('#suspend-hours')?.value || '24'); const reason = $('#suspend-reason')?.value || ''; await api(`/api/admin/suspend/${userId}`, { method: 'POST', body: { hours, reason } }); $('.modal-overlay')?.remove(); toast(S.lang==='ja'?'停止しました':'Suspended'); searchAdminUsers($('#admin-user-search')?.value || ''); }
async function adminUnsuspendUser(userId) { await api(`/api/admin/unsuspend/${userId}`, { method: 'POST' }); toast(S.lang==='ja'?'停止解除':'Unsuspended'); searchAdminUsers($('#admin-user-search')?.value || ''); }

function adminSetRole(userId, currentRole) {
  const roles = ['user', 'admin', 'superadmin'];
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-weight:700;margin-bottom:14px">${S.lang==='ja'?'ロール変更':'Change Role'}</h3><div style="display:flex;flex-direction:column;gap:8px">${roles.map(r => `<button class="btn ${r===currentRole?'btn-primary':'btn-secondary'}" style="width:100%" onclick="confirmAdminSetRole('${userId}','${r}')">${r}${r===currentRole?' ✓':''}</button>`).join('')}</div><button class="btn btn-secondary" style="width:100%;margin-top:12px" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function confirmAdminSetRole(userId, role) { await api(`/api/admin/set-role/${userId}`, { method: 'POST', body: { role } }); $('.modal-overlay')?.remove(); toast(S.lang==='ja'?'ロール変更':'Role changed'); searchAdminUsers($('#admin-user-search')?.value || ''); }

async function loadAdminAnnouncements(el) {
  const res = await api('/api/admin/announcements');
  const announcements = res.announcements || [];
  el.innerHTML = `<div style="padding:24px">
    <div style="margin-bottom:20px;padding:20px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'新しいアナウンス':'NEW ANNOUNCEMENT'}</h3>
      <input type="text" id="ann-title" class="input" placeholder="${S.lang==='ja'?'タイトル':'Title'}" maxlength="100" style="margin-bottom:10px">
      <textarea id="ann-content" class="input" placeholder="${S.lang==='ja'?'内容':'Content'}" maxlength="500" style="min-height:80px;margin-bottom:12px"></textarea>
      <button class="btn btn-primary btn-sm" onclick="createAnnouncement()">${S.lang==='ja'?'投稿する':'Post'}</button>
    </div>
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'アクティブなアナウンス':'ACTIVE ANNOUNCEMENTS'}</h3>
    <div id="ann-list">${announcements.length ? announcements.map(a => `
      <div style="padding:16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);margin-bottom:8px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <h4 style="font-weight:700;font-size:15px">${esc(a.title)}</h4>
          <button class="btn-icon" onclick="deleteAnnouncement('${a.id}')" style="width:28px;height:28px"><i class="fas fa-trash" style="font-size:12px;color:var(--accent)"></i></button>
        </div>
        <p style="font-size:14px;color:var(--text-secondary);line-height:1.6;white-space:pre-wrap">${esc(a.content)}</p>
        <div style="font-size:11px;color:var(--text-tertiary);margin-top:8px">${esc(a.author_display_name||a.author_username)} · ${timeAgo(a.created_at)}</div>
      </div>
    `).join('') : `<div style="padding:30px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'アナウンスなし':'No announcements'}</div>`}</div>
  </div>`;
}

async function createAnnouncement() {
  const title = $('#ann-title')?.value.trim(), content = $('#ann-content')?.value.trim();
  if (!title || !content) { toast(S.lang==='ja'?'タイトルと内容が必要':'Title and content required','error'); return; }
  const res = await api('/api/admin/announcements', { method: 'POST', body: { title, content } });
  if (res.success) { toast(S.lang==='ja'?'投稿しました':'Posted'); loadAdminAnnouncements($('#admin-content')); }
  else toast(res.error||'Error','error');
}
async function deleteAnnouncement(id) { confirmDialog(S.lang==='ja'?'削除しますか？':'Delete?', async () => { await api(`/api/admin/announcements/${id}`, { method: 'DELETE' }); toast(S.lang==='ja'?'削除しました':'Deleted'); loadAdminAnnouncements($('#admin-content')); }); }

async function loadAdminConfig(el) {
  const [dashRes, policyRes, ablyRes] = await Promise.all([api('/api/admin/dashboard'), api('/api/admin/content-policy'), api('/api/admin/ably-key')]);
  const rateLimits = dashRes.rate_limits || [];
  const policy = policyRes || { allow_r18: true, allow_ai_content: true, require_age_verify: true, r18_blur_default: true };
  const ablyKey = ablyRes?.ably_api_key || '';
  el.innerHTML = `<div style="padding:24px">
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px"><i class="fas fa-shield-halved" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'コンテンツポリシー':'CONTENT POLICY'}</h3>
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:28px">
      ${[
        { key: 'allow_r18', label: S.lang==='ja'?'R18コンテンツを許可':'Allow R18 Content', desc: S.lang==='ja'?'サイト全体でR18投稿の作成・表示を許可します':'Allow R18 posts to be created and displayed site-wide', icon: 'fa-fire', color: 'var(--accent)', val: policy.allow_r18 },
        { key: 'allow_ai_content', label: S.lang==='ja'?'AI生成コンテンツを許可':'Allow AI-Generated Content', desc: S.lang==='ja'?'AI生成マーク付き投稿の作成を許可します':'Allow posts marked as AI-generated', icon: 'fa-robot', color: 'var(--sky)', val: policy.allow_ai_content },
        { key: 'require_age_verify', label: S.lang==='ja'?'年齢確認を必須にする':'Require Age Verification', desc: S.lang==='ja'?'R18コンテンツ閲覧時に年齢確認モーダルを表示します':'Show age verification modal for R18 content access', icon: 'fa-id-card', color: 'var(--sage)', val: policy.require_age_verify },
        { key: 'r18_blur_default', label: S.lang==='ja'?'R18画像デフォルトぼかし':'Blur R18 Images by Default', desc: S.lang==='ja'?'R18投稿の画像をデフォルトでぼかし表示します':'Blur images on R18 posts by default', icon: 'fa-eye-slash', color: 'var(--violet)', val: policy.r18_blur_default }
      ].map(cfg => `<div style="display:flex;align-items:center;gap:14px;padding:16px 18px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);transition:all 0.2s">
        <i class="fas ${cfg.icon}" style="font-size:18px;color:${cfg.color};width:28px;text-align:center;flex-shrink:0"></i>
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:14px;margin-bottom:2px">${cfg.label}</div>
          <div style="font-size:12px;color:var(--text-tertiary);line-height:1.4">${cfg.desc}</div>
        </div>
        <label class="toggle-switch" style="flex-shrink:0">
          <input type="checkbox" id="cp-${cfg.key}" ${cfg.val?'checked':''} onchange="saveContentPolicy()">
          <span class="toggle-slider"></span>
        </label>
      </div>`).join('')}
    </div>
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px"><i class="fas fa-gauge-high" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'レートリミット設定':'RATE LIMIT CONFIG'}</h3>
    <div style="display:flex;flex-direction:column;gap:12px">
      ${[
        { key: 'posts_per_minute', label: S.lang==='ja'?'投稿/分':'Posts/min', icon: 'fa-pen' },
        { key: 'messages_per_minute', label: S.lang==='ja'?'クルーメッセージ/分':'Crew msg/min', icon: 'fa-comments' },
        { key: 'dm_per_minute', label: S.lang==='ja'?'DM/分':'DM/min', icon: 'fa-paper-plane' }
      ].map(cfg => {
        const current = rateLimits.find(r => r.key === cfg.key);
        return `<div style="display:flex;align-items:center;gap:12px;padding:16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
          <i class="fas ${cfg.icon}" style="font-size:16px;color:var(--accent);width:24px;text-align:center"></i>
          <div style="flex:1"><div style="font-weight:600;font-size:14px">${cfg.label}</div></div>
          <input type="number" id="rl-${cfg.key}" class="input" value="${current?.value || 5}" min="1" max="100" style="width:80px;text-align:center;padding:8px">
          <button class="btn btn-primary btn-xs" onclick="updateRateLimit('${cfg.key}')"><i class="fas fa-check"></i></button>
        </div>`;
      }).join('')}
    </div>
    <div style="margin-top:24px;padding:16px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md)">
      <div style="font-size:13px;color:var(--text-secondary);line-height:1.6">
        <i class="fas fa-info-circle" style="color:var(--accent);margin-right:6px"></i>
        ${S.lang==='ja'?'コンテンツポリシーとレートリミットの変更は即時反映されます。':'Content policy and rate limit changes apply immediately.'}
      </div>
    </div>
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin:28px 0 16px"><i class="fas fa-satellite-dish" style="color:var(--sky);margin-right:6px"></i>${S.lang==='ja'?'Ably リアルタイム設定':'ABLY REALTIME CONFIG'}</h3>
    <div style="padding:18px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
      <div style="margin-bottom:10px"><label style="font-size:12px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:6px">${S.lang==='ja'?'Ably APIキー':'Ably API Key'}</label><input type="text" id="ably-api-key" class="input" value="${esc(ablyKey)}" placeholder="xxxxx.xxxxx:xxxxxxxxxx" style="font-family:monospace;font-size:13px"></div>
      <div style="display:flex;gap:10px;align-items:center"><button class="btn btn-primary btn-sm" onclick="saveAblyKey()">${S.lang==='ja'?'保存':'Save'}</button><span style="font-size:12px;color:var(--text-tertiary)">${S.lang==='ja'?'チャットやクルーのリアルタイム通信に使用されます':'Used for realtime chat and crew communication'}</span></div>
    </div>
  </div>`;
}

async function saveContentPolicy() {
  const body = {
    allow_r18: $('#cp-allow_r18')?.checked || false,
    allow_ai_content: $('#cp-allow_ai_content')?.checked || false,
    require_age_verify: $('#cp-require_age_verify')?.checked || false,
    r18_blur_default: $('#cp-r18_blur_default')?.checked || false
  };
  const res = await api('/api/admin/content-policy', { method: 'POST', body });
  if (res.success) toast(S.lang==='ja'?'コンテンツポリシーを更新しました':'Content policy updated');
  else toast(res.error || 'Error', 'error');
}

async function saveAblyKey() {
  const key = $('#ably-api-key')?.value || '';
  const res = await api('/api/admin/ably-key', { method: 'POST', body: { ably_api_key: key } });
  if (res.success) {
    toast(S.lang==='ja'?'Ably APIキーを保存しました。ページを更新すると反映されます。':'Ably API key saved. Refresh to apply.');
    window.__ABLY_KEY__ = key;
    // Reinitialize Ably with new key
    if (S.ably) { try { S.ably.close(); } catch {} S.ably = null; S.ablyConnected = false; }
    if (key) initAbly();
  } else toast(res.error || 'Error', 'error');
}

// Admin: Spam words management
async function loadAdminSpamWords(el) {
  const res = await api('/api/admin/spam-words');
  const words = res.words || [];
  el.innerHTML = `<div style="padding:24px">
    <div style="display:flex;gap:10px;margin-bottom:20px"><input type="text" id="spam-word-input" class="input" placeholder="${S.lang==='ja'?'スパムワードを追加...':'Add spam word...'}" style="flex:1"><button class="btn btn-primary btn-sm" onclick="addSpamWord()"><i class="fas fa-plus"></i></button></div>
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'ブロックワード':'BLOCKED WORDS'} (${words.length})</h3>
    <div style="display:flex;flex-wrap:wrap;gap:8px">${words.map(w => `<div style="display:flex;align-items:center;gap:6px;padding:6px 14px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-full);font-size:13px"><span>${esc(w.word)}</span><button class="btn-icon" style="width:20px;height:20px" onclick="deleteSpamWord('${w.id}')"><i class="fas fa-times" style="font-size:10px;color:var(--accent)"></i></button></div>`).join('') || `<div style="color:var(--text-tertiary)">${S.lang==='ja'?'なし':'None'}</div>`}</div>
    <div style="margin-top:20px;padding:14px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);font-size:13px;color:var(--text-secondary)"><i class="fas fa-info-circle" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'スパムワードを含む投稿は自動的にブロックされます。':'Posts containing spam words are automatically blocked.'}</div>
  </div>`;
}
async function addSpamWord() { const input = $('#spam-word-input'); const word = input?.value.trim(); if (!word) return; try { const res = await api('/api/admin/spam-words', { method: 'POST', body: { word } }); if (res.success) { input.value = ''; toast(S.lang==='ja'?'追加しました':'Added'); loadAdminSpamWords($('#admin-content')); } else toast(res.error||'Error','error'); } catch(e) { toast(S.lang==='ja'?'ネットワークエラー':'Network error','error'); } }
async function deleteSpamWord(id) { await api(`/api/admin/spam-words/${id}`, { method: 'DELETE' }); toast(S.lang==='ja'?'削除しました':'Deleted'); loadAdminSpamWords($('#admin-content')); }

// Admin: IP monitoring
async function loadAdminIPMonitor(el) {
  const res = await api('/api/admin/ip-monitor');
  const ips = res.suspicious_ips || [];
  el.innerHTML = `<div style="padding:24px">
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px"><i class="fas fa-shield-halved" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'同一IP複数アカウント検知':'MULTI-ACCOUNT IP DETECTION'}</h3>
    ${ips.length ? ips.map(ip => `<div style="padding:14px 16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);margin-bottom:8px"><div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="font-family:monospace;font-size:13px;color:var(--text-primary);font-weight:600">${esc(ip.ip_address)}</span><span style="font-size:12px;color:var(--accent);font-weight:700">${ip.user_count} ${S.lang==='ja'?'アカウント':'accounts'}</span></div><div style="font-size:12px;color:var(--text-tertiary)">User IDs: ${esc((ip.user_ids||'').substring(0,80))}</div><div style="font-size:11px;color:var(--text-tertiary);margin-top:4px">${S.lang==='ja'?'最終確認':'Last seen'}: ${timeAgo(ip.last_seen)}</div></div>`).join('') : `<div style="padding:40px;text-align:center;color:var(--text-tertiary)"><i class="fas fa-check-circle" style="font-size:28px;margin-bottom:10px;display:block;color:var(--sage)"></i>${S.lang==='ja'?'疑わしいアクティビティなし':'No suspicious activity detected'}</div>`}
    <div style="margin-top:16px;padding:14px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);font-size:13px;color:var(--text-secondary)"><i class="fas fa-info-circle" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'過去24時間で同一IPから複数アカウントがアクセスした場合に表示されます。':'Shows IPs used by multiple accounts in the last 24 hours.'}</div>
  </div>`;
}

// Admin: Site images management
async function loadAdminImages(el) {
  const res = await api('/api/admin/site-images');
  const images = res.images || {};
  const imageKeys = [
    { key: 'splash_image', label: S.lang==='ja'?'スプラッシュ画面':'Splash Screen', desc: S.lang==='ja'?'アプリ起動時に表示される画像':'Image shown when the app starts' },
    { key: 'auth_logo', label: S.lang==='ja'?'ログイン/登録画面':'Login/Register', desc: S.lang==='ja'?'認証画面のロゴ':'Logo on auth pages' },
    { key: 'sidebar_logo', label: S.lang==='ja'?'サイドバーロゴ':'Sidebar Logo', desc: S.lang==='ja'?'サイドバーのロゴ画像':'Sidebar logo image' },
    { key: 'empty_state', label: S.lang==='ja'?'空の状態':'Empty States', desc: S.lang==='ja'?'データが無い時に表示':'Shown when no data' },
    { key: 'pwa_icon', label: 'PWA Icon', desc: S.lang==='ja'?'ホーム画面アイコン':'Home screen icon' },
  ];
  el.innerHTML = `<div style="padding:24px">
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
      <i class="fas fa-image" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'サイト画像管理':'SITE IMAGE MANAGEMENT'}
    </h3>
    <div style="display:flex;flex-direction:column;gap:16px">
      ${imageKeys.map(ik => {
        const current = images[ik.key] || '';
        return `<div style="padding:16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
            <div><div style="font-weight:600;font-size:14px">${ik.label}</div><div style="font-size:12px;color:var(--text-tertiary)">${ik.desc}</div></div>
            ${current ? `<img src="${esc(current)}" style="width:48px;height:48px;border-radius:var(--radius-sm);object-fit:cover;border:1px solid var(--border)">` : '<div style="width:48px;height:48px;border-radius:var(--radius-sm);background:var(--bg-elevated);display:flex;align-items:center;justify-content:center"><i class="fas fa-image" style="color:var(--text-tertiary)"></i></div>'}
          </div>
          <div style="display:flex;gap:8px">
            <input type="text" id="img-url-${ik.key}" class="input" style="flex:1;font-size:13px;padding:8px 12px" placeholder="https://... ${S.lang==='ja'?'またはbase64':'or base64'}" value="${esc(current)}">
            <label class="btn btn-secondary btn-xs" style="cursor:pointer;flex-shrink:0"><i class="fas fa-upload"></i><input type="file" accept="image/*" style="display:none" onchange="uploadSiteImage('${ik.key}',this)"></label>
            <button class="btn btn-primary btn-xs" onclick="saveSiteImage('${ik.key}')"><i class="fas fa-check"></i></button>
            ${current ? `<button class="btn btn-danger btn-xs" onclick="deleteSiteImage('${ik.key}')"><i class="fas fa-trash"></i></button>` : ''}
          </div>
        </div>`;
      }).join('')}
    </div>
    <div style="margin-top:16px;padding:14px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);font-size:13px;color:var(--text-secondary)">
      <i class="fas fa-info-circle" style="color:var(--accent);margin-right:6px"></i>
      ${S.lang==='ja'?'画像URLを入力するか、ファイルをアップロード（base64変換）してください。変更は即座に反映されます。':'Enter an image URL or upload a file (base64). Changes take effect immediately.'}
    </div>
  </div>`;
}

function uploadSiteImage(key, input) {
  const f = input.files[0]; if (!f) return;
  if (f.size > 2*1024*1024) { toast(S.lang==='ja'?'2MB以下':'Max 2MB','error'); return; }
  const r = new FileReader();
  r.onload = (e) => {
    const urlInput = document.getElementById('img-url-' + key);
    if (urlInput) urlInput.value = e.target.result;
  };
  r.readAsDataURL(f);
}

async function saveSiteImage(key) {
  const urlInput = document.getElementById('img-url-' + key);
  const url = urlInput?.value.trim() || '';
  const res = await api('/api/admin/site-images', { method: 'PUT', body: { key, value: url } });
  if (res.success) { toast(S.lang==='ja'?'保存しました':'Saved'); }
  else toast(res.error||'Error','error');
}

async function deleteSiteImage(key) {
  const res = await api('/api/admin/site-images', { method: 'PUT', body: { key, value: '' } });
  if (res.success) { toast(S.lang==='ja'?'削除しました':'Deleted'); loadAdminImages($('#admin-content')); }
  else toast(res.error||'Error','error');
}

async function updateRateLimit(key) {
  const val = parseInt(document.getElementById('rl-' + key)?.value || '5');
  if (val < 1 || val > 100) { toast(S.lang==='ja'?'1~100の範囲':'Range 1-100','error'); return; }
  const res = await api('/api/admin/rate-limits', { method: 'PUT', body: { key, value: val } });
  if (res.success) toast(S.lang==='ja'?'更新しました':'Updated');
  else toast(res.error||'Error','error');
}


// ===== ENHANCED ADMIN =====
async function adminSetOfficial(userId, isOfficial) {
  const res = await api(`/api/admin/official/${userId}`, { method: 'POST', body: { is_official: isOfficial } });
  if (res.success) { toast(S.lang==='ja'?(isOfficial?'公式に設定':'公式解除'):(isOfficial?'Set official':'Removed official')); searchAdminUsers($('#admin-user-search')?.value || ''); }
  else toast(res.error||'Error','error');
}
async function adminTransfer(userId) {
  confirmDialog(S.lang==='ja'?'本当にスーパー管理者権限を譲渡しますか？この操作は取り消せません。':'Really transfer superadmin rights? This cannot be undone.', async () => {
    const res = await api(`/api/admin/transfer/${userId}`, { method: 'POST' });
    if (res.success) { toast(S.lang==='ja'?'権限を譲渡しました':'Transferred'); S.user.role = 'admin'; location.reload(); }
    else toast(res.error||'Error','error');
  });
}
async function adminDeleteAllPosts(userId) {
  confirmDialog(S.lang==='ja'?'このユーザーの全投稿を削除しますか？':'Delete all posts by this user?', async () => {
    const res = await api(`/api/admin/users/${userId}/posts`, { method: 'DELETE' });
    if (res.success) toast(S.lang==='ja'?'全投稿を削除しました':'All posts deleted');
    else toast(res.error||'Error','error');
  });
}


// ===== ADMIN REPORTS MANAGEMENT =====
async function loadAdminReports(el) {
  el.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`;
  const res = await api('/api/admin/reports?status=pending');
  const reports = res.reports || [];
  if (reports.length === 0) { el.innerHTML = `<div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'通報なし':'No reports'}</div>`; return; }
  el.innerHTML = reports.map(r => `<div style="padding:16px;border-bottom:1px solid var(--border)">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
      <i class="fas fa-flag" style="color:var(--accent)"></i>
      <span style="font-weight:600">${esc(r.reporter_display_name)}</span>
      <span style="font-size:12px;color:var(--text-tertiary)">@${esc(r.reporter_username)}</span>
      <span style="font-size:12px;color:var(--text-tertiary);margin-left:auto">${timeAgo(r.created_at)}</span>
    </div>
    <div style="font-size:13px;color:var(--text-tertiary);margin-bottom:4px">${r.target_type === 'post' ? 'Post' : 'User'}: ${r.target_id}</div>
    <div style="font-size:14px;padding:8px;background:var(--bg-elevated);border-radius:var(--radius-sm);margin-bottom:8px">${esc(r.reason)}</div>
    <div style="display:flex;gap:8px">
      ${r.target_type === 'post' ? `<button class="btn btn-danger btn-xs" onclick="adminDeleteReportedPost('${r.target_id}','${r.id}')"><i class="fas fa-trash"></i> ${S.lang==='ja'?'投稿削除':'Delete Post'}</button>` : ''}
      <button class="btn btn-xs btn-secondary" onclick="reviewReport('${r.id}','reviewed')">✓ ${S.lang==='ja'?'対応済み':'Reviewed'}</button>
      <button class="btn btn-xs btn-secondary" onclick="reviewReport('${r.id}','dismissed')">${S.lang==='ja'?'却下':'Dismiss'}</button>
    </div>
  </div>`).join('');
}
async function reviewReport(id, status) { await api(`/api/admin/reports/${id}/review`, { method: 'POST', body: { status } }); toast(S.lang==='ja'?'更新しました':'Updated'); loadAdminReports(document.getElementById('admin-content')); }
async function adminDeleteReportedPost(postId, reportId) { await api(`/api/admin/posts/${postId}`, { method: 'DELETE' }); await api(`/api/admin/reports/${reportId}/review`, { method: 'POST', body: { status: 'reviewed', admin_note: 'Post deleted' } }); toast(S.lang==='ja'?'投稿削除&対応済み':'Deleted & reviewed'); loadAdminReports(document.getElementById('admin-content')); }
async function adminDeleteAccount(userId) { confirmDialog(S.lang==='ja'?'このアカウントを削除しますか？':'Delete this account?', async () => { const res = await api(`/api/admin/delete-account/${userId}`, { method: 'POST' }); if (res.success) { toast(S.lang==='ja'?'アカウント削除':'Account deleted'); searchAdminUsers(document.getElementById('admin-user-search')?.value || ''); } else toast(res.error || 'Error', 'error'); }); }
async function adminRemoveOfficial(userId) { await api(`/api/admin/official/${userId}`, { method: 'POST', body: { is_official: false } }); toast(S.lang==='ja'?'公式マーク解除':'Official mark removed'); searchAdminUsers(document.getElementById('admin-user-search')?.value || ''); }

async function adminDeleteFeedPost(postId) {
  confirmDialog(S.lang==='ja'?'管理者権限でこの投稿を削除しますか？':'Delete this post as admin?', async () => {
    const post = document.getElementById('post-' + postId);
    if (post) { post.style.transition = 'all 0.3s ease'; post.style.opacity = '0'; post.style.transform = 'scale(0.95)'; setTimeout(() => post.remove(), 300); }
    const res = await api(`/api/admin/feed-posts/${postId}`, { method: 'DELETE' });
    if (res.success) { toast(S.lang==='ja'?'管理者として削除しました':'Deleted as admin'); S.cache.posts = S.cache.posts.filter(p => p.id !== postId); }
    else toast(res.error || 'Error', 'error');
  });
}

// ===== ADMIN DB OPERATIONS =====
async function loadAdminDBOps(el) {
  const res = await api('/api/admin/db-queries');
  const queries = res.queries || [];
  el.innerHTML = `<div style="padding:24px">
    <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">
      <i class="fas fa-database" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'データベース直接操作':'DIRECT DB OPERATIONS'}
    </h3>
    <div style="margin-bottom:20px;padding:14px;background:rgba(200,85,61,0.04);border:1px solid rgba(200,85,61,0.12);border-radius:var(--radius-md);font-size:13px;color:var(--accent)">
      <i class="fas fa-exclamation-triangle" style="margin-right:6px"></i>
      ${S.lang==='ja'?'⚠️ スーパー管理者専用。SQLクエリを直接実行できます。注意して使用してください。':'⚠️ Superadmin only. Execute SQL queries directly. Use with caution.'}
    </div>
    <div style="margin-bottom:20px">
      <textarea id="db-query-input" class="input" style="min-height:100px;font-family:monospace;font-size:13px" placeholder="SELECT * FROM users LIMIT 10"></textarea>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="btn btn-primary btn-sm" onclick="executeDBQuery()"><i class="fas fa-play" style="margin-right:4px"></i>${S.lang==='ja'?'実行':'Execute'}</button>
        <button class="btn btn-secondary btn-sm" onclick="$('#db-query-input').value='SELECT name FROM sqlite_master WHERE type=\\'table\\' ORDER BY name'">${S.lang==='ja'?'テーブル一覧':'List Tables'}</button>
        <button class="btn btn-secondary btn-sm" onclick="$('#db-query-input').value='SELECT COUNT(*) as count FROM users'">Count Users</button>
      </div>
    </div>
    <div id="db-query-result" style="display:none;margin-bottom:20px;padding:16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md);overflow-x:auto"></div>
    <h3 style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">${S.lang==='ja'?'クエリ履歴':'QUERY HISTORY'}</h3>
    <div style="display:flex;flex-direction:column;gap:6px">${queries.map(q => `<div style="padding:10px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm);cursor:pointer" onclick="$('#db-query-input').value=decodeURIComponent('${encodeURIComponent(q.query_text)}')">
      <div style="font-family:monospace;font-size:12px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(q.query_text)}</div>
      <div style="font-size:10px;color:var(--text-tertiary);margin-top:4px">${timeAgo(q.created_at)}</div>
    </div>`).join('') || `<div style="color:var(--text-tertiary);font-size:13px">${S.lang==='ja'?'履歴なし':'No history'}</div>`}</div>
  </div>`;
}
async function executeDBQuery() {
  const query = $('#db-query-input')?.value.trim();
  if (!query) return toast(S.lang==='ja'?'クエリを入力':'Enter a query','error');
  const resultEl = $('#db-query-result');
  if (resultEl) { resultEl.style.display = 'block'; resultEl.innerHTML = '<div class="spinner" style="margin:0 auto;width:20px;height:20px"></div>'; }
  const res = await api('/api/admin/db-query', { method: 'POST', body: { query } });
  if (res.error) {
    if (resultEl) resultEl.innerHTML = `<div style="color:var(--accent);font-size:13px"><i class="fas fa-times-circle" style="margin-right:4px"></i>${esc(res.error)}</div>`;
    return;
  }
  if (res.is_select && res.result?.results) {
    const rows = res.result.results;
    if (rows.length === 0) {
      if (resultEl) resultEl.innerHTML = '<div style="color:var(--text-tertiary);font-size:13px">No results</div>';
      return;
    }
    const cols = Object.keys(rows[0]);
    let html = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:12px">';
    html += '<tr>' + cols.map(c => `<th style="padding:6px 10px;background:var(--bg-elevated);border:1px solid var(--border);font-weight:700;text-align:left;white-space:nowrap">${esc(c)}</th>`).join('') + '</tr>';
    rows.slice(0, 100).forEach(r => { html += '<tr>' + cols.map(c => `<td style="padding:4px 10px;border:1px solid var(--border);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(String(r[c]??''))}</td>`).join('') + '</tr>'; });
    html += '</table></div>';
    html += `<div style="font-size:11px;color:var(--text-tertiary);margin-top:8px">${rows.length} ${S.lang==='ja'?'行':'rows'}${rows.length>=100?' (max 100)':''}</div>`;
    if (resultEl) resultEl.innerHTML = html;
  } else {
    if (resultEl) resultEl.innerHTML = `<div style="color:var(--sage);font-size:13px"><i class="fas fa-check-circle" style="margin-right:4px"></i>${S.lang==='ja'?'クエリ実行成功':'Query executed successfully'}</div><pre style="font-size:11px;color:var(--text-tertiary);margin-top:8px;white-space:pre-wrap">${esc(JSON.stringify(res.result?.meta||{}, null, 2))}</pre>`;
  }
  toast(S.lang==='ja'?'実行完了':'Executed');
}


// ===== ADMIN: Set R18/AI on posts =====
function showAdminPostFlagsModal(postId) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()">
    <h3 style="font-weight:700;margin-bottom:14px"><i class="fas fa-shield-halved" style="color:var(--accent);margin-right:6px"></i>${S.lang==='ja'?'投稿フラグ設定':'Post Flags'}</h3>
    <div style="display:flex;flex-direction:column;gap:12px">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
        <input type="checkbox" id="admin-flag-r18" style="accent-color:var(--accent)">
        <span style="font-size:14px">🔞 R18${S.lang==='ja'?' コンテンツ':' Content'}</span>
      </label>
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-md)">
        <input type="checkbox" id="admin-flag-ai" style="accent-color:var(--sky)">
        <span style="font-size:14px">🤖 AI${S.lang==='ja'?' 生成':' Generated'}</span>
      </label>
    </div>
    <div style="display:flex;gap:12px;margin-top:16px">
      <button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'キャンセル':'Cancel'}</button>
      <button class="btn btn-primary" style="flex:1" onclick="submitAdminPostFlags('${postId}')">${S.lang==='ja'?'保存':'Save'}</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}
async function submitAdminPostFlags(postId) {
  const isR18 = $('#admin-flag-r18')?.checked || false;
  const isAI = $('#admin-flag-ai')?.checked || false;
  const res = await api(`/api/admin/posts/${postId}/flags`, { method: 'POST', body: { is_r18: isR18, is_ai_generated: isAI } });
  if (res.success) { document.querySelector('.modal-overlay')?.remove(); toast(S.lang==='ja'?'フラグを更新しました':'Flags updated'); }
  else toast(res.error || 'Error', 'error');
}



// ===== LEGAL PAGE MANAGEMENT =====
async function loadAdminLegal(el) {
  const res = await api('/api/admin/legal');
  const legal = res.legal || {};
  el.innerHTML = `<div style="padding:24px">
    <h3 style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px"><i class="fas fa-file-contract" style="margin-right:6px"></i>${S.lang==='ja'?'利用規約・プライバシーポリシー':'Terms of Service & Privacy Policy'}</h3>
    <div style="margin-bottom:24px">
      <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px">${S.lang==='ja'?'利用規約 (日本語)':'Terms of Service (Japanese)'}</label>
      <textarea id="legal-terms-ja" class="input" style="min-height:200px;font-size:13px;line-height:1.7;font-family:inherit">${esc(legal.legal_terms_ja || '')}</textarea>
    </div>
    <div style="margin-bottom:24px">
      <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px">${S.lang==='ja'?'利用規約 (English)':'Terms of Service (English)'}</label>
      <textarea id="legal-terms-en" class="input" style="min-height:200px;font-size:13px;line-height:1.7;font-family:inherit">${esc(legal.legal_terms_en || '')}</textarea>
    </div>
    <div style="margin-bottom:24px">
      <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px">${S.lang==='ja'?'プライバシーポリシー (日本語)':'Privacy Policy (Japanese)'}</label>
      <textarea id="legal-privacy-ja" class="input" style="min-height:200px;font-size:13px;line-height:1.7;font-family:inherit">${esc(legal.legal_privacy_ja || '')}</textarea>
    </div>
    <div style="margin-bottom:24px">
      <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px">${S.lang==='ja'?'プライバシーポリシー (English)':'Privacy Policy (English)'}</label>
      <textarea id="legal-privacy-en" class="input" style="min-height:200px;font-size:13px;line-height:1.7;font-family:inherit">${esc(legal.legal_privacy_en || '')}</textarea>
    </div>
    <div style="display:flex;gap:12px;align-items:center">
      <button class="btn btn-primary" onclick="saveAdminLegal()"><i class="fas fa-save" style="margin-right:6px"></i>${S.lang==='ja'?'保存':'Save'}</button>
      <a href="/terms" class="btn btn-secondary btn-sm" style="text-decoration:none">${S.lang==='ja'?'プレビュー →':'Preview →'}</a>
    </div>
    ${legal.legal_updated_at ? `<div style="margin-top:12px;font-size:12px;color:var(--text-tertiary)"><i class="fas fa-clock" style="margin-right:4px"></i>${S.lang==='ja'?'最終更新':'Last updated'}: ${legal.legal_updated_at}</div>` : ''}
  </div>`;
}

async function saveAdminLegal() {
  const body = {
    legal_terms_ja: $('#legal-terms-ja')?.value || '',
    legal_terms_en: $('#legal-terms-en')?.value || '',
    legal_privacy_ja: $('#legal-privacy-ja')?.value || '',
    legal_privacy_en: $('#legal-privacy-en')?.value || ''
  };
  const res = await api('/api/admin/legal', { method: 'PUT', body });
  if (res.success) toast(S.lang==='ja'?'保存しました':'Saved');
  else toast(res.error || 'Error', 'error');
}

// Override stub functions in parent scope
window._pageAdmin = _pageAdmin;
window.switchAdminTab = switchAdminTab;
window.loadAdminTab = loadAdminTab;
window.loadAdminDashboard = loadAdminDashboard;
window.loadAdminOfficialUsers = loadAdminOfficialUsers;
window.loadOfficialUsersList = loadOfficialUsersList;
window.showGrantOfficialModal = showGrantOfficialModal;
window.searchUsersForOfficial = searchUsersForOfficial;
window.grantOfficialMark = grantOfficialMark;
window.confirmRemoveOfficial = confirmRemoveOfficial;
window.loadAdminUsers = loadAdminUsers;
window.debounceAdminUserSearch = debounceAdminUserSearch;
window.searchAdminUsers = searchAdminUsers;
window.adminBanUser = adminBanUser;
window.confirmAdminBan = confirmAdminBan;
window.adminUnbanUser = adminUnbanUser;
window.adminSuspendUser = adminSuspendUser;
window.confirmAdminSuspend = confirmAdminSuspend;
window.adminUnsuspendUser = adminUnsuspendUser;
window.adminSetRole = adminSetRole;
window.confirmAdminSetRole = confirmAdminSetRole;
window.loadAdminAnnouncements = loadAdminAnnouncements;
window.createAnnouncement = createAnnouncement;
window.deleteAnnouncement = deleteAnnouncement;
window.loadAdminConfig = loadAdminConfig;
window.saveContentPolicy = saveContentPolicy;
window.saveAblyKey = saveAblyKey;
window.loadAdminSpamWords = loadAdminSpamWords;
window.addSpamWord = addSpamWord;
window.deleteSpamWord = deleteSpamWord;
window.loadAdminIPMonitor = loadAdminIPMonitor;
window.loadAdminImages = loadAdminImages;
window.uploadSiteImage = uploadSiteImage;
window.saveSiteImage = saveSiteImage;
window.deleteSiteImage = deleteSiteImage;
window.updateRateLimit = updateRateLimit;
window.adminSetOfficial = adminSetOfficial;
window.adminTransfer = adminTransfer;
window.adminDeleteAllPosts = adminDeleteAllPosts;
window.loadAdminReports = loadAdminReports;
window.reviewReport = reviewReport;
window.adminDeleteReportedPost = adminDeleteReportedPost;
window.adminDeleteAccount = adminDeleteAccount;
window.adminRemoveOfficial = adminRemoveOfficial;
window.adminDeleteFeedPost = adminDeleteFeedPost;
window.loadAdminDBOps = loadAdminDBOps;
window.executeDBQuery = executeDBQuery;
window.showAdminPostFlagsModal = showAdminPostFlagsModal;
window.submitAdminPostFlags = submitAdminPostFlags;
window.loadAdminLegal = loadAdminLegal;
window.saveAdminLegal = saveAdminLegal;
