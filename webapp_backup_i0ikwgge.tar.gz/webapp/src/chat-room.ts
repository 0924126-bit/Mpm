import { DurableObject } from 'cloudflare:workers'

interface Env {
  DB: D1Database
  CHAT_ROOM: DurableObjectNamespace
}

interface WsAttachment {
  userId: string
  username: string
  displayName: string
  avatarUrl: string
  channel: string
}

// Durable Object: ChatRoom with WebSocket Hibernation
// Each channel (dm:xxx, crew:xxx, vr:xxx, wb:xxx) gets its own DO instance
export class ChatRoom extends DurableObject<Env> {

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url)

    if (url.pathname === '/ws') {
      // WebSocket upgrade
      const upgradeHeader = request.headers.get('Upgrade')
      if (!upgradeHeader || upgradeHeader !== 'websocket') {
        return new Response('Expected Upgrade: websocket', { status: 426 })
      }

      const userId = url.searchParams.get('userId') || ''
      const username = url.searchParams.get('username') || ''
      const displayName = url.searchParams.get('displayName') || ''
      const avatarUrl = url.searchParams.get('avatarUrl') || ''
      const channel = url.searchParams.get('channel') || ''

      const pair = new WebSocketPair()
      const [client, server] = Object.values(pair)

      // Accept with Hibernation API (survives DO eviction)
      this.ctx.acceptWebSocket(server)

      // Persist user info on the connection (survives hibernation)
      server.serializeAttachment({
        userId, username, displayName, avatarUrl, channel
      } satisfies WsAttachment)

      // Notify existing clients of the new user joining
      const onlineCount = this.getUniqueUserCount()
      this.broadcast(JSON.stringify({
        type: 'user_join',
        user_id: userId,
        username: username,
        display_name: displayName,
        online: onlineCount + 1
      }), server)

      // Send connection confirmation to the new client
      server.send(JSON.stringify({
        type: 'connected',
        channel,
        online: onlineCount + 1
      }))

      return new Response(null, { status: 101, webSocket: client })
    }

    return new Response('Not found', { status: 404 })
  }

  // Called when a hibernated DO receives a WebSocket message
  async webSocketMessage(ws: WebSocket, message: string | ArrayBuffer): Promise<void> {
    if (typeof message !== 'string') return
    try {
      const data = JSON.parse(message)
      const attachment = ws.deserializeAttachment() as WsAttachment
      if (!attachment) return

      const { userId, username, displayName, avatarUrl, channel } = attachment
      const [type, id] = channel.split(':')

      if (data.type === 'chat' && data.content?.trim()) {
        const content = data.content.trim().substring(0, 2000)
        const clientMsgId = data.client_id || ''
        const msgId = crypto.randomUUID().replace(/-/g, '').substring(0, 16)
        const now = new Date().toISOString()

        const msgPayload = JSON.stringify({
          type: 'chat',
          message: {
            id: msgId, sender_id: userId, content,
            created_at: now,
            sender_username: username,
            sender_display_name: displayName,
            sender_avatar_url: avatarUrl,
            client_id: clientMsgId
          }
        })

        // Broadcast to ALL connected clients (including sender for confirmation)
        this.broadcast(msgPayload)

        // Persist to DB asynchronously
        try {
          if (type === 'dm') {
            await this.env.DB.prepare('INSERT INTO messages (id, conversation_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run()
            this.env.DB.prepare("UPDATE conversations SET last_message_at = datetime('now') WHERE id = ?").bind(id).run()
            // Notification for offline user
            try {
              const conv = await this.env.DB.prepare('SELECT user1_id, user2_id FROM conversations WHERE id = ?').bind(id).first() as any
              if (conv) {
                const otherUserId = conv.user1_id === userId ? conv.user2_id : conv.user1_id
                const isOnline = this.isUserOnline(otherUserId)
                if (!isOnline) {
                  const nid = crypto.randomUUID().replace(/-/g, '').substring(0, 16)
                  this.env.DB.prepare("INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, 'dm', ?, ?, 'conversation')").bind(nid, otherUserId, userId, id).run()
                }
              }
            } catch {}
          } else if (type === 'crew') {
            await this.env.DB.prepare('INSERT INTO crew_messages (id, channel_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run()
          } else if (type === 'vr') {
            await this.env.DB.prepare('INSERT INTO voice_room_messages (id, room_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run()
          }
        } catch (e) { console.error('DB persist error:', e) }

      } else if (data.type === 'typing') {
        this.broadcast(JSON.stringify({
          type: 'typing',
          user_id: userId,
          username: username,
          display_name: displayName
        }), ws)

      } else if (data.type === 'stroke' && data.stroke_data) {
        const strokeId = crypto.randomUUID().replace(/-/g, '').substring(0, 16)
        this.broadcast(JSON.stringify({
          type: 'stroke',
          stroke: {
            id: strokeId, user_id: userId,
            stroke_data: data.stroke_data,
            color: data.color || '#c8553d',
            width: data.width || 3,
            tool: data.tool || 'pen'
          }
        }))
        const [, roomId] = channel.split(':')
        this.env.DB.prepare('INSERT INTO whiteboard_strokes (id, room_id, user_id, stroke_data, color, width, tool) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(strokeId, roomId, userId, data.stroke_data, data.color || '#c8553d', data.width || 3, data.tool || 'pen').run()

      } else if (data.type === 'wb_clear') {
        this.broadcast(JSON.stringify({ type: 'wb_clear' }))

      } else if (data.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong', ts: Date.now() }))
      }
    } catch (e) { console.error('WS message error:', e) }
  }

  async webSocketClose(ws: WebSocket, code: number, reason: string, wasClean: boolean): Promise<void> {
    try {
      const attachment = ws.deserializeAttachment() as WsAttachment
      if (attachment) {
        this.broadcast(JSON.stringify({
          type: 'user_leave',
          user_id: attachment.userId,
          username: attachment.username,
          online: this.getUniqueUserCount() - 1
        }), ws)
      }
    } catch {}
    ws.close(code, reason)
  }

  async webSocketError(ws: WebSocket, error: unknown): Promise<void> {
    try {
      const attachment = ws.deserializeAttachment() as WsAttachment
      if (attachment) {
        this.broadcast(JSON.stringify({
          type: 'user_leave',
          user_id: attachment.userId,
          username: attachment.username,
          online: this.getUniqueUserCount() - 1
        }), ws)
      }
    } catch {}
    ws.close(1011, 'WebSocket error')
  }

  // Broadcast message to all connected WebSockets
  private broadcast(message: string, excludeWs?: WebSocket): void {
    const sockets = this.ctx.getWebSockets()
    for (const socket of sockets) {
      if (socket === excludeWs) continue
      try { socket.send(message) } catch {}
    }
  }

  // Check if a specific user is online
  private isUserOnline(userId: string): boolean {
    const sockets = this.ctx.getWebSockets()
    for (const socket of sockets) {
      try {
        const att = socket.deserializeAttachment() as WsAttachment
        if (att && att.userId === userId) return true
      } catch {}
    }
    return false
  }

  // Get unique connected user count
  private getUniqueUserCount(): number {
    const sockets = this.ctx.getWebSockets()
    const userIds = new Set<string>()
    for (const socket of sockets) {
      try {
        const att = socket.deserializeAttachment() as WsAttachment
        if (att) userIds.add(att.userId)
      } catch {}
    }
    return userIds.size
  }
}
