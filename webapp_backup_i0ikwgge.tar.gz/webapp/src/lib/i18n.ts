export type Lang = 'ja' | 'en';

const translations: Record<string, Record<Lang, string>> = {
  'nav.home': { ja: 'ホーム', en: 'Home' },
  'nav.explore': { ja: '探索', en: 'Explore' },
  'nav.voice': { ja: 'ボイス', en: 'Voice' },
  'nav.profile': { ja: 'プロフィール', en: 'Profile' },
  'nav.settings': { ja: '設定', en: 'Settings' },
  'nav.logout': { ja: 'ログアウト', en: 'Log out' },
  'nav.login': { ja: 'ログイン', en: 'Log in' },
  'nav.register': { ja: '新規登録', en: 'Sign up' },
  'nav.crew': { ja: 'クルー', en: 'Crew' },
  'nav.dm': { ja: 'メッセージ', en: 'Messages' },

  'site.name': { ja: 'さとっち', en: 'Satocchi' },
  'site.tagline': { ja: 'みんなの居場所', en: 'A place for everyone' },

  'auth.login': { ja: 'ログイン', en: 'Log in' },
  'auth.register': { ja: 'アカウント作成', en: 'Create account' },
  'auth.email': { ja: 'メールアドレス', en: 'Email' },
  'auth.password': { ja: 'パスワード', en: 'Password' },
  'auth.username': { ja: 'ユーザー名', en: 'Username' },
  'auth.display_name': { ja: '表示名', en: 'Display name' },
  'auth.have_account': { ja: 'アカウントをお持ちの方', en: 'Already have an account?' },
  'auth.no_account': { ja: 'アカウントをお持ちでない方', en: "Don't have an account?" },
  'auth.welcome': { ja: 'おかえりなさい！', en: 'Welcome back!' },
  'auth.create_welcome': { ja: 'さとっちへようこそ！', en: 'Welcome to Satocchi!' },
  'auth.avatar': { ja: 'アイコン', en: 'Avatar' },

  'post.placeholder': { ja: 'いま何してる？ 🌟', en: "What's happening? 🌟" },
  'post.submit': { ja: '投稿する', en: 'Post' },
  'post.image': { ja: '画像を追加', en: 'Add image' },
  'post.empty': { ja: 'まだ投稿がありません', en: 'No posts yet' },
  'post.read_more': { ja: '続きを読む', en: 'Read more' },
  'post.read_less': { ja: '折りたたむ', en: 'Show less' },

  'voice.rooms': { ja: 'ボイスルーム', en: 'Voice Rooms' },
  'voice.create': { ja: 'ルームを作成', en: 'Create Room' },
  'voice.join': { ja: '参加する', en: 'Join' },
  'voice.leave': { ja: '退出する', en: 'Leave' },
  'voice.name': { ja: 'ルーム名', en: 'Room name' },
  'voice.name_placeholder': { ja: 'ルーム名（任意）', en: 'Room name (optional)' },
  'voice.tag': { ja: 'タグ', en: 'Tag' },
  'voice.members': { ja: '人', en: ' online' },
  'voice.empty': { ja: '開いているルームはありません', en: 'No active rooms' },
  'voice.mute': { ja: 'ミュート', en: 'Mute' },
  'voice.unmute': { ja: 'ミュート解除', en: 'Unmute' },
  'voice.active': { ja: '配信中', en: 'Live' },
  'voice.recommended': { ja: 'おすすめのルーム', en: 'Recommended Rooms' },
  'voice.in_room': { ja: 'ボイスルーム参加中', en: 'In Voice Room' },
  'voice.chat': { ja: 'チャット', en: 'Chat' },
  'voice.whiteboard': { ja: 'お絵かき', en: 'Whiteboard' },
  'voice.music': { ja: '音楽', en: 'Music' },

  'tag.recruit': { ja: '新規募集', en: 'Recruiting' },
  'tag.sleep': { ja: '寝落ちぼ', en: 'Sleep call' },
  'tag.game': { ja: 'ゲームぼ', en: 'Gaming' },
  'tag.chat': { ja: '雑談', en: 'Chat' },
  'tag.music': { ja: '音楽', en: 'Music' },
  'tag.study': { ja: '勉強', en: 'Study' },

  'profile.posts': { ja: '投稿', en: 'Posts' },
  'profile.followers': { ja: 'フォロワー', en: 'Followers' },
  'profile.following': { ja: 'フォロー中', en: 'Following' },
  'profile.follow': { ja: 'フォローする', en: 'Follow' },
  'profile.unfollow': { ja: 'フォロー解除', en: 'Unfollow' },
  'profile.edit': { ja: 'プロフィール編集', en: 'Edit Profile' },
  'profile.joined': { ja: '登録日', en: 'Joined' },
  'profile.bio': { ja: '自己紹介', en: 'Bio' },
  'profile.bio_placeholder': { ja: '自己紹介を入力...', en: 'Tell us about yourself...' },
  'profile.save': { ja: '保存', en: 'Save' },
  'profile.cancel': { ja: 'キャンセル', en: 'Cancel' },
  'profile.voice_status': { ja: '現在のボイスルーム', en: 'Current Voice Room' },

  'feed.title': { ja: 'タイムライン', en: 'Timeline' },
  'feed.global': { ja: 'みんなの投稿', en: 'Global' },
  'feed.following': { ja: 'フォロー中', en: 'Following' },
  'feed.new_posts': { ja: '新しい投稿があります', en: 'New posts available' },
  'feed.refresh': { ja: '更新する', en: 'Refresh' },

  'crew.title': { ja: 'クルー', en: 'Crew' },
  'crew.create': { ja: 'クルーを作成', en: 'Create Crew' },
  'crew.name': { ja: 'クルー名', en: 'Crew name' },
  'crew.desc': { ja: '説明', en: 'Description' },
  'crew.join': { ja: '参加する', en: 'Join' },
  'crew.leave': { ja: '退出する', en: 'Leave' },
  'crew.members': { ja: 'メンバー', en: 'Members' },
  'crew.channels': { ja: 'チャンネル', en: 'Channels' },
  'crew.roles': { ja: 'ロール', en: 'Roles' },
  'crew.discover': { ja: 'クルーを探す', en: 'Discover' },
  'crew.my_crews': { ja: 'マイクルー', en: 'My Crews' },
  'crew.empty': { ja: 'まだクルーに参加していません', en: 'Not in any crew yet' },
  'crew.add_channel': { ja: 'チャンネル追加', en: 'Add Channel' },
  'crew.text_channel': { ja: 'テキスト', en: 'Text' },
  'crew.voice_channel': { ja: 'ボイス', en: 'Voice' },
  'crew.send': { ja: '送信', en: 'Send' },
  'crew.owner': { ja: 'オーナー', en: 'Owner' },
  'crew.admin': { ja: '管理者', en: 'Admin' },
  'crew.member': { ja: 'メンバー', en: 'Member' },

  'notif.title': { ja: '通知', en: 'Notifications' },
  'notif.empty': { ja: '通知はまだありません', en: 'No notifications yet' },
  'notif.follow': { ja: 'があなたをフォローしました', en: 'followed you' },
  'notif.like': { ja: 'があなたの投稿にいいねしました', en: 'liked your post' },
  'notif.reply': { ja: 'があなたの投稿に返信しました', en: 'replied to your post' },
  'notif.mark_read': { ja: 'すべて既読にする', en: 'Mark all read' },

  'settings.title': { ja: '設定', en: 'Settings' },
  'settings.change_password': { ja: 'パスワード変更', en: 'Change Password' },
  'settings.current_password': { ja: '現在のパスワード', en: 'Current password' },
  'settings.new_password': { ja: '新しいパスワード', en: 'New password' },
  'settings.confirm_password': { ja: 'パスワード確認', en: 'Confirm password' },
  'settings.account': { ja: 'アカウント', en: 'Account' },
  'settings.appearance': { ja: '外観', en: 'Appearance' },
  'settings.language': { ja: '言語', en: 'Language' },
  'settings.theme': { ja: 'テーマ', en: 'Theme' },

  'general.loading': { ja: '読み込み中...', en: 'Loading...' },
  'general.error': { ja: 'エラーが発生しました', en: 'An error occurred' },
  'general.save': { ja: '保存', en: 'Save' },
  'general.cancel': { ja: 'キャンセル', en: 'Cancel' },
  'general.delete': { ja: '削除', en: 'Delete' },
  'general.confirm': { ja: '確認', en: 'Confirm' },
  'general.just_now': { ja: 'たった今', en: 'Just now' },
};

export function t(key: string, lang: Lang = 'ja'): string {
  return translations[key]?.[lang] ?? key;
}

export function generateI18nScript(lang: Lang): string {
  const subset: Record<string, string> = {};
  for (const [key, val] of Object.entries(translations)) {
    subset[key] = val[lang];
  }
  return `window.__LANG__='${lang}';window.__I18N__=${JSON.stringify(subset)};function t(k){return window.__I18N__[k]||k;}`;
}
