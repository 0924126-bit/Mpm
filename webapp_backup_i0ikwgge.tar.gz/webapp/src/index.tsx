import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { getCookie, setCookie, deleteCookie } from 'hono/cookie'
import { hashPassword, verifyPassword, generateId, generateSessionId } from './lib/auth'
import { t, generateI18nScript } from './lib/i18n'
import type { Lang } from './lib/i18n'
import adminJsContent from '../private/admin.js?raw'

type Bindings = { DB: D1Database; CHAT_ROOM?: DurableObjectNamespace }
type Variables = { user: any; lang: Lang; clientIp: string }

// Re-export Durable Object class so Cloudflare can find it
export { ChatRoom } from './chat-room'

const app = new Hono<{ Bindings: Bindings; Variables: Variables }>()

app.use('/api/*', cors())

// Security headers + Performance headers (combined to reduce middleware overhead)
app.use('*', async (c, next) => {
  await next()
  // Security
  c.header('X-Content-Type-Options', 'nosniff')
  c.header('X-Frame-Options', 'DENY')
  c.header('Referrer-Policy', 'strict-origin-when-cross-origin')
  // Performance: Vary for CDN caching
  if (!c.res.headers.has('Vary')) c.header('Vary', 'Accept-Encoding')
  // Static assets: aggressive caching (Cloudflare handles content-hash via ETag)
  const path = c.req.path
  if (path.startsWith('/static/')) {
    if (path.endsWith('.js') || path.endsWith('.css')) {
      c.header('Cache-Control', 'public, max-age=86400, stale-while-revalidate=604800')
    } else if (path.endsWith('.png') || path.endsWith('.svg') || path.endsWith('.ico')) {
      c.header('Cache-Control', 'public, max-age=604800, immutable')
    } else if (path.endsWith('.wav') || path.endsWith('.mp3')) {
      c.header('Cache-Control', 'public, max-age=604800, immutable')
    }
  }
  // API cache headers
  if (c.req.method === 'GET' && path.startsWith('/api/')) {
    if (path.includes('/api/casino/leaderboard') || path.includes('/api/crews/discover') || path.includes('/api/admin/announcements')) {
      c.header('Cache-Control', 'public, max-age=15, stale-while-revalidate=30')
    } else if (path.includes('/api/posts') || path.includes('/api/voice-rooms')) {
      c.header('Cache-Control', 'public, max-age=3, stale-while-revalidate=8')
    } else if (path.includes('/api/users/')) {
      c.header('Cache-Control', 'public, max-age=8, stale-while-revalidate=15')
    } else if (path === '/api/me' || path.includes('/api/dm/unread') || path.includes('/api/notifications/unread')) {
      c.header('Cache-Control', 'private, max-age=2, stale-while-revalidate=4')
    } else if (path.includes('/api/channels/') || path.includes('/api/sse/')) {
      c.header('Cache-Control', 'no-cache')
    }
  }
  // SPA HTML: cache briefly for faster back-button
  if (!path.startsWith('/api/') && !path.startsWith('/static/') && !path.includes('.')) {
    c.header('Cache-Control', 'public, max-age=5, stale-while-revalidate=30')
  }
})

// Auth middleware + ban check + IP tracking
app.use('*', async (c, next) => {
  const lang = (getCookie(c, 'lang') as Lang) || 'ja'
  c.set('lang', lang)
  // Extract client IP
  const clientIp = c.req.header('cf-connecting-ip') || c.req.header('x-forwarded-for')?.split(',')[0]?.trim() || c.req.header('x-real-ip') || '0.0.0.0'
  c.set('clientIp', clientIp)
  const sessionId = getCookie(c, 'session')
  if (sessionId) {
    try {
      const session = await c.env.DB.prepare(
        `SELECT u.id, u.username, u.display_name, u.email, u.bio, u.avatar_url, u.banner_url, u.lang, u.theme, u.profile_url, u.coins, u.role, u.is_banned, u.ban_reason, u.is_suspended, u.suspended_until, u.is_official, u.name_color, u.bg_color, u.badge, u.sid, u.age_verified, u.is_adult, u.show_r18, u.app_version, u.is_private
         FROM sessions s JOIN users u ON s.user_id = u.id
         WHERE s.id = ? AND s.expires_at > datetime('now')`
      ).bind(sessionId).first()
      if (session) {
        // Check ban/suspension
        if ((session as any).is_banned) {
          if (c.req.path === '/api/logout') { c.set('user', session); await next(); return; }
          if (c.req.path.startsWith('/api/')) return c.json({ error: 'Account banned', reason: (session as any).ban_reason }, 403)
        }
        if ((session as any).is_suspended && (session as any).suspended_until) {
          const until = new Date((session as any).suspended_until + 'Z')
          if (until > new Date()) {
            if (c.req.path === '/api/logout') { c.set('user', session); await next(); return; }
            if (c.req.path.startsWith('/api/') && !c.req.path.startsWith('/api/me')) return c.json({ error: 'Account suspended', until: (session as any).suspended_until }, 403)
          }
        }
        c.set('user', session)
        // Log IP for tracking (async, non-blocking, fire-and-forget)
        if (c.req.path.startsWith('/api/') && c.req.method !== 'GET') {
          const ipId = generateId()
          c.env.DB.prepare('INSERT INTO ip_connections (id, user_id, ip_address, endpoint) VALUES (?, ?, ?, ?)').bind(ipId, (session as any).id, clientIp, c.req.path).run().catch(() => {})
        }
      }
    } catch (e) {}
  }
  await next()
})

// Helper: rate limiter (with safe table/field validation)
const VALID_RATE_TABLES: Record<string, string> = {
  'posts_per_minute': 'posts:user_id',
  'dm_per_minute': 'messages:sender_id',
  'messages_per_minute': 'crew_messages:sender_id',
}
async function checkRateLimit(db: D1Database, userId: string, type: string, table: string, field: string): Promise<{ allowed: boolean; limit: number }> {
  try {
    // Validate table/field against whitelist to prevent SQL injection
    const allowed = VALID_RATE_TABLES[type]
    if (!allowed) return { allowed: true, limit: 5 }
    const [safeTable, safeField] = allowed.split(':')
    const config = await db.prepare('SELECT value FROM rate_limit_config WHERE key = ?').bind(type).first() as any
    const limit = config?.value || 5
    const count = await db.prepare(`SELECT COUNT(*) as c FROM ${safeTable} WHERE ${safeField} = ? AND created_at > datetime('now', '-1 minute')`).bind(userId).first() as any
    return { allowed: !count || count.c < limit, limit }
  } catch (e) { return { allowed: true, limit: 5 } }
}

// Helper: spam word detection
async function containsSpamWords(db: D1Database, content: string): Promise<boolean> {
  try {
    const words = await db.prepare('SELECT word FROM spam_words').all()
    const lower = content.toLowerCase()
    return (words.results || []).some((w: any) => lower.includes(w.word.toLowerCase()))
  } catch { return false }
}

// Helper: check duplicate post (rapid same-content detection)
async function isDuplicatePost(db: D1Database, userId: string, content: string): Promise<boolean> {
  try {
    // Simple hash: first 50 chars + length
    const hash = content.trim().substring(0, 50).toLowerCase().replace(/\s+/g, '') + '_' + content.length
    const existing = await db.prepare(
      "SELECT 1 FROM post_hashes WHERE user_id = ? AND content_hash = ? AND created_at > datetime('now', '-5 minutes')"
    ).bind(userId, hash).first()
    if (existing) return true
    // Store hash
    await db.prepare('INSERT OR REPLACE INTO post_hashes (user_id, content_hash) VALUES (?, ?)').bind(userId, hash).run()
    // Cleanup old hashes
    db.prepare("DELETE FROM post_hashes WHERE created_at < datetime('now', '-1 hour')").run()
    return false
  } catch { return false }
}

// Helper: check IP abuse (multiple accounts from same IP)
async function getIPConnectionCount(db: D1Database, ip: string): Promise<number> {
  try {
    const r = await db.prepare(
      "SELECT COUNT(DISTINCT user_id) as c FROM ip_connections WHERE ip_address = ? AND created_at > datetime('now', '-1 hour')"
    ).bind(ip).first() as any
    return r?.c || 0
  } catch { return 0 }
}

// Helper: check block
async function isBlocked(db: D1Database, userId: string, targetId: string): Promise<boolean> {
  const b = await db.prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ? AND is_ghost = 0').bind(targetId, userId).first()
  return !!b
}
async function isGhostBlocked(db: D1Database, blockerId: string, blockedId: string): Promise<boolean> {
  const b = await db.prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ? AND is_ghost = 1').bind(blockerId, blockedId).first()
  return !!b
}

// Helper: enrich posts with quoted_post data for koremite display
async function enrichPostsWithQuotes(db: D1Database, posts: any[]): Promise<any[]> {
  const quotedIds = posts.filter(p => p.quote_of_id).map(p => p.quote_of_id)
  if (quotedIds.length === 0) return posts
  try {
    const uniqueIds = [...new Set(quotedIds)]
    const placeholders = uniqueIds.map(() => '?').join(',')
    const quotedPosts = await db.prepare(
      `SELECT p.id, p.content, p.image_url, p.created_at, u.username, u.display_name, u.avatar_url
       FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id IN (${placeholders})`
    ).bind(...uniqueIds).all()
    const quotedMap = new Map<string, any>()
    for (const qp of (quotedPosts.results || [])) { quotedMap.set((qp as any).id, qp) }
    for (const post of posts) {
      if (post.quote_of_id && quotedMap.has(post.quote_of_id)) {
        post.quoted_post = quotedMap.get(post.quote_of_id)
      }
    }
  } catch {}
  return posts
}

// Helper: admin check
function isAdmin(user: any): boolean { return user && (user.role === 'admin' || user.role === 'superadmin') }

// ===== AUTH =====
app.post('/api/register', async (c) => {
  try {
    const { username, display_name, email, password } = await c.req.json()
    if (!username || !display_name || !email || !password) return c.json({ error: 'All fields required' }, 400)
    if (password.length < 6) return c.json({ error: 'Password too short' }, 400)
    if (!/^[a-zA-Z0-9_]{1,20}$/.test(username)) return c.json({ error: 'Invalid username' }, 400)
    const existing = await c.env.DB.prepare('SELECT id FROM users WHERE username = ? OR email = ?').bind(username.toLowerCase(), email).first()
    if (existing) return c.json({ error: 'Username or email taken' }, 409)
    const id = generateId()
    const ph = await hashPassword(password)
    // Auto-promote first user to superadmin with 500 coins
    const userCount = await c.env.DB.prepare('SELECT COUNT(*) as c FROM users').first() as any
    const isFirstUser = !userCount || userCount.c === 0
    const initialCoins = isFirstUser ? 500 : 100
    const role = isFirstUser ? 'superadmin' : 'user'
    const isOfficial = isFirstUser ? 1 : 0
    const userSid = generateId() // permanent stable ID
    await c.env.DB.prepare('INSERT INTO users (id, username, display_name, email, password_hash, coins, role, is_official, sid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').bind(id, username.toLowerCase(), display_name, email, ph, initialCoins, role, isOfficial, userSid).run()
    const sid = generateSessionId()
    await c.env.DB.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))").bind(sid, id).run()
    const tid = generateId()
    await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type) VALUES (?, ?, ?, 'signup_bonus')").bind(tid, id, initialCoins).run()
    setCookie(c, 'session', sid, { path: '/', httpOnly: true, sameSite: 'Lax', maxAge: 2592000 })
    return c.json({ success: true, user: { id, username: username.toLowerCase(), display_name, coins: initialCoins, role, is_official: isOfficial, name_color: '', bg_color: '', badge: '', sid: userSid, age_verified: 0, is_adult: 0, show_r18: 0, app_version: '', is_private: 0 } })
  } catch (e: any) { return c.json({ error: e.message }, 500) }
})

app.post('/api/login', async (c) => {
  try {
    const { email, password } = await c.req.json()
    const user = await c.env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first() as any
    if (!user || !(await verifyPassword(password, user.password_hash))) return c.json({ error: 'Invalid credentials' }, 401)
    if (user.is_banned) return c.json({ error: 'Account banned', reason: user.ban_reason }, 403)
    const sid = generateSessionId()
    await c.env.DB.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))").bind(sid, user.id).run()
    setCookie(c, 'session', sid, { path: '/', httpOnly: true, sameSite: 'Lax', maxAge: 2592000 })
    return c.json({ success: true, user: { id: user.id, username: user.username, display_name: user.display_name, avatar_url: user.avatar_url, banner_url: user.banner_url, bio: user.bio, theme: user.theme, profile_url: user.profile_url, coins: user.coins, role: user.role || 'user', is_official: user.is_official || 0, name_color: user.name_color || '', bg_color: user.bg_color || '', badge: user.badge || '', sid: user.sid || '', age_verified: user.age_verified || 0, is_adult: user.is_adult || 0, show_r18: user.show_r18 || 0, app_version: user.app_version || '', is_private: user.is_private || 0 } })
  } catch (e: any) { return c.json({ error: e.message }, 500) }
})

app.post('/api/logout', async (c) => {
  const sid = getCookie(c, 'session')
  if (sid) await c.env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(sid).run()
  deleteCookie(c, 'session', { path: '/' })
  return c.json({ success: true })
})

app.get('/api/me', (c) => c.json({ user: c.get('user') || null }))

// Age verification
app.post('/api/age-verify', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { is_adult } = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET age_verified = 1, is_adult = ? WHERE id = ?').bind(is_adult ? 1 : 0, u.id).run()
  return c.json({ success: true })
})

// R18 content preference (for 18+ users)
app.post('/api/r18-preference', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { show_r18 } = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET show_r18 = ? WHERE id = ?').bind(show_r18 ? 1 : 0, u.id).run()
  return c.json({ success: true })
})

// Update app version marker (for showing age verify on updates)
app.post('/api/app-version', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { version } = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET app_version = ? WHERE id = ?').bind(version || '', u.id).run()
  return c.json({ success: true })
})

// ===== PROFILE =====
app.put('/api/profile', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { display_name, bio, avatar_url, banner_url, theme, profile_url, is_adult, show_r18, is_private } = await c.req.json()
  const sets: string[] = []; const vals: any[] = []
  if (display_name !== undefined) { sets.push('display_name = ?'); vals.push(display_name) }
  if (bio !== undefined) { sets.push('bio = ?'); vals.push(bio) }
  if (avatar_url !== undefined) { sets.push('avatar_url = ?'); vals.push(avatar_url) }
  if (banner_url !== undefined) { sets.push('banner_url = ?'); vals.push(banner_url) }
  if (theme !== undefined) { sets.push('theme = ?'); vals.push(theme) }
  if (profile_url !== undefined) { sets.push('profile_url = ?'); vals.push(profile_url) }
  if (is_adult !== undefined) { sets.push('is_adult = ?'); vals.push(is_adult ? 1 : 0) }
  if (show_r18 !== undefined) { sets.push('show_r18 = ?'); vals.push(show_r18 ? 1 : 0) }
  if (is_private !== undefined) { sets.push('is_private = ?'); vals.push(is_private ? 1 : 0) }
  if (sets.length === 0) return c.json({ error: 'Nothing to update' }, 400)
  vals.push(u.id)
  await c.env.DB.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run()
  return c.json({ success: true })
})

// Change username (user ID)
app.put('/api/profile/username', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { username } = await c.req.json()
  if (!username) return c.json({ error: 'Username required' }, 400)
  const newUsername = username.toLowerCase().trim()
  if (!/^[a-zA-Z0-9_]{1,20}$/.test(newUsername)) return c.json({ error: 'Invalid username: 1-20 chars, alphanumeric and _ only' }, 400)
  if (newUsername === u.username) return c.json({ error: 'Same as current' }, 400)
  // Rate limit: max 1 change per 24 hours
  try {
    const recent = await c.env.DB.prepare(
      "SELECT 1 FROM username_changes WHERE user_id = ? AND changed_at > datetime('now', '-1 day')"
    ).bind(u.id).first()
    if (recent) return c.json({ error: 'Can only change once per 24 hours' }, 429)
  } catch {}
  // Check availability
  const existing = await c.env.DB.prepare('SELECT id FROM users WHERE username = ? AND id != ?').bind(newUsername, u.id).first()
  if (existing) return c.json({ error: 'Username already taken' }, 409)
  // Update
  await c.env.DB.prepare('UPDATE users SET username = ? WHERE id = ?').bind(newUsername, u.id).run()
  // Log the change
  try {
    const changeId = generateId()
    await c.env.DB.prepare(
      'INSERT INTO username_changes (id, user_id, old_username, new_username) VALUES (?, ?, ?, ?)'
    ).bind(changeId, u.id, u.username, newUsername).run()
  } catch {}
  return c.json({ success: true, username: newUsername })
})

app.post('/api/change-password', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { current_password, new_password } = await c.req.json()
  if (!current_password || !new_password) return c.json({ error: 'Both passwords required' }, 400)
  if (new_password.length < 6) return c.json({ error: 'Password too short' }, 400)
  const user = await c.env.DB.prepare('SELECT password_hash FROM users WHERE id = ?').bind(u.id).first() as any
  if (!user || !(await verifyPassword(current_password, user.password_hash))) return c.json({ error: 'Current password is incorrect' }, 401)
  const ph = await hashPassword(new_password)
  await c.env.DB.prepare('UPDATE users SET password_hash = ? WHERE id = ?').bind(ph, u.id).run()
  return c.json({ success: true })
})

app.post('/api/lang', async (c) => {
  const { lang } = await c.req.json()
  if (lang !== 'ja' && lang !== 'en') return c.json({ error: 'Invalid' }, 400)
  setCookie(c, 'lang', lang, { path: '/', maxAge: 31536000 })
  const u = c.get('user')
  if (u) await c.env.DB.prepare('UPDATE users SET lang = ? WHERE id = ?').bind(lang, u.id).run()
  return c.json({ success: true })
})

// ===== COINS =====
app.get('/api/coins', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const user = await c.env.DB.prepare('SELECT coins FROM users WHERE id = ?').bind(u.id).first() as any
  return c.json({ coins: user?.coins || 0 })
})

app.get('/api/coins/history', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const txns = await c.env.DB.prepare('SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').bind(u.id).all()
  return c.json({ transactions: txns.results })
})

app.post('/api/coins/send', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { target_user_id, amount, message } = await c.req.json()
  if (!target_user_id || !amount || amount < 1) return c.json({ error: 'Invalid' }, 400)
  if (target_user_id === u.id) return c.json({ error: 'Cannot send to yourself' }, 400)
  const sender = await c.env.DB.prepare('SELECT coins FROM users WHERE id = ?').bind(u.id).first() as any
  if (!sender || sender.coins < amount) return c.json({ error: 'Insufficient coins' }, 400)
  await c.env.DB.prepare('UPDATE users SET coins = coins - ? WHERE id = ?').bind(amount, u.id).run()
  await c.env.DB.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').bind(amount, target_user_id).run()
  const t1 = generateId(), t2 = generateId()
  await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, ?, 'send', ?)").bind(t1, u.id, -amount, target_user_id).run()
  await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, ?, 'receive', ?)").bind(t2, target_user_id, amount, u.id).run()
  // Coin throw record
  const throwId = generateId()
  await c.env.DB.prepare('INSERT INTO coin_throws (id, sender_id, receiver_id, amount, message) VALUES (?, ?, ?, ?, ?)').bind(throwId, u.id, target_user_id, amount, message || '').run()
  // Notification
  const nid = generateId()
  await c.env.DB.prepare("INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, 'coin', ?, ?, 'coin')").bind(nid, target_user_id, u.id, String(amount)).run()
  return c.json({ success: true, new_balance: sender.coins - amount })
})

// Get coin throws received by a user
app.get('/api/coins/throws/:userId', async (c) => {
  const uid = c.req.param('userId')
  const throws = await c.env.DB.prepare(`
    SELECT ct.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url
    FROM coin_throws ct JOIN users u ON ct.sender_id = u.id WHERE ct.receiver_id = ? ORDER BY ct.created_at DESC LIMIT 20
  `).bind(uid).all()
  return c.json({ throws: throws.results })
})

// ===== WebSocket Chat Hub via Durable Objects =====
// Each channel (dm:xxx, crew:xxx, vr:xxx, wb:xxx) gets its own Durable Object instance
// Messages are routed through the DO, which manages all WebSocket connections for that channel
// The DO uses WebSocket Hibernation to keep connections alive even when idle

// In-memory WebSocket hub (fallback when DO not available)
type WsClient = { ws: WebSocket; userId: string; username: string; displayName: string; avatarUrl: string }
const wsChannels = new Map<string, Map<WebSocket, WsClient>>()
function broadcastToChannel(channel: string, data: any, excludeWs?: WebSocket) {
  const json = JSON.stringify(data)
  const clients = wsChannels.get(channel)
  if (!clients) return
  for (const [ws, client] of clients) {
    if (ws === excludeWs) continue
    try { ws.send(json) } catch { clients.delete(ws) }
  }
}

app.get('/api/ws', async (c) => {
  const upgradeHeader = c.req.header('Upgrade')
  if (!upgradeHeader || upgradeHeader !== 'websocket') {
    return new Response('Expected Upgrade: websocket', { status: 426 })
  }
  const u = c.get('user')
  if (!u) return new Response('Unauthorized', { status: 401 })

  const channel = c.req.query('channel') || ''
  if (!channel) return new Response('Channel required', { status: 400 })

  // Try Durable Objects first (production with DO Worker)
  if (c.env.CHAT_ROOM) {
    try {
      const doId = c.env.CHAT_ROOM.idFromName(channel)
      const doStub = c.env.CHAT_ROOM.get(doId)
      const doUrl = new URL('https://do/ws')
      doUrl.searchParams.set('channel', channel)
      doUrl.searchParams.set('userId', u.id)
      doUrl.searchParams.set('username', u.username)
      doUrl.searchParams.set('displayName', u.display_name || '')
      doUrl.searchParams.set('avatarUrl', u.avatar_url || '')
      return doStub.fetch(doUrl.toString(), { headers: c.req.raw.headers })
    } catch (e) { console.error('DO fallback:', e) }
  }

  // Fallback: in-memory WebSocket hub
  const pair = new WebSocketPair()
  const [client, server] = Object.values(pair)
  server.accept()
  const clientInfo: WsClient = { ws: server, userId: u.id, username: u.username, displayName: u.display_name || '', avatarUrl: u.avatar_url || '' }
  if (!wsChannels.has(channel)) wsChannels.set(channel, new Map())
  wsChannels.get(channel)!.set(server, clientInfo)
  const online = wsChannels.get(channel)!.size
  broadcastToChannel(channel, { type: 'user_join', user_id: u.id, username: u.username, display_name: u.display_name, online }, server)
  server.send(JSON.stringify({ type: 'connected', channel, online }))

  const [type, id] = channel.split(':')
  let recentMsgIds = new Set<string>()

  server.addEventListener('message', (event) => {
    try {
      const data = JSON.parse(event.data as string)
      if (data.type === 'chat' && data.content?.trim()) {
        const content = data.content.trim().substring(0, 2000)
        const clientMsgId = data.client_id || ''
        if (clientMsgId && recentMsgIds.has(clientMsgId)) return
        if (clientMsgId) { recentMsgIds.add(clientMsgId); if (recentMsgIds.size > 50) recentMsgIds = new Set([...recentMsgIds].slice(-25)) }
        const msgId = crypto.randomUUID().replace(/-/g, '').substring(0, 16)
        const now = new Date().toISOString()
        // Broadcast FIRST for instant delivery, then persist async (no await)
        broadcastToChannel(channel, { type: 'chat', message: { id: msgId, sender_id: u.id, content, created_at: now, sender_username: u.username, sender_display_name: u.display_name, sender_avatar_url: u.avatar_url, client_id: clientMsgId } })
        // Fire-and-forget DB persistence — no D1 latency on the hot path
        try {
          if (type === 'dm') {
            c.env.DB.prepare('INSERT INTO messages (id, conversation_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, u.id, content).run()
            c.env.DB.prepare("UPDATE conversations SET last_message_at = datetime('now') WHERE id = ?").bind(id).run()
          } else if (type === 'crew') {
            c.env.DB.prepare('INSERT INTO crew_messages (id, channel_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, u.id, content).run()
          } else if (type === 'vr') {
            c.env.DB.prepare('INSERT INTO voice_room_messages (id, room_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, u.id, content).run()
          }
        } catch {}
      } else if (data.type === 'typing') {
        broadcastToChannel(channel, { type: 'typing', user_id: u.id, username: u.username, display_name: u.display_name }, server)
      } else if (data.type === 'stroke' && data.stroke_data) {
        const strokeId = crypto.randomUUID().replace(/-/g, '').substring(0, 16)
        broadcastToChannel(channel, { type: 'stroke', stroke: { id: strokeId, user_id: u.id, stroke_data: data.stroke_data, color: data.color || '#c8553d', width: data.width || 3, tool: data.tool || 'pen' } })
        // Fire-and-forget
        c.env.DB.prepare('INSERT INTO whiteboard_strokes (id, room_id, user_id, stroke_data, color, width, tool) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(strokeId, id, u.id, data.stroke_data, data.color || '#c8553d', data.width || 3, data.tool || 'pen').run()
      } else if (data.type === 'wb_clear') {
        broadcastToChannel(channel, { type: 'wb_clear' })
      } else if (data.type === 'ping') {
        server.send(JSON.stringify({ type: 'pong', ts: Date.now() }))
      }
    } catch {}
  })

  server.addEventListener('close', () => {
    const clients = wsChannels.get(channel)
    if (clients) { clients.delete(server); broadcastToChannel(channel, { type: 'user_leave', user_id: u.id, username: u.username, online: clients.size }) }
  })
  server.addEventListener('error', () => {
    const clients = wsChannels.get(channel)
    if (clients) { clients.delete(server); broadcastToChannel(channel, { type: 'user_leave', user_id: u.id, username: u.username, online: clients.size }) }
  })

  return new Response(null, { status: 101, webSocket: client })
})

// ===== POSTS =====
// Track post views for recommendation algorithm
app.post('/api/posts/view', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ success: true })
  const { post_ids } = await c.req.json()
  if (!Array.isArray(post_ids) || post_ids.length === 0) return c.json({ success: true })
  // Batch upsert views (max 20 at a time)
  const ids = post_ids.slice(0, 20)
  for (const pid of ids) {
    try {
      await c.env.DB.prepare(`INSERT INTO post_views (user_id, post_id, view_count, last_viewed_at)
        VALUES (?, ?, 1, datetime('now'))
        ON CONFLICT(user_id, post_id) DO UPDATE SET view_count = view_count + 1, last_viewed_at = datetime('now')
      `).bind(u.id, pid).run()
    } catch {}
  }
  // Update user interest scores based on interaction
  try {
    for (const pid of ids) {
      const post = await c.env.DB.prepare('SELECT user_id FROM posts WHERE id = ?').bind(pid).first() as any
      if (post && post.user_id !== u.id) {
        await c.env.DB.prepare(`INSERT INTO user_interests (user_id, interest_user_id, score, updated_at)
          VALUES (?, ?, 1, datetime('now'))
          ON CONFLICT(user_id, interest_user_id) DO UPDATE SET score = score + 1, updated_at = datetime('now')
        `).bind(u.id, post.user_id).run()
      }
    }
  } catch {}
  return c.json({ success: true })
})

app.get('/api/posts', async (c) => {
  const tab = c.req.query('tab') || 'global'
  const u = c.get('user')
  const uid = u?.id || '__none__'
  const limit = Math.min(parseInt(c.req.query('limit') || '20'), 50)
  const cursor = c.req.query('cursor') || ''
  let where = ''
  const params: any[] = [uid]
  
  // Block filter
  if (u) {
    where += ` AND p.user_id NOT IN (SELECT blocked_id FROM blocks WHERE blocker_id = ? AND is_ghost = 0)`
    params.push(u.id)
    where += ` AND p.user_id NOT IN (SELECT blocker_id FROM blocks WHERE blocked_id = ? AND is_ghost = 0)`
    params.push(u.id)
  }
  
  // Hide banned users' posts
  where += ` AND p.user_id NOT IN (SELECT id FROM users WHERE is_banned = 1)`
  
  // Hide low-rated posts (rating score < -3)
  where += ` AND (SELECT COALESCE(SUM(rating), 0) FROM post_ratings WHERE post_id = p.id) > -3`
  
  // R18 content filtering: hide from underage or non-opted-in users
  if (!u || !(u as any).is_adult || !(u as any).show_r18) {
    where += ` AND COALESCE(p.is_r18, 0) = 0`
  }
  
  // Private account filter: hide private users' posts unless following or own
  if (tab !== 'following') {
    if (u) {
      where += ` AND (COALESCE((SELECT is_private FROM users WHERE id = p.user_id), 0) = 0 OR p.user_id = ? OR p.user_id IN (SELECT following_id FROM follows WHERE follower_id = ?))`
      params.push(u.id, u.id)
    } else {
      where += ` AND COALESCE((SELECT is_private FROM users WHERE id = p.user_id), 0) = 0`
    }
  }
  
  if (tab === 'following' && u) {
    where += ` AND p.user_id IN (SELECT following_id FROM follows WHERE follower_id = ?)`
    params.push(u.id)
  }
  
  if (cursor) { where += ` AND p.created_at < ?`; params.push(cursor) }
  where += ` AND (p.reply_to_id = '' OR p.reply_to_id IS NULL)`
  where += ` AND (p.expires_at IS NULL OR p.expires_at > datetime('now'))`

  // Blacklist + not-interested filtering for recommended tab
  if (tab === 'recommended' && u) {
    where += ` AND p.id NOT IN (SELECT post_id FROM not_interested WHERE user_id = '${u.id}')`
    where += ` AND p.user_id NOT IN (SELECT target_id FROM user_blacklist WHERE user_id = '${u.id}' AND blacklist_type = 'author' AND (expires_at IS NULL OR expires_at > datetime('now')))`
  }

  params.push(limit)
  
  let orderBy = 'ORDER BY p.created_at DESC'
  
  // Algorithmic feed only for 'recommended' tab
  // 'global' tab = chronological (all posts, newest first)
  if (tab === 'recommended') {
    // Fetch more candidates than needed, then apply diversity post-processing
    const overFetchMultiplier = 3
    params[params.length - 1] = limit * overFetchMultiplier

    if (u) {
      // Enhanced scoring algorithm v5:
      // - Strong freshness bias for active feel
      // - Heavy seen penalty to eliminate repeats
      // - Large random factor for variety on every refresh
      // - Interest + engagement scoring
      // - Topic interest matching via hashtags
      // - Negative signal suppression
      orderBy = `ORDER BY (
        CASE
          WHEN p.created_at > datetime('now', '-30 minutes') THEN 50
          WHEN p.created_at > datetime('now', '-1 hour') THEN 40
          WHEN p.created_at > datetime('now', '-3 hours') THEN 28
          WHEN p.created_at > datetime('now', '-6 hours') THEN 18
          WHEN p.created_at > datetime('now', '-12 hours') THEN 10
          WHEN p.created_at > datetime('now', '-24 hours') THEN 4
          ELSE 0
        END
        + (SELECT COUNT(*) FROM likes WHERE post_id = p.id) * 3
        + (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) * 5
        + CASE WHEN p.user_id IN (SELECT following_id FROM follows WHERE follower_id = '${u.id}') THEN 15 ELSE 0 END
        + COALESCE((SELECT score FROM user_interests WHERE user_id = '${u.id}' AND interest_user_id = p.user_id), 0)
        - CASE
            WHEN (SELECT view_count FROM post_views WHERE user_id = '${u.id}' AND post_id = p.id) > 3 THEN 60
            WHEN (SELECT view_count FROM post_views WHERE user_id = '${u.id}' AND post_id = p.id) > 1 THEN 35
            WHEN (SELECT view_count FROM post_views WHERE user_id = '${u.id}' AND post_id = p.id) > 0 THEN 20
            ELSE 0
          END
        + COALESCE((SELECT SUM(rating) FROM post_ratings WHERE post_id = p.id), 0) * 3
        + (ABS(RANDOM()) % 25)
        + CASE WHEN p.image_url != '' THEN 5 ELSE 0 END
        + CASE WHEN p.quote_of_id != '' THEN 3 ELSE 0 END
        + CASE WHEN p.text_style != '' THEN 2 ELSE 0 END
        + COALESCE((SELECT MAX(uti.score) FROM user_topic_interests uti WHERE uti.user_id = '${u.id}' AND (',' || REPLACE(LOWER(p.content), '#', ',') || ',') LIKE '%,' || uti.topic || ',%'), 0) * 2
        - COALESCE((SELECT SUM(CASE WHEN es.signal_type = 'not_interested' THEN 5 WHEN es.signal_type = 'scroll_skip' THEN 1.5 ELSE 0 END) FROM engagement_signals es WHERE es.post_id = p.id AND es.user_id = '${u.id}'), 0)
      ) DESC, p.created_at DESC`
    } else {
      orderBy = `ORDER BY (
        CASE
          WHEN p.created_at > datetime('now', '-1 hour') THEN 40
          WHEN p.created_at > datetime('now', '-6 hours') THEN 20
          WHEN p.created_at > datetime('now', '-24 hours') THEN 8
          ELSE 0
        END
        + (SELECT COUNT(*) FROM likes WHERE post_id = p.id) * 3
        + (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) * 5
        + COALESCE((SELECT SUM(rating) FROM post_ratings WHERE post_id = p.id), 0) * 3
        + (ABS(RANDOM()) % 25)
        + CASE WHEN p.image_url != '' THEN 5 ELSE 0 END
      ) DESC, p.created_at DESC`
    }
  }
  
  const posts = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge, u.sid as user_sid,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM posts p JOIN users u ON p.user_id = u.id
    WHERE 1=1 ${where}
    ${orderBy} LIMIT ?
  `).bind(...params).all()

  let finalPosts = posts.results as any[]

  // Diversity post-processing for recommended tab:
  // Limit max consecutive posts from same author, ensure variety
  if (tab === 'recommended' && finalPosts.length > limit) {
    const diverse: any[] = []
    const authorCount: Record<string, number> = {}
    const MAX_PER_AUTHOR = 3 // max posts from same author in one page
    for (const p of finalPosts) {
      const aid = p.user_id
      authorCount[aid] = (authorCount[aid] || 0) + 1
      if (authorCount[aid] <= MAX_PER_AUTHOR) {
        diverse.push(p)
      }
      if (diverse.length >= limit) break
    }
    // If not enough after diversity filter, fill from remaining
    if (diverse.length < limit) {
      const diverseIds = new Set(diverse.map((p: any) => p.id))
      for (const p of finalPosts) {
        if (!diverseIds.has(p.id)) {
          diverse.push(p)
          if (diverse.length >= limit) break
        }
      }
    }
    finalPosts = diverse
  }

  const next_cursor = finalPosts.length >= limit ? (finalPosts[finalPosts.length - 1] as any).created_at : null
  const enrichedPosts = await enrichPostsWithQuotes(c.env.DB, finalPosts.slice(0, limit))
  return c.json({ posts: enrichedPosts, next_cursor })
})

app.get('/api/posts/:id', async (c) => {
  const u = c.get('user'); const uid = u?.id || '__none__'
  const id = c.req.param('id')
  const post = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id = ?
  `).bind(uid, id).first()
  if (!post) return c.json({ error: 'Not found' }, 404)
  const replies = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM posts p JOIN users u ON p.user_id = u.id
    WHERE p.reply_to_id = ? ORDER BY p.created_at ASC
  `).bind(uid, id).all()
  const edits = await c.env.DB.prepare('SELECT * FROM post_edits WHERE post_id = ? ORDER BY edited_at DESC').bind(id).all()
  const poll = await c.env.DB.prepare('SELECT * FROM polls WHERE post_id = ?').bind(id).first() as any
  let pollData = null
  if (poll) {
    const options = await c.env.DB.prepare('SELECT po.*, (SELECT COUNT(*) FROM poll_votes WHERE option_id = po.id) as vote_count FROM poll_options po WHERE po.poll_id = ? ORDER BY po.position').bind(poll.id).all()
    const myVote = u ? await c.env.DB.prepare('SELECT option_id FROM poll_votes WHERE poll_id = ? AND user_id = ?').bind(poll.id, u.id).first() : null
    const totalVotes = await c.env.DB.prepare('SELECT COUNT(*) as c FROM poll_votes WHERE poll_id = ?').bind(poll.id).first() as any
    pollData = { ...poll, options: options.results, my_vote: myVote ? (myVote as any).option_id : null, total_votes: totalVotes?.c || 0 }
  }
  let quotedPost = null
  if ((post as any).quote_of_id) {
    quotedPost = await c.env.DB.prepare('SELECT p.*, u.username, u.display_name, u.avatar_url FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id = ?').bind((post as any).quote_of_id).first()
  }
  // Check bookmark status
  let bookmarked = false
  if (u) {
    try {
      const bm = await c.env.DB.prepare('SELECT 1 FROM bookmarks WHERE user_id = ? AND post_id = ?').bind(u.id, id).first()
      bookmarked = !!bm
    } catch {}
  }
  return c.json({ post, replies: replies.results, edits: edits.results, poll: pollData, quoted_post: quotedPost, bookmarked })
})

app.post('/api/posts', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { content, image_url, reply_to_id, text_style, quote_of_id, expires_in_hours, poll_options, is_r18, is_ai_generated, video_url } = await c.req.json()
  if (!content?.trim()) return c.json({ error: 'Content required' }, 400)
  
  // Rate limiting
  const rl = await checkRateLimit(c.env.DB, u.id, 'posts_per_minute', 'posts', 'user_id')
  if (!rl.allowed) return c.json({ error: `Rate limited. Max ${rl.limit} posts/min`, rate_limited: true }, 429)
  
  // Anti-spam: collapse excessive line breaks (>3 consecutive) and disallow empty-only content
  let sanitized = content.trim().replace(/\n{4,}/g, '\n\n\n')
  // Disallow content that is only whitespace/newlines
  if (!sanitized.replace(/\s/g, '')) return c.json({ error: 'Content required' }, 400)
  
  // Spam word detection
  if (await containsSpamWords(c.env.DB, sanitized)) return c.json({ error: 'Content contains blocked words', spam_detected: true }, 400)
  
  // Duplicate post detection (same content within 5 minutes)
  if (await isDuplicatePost(c.env.DB, u.id, sanitized)) return c.json({ error: 'Duplicate post detected. Please wait before posting the same content.', duplicate: true }, 429)
  
  const id = generateId()
  const safeHours = expires_in_hours ? Math.min(Math.max(Math.floor(Number(expires_in_hours)), 1), 168) : 0
  const expiresAtVal = safeHours ? new Date(Date.now() + safeHours * 3600 * 1000).toISOString() : null
  
  if (expiresAtVal) {
    await c.env.DB.prepare(
      'INSERT INTO posts (id, user_id, content, image_url, reply_to_id, text_style, quote_of_id, expires_at, is_r18, is_ai_generated, video_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(id, u.id, sanitized, image_url || '', reply_to_id || '', text_style || '', quote_of_id || '', expiresAtVal, is_r18 ? 1 : 0, is_ai_generated ? 1 : 0, video_url || '').run()
  } else {
    await c.env.DB.prepare(
      'INSERT INTO posts (id, user_id, content, image_url, reply_to_id, text_style, quote_of_id, is_r18, is_ai_generated, video_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(id, u.id, sanitized, image_url || '', reply_to_id || '', text_style || '', quote_of_id || '', is_r18 ? 1 : 0, is_ai_generated ? 1 : 0, video_url || '').run()
  }
  
  if (poll_options && Array.isArray(poll_options) && poll_options.length >= 2) {
    const pollId = generateId()
    await c.env.DB.prepare("INSERT INTO polls (id, post_id, expires_at) VALUES (?, ?, datetime('now', '+24 hours'))").bind(pollId, id).run()
    for (let i = 0; i < Math.min(poll_options.length, 4); i++) {
      const optId = generateId()
      await c.env.DB.prepare('INSERT INTO poll_options (id, poll_id, text, position) VALUES (?, ?, ?, ?)').bind(optId, pollId, poll_options[i].trim(), i).run()
    }
  }
  
  // Coins
  try {
    const today = await c.env.DB.prepare("SELECT COUNT(*) as c FROM coin_transactions WHERE user_id = ? AND type = 'post_reward' AND created_at > datetime('now', '-1 day')").bind(u.id).first() as any
    if (!today || today.c < 10) {
      await c.env.DB.prepare('UPDATE users SET coins = coins + 1 WHERE id = ?').bind(u.id).run()
      const ctid = generateId()
      await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, 1, 'post_reward', ?)").bind(ctid, u.id, id).run()
    }
  } catch(e) {}
  
  // Extract and store hashtags
  try {
    const hashtagMatches = sanitized.match(/#([a-zA-Z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF_]+)/g)
    if (hashtagMatches) {
      const uniqueTags = [...new Set(hashtagMatches.map((t: string) => t.substring(1).toLowerCase()))]
      for (const tagName of uniqueTags.slice(0, 5)) {
        const htId = generateId()
        await c.env.DB.prepare("INSERT OR IGNORE INTO hashtags (id, name) VALUES (?, ?)").bind(htId, tagName).run()
        const ht = await c.env.DB.prepare("SELECT id FROM hashtags WHERE name = ?").bind(tagName).first() as any
        if (ht) {
          await c.env.DB.prepare("INSERT OR IGNORE INTO post_hashtags (post_id, hashtag_id) VALUES (?, ?)").bind(id, ht.id).run()
          c.env.DB.prepare("UPDATE hashtags SET post_count = post_count + 1 WHERE id = ?").bind(ht.id).run()
        }
      }
    }
  } catch {}
  
  // Extract and store mentions
  try {
    const mentionMatches = sanitized.match(/@([a-zA-Z0-9_]+)/g)
    if (mentionMatches) {
      const uniqueMentions = [...new Set(mentionMatches.map((m: string) => m.substring(1).toLowerCase()))]
      for (const mentionedUsername of uniqueMentions.slice(0, 10)) {
        // Try to find by username first, then by sid
        let mentioned = await c.env.DB.prepare("SELECT id FROM users WHERE username = ?").bind(mentionedUsername).first() as any
        if (!mentioned) {
          mentioned = await c.env.DB.prepare("SELECT id FROM users WHERE sid = ?").bind(mentionedUsername).first() as any
        }
        if (mentioned && mentioned.id !== u.id) {
          const mId = generateId()
          await c.env.DB.prepare("INSERT INTO mentions (id, post_id, mentioned_user_id) VALUES (?, ?, ?)").bind(mId, id, mentioned.id).run()
          // Notification for mention
          const nid = generateId()
          await c.env.DB.prepare("INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, 'mention', ?, ?, 'post')").bind(nid, mentioned.id, u.id, id).run()
        }
      }
    }
  } catch {}
  
  // Notifications
  if (reply_to_id) {
    try {
      const parent = await c.env.DB.prepare('SELECT user_id FROM posts WHERE id = ?').bind(reply_to_id).first() as any
      if (parent && parent.user_id !== u.id) {
        const nid = generateId()
        await c.env.DB.prepare('INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, ?, ?, ?, ?)').bind(nid, parent.user_id, 'reply', u.id, reply_to_id, 'post').run()
      }
    } catch(e) {}
  }
  if (quote_of_id) {
    try {
      const quoted = await c.env.DB.prepare('SELECT user_id FROM posts WHERE id = ?').bind(quote_of_id).first() as any
      if (quoted && quoted.user_id !== u.id) {
        const nid = generateId()
        await c.env.DB.prepare('INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, ?, ?, ?, ?)').bind(nid, quoted.user_id, 'koremite', u.id, id, 'post').run()
      }
    } catch(e) {}
  }
  
  return c.json({ success: true, post: {
    id, user_id: u.id, content: sanitized, image_url: image_url || '',
    reply_to_id: reply_to_id || '', text_style: text_style || '', quote_of_id: quote_of_id || '',
    created_at: new Date().toISOString(), username: u.username,
    display_name: u.display_name, avatar_url: u.avatar_url,
    is_official: u.is_official || 0, name_color: u.name_color || '', badge: u.badge || '',
    like_count: 0, liked: 0, reply_count: 0,
    is_r18: is_r18 ? 1 : 0, is_ai_generated: is_ai_generated ? 1 : 0, video_url: video_url || ''
  }})
})

app.put('/api/posts/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const postId = c.req.param('id')
  const { content } = await c.req.json()
  if (!content?.trim()) return c.json({ error: 'Content required' }, 400)
  const post = await c.env.DB.prepare('SELECT * FROM posts WHERE id = ? AND user_id = ?').bind(postId, u.id).first() as any
  if (!post) return c.json({ error: 'Not found' }, 404)
  const editId = generateId()
  await c.env.DB.prepare('INSERT INTO post_edits (id, post_id, old_content, new_content) VALUES (?, ?, ?, ?)').bind(editId, postId, post.content, content.trim()).run()
  await c.env.DB.prepare('UPDATE posts SET content = ? WHERE id = ?').bind(content.trim(), postId).run()
  return c.json({ success: true })
})

app.delete('/api/posts/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  // Admin can delete any post
  if (isAdmin(u)) {
    await c.env.DB.prepare('DELETE FROM posts WHERE id = ?').bind(c.req.param('id')).run()
  } else {
    await c.env.DB.prepare('DELETE FROM posts WHERE id = ? AND user_id = ?').bind(c.req.param('id'), u.id).run()
  }
  return c.json({ success: true })
})

app.post('/api/posts/:id/like', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const postId = c.req.param('id')
  await c.env.DB.prepare('INSERT OR IGNORE INTO likes (user_id, post_id) VALUES (?, ?)').bind(u.id, postId).run()
  try {
    const post = await c.env.DB.prepare('SELECT user_id FROM posts WHERE id = ?').bind(postId).first() as any
    if (post && post.user_id !== u.id) {
      const nid = generateId()
      await c.env.DB.prepare('INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, ?, ?, ?, ?)').bind(nid, post.user_id, 'like', u.id, postId, 'post').run()
    }
  } catch(e) {}
  return c.json({ success: true })
})

app.delete('/api/posts/:id/like', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?').bind(u.id, c.req.param('id')).run()
  return c.json({ success: true })
})

// Post rating (downvote for hide algorithm)
app.post('/api/posts/:id/rate', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { rating } = await c.req.json() // -1 or 1
  if (rating !== -1 && rating !== 1) return c.json({ error: 'Invalid rating' }, 400)
  await c.env.DB.prepare('INSERT OR REPLACE INTO post_ratings (user_id, post_id, rating) VALUES (?, ?, ?)').bind(u.id, c.req.param('id'), rating).run()
  return c.json({ success: true })
})

// Poll voting
app.post('/api/polls/:pollId/vote', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { option_id } = await c.req.json()
  const pollId = c.req.param('pollId')
  const existing = await c.env.DB.prepare('SELECT 1 FROM poll_votes WHERE poll_id = ? AND user_id = ?').bind(pollId, u.id).first()
  if (existing) return c.json({ error: 'Already voted' }, 409)
  await c.env.DB.prepare('INSERT INTO poll_votes (poll_id, option_id, user_id) VALUES (?, ?, ?)').bind(pollId, option_id, u.id).run()
  return c.json({ success: true })
})

// Pinned posts
app.get('/api/users/:username/pinned', async (c) => {
  const uid = c.get('user')?.id || '__none__'
  const user = await c.env.DB.prepare('SELECT id FROM users WHERE username = ?').bind(c.req.param('username')).first() as any
  if (!user) return c.json({ pins: [] })
  const pins = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM pinned_posts pp JOIN posts p ON pp.post_id = p.id JOIN users u ON p.user_id = u.id
    WHERE pp.user_id = ? ORDER BY pp.position ASC LIMIT 3
  `).bind(uid, user.id).all()
  return c.json({ pins: pins.results })
})

app.post('/api/posts/:id/pin', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const postId = c.req.param('id')
  const count = await c.env.DB.prepare('SELECT COUNT(*) as c FROM pinned_posts WHERE user_id = ?').bind(u.id).first() as any
  if (count && count.c >= 3) return c.json({ error: 'Max 3 pinned posts' }, 400)
  const id = generateId()
  await c.env.DB.prepare('INSERT OR IGNORE INTO pinned_posts (id, user_id, post_id, position) VALUES (?, ?, ?, ?)').bind(id, u.id, postId, (count?.c || 0)).run()
  return c.json({ success: true })
})

app.delete('/api/posts/:id/pin', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare('DELETE FROM pinned_posts WHERE user_id = ? AND post_id = ?').bind(u.id, c.req.param('id')).run()
  return c.json({ success: true })
})

// ===== BLOCKS =====
app.post('/api/block/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { is_ghost } = await c.req.json().catch(() => ({ is_ghost: false }))
  await c.env.DB.prepare('INSERT OR REPLACE INTO blocks (blocker_id, blocked_id, is_ghost) VALUES (?, ?, ?)').bind(u.id, c.req.param('id'), is_ghost ? 1 : 0).run()
  await c.env.DB.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').bind(u.id, c.req.param('id')).run()
  if (!is_ghost) {
    await c.env.DB.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').bind(c.req.param('id'), u.id).run()
  }
  return c.json({ success: true })
})

app.delete('/api/block/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?').bind(u.id, c.req.param('id')).run()
  return c.json({ success: true })
})

app.get('/api/blocks', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const blocks = await c.env.DB.prepare(`
    SELECT b.*, u.username, u.display_name, u.avatar_url FROM blocks b JOIN users u ON b.blocked_id = u.id WHERE b.blocker_id = ?
  `).bind(u.id).all()
  return c.json({ blocks: blocks.results })
})

// ===== FOLLOWS =====
app.post('/api/follow/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const tid = c.req.param('id')
  if (tid === u.id) return c.json({ error: 'Cannot follow self' }, 400)
  if (await isBlocked(c.env.DB, u.id, tid)) return c.json({ error: 'Blocked' }, 403)
  await c.env.DB.prepare('INSERT OR IGNORE INTO follows (follower_id, following_id) VALUES (?, ?)').bind(u.id, tid).run()
  try {
    await c.env.DB.prepare("DELETE FROM notifications WHERE user_id = ? AND type = 'follow' AND actor_id = ?").bind(tid, u.id).run()
    const nid = generateId()
    await c.env.DB.prepare('INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, ?, ?, ?, ?)').bind(nid, tid, 'follow', u.id, u.id, 'user').run()
  } catch(e) {}
  return c.json({ success: true })
})

app.delete('/api/follow/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const tid = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').bind(u.id, tid).run()
  try { await c.env.DB.prepare("DELETE FROM notifications WHERE user_id = ? AND type = 'follow' AND actor_id = ?").bind(tid, u.id).run() } catch(e) {}
  return c.json({ success: true })
})

// ===== USERS =====
app.get('/api/users/:username', async (c) => {
  const uid = c.get('user')?.id || '__none__'
  const user = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.bio, u.avatar_url, u.banner_url, u.created_at, u.profile_url, u.coins, u.role, u.is_official, u.name_color, u.bg_color, u.badge, u.sid, u.is_private,
      (SELECT COUNT(*) FROM posts WHERE user_id = u.id AND (reply_to_id = '' OR reply_to_id IS NULL)) as post_count,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) as follower_count,
      (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) as following_count,
      (SELECT COUNT(*) FROM follows WHERE follower_id = ? AND following_id = u.id) as is_following,
      (SELECT COUNT(*) FROM blocks WHERE blocker_id = ? AND blocked_id = u.id) as is_blocked
    FROM users u WHERE u.username = ?
  `).bind(uid, uid, c.req.param('username')).first()
  if (!user) return c.json({ error: 'Not found' }, 404)
  const vr = await c.env.DB.prepare(`
    SELECT vr.*, (SELECT COUNT(*) FROM voice_room_members WHERE room_id = vr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name, ou.avatar_url as owner_avatar_url
    FROM voice_room_members vrm JOIN voice_rooms vr ON vrm.room_id = vr.id
    JOIN users ou ON vr.owner_id = ou.id WHERE vrm.user_id = ? AND vr.is_active = 1
  `).bind((user as any).id).first()
  const media = await c.env.DB.prepare("SELECT id, image_url, created_at FROM posts WHERE user_id = ? AND image_url != '' ORDER BY created_at DESC LIMIT 9").bind((user as any).id).all()
  return c.json({ user, voice_room: vr || null, media: media.results })
})

app.get('/api/users/:username/posts', async (c) => {
  const uid = c.get('user')?.id || '__none__'
  const limit = Math.min(parseInt(c.req.query('limit') || '20'), 50)
  const cursor = c.req.query('cursor') || ''
  let extra = ''
  const params: any[] = [uid, c.req.param('username')]
  if (cursor) { extra = 'AND p.created_at < ?'; params.push(cursor) }
  params.push(limit)
  const posts = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM posts p JOIN users u ON p.user_id = u.id
    WHERE u.username = ? AND (p.reply_to_id = '' OR p.reply_to_id IS NULL) ${extra}
    ORDER BY p.created_at DESC LIMIT ?
  `).bind(...params).all()
  const next_cursor = posts.results.length === limit ? (posts.results[posts.results.length - 1] as any).created_at : null
  const enriched = await enrichPostsWithQuotes(c.env.DB, posts.results as any[])
  return c.json({ posts: enriched, next_cursor })
})

app.get('/api/users/:username/followers', async (c) => {
  const r = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, u.bio
    FROM follows f JOIN users u ON f.follower_id = u.id JOIN users t ON f.following_id = t.id
    WHERE t.username = ? ORDER BY f.created_at DESC LIMIT 100
  `).bind(c.req.param('username')).all()
  return c.json({ users: r.results })
})

app.get('/api/users/:username/following', async (c) => {
  const r = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, u.bio
    FROM follows f JOIN users u ON f.following_id = u.id JOIN users s ON f.follower_id = s.id
    WHERE s.username = ? ORDER BY f.created_at DESC LIMIT 100
  `).bind(c.req.param('username')).all()
  return c.json({ users: r.results })
})

// ===== VOICE ROOMS =====
app.get('/api/voice-rooms', async (c) => {
  const tag = c.req.query('tag') || ''
  const u = c.get('user')
  let where = 'WHERE vr.is_active = 1'
  const params: any[] = []
  if (tag) { where += ' AND vr.tag = ?'; params.push(tag) }
  let orderBy = 'ORDER BY member_count DESC, vr.created_at DESC'
  if (u) {
    orderBy = `ORDER BY
      (SELECT COUNT(*) FROM voice_room_members vrm2
       JOIN follows f ON f.following_id = vrm2.user_id
       WHERE vrm2.room_id = vr.id AND f.follower_id = '${u.id}') DESC,
      member_count DESC, vr.created_at DESC`
  }
  const rooms = await c.env.DB.prepare(`
    SELECT vr.*, u.username as owner_username, u.display_name as owner_display_name, u.avatar_url as owner_avatar_url,
      (SELECT COUNT(*) FROM voice_room_members WHERE room_id = vr.id) as member_count
    FROM voice_rooms vr JOIN users u ON vr.owner_id = u.id
    ${where} ${orderBy} LIMIT 50
  `).bind(...params).all()
  return c.json({ rooms: rooms.results })
})

app.get('/api/voice-rooms/:id', async (c) => {
  const room = await c.env.DB.prepare(`
    SELECT vr.*, u.username as owner_username, u.display_name as owner_display_name, u.avatar_url as owner_avatar_url,
      (SELECT COUNT(*) FROM voice_room_members WHERE room_id = vr.id) as member_count
    FROM voice_rooms vr JOIN users u ON vr.owner_id = u.id WHERE vr.id = ?
  `).bind(c.req.param('id')).first()
  if (!room) return c.json({ error: 'Not found' }, 404)
  const members = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, vrm.is_muted, vrm.joined_at, vrm.peer_id, vrm.role
    FROM voice_room_members vrm JOIN users u ON vrm.user_id = u.id WHERE vrm.room_id = ?
  `).bind(c.req.param('id')).all()
  return c.json({ room, members: members.results })
})

app.post('/api/voice-rooms', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const ex = await c.env.DB.prepare('SELECT room_id FROM voice_room_members WHERE user_id = ?').bind(u.id).first() as any
  if (ex) {
    await c.env.DB.prepare('DELETE FROM voice_room_members WHERE user_id = ?').bind(u.id).run()
    const rem = await c.env.DB.prepare('SELECT COUNT(*) as c FROM voice_room_members WHERE room_id = ?').bind(ex.room_id).first() as any
    if (rem?.c === 0) {
      await c.env.DB.prepare('UPDATE voice_rooms SET is_active = 0 WHERE id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM voice_room_messages WHERE room_id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM whiteboard_strokes WHERE room_id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM unmute_requests WHERE room_id = ?').bind(ex.room_id).run()
    }
  }
  const { name, tag } = await c.req.json()
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO voice_rooms (id, owner_id, name, tag, max_members) VALUES (?, ?, ?, ?, 20)').bind(id, u.id, name || '', tag || '').run()
  await c.env.DB.prepare("INSERT INTO voice_room_members (room_id, user_id, role) VALUES (?, ?, 'owner')").bind(id, u.id).run()
  return c.json({ success: true, room_id: id })
})

app.post('/api/voice-rooms/:id/join', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const ex = await c.env.DB.prepare('SELECT room_id FROM voice_room_members WHERE user_id = ?').bind(u.id).first() as any
  if (ex && ex.room_id !== rid) {
    await c.env.DB.prepare('DELETE FROM voice_room_members WHERE user_id = ?').bind(u.id).run()
    const rem = await c.env.DB.prepare('SELECT COUNT(*) as c FROM voice_room_members WHERE room_id = ?').bind(ex.room_id).first() as any
    if (rem?.c === 0) {
      await c.env.DB.prepare('UPDATE voice_rooms SET is_active = 0 WHERE id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM voice_room_messages WHERE room_id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM whiteboard_strokes WHERE room_id = ?').bind(ex.room_id).run()
      await c.env.DB.prepare('DELETE FROM unmute_requests WHERE room_id = ?').bind(ex.room_id).run()
    }
  }
  const room = await c.env.DB.prepare('SELECT * FROM voice_rooms WHERE id = ? AND is_active = 1').bind(rid).first() as any
  if (!room) return c.json({ error: 'Not found' }, 404)
  const currentCount = await c.env.DB.prepare('SELECT COUNT(*) as c FROM voice_room_members WHERE room_id = ?').bind(rid).first() as any
  const maxMembers = room.max_members || 20
  if (currentCount?.c >= maxMembers) return c.json({ error: 'Room is full', max: maxMembers }, 403)
  await c.env.DB.prepare("INSERT OR REPLACE INTO voice_room_members (room_id, user_id, joined_at, role) VALUES (?, ?, datetime('now'), 'member')").bind(rid, u.id).run()
  const members = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, vrm.is_muted, vrm.joined_at, vrm.peer_id, vrm.role
    FROM voice_room_members vrm JOIN users u ON vrm.user_id = u.id WHERE vrm.room_id = ?
  `).bind(rid).all()
  return c.json({ success: true, members: members.results })
})

app.post('/api/voice-rooms/:id/leave', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM voice_room_members WHERE room_id = ? AND user_id = ?').bind(rid, u.id).run()
  const rem = await c.env.DB.prepare('SELECT COUNT(*) as c FROM voice_room_members WHERE room_id = ?').bind(rid).first() as any
  if (rem?.c === 0) {
    await c.env.DB.prepare('UPDATE voice_rooms SET is_active = 0 WHERE id = ?').bind(rid).run()
    await c.env.DB.prepare('DELETE FROM voice_room_messages WHERE room_id = ?').bind(rid).run()
    await c.env.DB.prepare('DELETE FROM whiteboard_strokes WHERE room_id = ?').bind(rid).run()
    await c.env.DB.prepare('DELETE FROM unmute_requests WHERE room_id = ?').bind(rid).run()
  }
  return c.json({ success: true })
})

app.post('/api/voice-rooms/:id/mute', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { muted } = await c.req.json()
  await c.env.DB.prepare('UPDATE voice_room_members SET is_muted = ? WHERE room_id = ? AND user_id = ?').bind(muted ? 1 : 0, c.req.param('id'), u.id).run()
  return c.json({ success: true })
})

app.post('/api/voice-rooms/:id/peer', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { peer_id } = await c.req.json()
  await c.env.DB.prepare('UPDATE voice_room_members SET peer_id = ? WHERE room_id = ? AND user_id = ?').bind(peer_id || '', c.req.param('id'), u.id).run()
  return c.json({ success: true })
})

app.get('/api/my-voice-room', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ room: null })
  const r = await c.env.DB.prepare(`
    SELECT vr.*, vrm.is_muted, vrm.role as my_role, (SELECT COUNT(*) FROM voice_room_members WHERE room_id = vr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name
    FROM voice_room_members vrm JOIN voice_rooms vr ON vrm.room_id = vr.id
    JOIN users ou ON vr.owner_id = ou.id WHERE vrm.user_id = ? AND vr.is_active = 1
  `).bind(u.id).first()
  return c.json({ room: r || null })
})

// Voice room roles
app.post('/api/voice-rooms/:id/set-role', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { target_user_id, role } = await c.req.json()
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || myMember.role !== 'owner') return c.json({ error: 'Only owner can set roles' }, 403)
  if (!['member', 'sub_owner'].includes(role)) return c.json({ error: 'Invalid role' }, 400)
  await c.env.DB.prepare('UPDATE voice_room_members SET role = ? WHERE room_id = ? AND user_id = ?').bind(role, rid, target_user_id).run()
  return c.json({ success: true })
})

app.post('/api/voice-rooms/:id/force-mute', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { target_user_id } = await c.req.json()
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || !['owner', 'sub_owner'].includes(myMember.role)) return c.json({ error: 'No permission' }, 403)
  await c.env.DB.prepare('UPDATE voice_room_members SET is_muted = 1 WHERE room_id = ? AND user_id = ?').bind(rid, target_user_id).run()
  return c.json({ success: true })
})

app.post('/api/voice-rooms/:id/force-kick', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { target_user_id } = await c.req.json()
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || !['owner', 'sub_owner'].includes(myMember.role)) return c.json({ error: 'No permission' }, 403)
  const target = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, target_user_id).first() as any
  if (target?.role === 'owner') return c.json({ error: 'Cannot kick owner' }, 403)
  if (myMember.role === 'sub_owner' && target?.role === 'sub_owner') return c.json({ error: 'Cannot kick sub-owner' }, 403)
  await c.env.DB.prepare('DELETE FROM voice_room_members WHERE room_id = ? AND user_id = ?').bind(rid, target_user_id).run()
  return c.json({ success: true })
})

app.post('/api/voice-rooms/:id/unmute-request', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const existing = await c.env.DB.prepare("SELECT id FROM unmute_requests WHERE room_id = ? AND user_id = ? AND status = 'pending'").bind(rid, u.id).first()
  if (existing) return c.json({ error: 'Already requested' }, 409)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO unmute_requests (id, room_id, user_id) VALUES (?, ?, ?)').bind(id, rid, u.id).run()
  return c.json({ success: true })
})

app.get('/api/voice-rooms/:id/unmute-requests', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const reqs = await c.env.DB.prepare(`
    SELECT ur.*, u.username, u.display_name, u.avatar_url
    FROM unmute_requests ur JOIN users u ON ur.user_id = u.id
    WHERE ur.room_id = ? AND ur.status = 'pending' ORDER BY ur.created_at ASC
  `).bind(rid).all()
  return c.json({ requests: reqs.results })
})

app.post('/api/voice-rooms/:id/approve-unmute', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { request_id, target_user_id } = await c.req.json()
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || !['owner', 'sub_owner'].includes(myMember.role)) return c.json({ error: 'No permission' }, 403)
  await c.env.DB.prepare("UPDATE unmute_requests SET status = 'approved' WHERE id = ?").bind(request_id).run()
  await c.env.DB.prepare('UPDATE voice_room_members SET is_muted = 0 WHERE room_id = ? AND user_id = ?').bind(rid, target_user_id).run()
  return c.json({ success: true })
})

// Voice room chat
app.get('/api/voice-rooms/:id/messages', async (c) => {
  const rid = c.req.param('id')
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [rid]
  if (after) { extra = 'AND m.created_at > ?'; params.push(after) }
  params.push(50)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url, u.is_official as sender_is_official
    FROM voice_room_messages m JOIN users u ON m.sender_id = u.id
    WHERE m.room_id = ? ${extra} ORDER BY m.created_at DESC LIMIT ?
  `).bind(...params).all()
  return c.json({ messages: msgs.results.reverse() })
})

app.post('/api/voice-rooms/:id/messages', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { content } = await c.req.json()
  if (!content?.trim()) return c.json({ error: 'Empty' }, 400)
  const inRoom = await c.env.DB.prepare('SELECT 1 FROM voice_room_members WHERE room_id = ? AND user_id = ?').bind(rid, u.id).first()
  if (!inRoom) return c.json({ error: 'Not in room' }, 403)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO voice_room_messages (id, room_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(id, rid, u.id, content.trim()).run()
  return c.json({ success: true, message: { id, room_id: rid, sender_id: u.id, content: content.trim(), created_at: new Date().toISOString(), sender_username: u.username, sender_display_name: u.display_name, sender_avatar_url: u.avatar_url } })
})

// Whiteboard
app.get('/api/voice-rooms/:id/whiteboard', async (c) => {
  const rid = c.req.param('id')
  const strokes = await c.env.DB.prepare('SELECT * FROM whiteboard_strokes WHERE room_id = ? ORDER BY created_at ASC LIMIT 500').bind(rid).all()
  return c.json({ strokes: strokes.results })
})

app.post('/api/voice-rooms/:id/whiteboard', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const { stroke_data, color, width, tool } = await c.req.json()
  if (!stroke_data) return c.json({ error: 'No data' }, 400)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO whiteboard_strokes (id, room_id, user_id, stroke_data, color, width, tool) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(id, rid, u.id, stroke_data, color || '#ffffff', width || 3, tool || 'pen').run()
  return c.json({ success: true, stroke_id: id })
})

app.delete('/api/voice-rooms/:id/whiteboard', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || !['owner', 'sub_owner'].includes(myMember.role)) return c.json({ error: 'No permission' }, 403)
  await c.env.DB.prepare('DELETE FROM whiteboard_strokes WHERE room_id = ?').bind(rid).run()
  return c.json({ success: true })
})

// SSE-style polling
app.get('/api/sse/dm/:convId', async (c) => {
  const u = c.get('user'); if (!u) return c.text('Unauthorized', 401)
  const convId = c.req.param('convId')
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [convId]
  if (after) { extra = 'AND m.created_at > ?'; params.push(after) }
  params.push(20)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url
    FROM messages m JOIN users u ON m.sender_id = u.id
    WHERE m.conversation_id = ? AND m.deleted_at IS NULL ${extra} ORDER BY m.created_at ASC LIMIT ?
  `).bind(...params).all()
  await c.env.DB.prepare("UPDATE messages SET read_at = datetime('now') WHERE conversation_id = ? AND sender_id != ? AND read_at IS NULL").bind(convId, u.id).run()
  return c.json({ messages: msgs.results })
})

app.get('/api/sse/channel/:channelId', async (c) => {
  const u = c.get('user'); if (!u) return c.text('Unauthorized', 401)
  const chId = c.req.param('channelId')
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [chId]
  if (after) { extra = 'AND m.created_at > ?'; params.push(after) }
  params.push(20)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url, u.is_official as sender_is_official
    FROM crew_messages m JOIN users u ON m.sender_id = u.id
    WHERE m.channel_id = ? ${extra} ORDER BY m.created_at ASC LIMIT ?
  `).bind(...params).all()
  return c.json({ messages: msgs.results })
})

app.get('/api/sse/vr/:roomId', async (c) => {
  const rid = c.req.param('roomId')
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [rid]
  if (after) { extra = 'AND m.created_at > ?'; params.push(after) }
  params.push(20)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url, u.is_official as sender_is_official
    FROM voice_room_messages m JOIN users u ON m.sender_id = u.id
    WHERE m.room_id = ? ${extra} ORDER BY m.created_at ASC LIMIT ?
  `).bind(...params).all()
  return c.json({ messages: msgs.results })
})

// ===== DM =====
app.get('/api/conversations', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const convs = await c.env.DB.prepare(`
    SELECT c.*,
      CASE WHEN c.user1_id = ? THEN u2.id ELSE u1.id END as other_id,
      CASE WHEN c.user1_id = ? THEN u2.username ELSE u1.username END as other_username,
      CASE WHEN c.user1_id = ? THEN u2.display_name ELSE u1.display_name END as other_display_name,
      CASE WHEN c.user1_id = ? THEN u2.avatar_url ELSE u1.avatar_url END as other_avatar_url,
      (SELECT content FROM messages WHERE conversation_id = c.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1) as last_message,
      (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND sender_id != ? AND read_at IS NULL AND deleted_at IS NULL) as unread_count
    FROM conversations c
    JOIN users u1 ON c.user1_id = u1.id JOIN users u2 ON c.user2_id = u2.id
    WHERE c.user1_id = ? OR c.user2_id = ?
    ORDER BY c.last_message_at DESC LIMIT 50
  `).bind(u.id, u.id, u.id, u.id, u.id, u.id, u.id).all()
  return c.json({ conversations: convs.results })
})

app.get('/api/conversations/:id/messages', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const limit = Math.min(parseInt(c.req.query('limit') || '50'), 100)
  const cursor = c.req.query('cursor') || ''
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [cid]
  if (cursor) { extra = 'AND m.created_at < ?'; params.push(cursor) }
  if (after) { extra += ' AND m.created_at > ?'; params.push(after) }
  params.push(limit)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url
    FROM messages m JOIN users u ON m.sender_id = u.id
    WHERE m.conversation_id = ? AND m.deleted_at IS NULL ${extra} ORDER BY m.created_at DESC LIMIT ?
  `).bind(...params).all()
  await c.env.DB.prepare("UPDATE messages SET read_at = datetime('now') WHERE conversation_id = ? AND sender_id != ? AND read_at IS NULL").bind(cid, u.id).run()
  return c.json({ messages: msgs.results.reverse() })
})

app.post('/api/conversations', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { user_id } = await c.req.json()
  if (!user_id || user_id === u.id) return c.json({ error: 'Invalid' }, 400)
  if (await isBlocked(c.env.DB, u.id, user_id)) return c.json({ error: 'Blocked' }, 403)
  const existing = await c.env.DB.prepare(
    'SELECT * FROM conversations WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)'
  ).bind(u.id, user_id, user_id, u.id).first()
  if (existing) return c.json({ conversation: existing })
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO conversations (id, user1_id, user2_id) VALUES (?, ?, ?)').bind(id, u.id, user_id).run()
  const conv = await c.env.DB.prepare('SELECT * FROM conversations WHERE id = ?').bind(id).first()
  return c.json({ conversation: conv })
})

app.post('/api/conversations/:id/messages', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { content } = await c.req.json()
  if (!content?.trim()) return c.json({ error: 'Empty' }, 400)
  // Rate limit DM
  const rl = await checkRateLimit(c.env.DB, u.id, 'dm_per_minute', 'messages', 'sender_id')
  if (!rl.allowed) return c.json({ error: 'Rate limited', rate_limited: true }, 429)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO messages (id, conversation_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(id, cid, u.id, content.trim()).run()
  await c.env.DB.prepare("UPDATE conversations SET last_message_at = datetime('now') WHERE id = ?").bind(cid).run()
  return c.json({ success: true, message: { id, conversation_id: cid, sender_id: u.id, content: content.trim(), created_at: new Date().toISOString(), sender_username: u.username, sender_display_name: u.display_name, sender_avatar_url: u.avatar_url } })
})

app.delete('/api/messages/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const msgId = c.req.param('id')
  const msg = await c.env.DB.prepare('SELECT * FROM messages WHERE id = ? AND sender_id = ?').bind(msgId, u.id).first() as any
  if (!msg) return c.json({ error: 'Not found' }, 404)
  await c.env.DB.prepare("UPDATE messages SET deleted_at = datetime('now'), content = '[メッセージが削除されました]' WHERE id = ?").bind(msgId).run()
  return c.json({ success: true })
})

app.get('/api/dm/unread', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ count: 0 })
  const r = await c.env.DB.prepare(`
    SELECT COUNT(*) as c FROM messages m JOIN conversations cv ON m.conversation_id = cv.id
    WHERE m.sender_id != ? AND m.read_at IS NULL AND m.deleted_at IS NULL AND (cv.user1_id = ? OR cv.user2_id = ?)
  `).bind(u.id, u.id, u.id).first() as any
  return c.json({ count: r?.c || 0 })
})

// ===== CREWS =====
app.get('/api/crews', async (c) => {
  const u = c.get('user')
  if (!u) return c.json({ crews: [] })
  const crews = await c.env.DB.prepare(`
    SELECT cr.*, cm.role,
      (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name
    FROM crew_members cm
    JOIN crews cr ON cm.crew_id = cr.id
    JOIN users ou ON cr.owner_id = ou.id
    WHERE cm.user_id = ?
    ORDER BY cr.created_at DESC
  `).bind(u.id).all()
  return c.json({ crews: crews.results })
})

app.get('/api/crews/discover', async (c) => {
  const u = c.get('user')
  const uid = u?.id || '__none__'
  const crews = await c.env.DB.prepare(`
    SELECT cr.*,
      (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name,
      (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id AND user_id = ?) as is_member
    FROM crews cr
    JOIN users ou ON cr.owner_id = ou.id
    WHERE cr.is_public = 1
    ORDER BY member_count DESC, cr.created_at DESC LIMIT 50
  `).bind(uid).all()
  return c.json({ crews: crews.results })
})

app.post('/api/crews', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { name, description, icon_url } = await c.req.json()
  if (!name?.trim()) return c.json({ error: 'Name required' }, 400)
  const ownedCount = await c.env.DB.prepare('SELECT COUNT(*) as c FROM crews WHERE owner_id = ?').bind(u.id).first() as any
  if (ownedCount && ownedCount.c >= 10) return c.json({ error: 'Too many crews' }, 429)
  const dup = await c.env.DB.prepare('SELECT id FROM crews WHERE owner_id = ? AND name = ?').bind(u.id, name.trim()).first()
  if (dup) return c.json({ error: 'You already have a crew with this name' }, 409)
  const lastCrew = await c.env.DB.prepare("SELECT created_at FROM crews WHERE owner_id = ? ORDER BY created_at DESC LIMIT 1").bind(u.id).first() as any
  if (lastCrew) {
    const diff = Date.now() - new Date(lastCrew.created_at + 'Z').getTime()
    if (diff < 10000) return c.json({ error: 'Please wait before creating another crew' }, 429)
  }
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO crews (id, name, description, icon_url, owner_id) VALUES (?, ?, ?, ?, ?)').bind(id, name.trim(), description || '', icon_url || '', u.id).run()
  await c.env.DB.prepare("INSERT INTO crew_members (crew_id, user_id, role) VALUES (?, ?, 'owner')").bind(id, u.id).run()
  const genId = generateId(), voiceId = generateId(), welcomeId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_channels (id, crew_id, name, type, position) VALUES (?, ?, 'general', 'text', 0)").bind(genId, id).run()
  await c.env.DB.prepare("INSERT INTO crew_channels (id, crew_id, name, type, position) VALUES (?, ?, 'welcome', 'text', 1)").bind(welcomeId, id).run()
  await c.env.DB.prepare("INSERT INTO crew_channels (id, crew_id, name, type, position) VALUES (?, ?, 'voice', 'voice', 2)").bind(voiceId, id).run()
  return c.json({ success: true, crew_id: id })
})

app.get('/api/crews/:id', async (c) => {
  const u = c.get('user')
  const uid = u?.id || '__none__'
  const crew = await c.env.DB.prepare(`
    SELECT cr.*,
      (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name, ou.avatar_url as owner_avatar_url,
      (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id AND user_id = ?) as is_member,
      (SELECT role FROM crew_members WHERE crew_id = cr.id AND user_id = ?) as my_role
    FROM crews cr JOIN users ou ON cr.owner_id = ou.id WHERE cr.id = ?
  `).bind(uid, uid, c.req.param('id')).first()
  if (!crew) return c.json({ error: 'Not found' }, 404)
  const channels = await c.env.DB.prepare('SELECT * FROM crew_channels WHERE crew_id = ? ORDER BY position ASC').bind(c.req.param('id')).all()
  const members = await c.env.DB.prepare(`
    SELECT cm.*, u.username, u.display_name, u.avatar_url, u.is_official
    FROM crew_members cm JOIN users u ON cm.user_id = u.id
    WHERE cm.crew_id = ? ORDER BY
      CASE cm.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'moderator' THEN 2 ELSE 3 END, cm.joined_at ASC
    LIMIT 100
  `).bind(c.req.param('id')).all()
  const roles = await c.env.DB.prepare('SELECT * FROM crew_roles WHERE crew_id = ? ORDER BY position ASC').bind(c.req.param('id')).all()
  return c.json({ crew, channels: channels.results, members: members.results, roles: roles.results })
})

app.post('/api/crews/:id/join', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const crew = await c.env.DB.prepare('SELECT * FROM crews WHERE id = ? AND is_public = 1').bind(cid).first()
  if (!crew) return c.json({ error: 'Not found' }, 404)
  // Check if banned
  const banned = await c.env.DB.prepare('SELECT 1 FROM crew_bans WHERE crew_id = ? AND user_id = ?').bind(cid, u.id).first()
  if (banned) return c.json({ error: 'You are banned from this crew' }, 403)
  await c.env.DB.prepare("INSERT OR IGNORE INTO crew_members (crew_id, user_id, role) VALUES (?, ?, 'member')").bind(cid, u.id).run()
  return c.json({ success: true })
})

app.post('/api/crews/:id/leave', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const crew = await c.env.DB.prepare('SELECT owner_id FROM crews WHERE id = ?').bind(cid).first() as any
  if (crew?.owner_id === u.id) return c.json({ error: 'Owner cannot leave' }, 400)
  await c.env.DB.prepare('DELETE FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(cid, u.id).run()
  return c.json({ success: true })
})

app.post('/api/crews/:id/channels', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const member = await c.env.DB.prepare("SELECT role FROM crew_members WHERE crew_id = ? AND user_id = ? AND role IN ('owner','admin')").bind(cid, u.id).first()
  if (!member) return c.json({ error: 'No permission' }, 403)
  const { name, type } = await c.req.json()
  if (!name?.trim()) return c.json({ error: 'Name required' }, 400)
  const chId = generateId()
  const maxPos = await c.env.DB.prepare('SELECT MAX(position) as mp FROM crew_channels WHERE crew_id = ?').bind(cid).first() as any
  await c.env.DB.prepare('INSERT INTO crew_channels (id, crew_id, name, type, position) VALUES (?, ?, ?, ?, ?)').bind(chId, cid, name.trim(), type || 'text', (maxPos?.mp || 0) + 1).run()
  return c.json({ success: true, channel_id: chId })
})

app.get('/api/channels/:id/messages', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const chId = c.req.param('id')
  const limit = Math.min(parseInt(c.req.query('limit') || '50'), 100)
  const after = c.req.query('after') || ''
  let extra = ''; const params: any[] = [chId]
  if (after) { extra = 'AND m.created_at > ?'; params.push(after) }
  params.push(limit)
  const msgs = await c.env.DB.prepare(`
    SELECT m.*, u.username as sender_username, u.display_name as sender_display_name, u.avatar_url as sender_avatar_url, u.is_official as sender_is_official
    FROM crew_messages m JOIN users u ON m.sender_id = u.id
    WHERE m.channel_id = ? ${extra} ORDER BY m.created_at DESC LIMIT ?
  `).bind(...params).all()
  return c.json({ messages: msgs.results.reverse() })
})

app.post('/api/channels/:id/messages', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const chId = c.req.param('id')
  const { content } = await c.req.json()
  if (!content?.trim()) return c.json({ error: 'Empty' }, 400)
  // Rate limit crew messages
  const rl = await checkRateLimit(c.env.DB, u.id, 'messages_per_minute', 'crew_messages', 'sender_id')
  if (!rl.allowed) return c.json({ error: 'Rate limited', rate_limited: true }, 429)
  const ch = await c.env.DB.prepare('SELECT crew_id FROM crew_channels WHERE id = ?').bind(chId).first() as any
  if (!ch) return c.json({ error: 'Channel not found' }, 404)
  const isMember = await c.env.DB.prepare('SELECT 1 FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(ch.crew_id, u.id).first()
  if (!isMember) return c.json({ error: 'Not a member' }, 403)
  // Check timeout
  const timeout = await c.env.DB.prepare("SELECT 1 FROM crew_timeouts WHERE crew_id = ? AND user_id = ? AND expires_at > datetime('now')").bind(ch.crew_id, u.id).first()
  if (timeout) return c.json({ error: 'You are timed out in this crew', timed_out: true }, 403)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO crew_messages (id, channel_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(id, chId, u.id, content.trim()).run()
  return c.json({ success: true, message: { id, channel_id: chId, sender_id: u.id, content: content.trim(), created_at: new Date().toISOString(), sender_username: u.username, sender_display_name: u.display_name, sender_avatar_url: u.avatar_url } })
})

// Crew voice
app.get('/api/crew-voice/:channelId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const chId = c.req.param('channelId')
  const ch = await c.env.DB.prepare("SELECT crew_id FROM crew_channels WHERE id = ? AND type = 'voice'").bind(chId).first() as any
  if (!ch) return c.json({ error: 'Not found' }, 404)
  const isMember = await c.env.DB.prepare('SELECT 1 FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(ch.crew_id, u.id).first()
  if (!isMember) return c.json({ error: 'Not a member' }, 403)
  const members = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, cvm.is_muted, cvm.peer_id
    FROM crew_voice_members cvm JOIN users u ON cvm.user_id = u.id WHERE cvm.channel_id = ?
  `).bind(chId).all()
  return c.json({ members: members.results })
})

app.post('/api/crew-voice/:channelId/join', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const chId = c.req.param('channelId')
  const ch = await c.env.DB.prepare("SELECT crew_id FROM crew_channels WHERE id = ? AND type = 'voice'").bind(chId).first() as any
  if (!ch) return c.json({ error: 'Not found' }, 404)
  const isMember = await c.env.DB.prepare('SELECT 1 FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(ch.crew_id, u.id).first()
  if (!isMember) return c.json({ error: 'Not a member' }, 403)
  await c.env.DB.prepare('DELETE FROM crew_voice_members WHERE user_id = ?').bind(u.id).run()
  const cnt = await c.env.DB.prepare('SELECT COUNT(*) as c FROM crew_voice_members WHERE channel_id = ?').bind(chId).first() as any
  if (cnt?.c >= 20) return c.json({ error: 'Channel full' }, 403)
  await c.env.DB.prepare('INSERT OR REPLACE INTO crew_voice_members (channel_id, user_id) VALUES (?, ?)').bind(chId, u.id).run()
  return c.json({ success: true })
})

app.post('/api/crew-voice/:channelId/leave', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare('DELETE FROM crew_voice_members WHERE channel_id = ? AND user_id = ?').bind(c.req.param('channelId'), u.id).run()
  return c.json({ success: true })
})

app.post('/api/crew-voice/:channelId/peer', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { peer_id } = await c.req.json()
  await c.env.DB.prepare('UPDATE crew_voice_members SET peer_id = ? WHERE channel_id = ? AND user_id = ?').bind(peer_id || '', c.req.param('channelId'), u.id).run()
  return c.json({ success: true })
})

app.post('/api/crew-voice/:channelId/mute', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { muted } = await c.req.json()
  await c.env.DB.prepare('UPDATE crew_voice_members SET is_muted = ? WHERE channel_id = ? AND user_id = ?').bind(muted ? 1 : 0, c.req.param('channelId'), u.id).run()
  return c.json({ success: true })
})

app.post('/api/crews/:id/roles', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const member = await c.env.DB.prepare("SELECT role FROM crew_members WHERE crew_id = ? AND user_id = ? AND role IN ('owner','admin')").bind(cid, u.id).first()
  if (!member) return c.json({ error: 'No permission' }, 403)
  const { name, color } = await c.req.json()
  if (!name?.trim()) return c.json({ error: 'Name required' }, 400)
  const roleId = generateId()
  await c.env.DB.prepare('INSERT INTO crew_roles (id, crew_id, name, color) VALUES (?, ?, ?, ?)').bind(roleId, cid, name.trim(), color || '#8b5cf6').run()
  return c.json({ success: true, role_id: roleId })
})

// Helper: check crew permission level (owner > admin > moderator > member)
function crewRoleLevel(role: string): number {
  switch(role) { case 'owner': return 4; case 'admin': return 3; case 'moderator': return 2; default: return 1; }
}
async function getCrewMemberRole(db: D1Database, crewId: string, userId: string): Promise<string|null> {
  const m = await db.prepare("SELECT role FROM crew_members WHERE crew_id = ? AND user_id = ?").bind(crewId, userId).first() as any
  return m?.role || null
}

// Crew: set member role (owner/admin can promote/demote)
app.post('/api/crews/:id/set-member-role', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { target_user_id, role } = await c.req.json()
  if (!target_user_id || !role) return c.json({ error: 'Invalid' }, 400)
  if (!['member', 'moderator', 'admin'].includes(role)) return c.json({ error: 'Invalid role' }, 400)
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 3) return c.json({ error: 'No permission' }, 403)
  const targetRole = await getCrewMemberRole(c.env.DB, cid, target_user_id)
  if (!targetRole) return c.json({ error: 'Not a member' }, 404)
  if (targetRole === 'owner') return c.json({ error: 'Cannot change owner role' }, 403)
  // Admin can only set moderator/member, only owner can set admin
  if (role === 'admin' && myRole !== 'owner') return c.json({ error: 'Only owner can set admin' }, 403)
  if (crewRoleLevel(targetRole) >= crewRoleLevel(myRole) && myRole !== 'owner') return c.json({ error: 'Cannot modify same or higher role' }, 403)
  await c.env.DB.prepare('UPDATE crew_members SET role = ? WHERE crew_id = ? AND user_id = ?').bind(role, cid, target_user_id).run()
  const logId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_audit_log (id, crew_id, actor_id, action, target_id, details) VALUES (?, ?, ?, 'set_role', ?, ?)").bind(logId, cid, u.id, target_user_id, role).run()
  return c.json({ success: true })
})

// Crew: kick member
app.post('/api/crews/:id/kick', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { target_user_id, reason } = await c.req.json()
  if (!target_user_id) return c.json({ error: 'Invalid' }, 400)
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403) // moderator+
  const targetRole = await getCrewMemberRole(c.env.DB, cid, target_user_id)
  if (!targetRole) return c.json({ error: 'Not a member' }, 404)
  if (crewRoleLevel(targetRole) >= crewRoleLevel(myRole)) return c.json({ error: 'Cannot kick same or higher role' }, 403)
  await c.env.DB.prepare('DELETE FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(cid, target_user_id).run()
  const logId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_audit_log (id, crew_id, actor_id, action, target_id, details) VALUES (?, ?, ?, 'kick', ?, ?)").bind(logId, cid, u.id, target_user_id, reason || '').run()
  return c.json({ success: true })
})

// Crew: ban member
app.post('/api/crews/:id/ban', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { target_user_id, reason } = await c.req.json()
  if (!target_user_id) return c.json({ error: 'Invalid' }, 400)
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  const targetRole = await getCrewMemberRole(c.env.DB, cid, target_user_id)
  if (targetRole && crewRoleLevel(targetRole) >= crewRoleLevel(myRole)) return c.json({ error: 'Cannot ban same or higher role' }, 403)
  // Remove from crew + add to ban list
  await c.env.DB.prepare('DELETE FROM crew_members WHERE crew_id = ? AND user_id = ?').bind(cid, target_user_id).run()
  const banId = generateId()
  await c.env.DB.prepare('INSERT OR REPLACE INTO crew_bans (id, crew_id, user_id, banned_by, reason) VALUES (?, ?, ?, ?, ?)').bind(banId, cid, target_user_id, u.id, reason || '').run()
  const logId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_audit_log (id, crew_id, actor_id, action, target_id, details) VALUES (?, ?, ?, 'ban', ?, ?)").bind(logId, cid, u.id, target_user_id, reason || '').run()
  return c.json({ success: true })
})

// Crew: unban member
app.post('/api/crews/:id/unban', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { target_user_id } = await c.req.json()
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  await c.env.DB.prepare('DELETE FROM crew_bans WHERE crew_id = ? AND user_id = ?').bind(cid, target_user_id).run()
  const logId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_audit_log (id, crew_id, actor_id, action, target_id) VALUES (?, ?, ?, 'unban', ?)").bind(logId, cid, u.id, target_user_id).run()
  return c.json({ success: true })
})

// Crew: timeout member
app.post('/api/crews/:id/timeout', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const { target_user_id, duration_minutes, reason } = await c.req.json()
  if (!target_user_id || !duration_minutes) return c.json({ error: 'Invalid' }, 400)
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  const targetRole = await getCrewMemberRole(c.env.DB, cid, target_user_id)
  if (targetRole && crewRoleLevel(targetRole) >= crewRoleLevel(myRole)) return c.json({ error: 'Cannot timeout same or higher role' }, 403)
  const mins = Math.min(Math.max(Math.floor(Number(duration_minutes)) || 5, 1), 10080) // max 7 days
  const expiresAt = new Date(Date.now() + mins * 60 * 1000).toISOString()
  const toId = generateId()
  await c.env.DB.prepare('INSERT INTO crew_timeouts (id, crew_id, user_id, timed_out_by, expires_at, reason) VALUES (?, ?, ?, ?, ?, ?)').bind(toId, cid, target_user_id, u.id, expiresAt, reason || '').run()
  const logId = generateId()
  await c.env.DB.prepare("INSERT INTO crew_audit_log (id, crew_id, actor_id, action, target_id, details) VALUES (?, ?, ?, 'timeout', ?, ?)").bind(logId, cid, u.id, target_user_id, `${mins}min: ${reason||''}`).run()
  return c.json({ success: true })
})

// Crew: remove timeout
app.delete('/api/crews/:id/timeout/:userId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const targetId = c.req.param('userId')
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  await c.env.DB.prepare("DELETE FROM crew_timeouts WHERE crew_id = ? AND user_id = ?").bind(cid, targetId).run()
  return c.json({ success: true })
})

// Crew: delete message (admin/mod can delete any, member can delete own)
app.delete('/api/crew-messages/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const msgId = c.req.param('id')
  const msg = await c.env.DB.prepare('SELECT cm.*, cc.crew_id FROM crew_messages cm JOIN crew_channels cc ON cm.channel_id = cc.id WHERE cm.id = ?').bind(msgId).first() as any
  if (!msg) return c.json({ error: 'Not found' }, 404)
  // Own message or has mod+ permissions
  if (msg.sender_id !== u.id) {
    const myRole = await getCrewMemberRole(c.env.DB, msg.crew_id, u.id)
    if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  }
  await c.env.DB.prepare('DELETE FROM crew_messages WHERE id = ?').bind(msgId).run()
  return c.json({ success: true })
})

// Crew: get ban list
app.get('/api/crews/:id/bans', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 2) return c.json({ error: 'No permission' }, 403)
  const bans = await c.env.DB.prepare(`
    SELECT cb.*, u.username, u.display_name, u.avatar_url, bu.username as banned_by_username
    FROM crew_bans cb JOIN users u ON cb.user_id = u.id JOIN users bu ON cb.banned_by = bu.id
    WHERE cb.crew_id = ? ORDER BY cb.created_at DESC
  `).bind(cid).all()
  return c.json({ bans: bans.results })
})

// Crew: get audit log
app.get('/api/crews/:id/audit-log', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 3) return c.json({ error: 'No permission' }, 403)
  const logs = await c.env.DB.prepare(`
    SELECT cl.*, u.username as actor_username, u.display_name as actor_display_name,
      tu.username as target_username, tu.display_name as target_display_name
    FROM crew_audit_log cl JOIN users u ON cl.actor_id = u.id
    LEFT JOIN users tu ON cl.target_id = tu.id
    WHERE cl.crew_id = ? ORDER BY cl.created_at DESC LIMIT 50
  `).bind(cid).all()
  return c.json({ logs: logs.results })
})

// Crew: delete crew (owner only)
app.delete('/api/crews/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const crew = await c.env.DB.prepare('SELECT owner_id FROM crews WHERE id = ?').bind(cid).first() as any
  if (!crew) return c.json({ error: 'Not found' }, 404)
  // Only owner or site admin can delete
  if (crew.owner_id !== u.id && !isAdmin(u)) return c.json({ error: 'Only crew owner or site admin can delete' }, 403)
  // Delete all related data
  await Promise.all([
    c.env.DB.prepare('DELETE FROM crew_messages WHERE channel_id IN (SELECT id FROM crew_channels WHERE crew_id = ?)').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_voice_members WHERE channel_id IN (SELECT id FROM crew_channels WHERE crew_id = ?)').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_channels WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_members WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_bans WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_timeouts WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_audit_log WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_roles WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_notification_mutes WHERE crew_id = ?').bind(cid).run(),
  ])
  await c.env.DB.prepare('DELETE FROM crews WHERE id = ?').bind(cid).run()
  if (isAdmin(u) && crew.owner_id !== u.id) {
    const aid = generateId()
    await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'delete_crew', 'crew', ?, 'admin deletion')").bind(aid, u.id, cid).run()
  }
  return c.json({ success: true })
})

// Crew: delete channel (admin+)
app.delete('/api/crews/:id/channels/:channelId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const chId = c.req.param('channelId')
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 3) return c.json({ error: 'No permission' }, 403)
  // Don't delete the last text channel
  const textChannels = await c.env.DB.prepare("SELECT COUNT(*) as c FROM crew_channels WHERE crew_id = ? AND type = 'text'").bind(cid).first() as any
  const ch = await c.env.DB.prepare('SELECT type FROM crew_channels WHERE id = ?').bind(chId).first() as any
  if (ch?.type === 'text' && textChannels?.c <= 1) return c.json({ error: 'Cannot delete last text channel' }, 400)
  await c.env.DB.prepare('DELETE FROM crew_messages WHERE channel_id = ?').bind(chId).run()
  await c.env.DB.prepare('DELETE FROM crew_voice_members WHERE channel_id = ?').bind(chId).run()
  await c.env.DB.prepare('DELETE FROM crew_channels WHERE id = ?').bind(chId).run()
  return c.json({ success: true })
})

// Crew: update settings (name, description, icon)
app.put('/api/crews/:id', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const cid = c.req.param('id')
  const myRole = await getCrewMemberRole(c.env.DB, cid, u.id)
  if (!myRole || crewRoleLevel(myRole) < 3) return c.json({ error: 'No permission' }, 403)
  const { name, description, icon_url, is_public } = await c.req.json()
  const sets: string[] = []; const vals: any[] = []
  if (name !== undefined) { sets.push('name = ?'); vals.push(name.trim().substring(0, 50)) }
  if (description !== undefined) { sets.push('description = ?'); vals.push((description || '').substring(0, 200)) }
  if (icon_url !== undefined) { sets.push('icon_url = ?'); vals.push(icon_url || '') }
  if (is_public !== undefined) { sets.push('is_public = ?'); vals.push(is_public ? 1 : 0) }
  if (sets.length === 0) return c.json({ error: 'Nothing to update' }, 400)
  vals.push(cid)
  await c.env.DB.prepare(`UPDATE crews SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run()
  return c.json({ success: true })
})

// Admin: list all crews
app.get('/api/admin/crews', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const crews = await c.env.DB.prepare(`
    SELECT cr.*, (SELECT COUNT(*) FROM crew_members WHERE crew_id = cr.id) as member_count,
      ou.username as owner_username, ou.display_name as owner_display_name
    FROM crews cr JOIN users ou ON cr.owner_id = ou.id
    ORDER BY cr.created_at DESC LIMIT 100
  `).all()
  return c.json({ crews: crews.results })
})

// Admin: force delete any crew
app.delete('/api/admin/crews/:id', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const cid = c.req.param('id')
  await Promise.all([
    c.env.DB.prepare('DELETE FROM crew_messages WHERE channel_id IN (SELECT id FROM crew_channels WHERE crew_id = ?)').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_voice_members WHERE channel_id IN (SELECT id FROM crew_channels WHERE crew_id = ?)').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_channels WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_members WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_bans WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_timeouts WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_audit_log WHERE crew_id = ?').bind(cid).run(),
    c.env.DB.prepare('DELETE FROM crew_roles WHERE crew_id = ?').bind(cid).run(),
  ])
  await c.env.DB.prepare('DELETE FROM crews WHERE id = ?').bind(cid).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'delete_crew', 'crew', ?, 'admin force delete')").bind(aid, u.id, cid).run()
  return c.json({ success: true })
})

// ===== NOTIFICATIONS =====
app.get('/api/notifications', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const limit = Math.min(parseInt(c.req.query('limit') || '30'), 50)
  const cursor = c.req.query('cursor') || ''
  let extra = ''; const params: any[] = [u.id]
  if (cursor) { extra = 'AND n.created_at < ?'; params.push(cursor) }
  params.push(limit)
  const notifs = await c.env.DB.prepare(`
    SELECT n.*, a.username as actor_username, a.display_name as actor_display_name, a.avatar_url as actor_avatar_url
    FROM notifications n JOIN users a ON n.actor_id = a.id
    WHERE n.user_id = ? ${extra}
    ORDER BY n.created_at DESC LIMIT ?
  `).bind(...params).all()
  const next_cursor = notifs.results.length === limit ? (notifs.results[notifs.results.length - 1] as any).created_at : null
  return c.json({ notifications: notifs.results, next_cursor })
})

app.get('/api/notifications/unread', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ count: 0 })
  const r = await c.env.DB.prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND read_at IS NULL').bind(u.id).first() as any
  return c.json({ count: r?.c || 0 })
})

app.post('/api/notifications/read', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare("UPDATE notifications SET read_at = datetime('now') WHERE user_id = ? AND read_at IS NULL").bind(u.id).run()
  return c.json({ success: true })
})

// ===== NOTIFICATION SETTINGS =====
app.get('/api/notification-settings', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const [settings, dmMutes, crewMutes] = await Promise.all([
    c.env.DB.prepare("SELECT * FROM notification_settings WHERE user_id = ?").bind(u.id).first(),
    c.env.DB.prepare("SELECT m.muted_user_id, u.username, u.display_name, u.avatar_url FROM dm_notification_mutes m JOIN users u ON m.muted_user_id = u.id WHERE m.user_id = ?").bind(u.id).all(),
    c.env.DB.prepare("SELECT m.crew_id, cr.name FROM crew_notification_mutes m JOIN crews cr ON m.crew_id = cr.id WHERE m.user_id = ?").bind(u.id).all()
  ])
  const defaults = { notif_follow: 1, notif_like: 1, notif_reply: 1, notif_quote: 1, notif_coin: 1, notif_koremite: 1, notif_dm_global: 1, notif_crew_global: 1 }
  return c.json({ settings: settings || defaults, dm_mutes: dmMutes.results, crew_mutes: crewMutes.results })
})

app.put('/api/notification-settings', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const body = await c.req.json()
  const fields = ['notif_follow', 'notif_like', 'notif_reply', 'notif_quote', 'notif_coin', 'notif_koremite', 'notif_dm_global', 'notif_crew_global']
  const vals: any = {}
  for (const f of fields) { vals[f] = body[f] !== undefined ? (body[f] ? 1 : 0) : 1 }
  await c.env.DB.prepare(
    "INSERT INTO notification_settings (user_id, notif_follow, notif_like, notif_reply, notif_quote, notif_coin, notif_koremite, notif_dm_global, notif_crew_global, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now')) ON CONFLICT(user_id) DO UPDATE SET notif_follow=excluded.notif_follow, notif_like=excluded.notif_like, notif_reply=excluded.notif_reply, notif_quote=excluded.notif_quote, notif_coin=excluded.notif_coin, notif_koremite=excluded.notif_koremite, notif_dm_global=excluded.notif_dm_global, notif_crew_global=excluded.notif_crew_global, updated_at=excluded.updated_at"
  ).bind(u.id, vals.notif_follow, vals.notif_like, vals.notif_reply, vals.notif_quote, vals.notif_coin, vals.notif_koremite, vals.notif_dm_global, vals.notif_crew_global).run()
  return c.json({ success: true })
})

app.post('/api/notification-settings/dm-mute/:userId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const targetId = c.req.param('userId')
  await c.env.DB.prepare("INSERT OR IGNORE INTO dm_notification_mutes (user_id, muted_user_id) VALUES (?, ?)").bind(u.id, targetId).run()
  return c.json({ success: true })
})

app.delete('/api/notification-settings/dm-mute/:userId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const targetId = c.req.param('userId')
  await c.env.DB.prepare("DELETE FROM dm_notification_mutes WHERE user_id = ? AND muted_user_id = ?").bind(u.id, targetId).run()
  return c.json({ success: true })
})

app.post('/api/notification-settings/crew-mute/:crewId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const crewId = c.req.param('crewId')
  await c.env.DB.prepare("INSERT OR IGNORE INTO crew_notification_mutes (user_id, crew_id) VALUES (?, ?)").bind(u.id, crewId).run()
  return c.json({ success: true })
})

app.delete('/api/notification-settings/crew-mute/:crewId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const crewId = c.req.param('crewId')
  await c.env.DB.prepare("DELETE FROM crew_notification_mutes WHERE user_id = ? AND crew_id = ?").bind(u.id, crewId).run()
  return c.json({ success: true })
})

// Admin: list official users
app.get('/api/admin/official-users', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const q = c.req.query('q') || ''
  let users
  if (q) {
    users = await c.env.DB.prepare("SELECT id, username, display_name, avatar_url, is_official, role, created_at FROM users WHERE is_official = 1 AND (username LIKE ? OR display_name LIKE ?) ORDER BY display_name LIMIT 50").bind(`%${q}%`, `%${q}%`).all()
  } else {
    users = await c.env.DB.prepare("SELECT id, username, display_name, avatar_url, is_official, role, created_at FROM users WHERE is_official = 1 ORDER BY display_name LIMIT 50").all()
  }
  const total = await c.env.DB.prepare("SELECT COUNT(*) as c FROM users WHERE is_official = 1").first()
  return c.json({ users: users.results, total: (total as any)?.c || 0 })
})

// ===== SEARCH =====
app.get('/api/search/users', async (c) => {
  const q = c.req.query('q') || ''
  if (q.length < 1) return c.json({ users: [] })
  // Search by username, display_name, or sid (internally) but do NOT expose sid in results
  const r = await c.env.DB.prepare(
    "SELECT id, username, display_name, avatar_url, bio FROM users WHERE (username LIKE ? OR display_name LIKE ? OR sid LIKE ?) AND is_banned = 0 LIMIT 20"
  ).bind(`%${q}%`, `%${q}%`, `%${q}%`).all()
  return c.json({ users: r.results })
})

// Search posts by content
app.get('/api/search/posts', async (c) => {
  const q = c.req.query('q') || ''
  const uid = c.get('user')?.id || '__none__'
  if (q.length < 1) return c.json({ posts: [] })
  const limit = Math.min(parseInt(c.req.query('limit') || '20'), 50)
  const cursor = c.req.query('cursor') || ''
  let extra = ''; const params: any[] = [uid, `%${q.toLowerCase()}%`]
  if (cursor) { extra = 'AND p.created_at < ?'; params.push(cursor) }
  params.push(limit)
  const posts = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge, u.sid as user_sid,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM posts p JOIN users u ON p.user_id = u.id
    WHERE LOWER(p.content) LIKE ? AND (p.reply_to_id = '' OR p.reply_to_id IS NULL)
    AND p.user_id NOT IN (SELECT id FROM users WHERE is_banned = 1)
    ${extra}
    ORDER BY p.created_at DESC LIMIT ?
  `).bind(...params).all()
  const next_cursor = posts.results.length === limit ? (posts.results[posts.results.length - 1] as any).created_at : null
  const enriched = await enrichPostsWithQuotes(c.env.DB, posts.results as any[])
  return c.json({ posts: enriched, next_cursor })
})

// ===== ADMIN =====
// Admin dashboard data
app.get('/api/admin/dashboard', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const [users, posts, rooms, crews, banned, reports] = await Promise.all([
    c.env.DB.prepare('SELECT COUNT(*) as c FROM users').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as c FROM posts').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as c FROM voice_rooms WHERE is_active = 1').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as c FROM crews').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as c FROM users WHERE is_banned = 1').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as c FROM post_ratings WHERE rating = -1').first() as any,
  ])
  // Recent users
  const recentUsers = await c.env.DB.prepare('SELECT id, username, display_name, avatar_url, role, is_banned, created_at FROM users ORDER BY created_at DESC LIMIT 20').all()
  // Recent admin actions
  const recentActions = await c.env.DB.prepare(`
    SELECT aa.*, u.username as admin_username, u.display_name as admin_display_name
    FROM admin_actions aa JOIN users u ON aa.admin_id = u.id ORDER BY aa.created_at DESC LIMIT 20
  `).all()
  // Rate limit config
  const rateLimits = await c.env.DB.prepare('SELECT * FROM rate_limit_config').all()
  return c.json({
    stats: { users: users?.c || 0, posts: posts?.c || 0, active_rooms: rooms?.c || 0, crews: crews?.c || 0, banned: banned?.c || 0, reports: reports?.c || 0 },
    recent_users: recentUsers.results,
    recent_actions: recentActions.results,
    rate_limits: rateLimits.results
  })
})

// Admin: list all users
app.get('/api/admin/users', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const q = c.req.query('q') || ''
  const limit = Math.min(parseInt(c.req.query('limit') || '50'), 100)
  let where = ''
  const params: any[] = []
  if (q) { where = 'WHERE username LIKE ? OR display_name LIKE ? OR email LIKE ?'; params.push(`%${q}%`, `%${q}%`, `%${q}%`) }
  params.push(limit)
  const users = await c.env.DB.prepare(`SELECT id, username, display_name, email, avatar_url, role, is_banned, ban_reason, is_suspended, suspended_until, coins, created_at FROM users ${where} ORDER BY created_at DESC LIMIT ?`).bind(...params).all()
  return c.json({ users: users.results })
})

// Admin: ban user
app.post('/api/admin/ban/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { reason } = await c.req.json().catch(() => ({ reason: '' }))
  const userId = c.req.param('userId')
  // Don't ban other admins
  const target = await c.env.DB.prepare('SELECT role FROM users WHERE id = ?').bind(userId).first() as any
  if (target?.role === 'admin' || target?.role === 'superadmin') return c.json({ error: 'Cannot ban admin' }, 403)
  await c.env.DB.prepare('UPDATE users SET is_banned = 1, ban_reason = ? WHERE id = ?').bind(reason || '', userId).run()
  // Log action
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, reason) VALUES (?, ?, 'ban', 'user', ?, ?)").bind(aid, u.id, userId, reason || '').run()
  // Delete sessions
  await c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId).run()
  return c.json({ success: true })
})

// Admin: unban user
app.post('/api/admin/unban/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const userId = c.req.param('userId')
  await c.env.DB.prepare('UPDATE users SET is_banned = 0, ban_reason = ? WHERE id = ?').bind('', userId).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id) VALUES (?, ?, 'unban', 'user', ?)").bind(aid, u.id, userId).run()
  return c.json({ success: true })
})

// Admin: suspend user
app.post('/api/admin/suspend/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { hours, reason } = await c.req.json().catch(() => ({ hours: 24, reason: '' }))
  const userId = c.req.param('userId')
  const target = await c.env.DB.prepare('SELECT role FROM users WHERE id = ?').bind(userId).first() as any
  if (target?.role === 'admin' || target?.role === 'superadmin') return c.json({ error: 'Cannot suspend admin' }, 403)
  const safeHours = Math.min(Math.max(Math.floor(Number(hours) || 24), 1), 8760)
  const suspendUntil = new Date(Date.now() + safeHours * 3600 * 1000).toISOString()
  await c.env.DB.prepare('UPDATE users SET is_suspended = 1, suspended_until = ? WHERE id = ?').bind(suspendUntil, userId).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, reason, details) VALUES (?, ?, 'suspend', 'user', ?, ?, ?)").bind(aid, u.id, userId, reason || '', `${safeHours}h`).run()
  return c.json({ success: true })
})

// Admin: unsuspend user
app.post('/api/admin/unsuspend/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  await c.env.DB.prepare('UPDATE users SET is_suspended = 0, suspended_until = NULL WHERE id = ?').bind(c.req.param('userId')).run()
  return c.json({ success: true })
})

// Admin: set user role
app.post('/api/admin/set-role/:userId', async (c) => {
  const u = c.get('user'); if (!u || u.role !== 'superadmin') return c.json({ error: 'Forbidden' }, 403)
  const { role } = await c.req.json()
  if (!['user', 'admin', 'superadmin'].includes(role)) return c.json({ error: 'Invalid role' }, 400)
  await c.env.DB.prepare('UPDATE users SET role = ? WHERE id = ?').bind(role, c.req.param('userId')).run()
  return c.json({ success: true })
})

// Admin: delete any post
app.delete('/api/admin/posts/:id', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const postId = c.req.param('id')
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id) VALUES (?, ?, 'delete_post', 'post', ?)").bind(aid, u.id, postId).run()
  await c.env.DB.prepare('DELETE FROM posts WHERE id = ?').bind(postId).run()
  return c.json({ success: true })
})

// Admin: update rate limit
app.put('/api/admin/rate-limits', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { key, value } = await c.req.json()
  if (!key || typeof value !== 'number') return c.json({ error: 'Invalid' }, 400)
  await c.env.DB.prepare("INSERT OR REPLACE INTO rate_limit_config (key, value, updated_at) VALUES (?, ?, datetime('now'))").bind(key, Math.max(1, Math.min(value, 100))).run()
  return c.json({ success: true })
})

// Admin: announcements
app.get('/api/admin/announcements', async (c) => {
  const announcements = await c.env.DB.prepare(`
    SELECT a.*, u.username as author_username, u.display_name as author_display_name
    FROM admin_announcements a JOIN users u ON a.author_id = u.id
    WHERE a.is_active = 1 ORDER BY a.created_at DESC LIMIT 20
  `).all()
  return c.json({ announcements: announcements.results })
})

app.post('/api/admin/announcements', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { title, content } = await c.req.json()
  if (!title?.trim() || !content?.trim()) return c.json({ error: 'Title and content required' }, 400)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO admin_announcements (id, title, content, author_id) VALUES (?, ?, ?, ?)').bind(id, title.trim(), content.trim(), u.id).run()
  return c.json({ success: true, id })
})

app.delete('/api/admin/announcements/:id', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  await c.env.DB.prepare('UPDATE admin_announcements SET is_active = 0 WHERE id = ?').bind(c.req.param('id')).run()
  return c.json({ success: true })
})

// Admin: set official account
app.post('/api/admin/official/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { is_official } = await c.req.json().catch(() => ({ is_official: true }))
  await c.env.DB.prepare('UPDATE users SET is_official = ? WHERE id = ?').bind(is_official ? 1 : 0, c.req.param('userId')).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'set_official', 'user', ?, ?)").bind(aid, u.id, c.req.param('userId'), is_official ? 'official' : 'unofficial').run()
  return c.json({ success: true })
})

// Admin: transfer admin rights (superadmin only)
app.post('/api/admin/transfer/:userId', async (c) => {
  const u = c.get('user'); if (!u || u.role !== 'superadmin') return c.json({ error: 'Forbidden' }, 403)
  const userId = c.req.param('userId')
  if (userId === u.id) return c.json({ error: 'Cannot transfer to self' }, 400)
  // Make target superadmin, demote self to admin
  await c.env.DB.prepare('UPDATE users SET role = ? WHERE id = ?').bind('superadmin', userId).run()
  await c.env.DB.prepare('UPDATE users SET role = ? WHERE id = ?').bind('admin', u.id).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'transfer_admin', 'user', ?, 'superadmin')").bind(aid, u.id, userId).run()
  return c.json({ success: true })
})

// Admin: manage spam words
app.get('/api/admin/spam-words', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const words = await c.env.DB.prepare('SELECT * FROM spam_words ORDER BY created_at DESC').all()
  return c.json({ words: words.results })
})

app.post('/api/admin/spam-words', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { word } = await c.req.json()
  if (!word?.trim()) return c.json({ error: 'Word required' }, 400)
  // Sanitize: max 50 chars, no special chars
  const cleaned = word.trim().toLowerCase().substring(0, 50)
  if (!cleaned) return c.json({ error: 'Invalid word' }, 400)
  const id = generateId()
  await c.env.DB.prepare('INSERT OR IGNORE INTO spam_words (id, word) VALUES (?, ?)').bind(id, cleaned).run()
  return c.json({ success: true })
})

app.delete('/api/admin/spam-words/:id', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  await c.env.DB.prepare('DELETE FROM spam_words WHERE id = ?').bind(c.req.param('id')).run()
  return c.json({ success: true })
})

// Admin: IP monitoring
app.get('/api/admin/ip-monitor', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  // Find IPs used by multiple users in the last 24 hours
  const suspicious = await c.env.DB.prepare(`
    SELECT ip_address, COUNT(DISTINCT user_id) as user_count, GROUP_CONCAT(DISTINCT user_id) as user_ids, MAX(created_at) as last_seen
    FROM ip_connections WHERE created_at > datetime('now', '-24 hours')
    GROUP BY ip_address HAVING COUNT(DISTINCT user_id) > 1
    ORDER BY user_count DESC LIMIT 50
  `).all()
  return c.json({ suspicious_ips: suspicious.results })
})

// Admin: delete all posts by user
app.delete('/api/admin/users/:userId/posts', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const userId = c.req.param('userId')
  await c.env.DB.prepare('DELETE FROM posts WHERE user_id = ?').bind(userId).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'delete_all_posts', 'user', ?, 'all posts')").bind(aid, u.id, userId).run()
  return c.json({ success: true })
})

// ===== POST THREAD CHAIN (reply backtrack) =====
app.get('/api/posts/:id/thread', async (c) => {
  const uid = c.get('user')?.id || '__none__'
  const postId = c.req.param('id')
  const chain: any[] = []
  let currentId = postId
  // Walk up the reply chain (max 10 levels)
  for (let i = 0; i < 10 && currentId; i++) {
    const post = await c.env.DB.prepare(`
      SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
        (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
        (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
        (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
      FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id = ?
    `).bind(uid, currentId).first() as any
    if (!post) break
    chain.unshift(post) // prepend so oldest is first
    currentId = post.reply_to_id || ''
    if (!currentId) break
  }
  return c.json({ thread: chain })
})

// ===== HASHTAG SEARCH =====
app.get('/api/hashtags/search', async (c) => {
  const q = c.req.query('q') || ''
  if (q.length < 1) return c.json({ hashtags: [] })
  const r = await c.env.DB.prepare("SELECT * FROM hashtags WHERE name LIKE ? ORDER BY post_count DESC LIMIT 20").bind(`%${q}%`).all()
  return c.json({ hashtags: r.results })
})

app.get('/api/hashtags/:name/posts', async (c) => {
  const uid = c.get('user')?.id || '__none__'
  const name = c.req.param('name').toLowerCase()
  const limit = Math.min(parseInt(c.req.query('limit') || '20'), 50)
  const cursor = c.req.query('cursor') || ''
  let extra = ''; const params: any[] = [uid, name]
  if (cursor) { extra = 'AND p.created_at < ?'; params.push(cursor) }
  params.push(limit)
  const posts = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count
    FROM post_hashtags ph JOIN posts p ON ph.post_id = p.id JOIN users u ON p.user_id = u.id
    JOIN hashtags h ON ph.hashtag_id = h.id
    WHERE h.name = ? ${extra}
    ORDER BY p.created_at DESC LIMIT ?
  `).bind(...params).all()
  const next_cursor = posts.results.length === limit ? (posts.results[posts.results.length - 1] as any).created_at : null
  const enriched = await enrichPostsWithQuotes(c.env.DB, posts.results as any[])
  // Also return hashtag info with post_count
  const ht = await c.env.DB.prepare('SELECT * FROM hashtags WHERE name = ?').bind(name).first() as any
  return c.json({ posts: enriched, next_cursor, hashtag: ht || null })
})

// ===== MENTION SEARCH (autocomplete) =====
app.get('/api/mentions/search', async (c) => {
  const q = c.req.query('q') || ''
  if (q.length < 1) return c.json({ users: [] })
  const r = await c.env.DB.prepare(
    "SELECT id, username, display_name, avatar_url FROM users WHERE (username LIKE ? OR display_name LIKE ?) AND is_banned = 0 LIMIT 10"
  ).bind(`${q}%`, `%${q}%`).all()
  return c.json({ users: r.results })
})

// ===== CASINO =====
app.post('/api/casino/bet', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { game, bet_amount, result, win_amount } = await c.req.json()
  if (!game || !bet_amount || bet_amount < 1) return c.json({ error: 'Invalid bet' }, 400)
  const user = await c.env.DB.prepare('SELECT coins FROM users WHERE id = ?').bind(u.id).first() as any
  if (!user || user.coins < bet_amount) return c.json({ error: 'Insufficient coins' }, 400)
  const net = (win_amount || 0) - bet_amount
  await c.env.DB.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').bind(net, u.id).run()
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO casino_bets (id, user_id, game, bet_amount, win_amount, result) VALUES (?, ?, ?, ?, ?, ?)').bind(id, u.id, game, bet_amount, win_amount || 0, result || '').run()
  const tid = generateId()
  await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, ?, 'casino', ?)").bind(tid, u.id, net, game).run()
  return c.json({ success: true, new_balance: user.coins + net, net })
})

app.get('/api/casino/history', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const bets = await c.env.DB.prepare('SELECT * FROM casino_bets WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').bind(u.id).all()
  return c.json({ bets: bets.results })
})

app.get('/api/casino/leaderboard', async (c) => {
  const r = await c.env.DB.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_url, 
      SUM(cb.win_amount - cb.bet_amount) as net_profit, COUNT(*) as total_bets
    FROM casino_bets cb JOIN users u ON cb.user_id = u.id
    GROUP BY cb.user_id ORDER BY net_profit DESC LIMIT 20
  `).all()
  return c.json({ leaderboard: r.results })
})

// ===== LINE LOGIN =====
app.post('/api/auth/line', async (c) => {
  try {
    const { code, redirect_uri } = await c.req.json()
    if (!code) return c.json({ error: 'Code required' }, 400)
    // Exchange code for token
    const tokenRes = await fetch('https://api.line.me/oauth2/v2.1/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirect_uri || '',
        client_id: '2009635496',
        client_secret: '711fa481354bc97d56a5aecb6358c3a3'
      })
    })
    const tokenData = await tokenRes.json() as any
    if (!tokenData.access_token) return c.json({ error: 'LINE auth failed' }, 401)
    // Get user profile
    const profileRes = await fetch('https://api.line.me/v2/profile', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    })
    const profile = await profileRes.json() as any
    if (!profile.userId) return c.json({ error: 'Failed to get LINE profile' }, 401)
    // Check if LINE user exists
    let user = await c.env.DB.prepare('SELECT * FROM users WHERE line_user_id = ?').bind(profile.userId).first() as any
    if (user) {
      // Login existing user
      const sid = generateSessionId()
      await c.env.DB.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))").bind(sid, user.id).run()
      setCookie(c, 'session', sid, { path: '/', httpOnly: true, sameSite: 'Lax', maxAge: 2592000 })
      return c.json({ success: true, action: 'login', user: { id: user.id, username: user.username, display_name: user.display_name, avatar_url: user.avatar_url, banner_url: user.banner_url, bio: user.bio, theme: user.theme, profile_url: user.profile_url, coins: user.coins, role: user.role || 'user', is_official: user.is_official || 0, name_color: user.name_color || '', bg_color: user.bg_color || '', badge: user.badge || '' } })
    } else {
      // New user: register with LINE data
      const id = generateId()
      const username = 'line_' + profile.userId.substring(0, 10).toLowerCase()
      const displayName = profile.displayName || 'LINEユーザー'
      const avatarUrl = profile.pictureUrl || ''
      const userCount = await c.env.DB.prepare('SELECT COUNT(*) as c FROM users').first() as any
      const isFirstUser = !userCount || userCount.c === 0
      const initialCoins = isFirstUser ? 500 : 100
      const role = isFirstUser ? 'superadmin' : 'user'
      const ph = await hashPassword(crypto.randomUUID()) // random password
      const lineSid = generateId() // permanent stable ID for LINE users
      await c.env.DB.prepare('INSERT INTO users (id, username, display_name, email, password_hash, avatar_url, coins, role, line_user_id, sid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').bind(id, username, displayName, `${username}@line.local`, ph, avatarUrl, initialCoins, role, profile.userId, lineSid).run()
      const sid = generateSessionId()
      await c.env.DB.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))").bind(sid, id).run()
      const tid = generateId()
      await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type) VALUES (?, ?, ?, 'signup_bonus')").bind(tid, id, initialCoins).run()
      setCookie(c, 'session', sid, { path: '/', httpOnly: true, sameSite: 'Lax', maxAge: 2592000 })
      return c.json({ success: true, action: 'register', user: { id, username, display_name: displayName, avatar_url: avatarUrl, coins: initialCoins, role, is_official: 0, name_color: '', bg_color: '', badge: '', sid: lineSid } })
    }
  } catch (e: any) { return c.json({ error: e.message }, 500) }
})

// ===== COIN SHOP =====
app.get('/api/shop/items', async (c) => {
  return c.json({ items: [
    { type: 'name_color', label: '名前カラー', options: [
      { value: '#c8553d', label: 'レッド', cost: 50 },
      { value: '#5b8fa8', label: 'ブルー', cost: 50 },
      { value: '#6b8f71', label: 'グリーン', cost: 50 },
      { value: '#c2b280', label: 'ゴールド', cost: 80 },
      { value: '#8b7eb8', label: 'パープル', cost: 50 },
      { value: '#e6388e', label: 'ピンク', cost: 50 },
      { value: '#ff6b35', label: 'オレンジ', cost: 50 },
      { value: 'rainbow', label: 'レインボー', cost: 200 },
    ]},
    { type: 'bg_color', label: 'プロフィール背景', options: [
      { value: 'gradient-sunset', label: 'サンセット', cost: 100 },
      { value: 'gradient-ocean', label: 'オーシャン', cost: 100 },
      { value: 'gradient-forest', label: 'フォレスト', cost: 100 },
      { value: 'gradient-galaxy', label: 'ギャラクシー', cost: 150 },
      { value: 'gradient-aurora', label: 'オーロラ', cost: 150 },
      { value: 'gradient-sakura', label: 'さくら', cost: 120 },
    ]},
    { type: 'badge', label: 'バッジ', options: [
      { value: 'star', label: '⭐ スター', cost: 80 },
      { value: 'fire', label: '🔥 ファイア', cost: 80 },
      { value: 'diamond', label: '💎 ダイヤ', cost: 150 },
      { value: 'crown', label: '👑 クラウン', cost: 200 },
      { value: 'heart', label: '❤️ ハート', cost: 60 },
      { value: 'lightning', label: '⚡ ライトニング', cost: 80 },
    ]},
  ]})
})

app.post('/api/shop/buy', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { item_type, item_value, cost } = await c.req.json()
  if (!item_type || !item_value || !cost) return c.json({ error: 'Invalid' }, 400)
  if (!['name_color', 'bg_color', 'badge'].includes(item_type)) return c.json({ error: 'Invalid type' }, 400)
  const user = await c.env.DB.prepare('SELECT coins FROM users WHERE id = ?').bind(u.id).first() as any
  if (!user || user.coins < cost) return c.json({ error: 'Insufficient coins' }, 400)
  // Deduct coins & apply item (safe column mapping)
  if (item_type === 'name_color') await c.env.DB.prepare('UPDATE users SET coins = coins - ?, name_color = ? WHERE id = ?').bind(cost, item_value, u.id).run()
  else if (item_type === 'bg_color') await c.env.DB.prepare('UPDATE users SET coins = coins - ?, bg_color = ? WHERE id = ?').bind(cost, item_value, u.id).run()
  else if (item_type === 'badge') await c.env.DB.prepare('UPDATE users SET coins = coins - ?, badge = ? WHERE id = ?').bind(cost, item_value, u.id).run()
  else return c.json({ error: 'Invalid type' }, 400)
  const pid = generateId(), tid = generateId()
  await c.env.DB.prepare('INSERT INTO shop_purchases (id, user_id, item_type, item_value, cost) VALUES (?, ?, ?, ?, ?)').bind(pid, u.id, item_type, item_value, cost).run()
  await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, ?, 'shop', ?)").bind(tid, u.id, -cost, item_type + ':' + item_value).run()
  // Save to inventory for persistence
  try {
    const invId = generateId()
    await c.env.DB.prepare('INSERT OR IGNORE INTO user_inventory (id, user_id, item_type, item_value) VALUES (?, ?, ?, ?)').bind(invId, u.id, item_type, item_value).run()
  } catch {}
  return c.json({ success: true, new_balance: user.coins - cost })
})

// ===== DAILY BONUS =====
app.post('/api/daily-bonus', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const today = new Date().toISOString().split('T')[0]
  const existing = await c.env.DB.prepare('SELECT 1 FROM daily_bonus WHERE user_id = ? AND claimed_date = ?').bind(u.id, today).first()
  if (existing) return c.json({ error: 'already claimed' }, 400)
  const bonusAmount = 5
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO daily_bonus (id, user_id, claimed_date) VALUES (?, ?, ?)').bind(id, u.id, today).run()
  await c.env.DB.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').bind(bonusAmount, u.id).run()
  const tid = generateId()
  await c.env.DB.prepare("INSERT INTO coin_transactions (id, user_id, amount, type, ref_id) VALUES (?, ?, ?, 'daily_bonus', ?)").bind(tid, u.id, bonusAmount, today).run()
  const updated = await c.env.DB.prepare('SELECT coins FROM users WHERE id = ?').bind(u.id).first() as any
  return c.json({ success: true, new_balance: updated?.coins || 0, amount: bonusAmount })
})

// ===== BOOKMARKS =====
app.post('/api/bookmarks/:postId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const id = generateId()
  await c.env.DB.prepare('INSERT OR IGNORE INTO bookmarks (id, user_id, post_id) VALUES (?, ?, ?)').bind(id, u.id, c.req.param('postId')).run()
  return c.json({ success: true })
})

app.delete('/api/bookmarks/:postId', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare('DELETE FROM bookmarks WHERE user_id = ? AND post_id = ?').bind(u.id, c.req.param('postId')).run()
  return c.json({ success: true })
})

app.get('/api/bookmarks', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const uid = u.id
  const limit = Math.min(parseInt(c.req.query('limit') || '20'), 50)
  const cursor = c.req.query('cursor') || ''
  let extra = ''; const params: any[] = [uid, uid]
  if (cursor) { extra = 'AND b.created_at < ?'; params.push(cursor) }
  params.push(limit)
  const posts = await c.env.DB.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url, u.is_official, u.name_color, u.badge,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as liked,
      (SELECT COUNT(*) FROM posts WHERE reply_to_id = p.id) as reply_count,
      b.created_at as bookmarked_at
    FROM bookmarks b JOIN posts p ON b.post_id = p.id JOIN users u ON p.user_id = u.id
    WHERE b.user_id = ? ${extra}
    ORDER BY b.created_at DESC LIMIT ?
  `).bind(...params).all()
  const next_cursor = posts.results.length === limit ? (posts.results[posts.results.length - 1] as any).bookmarked_at : null
  const enriched = await enrichPostsWithQuotes(c.env.DB, posts.results as any[])
  return c.json({ posts: enriched, next_cursor })
})

// ===== ADMIN: Set R18/AI on posts =====
app.post('/api/admin/posts/:id/flags', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { is_r18, is_ai_generated } = await c.req.json()
  const postId = c.req.param('id')
  const sets: string[] = []; const vals: any[] = []
  if (is_r18 !== undefined) { sets.push('is_r18 = ?'); vals.push(is_r18 ? 1 : 0) }
  if (is_ai_generated !== undefined) { sets.push('is_ai_generated = ?'); vals.push(is_ai_generated ? 1 : 0) }
  if (sets.length === 0) return c.json({ error: 'Nothing to update' }, 400)
  vals.push(postId)
  await c.env.DB.prepare(`UPDATE posts SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'set_flags', 'post', ?, ?)").bind(aid, u.id, postId, `r18:${is_r18?1:0},ai:${is_ai_generated?1:0}`).run()
  return c.json({ success: true })
})

// ===== ADMIN: Ably API Key Management =====
app.get('/api/admin/ably-key', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const row = await c.env.DB.prepare("SELECT value FROM site_settings WHERE key = 'ably_api_key'").first() as any
  return c.json({ ably_api_key: row?.value || '' })
})

app.post('/api/admin/ably-key', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { ably_api_key } = await c.req.json()
  await c.env.DB.prepare("INSERT OR REPLACE INTO site_settings (key, value, updated_at) VALUES ('ably_api_key', ?, datetime('now'))").bind(ably_api_key || '').run()
  return c.json({ success: true })
})

// Public endpoint to get Ably API key for frontend
app.get('/api/ably-key', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  try {
    const row = await c.env.DB.prepare("SELECT value FROM site_settings WHERE key = 'ably_api_key'").first() as any
    return c.json({ ably_api_key: row?.value || '' })
  } catch { return c.json({ ably_api_key: '' }) }
})

// ===== ADMIN: Delete any post (for recommended feed) =====
app.delete('/api/admin/feed-posts/:id', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const postId = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM posts WHERE id = ?').bind(postId).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id) VALUES (?, ?, 'delete_post_feed', 'post', ?)").bind(aid, u.id, postId).run()
  return c.json({ success: true })
})

// ===== ADMIN: Content Policy (site-wide R18/AI toggles) =====
app.get('/api/admin/content-policy', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const rows = await c.env.DB.prepare("SELECT key, value FROM site_settings WHERE key IN ('allow_r18', 'allow_ai_content', 'require_age_verify', 'r18_blur_default')").all()
  const settings: Record<string, string> = {}
  for (const r of rows.results as any[]) settings[r.key] = r.value
  return c.json({
    allow_r18: settings.allow_r18 !== '0',
    allow_ai_content: settings.allow_ai_content !== '0',
    require_age_verify: settings.require_age_verify !== '0',
    r18_blur_default: settings.r18_blur_default !== '0'
  })
})

app.post('/api/admin/content-policy', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const body = await c.req.json()
  const allowed = ['allow_r18', 'allow_ai_content', 'require_age_verify', 'r18_blur_default']
  for (const key of allowed) {
    if (body[key] !== undefined) {
      await c.env.DB.prepare("INSERT OR REPLACE INTO site_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))").bind(key, body[key] ? '1' : '0').run()
    }
  }
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'content_policy', 'site', 'global', ?)").bind(aid, u.id, JSON.stringify(body)).run()
  return c.json({ success: true })
})

// Public content policy (for frontend to know if R18/AI is allowed)
app.get('/api/content-policy', async (c) => {
  try {
    const rows = await c.env.DB.prepare("SELECT key, value FROM site_settings WHERE key IN ('allow_r18', 'allow_ai_content', 'require_age_verify', 'r18_blur_default')").all()
    const settings: Record<string, string> = {}
    for (const r of rows.results as any[]) settings[r.key] = r.value
    return c.json({
      allow_r18: settings.allow_r18 !== '0',
      allow_ai_content: settings.allow_ai_content !== '0',
      require_age_verify: settings.require_age_verify !== '0',
      r18_blur_default: settings.r18_blur_default !== '0'
    })
  } catch {
    return c.json({ allow_r18: true, allow_ai_content: true, require_age_verify: true, r18_blur_default: true })
  }
})

// ===== HASHTAG with post count =====
app.get('/api/hashtags/:name', async (c) => {
  const name = c.req.param('name').toLowerCase()
  const ht = await c.env.DB.prepare('SELECT * FROM hashtags WHERE name = ?').bind(name).first() as any
  if (!ht) return c.json({ hashtag: null })
  return c.json({ hashtag: ht })
})

// ===== OGP LINK PREVIEW =====
app.get('/api/ogp', async (c) => {
  const url = c.req.query('url') || ''
  if (!url) return c.json({ error: 'URL required' }, 400)
  try {
    const cached = await c.env.DB.prepare("SELECT * FROM link_previews WHERE url = ? AND fetched_at > datetime('now', '-24 hours')").bind(url).first() as any
    if (cached) {
      c.header('Cache-Control', 'public, max-age=3600, stale-while-revalidate=86400')
      return c.json({ title: cached.title, description: cached.description, image: cached.image, site_name: cached.site_name, url })
    }
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 5000)
    const res = await fetch(url, { headers: { 'User-Agent': 'bot' }, signal: controller.signal, redirect: 'follow' })
    clearTimeout(timeout)
    const html = await res.text()
    const getTag = (name: string) => {
      const m = html.match(new RegExp(`<meta[^>]*property=["']og:${name}["'][^>]*content=["']([^"']*)["']`, 'i'))
        || html.match(new RegExp(`<meta[^>]*content=["']([^"']*)["'][^>]*property=["']og:${name}["']`, 'i'))
      return m?.[1] || ''
    }
    let title = getTag('title') || (html.match(/<title[^>]*>([^<]*)<\/title>/i)?.[1] || '').trim()
    let description = getTag('description') || (html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)["']/i)?.[1] || '')
    const image = getTag('image')
    const site_name = getTag('site_name')
    title = title.substring(0, 200)
    description = description.substring(0, 300)
    try { await c.env.DB.prepare('INSERT OR REPLACE INTO link_previews (url, title, description, image, site_name) VALUES (?, ?, ?, ?, ?)').bind(url, title, description, image, site_name).run() } catch {}
    return c.json({ title, description, image, site_name, url })
  } catch { return c.json({ title: '', description: '', image: '', site_name: '', url }) }
})

// ===== REPORTS =====
app.post('/api/reports', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { target_type, target_id, reason } = await c.req.json()
  if (!target_type || !target_id || !reason?.trim()) return c.json({ error: 'Reason required' }, 400)
  if (!['post', 'user'].includes(target_type)) return c.json({ error: 'Invalid type' }, 400)
  if (reason.trim().length < 3) return c.json({ error: 'Reason too short' }, 400)
  const id = generateId()
  await c.env.DB.prepare('INSERT INTO reports (id, reporter_id, target_type, target_id, reason) VALUES (?, ?, ?, ?, ?)').bind(id, u.id, target_type, target_id, reason.trim()).run()
  return c.json({ success: true })
})

app.get('/api/admin/reports', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const status = c.req.query('status') || 'pending'
  const reports = await c.env.DB.prepare(`
    SELECT r.*, ru.username as reporter_username, ru.display_name as reporter_display_name
    FROM reports r JOIN users ru ON r.reporter_id = ru.id
    WHERE r.status = ? ORDER BY r.created_at DESC LIMIT 50
  `).bind(status).all()
  return c.json({ reports: reports.results })
})

app.post('/api/admin/reports/:id/review', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { status, admin_note } = await c.req.json()
  if (!['reviewed', 'dismissed'].includes(status)) return c.json({ error: 'Invalid status' }, 400)
  await c.env.DB.prepare("UPDATE reports SET status = ?, admin_note = ?, reviewed_at = datetime('now'), reviewed_by = ? WHERE id = ?").bind(status, admin_note || '', u.id, c.req.param('id')).run()
  return c.json({ success: true })
})

// ===== ACCOUNT DELETION =====
app.post('/api/account/delete', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  await c.env.DB.prepare("UPDATE users SET is_deleted = 1, deleted_at = datetime('now'), display_name = '[deleted]', bio = '' WHERE id = ?").bind(u.id).run()
  await c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id).run()
  deleteCookie(c, 'session', { path: '/' })
  return c.json({ success: true })
})

app.post('/api/admin/delete-account/:userId', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const userId = c.req.param('userId')
  const target = await c.env.DB.prepare('SELECT role FROM users WHERE id = ?').bind(userId).first() as any
  if (target?.role === 'superadmin') return c.json({ error: 'Cannot delete superadmin' }, 403)
  await c.env.DB.prepare("UPDATE users SET is_deleted = 1, deleted_at = datetime('now'), is_banned = 1, ban_reason = 'Account deleted by admin' WHERE id = ?").bind(userId).run()
  await c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId).run()
  const aid = generateId()
  await c.env.DB.prepare("INSERT INTO admin_actions (id, admin_id, action_type, target_type, target_id, details) VALUES (?, ?, 'delete_account', 'user', ?, 'admin deletion')").bind(aid, u.id, userId).run()
  return c.json({ success: true })
})

// ===== VOICE ROOM ICON =====
app.put('/api/voice-rooms/:id/icon', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const rid = c.req.param('id')
  const myMember = await c.env.DB.prepare("SELECT role FROM voice_room_members WHERE room_id = ? AND user_id = ?").bind(rid, u.id).first() as any
  if (!myMember || myMember.role !== 'owner') return c.json({ error: 'Only owner' }, 403)
  const { icon_url } = await c.req.json()
  await c.env.DB.prepare('UPDATE voice_rooms SET icon_url = ? WHERE id = ?').bind(icon_url || '', rid).run()
  return c.json({ success: true })
})

// ===== SHOP INVENTORY =====
app.get('/api/shop/inventory', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const items = await c.env.DB.prepare('SELECT * FROM user_inventory WHERE user_id = ? ORDER BY purchased_at DESC').bind(u.id).all()
  return c.json({ inventory: items.results })
})

app.post('/api/shop/equip', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const { item_type, item_value } = await c.req.json()
  if (!item_type || !['name_color', 'bg_color', 'badge'].includes(item_type)) return c.json({ error: 'Invalid' }, 400)
  if (item_value) {
    const owns = await c.env.DB.prepare('SELECT 1 FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_value = ?').bind(u.id, item_type, item_value).first()
    if (!owns) return c.json({ error: 'Not owned' }, 403)
  }
  // Use safe column mapping instead of dynamic SQL
  if (item_type === 'name_color') await c.env.DB.prepare('UPDATE users SET name_color = ? WHERE id = ?').bind(item_value || '', u.id).run()
  else if (item_type === 'bg_color') await c.env.DB.prepare('UPDATE users SET bg_color = ? WHERE id = ?').bind(item_value || '', u.id).run()
  else if (item_type === 'badge') await c.env.DB.prepare('UPDATE users SET badge = ? WHERE id = ?').bind(item_value || '', u.id).run()
  return c.json({ success: true })
})

// ===== Admin: Site Images Management =====
app.get('/api/admin/site-images', async (c) => {
  try {
    const rows = await c.env.DB.prepare('SELECT key, value FROM site_settings WHERE key LIKE ?').bind('img_%').all()
    const images: Record<string, string> = {}
    for (const row of (rows.results || []) as any[]) {
      images[row.key.replace('img_', '')] = row.value
    }
    return c.json({ images })
  } catch { return c.json({ images: {} }) }
})

app.put('/api/admin/site-images', async (c) => {
  const u = c.get('user'); if (!u || !isAdmin(u)) return c.json({ error: 'Forbidden' }, 403)
  const { key, value } = await c.req.json()
  if (!key) return c.json({ error: 'Key required' }, 400)
  const dbKey = 'img_' + key
  await c.env.DB.prepare('INSERT OR REPLACE INTO site_settings (key, value, updated_at) VALUES (?, ?, datetime(\'now\'))').bind(dbKey, value || '').run()
  return c.json({ success: true })
})

// ===== Admin: Direct DB Operations =====
app.post('/api/admin/db-query', async (c) => {
  const u = c.get('user'); if (!u || u.role !== 'superadmin') return c.json({ error: 'Superadmin only' }, 403)
  const { query } = await c.req.json()
  if (!query?.trim()) return c.json({ error: 'Query required' }, 400)
  const q = query.trim()
  // Safety: block dangerous patterns
  const dangerous = /\b(DROP\s+DATABASE|DROP\s+TABLE\s+users|DROP\s+TABLE\s+sessions|PRAGMA\s+key|ATTACH)\b/i
  if (dangerous.test(q)) return c.json({ error: 'Dangerous query blocked' }, 403)
  // Block write to sessions table (could be used for privilege escalation)
  if (/\b(INSERT|UPDATE|DELETE)\b.*\bsessions\b/i.test(q) && !/admin_db/i.test(q)) return c.json({ error: 'Cannot modify sessions table' }, 403)
  try {
    const isSelect = /^\s*SELECT\b/i.test(q)
    let result: any
    if (isSelect) {
      result = await c.env.DB.prepare(q).all()
    } else {
      result = await c.env.DB.prepare(q).run()
    }
    // Log the query
    try {
      const logId = generateId()
      await c.env.DB.prepare('INSERT INTO admin_db_queries (id, admin_id, query_text, result_text) VALUES (?, ?, ?, ?)').bind(logId, u.id, q, JSON.stringify(result).substring(0, 5000)).run()
    } catch {}
    return c.json({ success: true, result, is_select: isSelect })
  } catch (e: any) {
    return c.json({ error: e.message || 'Query failed' }, 400)
  }
})

app.get('/api/admin/db-queries', async (c) => {
  const u = c.get('user'); if (!u || u.role !== 'superadmin') return c.json({ error: 'Superadmin only' }, 403)
  try {
  } catch {}
  const queries = await c.env.DB.prepare('SELECT * FROM admin_db_queries ORDER BY created_at DESC LIMIT 50').all()
  return c.json({ queries: queries.results })
})

// ===== LEGAL PAGES (Terms of Service, Privacy Policy) =====
app.get('/api/legal/:type', async (c) => {
  const type = c.req.param('type')
  if (type !== 'terms' && type !== 'privacy') return c.json({ error: 'Invalid type' }, 400)
  const lang = c.get('lang') || 'ja'
  try {
    const row = await c.env.DB.prepare('SELECT value FROM site_settings WHERE key = ?').bind(`legal_${type}_${lang}`).first() as any
    const updatedRow = await c.env.DB.prepare("SELECT value FROM site_settings WHERE key = 'legal_updated_at'").first() as any
    return c.json({ content: row?.value || '', updated_at: updatedRow?.value || '' })
  } catch { return c.json({ content: '', updated_at: '' }) }
})

app.get('/api/admin/legal', async (c) => {
  const u = c.get('user'); if (!u || (u.role !== 'admin' && u.role !== 'superadmin')) return c.json({ error: 'Admin only' }, 403)
  try {
    const rows = await c.env.DB.prepare("SELECT key, value FROM site_settings WHERE key LIKE 'legal_%'").all()
    const legal: Record<string, string> = {}
    for (const row of (rows.results || []) as any[]) { legal[row.key] = row.value }
    return c.json({ legal })
  } catch { return c.json({ legal: {} }) }
})

app.put('/api/admin/legal', async (c) => {
  const u = c.get('user'); if (!u || (u.role !== 'admin' && u.role !== 'superadmin')) return c.json({ error: 'Admin only' }, 403)
  const body = await c.req.json()
  const validKeys = ['legal_terms_ja', 'legal_terms_en', 'legal_privacy_ja', 'legal_privacy_en']
  try {
    for (const key of validKeys) {
      if (body[key] !== undefined) {
        await c.env.DB.prepare("INSERT OR REPLACE INTO site_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))").bind(key, body[key]).run()
      }
    }
    await c.env.DB.prepare("INSERT OR REPLACE INTO site_settings (key, value, updated_at) VALUES ('legal_updated_at', ?, datetime('now'))").bind(new Date().toISOString()).run()
    return c.json({ success: true })
  } catch (e: any) { return c.json({ error: e.message }, 500) }
})


// ===== RECOMMENDATION ENGINE API ROUTES (v23) =====
app.post('/api/signals', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ success: true })
  const { signals } = await c.req.json()
  if (!Array.isArray(signals) || signals.length === 0) return c.json({ success: true })
  const batch = signals.slice(0, 30)
  const stmts: D1PreparedStatement[] = []
  for (const s of batch) {
    if (!s.post_id || !s.type) continue
    const validTypes = ['dwell','like','reply','detail_view','profile_click','share','bookmark','not_interested','scroll_skip']
    if (!validTypes.includes(s.type)) continue
    let val = typeof s.value === 'number' ? Math.min(Math.max(s.value, -100), 600) : 1.0
    // DWELL TIME NORMALIZATION: normalize raw seconds by expected reading time
    if (s.type === 'dwell' && val > 0) {
      const contentLen = typeof s.content_length === 'number' ? s.content_length : 50
      const hasMedia = s.has_media ? 1 : 0
      // Expected dwell = 2s base + 0.04s per character + 3s for media
      const expectedDwell = 2 + contentLen * 0.04 + hasMedia * 3
      // Relative dwell: 1.0 = average, >1 = above average, <1 = below
      val = Math.min(5.0, val / Math.max(1, expectedDwell))
    }
    const id = generateId()
    stmts.push(
      c.env.DB.prepare('INSERT INTO engagement_signals (id, user_id, post_id, signal_type, signal_value) VALUES (?,?,?,?,?)')
        .bind(id, u.id, s.post_id, s.type, val)
    )
  }
  if (stmts.length > 0) { try { await c.env.DB.batch(stmts) } catch {} }
  // SCROLL_SKIP BLACKLIST: When many scroll_skips happen for same author, auto-blacklist
  try {
    const skipSignals = batch.filter(s => s.type === 'scroll_skip' && s.author_id && s.author_id !== u.id)
    const skipAuthors = new Map<string, number>()
    for (const s of skipSignals) {
      skipAuthors.set(s.author_id, (skipAuthors.get(s.author_id) || 0) + 1)
    }
    const blStmts: D1PreparedStatement[] = []
    for (const [authorId, count] of skipAuthors) {
      if (count >= 2) {
        // After 2+ scroll_skips in one batch: soft blacklist for 3 hours
        blStmts.push(
          c.env.DB.prepare(`INSERT OR REPLACE INTO user_blacklist (user_id, blacklist_type, target_id, expires_at) VALUES (?,?,?,datetime('now','+3 hours'))`)
            .bind(u.id, 'author', authorId)
        )
        // Reduce interest score
        blStmts.push(
          c.env.DB.prepare(`INSERT INTO user_interests (user_id, interest_user_id, score, negative_score, updated_at)
            VALUES (?,?,0,1,datetime('now'))
            ON CONFLICT(user_id, interest_user_id) DO UPDATE SET score = MAX(0, score - 1), negative_score = negative_score + 0.5, updated_at = datetime('now')`)
            .bind(u.id, authorId)
        )
      }
    }
    if (blStmts.length > 0) await c.env.DB.batch(blStmts)
  } catch {}
  // Update user interests
  try {
    const authorMap = new Map<string, {like:number,reply:number,dwell:number,neg:number}>()
    for (const s of batch) {
      if (!s.post_id || !s.author_id || s.author_id === u.id) continue
      if (!authorMap.has(s.author_id)) authorMap.set(s.author_id, {like:0,reply:0,dwell:0,neg:0})
      const a = authorMap.get(s.author_id)!
      if (s.type === 'like') a.like += 1
      else if (s.type === 'reply') a.reply += 1
      else if (s.type === 'dwell') a.dwell += Math.min(s.value || 0, 60) / 10
      else if (s.type === 'not_interested') a.neg += 1
    }
    const iStmts: D1PreparedStatement[] = []
    for (const [authorId, scores] of authorMap) {
      const total = scores.like * 2 + scores.reply * 4 + scores.dwell * 1.5 - scores.neg * 3
      iStmts.push(
        c.env.DB.prepare(`INSERT INTO user_interests (user_id, interest_user_id, score, like_score, reply_score, dwell_score, negative_score, updated_at)
          VALUES (?,?,?,?,?,?,?,datetime('now'))
          ON CONFLICT(user_id, interest_user_id) DO UPDATE SET
            score = MAX(0, score + ?), like_score = like_score + ?, reply_score = reply_score + ?,
            dwell_score = dwell_score + ?, negative_score = negative_score + ?, updated_at = datetime('now')`)
          .bind(u.id, authorId, Math.max(0,total), scores.like, scores.reply, scores.dwell, scores.neg,
                total, scores.like, scores.reply, scores.dwell, scores.neg)
      )
    }
    if (iStmts.length > 0) await c.env.DB.batch(iStmts)
  } catch {}
  // Update topic interests from hashtags
  try {
    const tStmts: D1PreparedStatement[] = []
    const WEIGHTS: Record<string, number> = {dwell:3,like:2,reply:4,detail_view:1.5,profile_click:2.5,bookmark:3.5,not_interested:-5,scroll_skip:-1.5}
    for (const s of batch) {
      if (!s.hashtags || !Array.isArray(s.hashtags)) continue
      const w = WEIGHTS[s.type] || 1
      for (const tag of s.hashtags.slice(0, 5)) {
        if (typeof tag !== 'string' || tag.length > 50) continue
        tStmts.push(
          c.env.DB.prepare(`INSERT INTO user_topic_interests (user_id, topic, score, interaction_count, last_interaction)
            VALUES (?,?,?,1,datetime('now'))
            ON CONFLICT(user_id, topic) DO UPDATE SET score = score + ?, interaction_count = interaction_count + 1, last_interaction = datetime('now')`)
            .bind(u.id, tag.toLowerCase(), Math.max(0, w), Math.max(0, w))
        )
      }
    }
    if (tStmts.length > 0) await c.env.DB.batch(tStmts)
  } catch {}
  return c.json({ success: true })
})

// Not interested: adds to blacklist for real-time exclusion
app.post('/api/posts/:id/not-interested', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ error: 'Unauthorized' }, 401)
  const postId = c.req.param('id')
  const { reason } = await c.req.json().catch(() => ({ reason: '' }))
  const post = await c.env.DB.prepare('SELECT user_id, content FROM posts WHERE id = ?').bind(postId).first() as any
  const authorId = post?.user_id || ''
  // Record not-interested
  await c.env.DB.prepare(`INSERT OR REPLACE INTO not_interested (user_id, post_id, author_id, reason) VALUES (?,?,?,?)`)
    .bind(u.id, postId, authorId, reason || '').run()
  // Record negative signal
  const sigId = generateId()
  await c.env.DB.prepare('INSERT INTO engagement_signals (id, user_id, post_id, signal_type, signal_value) VALUES (?,?,?,?,?)').bind(sigId, u.id, postId, 'not_interested', -5.0).run()
  // REAL-TIME BLACKLIST: Add author to blacklist for 6 hours
  if (authorId && authorId !== u.id) {
    // Count how many times user has marked this author's content as not-interested
    const niCount = await c.env.DB.prepare("SELECT COUNT(*) as c FROM not_interested WHERE user_id = ? AND author_id = ?").bind(u.id, authorId).first() as any
    const count = niCount?.c || 1
    // Escalating blacklist: 1x=6h, 2x=24h, 3+=permanent
    const duration = count >= 3 ? '+10 years' : count >= 2 ? '+24 hours' : '+6 hours'
    await c.env.DB.prepare(`INSERT OR REPLACE INTO user_blacklist (user_id, blacklist_type, target_id, expires_at) VALUES (?,?,?,datetime('now','${duration}'))`)
      .bind(u.id, 'author', authorId).run()
    // Reduce interest in author
    await c.env.DB.prepare(`INSERT INTO user_interests (user_id, interest_user_id, score, negative_score, updated_at)
      VALUES (?,?,0,1,datetime('now'))
      ON CONFLICT(user_id, interest_user_id) DO UPDATE SET
        score = MAX(0, score - 3), negative_score = negative_score + 1, updated_at = datetime('now')`)
      .bind(u.id, authorId).run()
  }
  // BLACKLIST TOPICS from post hashtags
  try {
    const content = post?.content || ''
    const tags = content.match(/#[\w\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]+/g) || []
    for (const tag of tags.slice(0, 3)) {
      const clean = tag.replace('#','').toLowerCase()
      await c.env.DB.prepare(`INSERT OR REPLACE INTO user_blacklist (user_id, blacklist_type, target_id, expires_at) VALUES (?,?,?,datetime('now','+6 hours'))`)
        .bind(u.id, 'topic', clean).run()
      // Reduce topic interest
      await c.env.DB.prepare(`UPDATE user_topic_interests SET score = MAX(0, score - 2) WHERE user_id = ? AND topic = ?`)
        .bind(u.id, clean).run()
    }
  } catch {}
  return c.json({ success: true })
})

// Feed impressions
app.post('/api/feed/impressions', async (c) => {
  const u = c.get('user'); if (!u) return c.json({ success: true })
  const { impressions } = await c.req.json()
  if (!Array.isArray(impressions) || impressions.length === 0) return c.json({ success: true })
  const stmts: D1PreparedStatement[] = []
  for (const imp of impressions.slice(0, 30)) {
    if (!imp.post_id) continue
    stmts.push(c.env.DB.prepare(`INSERT OR REPLACE INTO feed_impressions (user_id, post_id, position, was_engaged, shown_at) VALUES (?,?,?,0,datetime('now'))`).bind(u.id, imp.post_id, imp.position || 0))
  }
  if (stmts.length > 0) { try { await c.env.DB.batch(stmts) } catch {} }
  return c.json({ success: true })
})

// Trending topics
app.get('/api/trending', async (c) => {
  const topics = await c.env.DB.prepare('SELECT topic, post_count, trending_score FROM trending_cache ORDER BY trending_score DESC LIMIT 10').all()
  c.header('Cache-Control', 'public, max-age=60, stale-while-revalidate=120')
  return c.json({ topics: topics.results })
})

// ===== ADMIN MODULE PROTECTION =====
app.get('/api/modules/admin.js', async (c) => {
  const user = c.get('user')
  if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
    return c.text('// Access denied', 403, { 'Content-Type': 'application/javascript' })
  }
  return c.text(adminJsContent, 200, {
    'Content-Type': 'application/javascript',
    'Cache-Control': 'private, no-cache'
  })
})


// ===== SPA Shell =====
app.get('/favicon.ico', (c) => new Response(null, { status: 204 }))
app.get('/static/*', (c) => c.notFound())
app.get('/manifest.json', (c) => {
  return c.json({
    name: '\u3055\u3068\u3063\u3061',
    short_name: '\u3055\u3068\u3063\u3061',
    description: '\u307f\u3093\u306a\u306e\u5c45\u5834\u6240',
    start_url: '/?source=pwa',
    display: 'standalone',
    background_color: '#fafaf8',
    theme_color: '#1a1a2e',
    orientation: 'portrait',
    categories: ['social'],
    icons: [
      { src: '/static/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
      { src: '/static/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }
    ]
  })
})

// Performance: In-memory cache for site_settings (avoids DB query on every page load)
let _siteSettingsCache: { data: Record<string, string>; ts: number } | null = null
const SITE_SETTINGS_TTL = 60000 // 60 seconds

async function getSiteSettings(db: D1Database): Promise<Record<string, string>> {
  if (_siteSettingsCache && Date.now() - _siteSettingsCache.ts < SITE_SETTINGS_TTL) {
    return _siteSettingsCache.data
  }
  const result: Record<string, string> = {}
  try {
    const rows = await db.prepare('SELECT key, value FROM site_settings WHERE key LIKE ? OR key = ?').bind('img_%', 'ably_api_key').all()
    for (const row of (rows.results || []) as any[]) {
      result[row.key] = row.value || ''
    }
  } catch {}
  _siteSettingsCache = { data: result, ts: Date.now() }
  return result
}

// Pre-generate i18n scripts (avoid regeneration per request)
const _i18nCache: Record<string, string> = {}
function getCachedI18n(lang: Lang): string {
  if (!_i18nCache[lang]) _i18nCache[lang] = generateI18nScript(lang)
  return _i18nCache[lang]
}

const spaRoutes = ['/', '/login', '/register', '/voice', '/voice/*', '/profile/*', '/dm', '/dm/*', '/post/*', '/crew', '/crew/*', '/notifications', '/settings', '/shop', '/help', '/help/*', '/admin', '/admin/*', '/casino', '/casino/*', '/hashtag/*', '/search', '/line-callback', '/404']
for (const route of spaRoutes) {
  app.get(route, async (c) => {
    const lang = c.get('lang')
    const user = c.get('user')
    const i18nScript = getCachedI18n(lang)
    const userJson = user ? JSON.stringify(user) : 'null'
    // Load admin-configured site images + ably key (cached in memory)
    const settings = await getSiteSettings(c.env.DB)
    let siteImages: Record<string, string> = {}
    let ablyApiKey = ''
    for (const [k, v] of Object.entries(settings)) {
      if (k === 'ably_api_key') ablyApiKey = v
      else if (k.startsWith('img_')) siteImages[k.replace('img_', '')] = v
    }
    const siteImagesJson = JSON.stringify(siteImages)
    // Optimized HTML shell with performance best practices
    return c.html(`<!DOCTYPE html>
<html lang="${lang}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#fafaf8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="description" content="さとっち - みんなの場所。投稿、ボイスチャット、クルー、カジノを楽しもう。">
<link rel="manifest" href="/manifest.json">
<title>さとっち</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<link rel="preconnect" href="https://cdn.ably.com" crossorigin>
<link rel="dns-prefetch" href="https://unpkg.com">
<script>${i18nScript};window.__USER__=${userJson};window.__SITE_IMAGES__=${siteImagesJson};window.__ABLY_KEY__='${ablyApiKey}';</script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans','Noto Sans JP',system-ui,-apple-system,sans-serif;background:#fafaf8;color:#1a1a2e;-webkit-font-smoothing:antialiased;overscroll-behavior:none;-webkit-touch-callout:none;overflow-x:hidden}
.app-shell{display:flex;min-height:100dvh}
.sidebar{display:none}
.main-content{flex:1;min-width:0;padding-bottom:72px}
.page-container{max-width:640px;margin:0 auto;padding:0 16px}
@keyframes splash-in{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes sk-pulse{0%{opacity:.06}50%{opacity:.12}100%{opacity:.06}}
.sk{background:var(--bg-elevated,rgba(0,0,0,.025));border-radius:10px;animation:sk-pulse 1.5s ease-in-out infinite}
@media(min-width:769px){.sidebar{display:flex;flex-direction:column;width:72px;position:sticky;top:0;height:100dvh;border-right:1px solid rgba(0,0,0,.06);padding:16px 0;align-items:center;gap:8px;background:#fff}.main-content{padding-bottom:0}}
</style>
<link rel="stylesheet" href="/static/styles.css" media="all">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,600;9..40,700&family=Cormorant+Garamond:wght@600;700&family=Noto+Sans+JP:wght@400;500;700&display=swap" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,600;9..40,700&family=Cormorant+Garamond:wght@600;700&family=Noto+Sans+JP:wght@400;500;700&display=swap"></noscript>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css"></noscript>
</head>
<body>
<div id="splash" style="position:fixed;inset:0;z-index:9999;background:var(--bg-primary,#fafaf8);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;transition:opacity 0.4s ease">
${siteImages.splash_image ? `<img src="${siteImages.splash_image}" style="max-width:120px;max-height:120px;border-radius:24px;opacity:0;animation:splash-in 0.8s ease 0.2s forwards" alt="" fetchpriority="high">` : ''}
<div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:42px;font-weight:700;color:var(--text-primary,#1a1a2e);letter-spacing:-0.03em;opacity:0;animation:splash-in 0.8s ease 0.2s forwards">さとっち</div>
<div style="font-size:13px;color:var(--text-tertiary,#a0a098);letter-spacing:0.1em;opacity:0;animation:splash-in 0.6s ease 0.6s forwards">A PLACE FOR EVERYONE</div>
</div>
<div id="app"><div class="app-shell"><nav class="sidebar" id="sidebar"></nav><div class="main-content"><div class="page-container" id="page"><div style="padding:24px 0"><div class="sk" style="height:48px;margin-bottom:16px"></div><div class="sk" style="height:120px;margin-bottom:12px"></div><div class="sk" style="height:120px;margin-bottom:12px"></div><div class="sk" style="height:80px"></div></div></div></div></div></div>
<script src="/static/app.js" defer></script>
<script src="/static/voice.js" defer></script>
<script src="/static/social.js" defer></script>
<script src="/static/shop.js" defer></script>
<script>
(function(){var d=document,w=window;
function ll(u,a){var s=d.createElement('script');s.src=u;if(a)s.async=true;d.body.appendChild(s);}
if(w.__ABLY_KEY__&&w.__USER__){ll('https://cdn.ably.com/lib/ably.min-2.js',true);}
w.addEventListener('load',function(){ll('https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js',true);});
})();
</script>
</body>
</html>`)
  })
}

// Catch-all 404
app.all('*', (c) => {
  const lang = c.get('lang')
  const user = c.get('user')
  const i18nScript = getCachedI18n(lang)
  const userJson = user ? JSON.stringify(user) : 'null'
  return c.html(`<!DOCTYPE html>
<html lang="${lang}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#fafaf8">
<title>404 - さとっち</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'DM Sans','Noto Sans JP',system-ui,sans-serif;background:#fafaf8;color:#1a1a2e}</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,600;9..40,700&family=Cormorant+Garamond:wght@600;700&family=Noto+Sans+JP:wght@400;500;700&display=swap" media="print" onload="this.media='all'">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css" media="print" onload="this.media='all'">
<script>${i18nScript};window.__USER__=${userJson};</script>
<link rel="stylesheet" href="/static/styles.css">
</head>
<body>
<div id="app"></div>
<script src="/static/app.js" defer></script>
<script src="/static/voice.js" defer></script>
<script src="/static/social.js" defer></script>
<script src="/static/shop.js" defer></script>
</body>
</html>`, 404)
})

export default app
