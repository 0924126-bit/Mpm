-- Clean seed data (no bots)
-- Users are meant to register themselves
-- This is just for testing the schema
SELECT 1;
