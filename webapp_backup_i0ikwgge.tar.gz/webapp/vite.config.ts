import { defineConfig } from 'vite'
import pages from '@hono/vite-cloudflare-pages'
import { readFileSync, writeFileSync, existsSync } from 'fs'
import { resolve } from 'path'

// Post-build plugin to append Durable Object exports
function appendDOExports() {
  return {
    name: 'append-do-exports',
    closeBundle() {
      const workerPath = resolve(__dirname, 'dist/_worker.js')
      if (existsSync(workerPath)) {
        const content = readFileSync(workerPath, 'utf-8')
        if (!content.includes('ChatRoom')) {
          const appendCode = `
// === Durable Object: ChatRoom (appended by build) ===
import { DurableObject as DO } from 'cloudflare:workers';
class ChatRoom extends DO {
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/ws') {
      const upgradeHeader = request.headers.get('Upgrade');
      if (!upgradeHeader || upgradeHeader !== 'websocket') return new Response('Expected Upgrade: websocket', { status: 426 });
      const userId = url.searchParams.get('userId') || '';
      const username = url.searchParams.get('username') || '';
      const displayName = url.searchParams.get('displayName') || '';
      const avatarUrl = url.searchParams.get('avatarUrl') || '';
      const channel = url.searchParams.get('channel') || '';
      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      this.ctx.acceptWebSocket(server);
      server.serializeAttachment({ userId, username, displayName, avatarUrl, channel });
      const onlineCount = this._getUniqueUserCount();
      this._broadcast(JSON.stringify({ type: 'user_join', user_id: userId, username, display_name: displayName, online: onlineCount + 1 }), server);
      server.send(JSON.stringify({ type: 'connected', channel, online: onlineCount + 1 }));
      return new Response(null, { status: 101, webSocket: client });
    }
    return new Response('Not found', { status: 404 });
  }
  async webSocketMessage(ws, message) {
    if (typeof message !== 'string') return;
    try {
      const data = JSON.parse(message);
      const attachment = ws.deserializeAttachment();
      if (!attachment) return;
      const { userId, username, displayName, avatarUrl, channel } = attachment;
      const [type, id] = channel.split(':');
      if (data.type === 'chat' && data.content?.trim()) {
        const content = data.content.trim().substring(0, 2000);
        const clientMsgId = data.client_id || '';
        const msgId = crypto.randomUUID().replace(/-/g, '').substring(0, 16);
        const now = new Date().toISOString();
        this._broadcast(JSON.stringify({ type: 'chat', message: { id: msgId, sender_id: userId, content, created_at: now, sender_username: username, sender_display_name: displayName, sender_avatar_url: avatarUrl, client_id: clientMsgId } }));
        try {
          if (type === 'dm') {
            await this.env.DB.prepare('INSERT INTO messages (id, conversation_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run();
            this.env.DB.prepare("UPDATE conversations SET last_message_at = datetime('now') WHERE id = ?").bind(id).run();
            try {
              const conv = await this.env.DB.prepare('SELECT user1_id, user2_id FROM conversations WHERE id = ?').bind(id).first();
              if (conv) {
                const otherUserId = conv.user1_id === userId ? conv.user2_id : conv.user1_id;
                const isOnline = this._isUserOnline(otherUserId);
                if (!isOnline) {
                  const nid = crypto.randomUUID().replace(/-/g, '').substring(0, 16);
                  this.env.DB.prepare("INSERT INTO notifications (id, user_id, type, actor_id, target_id, target_type) VALUES (?, ?, 'dm', ?, ?, 'conversation')").bind(nid, otherUserId, userId, id).run();
                }
              }
            } catch {}
          } else if (type === 'crew') {
            await this.env.DB.prepare('INSERT INTO crew_messages (id, channel_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run();
          } else if (type === 'vr') {
            await this.env.DB.prepare('INSERT INTO voice_room_messages (id, room_id, sender_id, content) VALUES (?, ?, ?, ?)').bind(msgId, id, userId, content).run();
          }
        } catch (e) { console.error('DB persist error:', e); }
      } else if (data.type === 'typing') {
        this._broadcast(JSON.stringify({ type: 'typing', user_id: userId, username, display_name: displayName }), ws);
      } else if (data.type === 'stroke' && data.stroke_data) {
        const strokeId = crypto.randomUUID().replace(/-/g, '').substring(0, 16);
        this._broadcast(JSON.stringify({ type: 'stroke', stroke: { id: strokeId, user_id: userId, stroke_data: data.stroke_data, color: data.color || '#c8553d', width: data.width || 3, tool: data.tool || 'pen' } }));
        const [, roomId] = channel.split(':');
        this.env.DB.prepare('INSERT INTO whiteboard_strokes (id, room_id, user_id, stroke_data, color, width, tool) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(strokeId, roomId, userId, data.stroke_data, data.color || '#c8553d', data.width || 3, data.tool || 'pen').run();
      } else if (data.type === 'wb_clear') {
        this._broadcast(JSON.stringify({ type: 'wb_clear' }));
      } else if (data.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong', ts: Date.now() }));
      }
    } catch (e) { console.error('WS message error:', e); }
  }
  async webSocketClose(ws, code, reason, wasClean) {
    try {
      const att = ws.deserializeAttachment();
      if (att) this._broadcast(JSON.stringify({ type: 'user_leave', user_id: att.userId, username: att.username, online: this._getUniqueUserCount() - 1 }), ws);
    } catch {}
    ws.close(code, reason);
  }
  async webSocketError(ws, error) {
    try {
      const att = ws.deserializeAttachment();
      if (att) this._broadcast(JSON.stringify({ type: 'user_leave', user_id: att.userId, username: att.username, online: this._getUniqueUserCount() - 1 }), ws);
    } catch {}
    ws.close(1011, 'WebSocket error');
  }
  _broadcast(message, excludeWs) {
    for (const socket of this.ctx.getWebSockets()) {
      if (socket === excludeWs) continue;
      try { socket.send(message); } catch {}
    }
  }
  _isUserOnline(userId) {
    for (const socket of this.ctx.getWebSockets()) {
      try { const att = socket.deserializeAttachment(); if (att && att.userId === userId) return true; } catch {}
    }
    return false;
  }
  _getUniqueUserCount() {
    const userIds = new Set();
    for (const socket of this.ctx.getWebSockets()) {
      try { const att = socket.deserializeAttachment(); if (att) userIds.add(att.userId); } catch {}
    }
    return userIds.size;
  }
}
export { ChatRoom };
`
          writeFileSync(workerPath, content + appendCode)
          console.log('[DO] ChatRoom class appended to _worker.js')
        }
      }
    }
  }
}

export default defineConfig({
  plugins: [pages({ entry: 'src/index.tsx' }), appendDOExports()],
  build: {
    outDir: 'dist',
    rollupOptions: {
      external: ['cloudflare:workers']
    }
  }
})
