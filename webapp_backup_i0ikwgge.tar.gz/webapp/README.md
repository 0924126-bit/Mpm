# さとっち (Satocchi) - みんなの居場所

## Project Overview
- **Name**: さとっち (Satocchi)
- **Goal**: Premium social platform with voice rooms, crews, DM, casino - designed for community building
- **Theme**: "A place for everyone" - editorial, sophisticated, minimalist design

## URLs
- **Production**: https://smog.satocchi-app.workers.dev
- **Sandbox**: https://3000-isdh14arlcxk2uvw8zdw7-cc2fbc16.sandbox.novita.ai
- **Platform**: Cloudflare Workers (Hono + D1 + Durable Objects)

## v18 Changes
- **SID Hidden**: Permanent stable ID no longer exposed to users in UI or search results (still used internally for mentions)
- **Scroll-Aware Header**: Home feed header/nav auto-hides on scroll down, reveals on scroll up for immersive reading
- **Search Results Page**: Pressing Enter on search opens a dedicated full search page with users and posts
- **Pull-to-Refresh Redesign**: Ring spinner animation, works on all pages (home, voice, notifications), prevents duplicate posts
- **iOS Haptics**: Safari vibration via hidden `<input type="checkbox" switch>` trick (web-haptics approach)
- **Floating Voice Bubble**: When leaving voice room page while in call, a draggable floating bubble appears for quick return
- **Voice Room Background**: Navigate app freely while in voice call, bubble persists
- **Improved Feed Algorithm**: Boosts for images (+5), quotes (+3), text styles (+2), more randomization (+8)
- **Custom Overscroll**: Disabled default browser overscroll, custom pull-to-refresh design
- **VisualViewport Keyboard Fix**: Chat inputs pinned just above keyboard on mobile
- **Enhanced Context Menu**: Glass blur effect, better positioning
- **Better Animations**: glow-pulse, scale-out, shake, slide-down-spring keyframes
- **Post Interactions**: Active state scale effects for better tactile feedback
- **Service Worker v10**: Redesigned offline page with WiFi icon, improved caching
- **Notch-Safe Areas**: Better safe-area-inset handling throughout app
- **Bottom Nav Slide**: Hides on scroll down (nav-hidden class), reveals on scroll up

## Features

### Core
- **Authentication**: Register, login, LINE login (channel 2009621009), session (30-day cookie)
- **Permanent SID**: Immutable stable ID for mention tracking across username changes (hidden from users)
- **Follow System**: Follow/unfollow, follower/following lists
- **Posts**: Text (500 char, 4-line collapse), images, text colors, likes, replies, polls, quotes (コレミテ)
- **Timeline**: おすすめ (algorithmic), フォロー中, 新着 tabs with infinite scroll
- **Search**: Full-text search for users and posts (inline results + dedicated page)
- **Voice Rooms**: WebRTC P2P audio (up to 20 users), tags, whiteboard, music player, floating bubble
- **Crew (Discord-style)**: Text/voice channels, roles, real-time WebSocket chat
- **DM**: WebSocket-powered 1-on-1 messaging with typing indicators
- **Casino**: Blackjack, Roulette, Crash, Sic Bo, Craps, Two-Up, Money Wheel
- **Coins**: Economy system with tips, shop (name colors, badges, backgrounds)
- **Admin**: Dashboard, user management, announcements, spam words, IP monitoring, site images

### SPA Features
- **Scroll-Aware UI**: Header/nav auto-hide on scroll for immersive reading
- **Floating Voice Bubble**: Draggable always-on-top bubble when voice room is minimized
- **IndexedDB Cache**: Near-instant reload from browser storage
- **Pull-to-Refresh**: Ring spinner, works on multiple pages, no duplicates
- **VisualViewport**: Keyboard-aware input pinning above keyboard
- **Custom Context Menu**: Glass-blur action sheets on long-press
- **iOS/Android Haptics**: Vibration via Safari checkbox trick + navigator.vibrate
- **Safe Area**: Full notch/cutout support with env() variables
- **Offline Screen**: Styled offline page via Service Worker with WiFi icon
- **PWA**: Installable, maskable icons, offline-capable, cache-first static assets

## Data Architecture
- **Database**: Cloudflare D1 (SQLite)
- **Real-time**: WebSocket via Durable Objects (fallback: in-memory hub)
- **Auth**: SHA-256 hashed passwords, UUID session cookies
- **Key Tables**: users (with sid), posts, likes, follows, voice_rooms, crews, conversations, messages, casino_bets, hashtags, mentions, pinned_posts

## Tech Stack
- **Backend**: Hono 4 on Cloudflare Workers
- **Frontend**: Vanilla JS SPA (no framework, no Tailwind CDN)
- **Database**: Cloudflare D1
- **Real-time**: Durable Objects + WebSocket
- **Styling**: Custom CSS Design System v8
- **Fonts**: DM Sans + Cormorant Garamond + Noto Sans JP
- **Icons**: FontAwesome 6.5

## Recommended Next Steps
1. Cloudflare Realtime for ultra-fast chat latency (replace WS fallback)
2. Incoming call UI with Web Push (scenario: "incoming-call")
3. Admin-configurable PWA icon/splash images with cache-busting
4. Individual 1:1 calls via Realtime
5. Voice room per-room custom icons
6. Web Push notifications for DM/mentions

## Deployment
- **Platform**: Cloudflare Workers
- **Status**: ✅ Active
- **Version**: v18
- **Last Updated**: 2026-03-29
