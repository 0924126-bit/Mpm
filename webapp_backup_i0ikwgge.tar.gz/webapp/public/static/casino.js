// =============================================
// Satocchi Casino Engine v4.0
// Realistic probabilities, smooth Canvas animations
// Games: Blackjack, Roulette, Crash, Sic Bo, Craps, Two-Up, Money Wheel
// =============================================
'use strict';

const CS = { animId: null, particles: [], sparkles: [], canvas: null, ctx: null, game: null, coins: 0, bet: 10, running: false };
const GOLD = '#d4a017', GOLD2 = '#f5c842', DARK = '#0a0a14', DARK2 = '#12121e', RED = '#e63946', GREEN = '#2ec486', PURPLE = '#8b5cf6', CYAN = '#06b6d4';

// ===== PARTICLE SYSTEM (enhanced) =====
class Particle {
  constructor(x, y, color, opts = {}) {
    this.x = x; this.y = y; this.color = color;
    const angle = opts.angle !== undefined ? opts.angle : Math.random() * Math.PI * 2;
    const speed = opts.speed || (2 + Math.random() * 4);
    this.vx = Math.cos(angle) * speed * (0.5 + Math.random());
    this.vy = Math.sin(angle) * speed * (0.5 + Math.random()) - (opts.upward || 0);
    this.life = 1; this.decay = 0.008 + Math.random() * 0.015;
    this.size = opts.size || (1.5 + Math.random() * 2.5);
    this.gravity = opts.gravity || 0.03;
    this.type = opts.type || 'circle';
    this.rotation = Math.random() * Math.PI * 2;
    this.rotSpeed = (Math.random() - 0.5) * 0.1;
  }
  update() { this.x += this.vx; this.y += this.vy; this.vy += this.gravity; this.life -= this.decay; this.vx *= 0.985; this.rotation += this.rotSpeed; }
  draw(ctx) {
    if (this.life <= 0) return;
    ctx.save();
    ctx.globalAlpha = Math.min(1, this.life * 1.5);
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    if (this.type === 'star') {
      ctx.fillStyle = this.color;
      const s = this.size * 2;
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const a = (i * 4 * Math.PI / 5) - Math.PI / 2;
        const r = i === 0 ? s : s * 0.4;
        ctx[i === 0 ? 'moveTo' : 'lineTo'](Math.cos(a) * s, Math.sin(a) * s);
        const a2 = a + 2 * Math.PI / 5;
        ctx.lineTo(Math.cos(a2) * s * 0.4, Math.sin(a2) * s * 0.4);
      }
      ctx.closePath(); ctx.fill();
    } else if (this.type === 'confetti') {
      ctx.fillStyle = this.color;
      ctx.fillRect(-this.size, -this.size * 0.4, this.size * 2, this.size * 0.8);
    } else {
      ctx.beginPath(); ctx.arc(0, 0, this.size * this.life, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      // Glow effect
      ctx.shadowColor = this.color;
      ctx.shadowBlur = this.size * 3;
      ctx.fill();
    }
    ctx.restore();
  }
}

function emitParticles(x, y, count, color, opts) {
  const colors = Array.isArray(color) ? color : [color];
  for (let i = 0; i < count; i++) CS.particles.push(new Particle(x, y, colors[i % colors.length], opts));
}

function emitWinExplosion(x, y) {
  // Phase 1: Central burst
  emitParticles(x, y, 50, [GOLD, GOLD2, '#fff', CYAN, PURPLE], { speed: 10, upward: 3, size: 3 });
  // Phase 2: Confetti rain
  setTimeout(() => emitParticles(x, y, 30, [GOLD, '#ff6b6b', '#4ecdc4', '#ffe66d', '#8b5cf6'], { speed: 8, upward: 6, size: 2, type: 'confetti' }), 100);
  // Phase 3: Stars
  setTimeout(() => emitParticles(x, y, 15, [GOLD, GOLD2, '#fff'], { speed: 5, upward: 2, size: 2, type: 'star' }), 200);
  // Shockwave ring
  CS._shockwave = { x, y, radius: 0, maxRadius: 150, alpha: 0.6, color: GOLD };
}

function emitCoinBurst(x, y) {
  emitParticles(x, y, 30, [GOLD, GOLD2, '#ffd700', '#ffec8b'], { speed: 6, upward: 5, size: 2.5 });
}

// ===== SPARKLE BACKGROUND =====
class Sparkle {
  constructor(w, h) {
    this.x = Math.random() * w; this.y = Math.random() * h;
    this.size = Math.random() * 1.5 + 0.3;
    this.speed = Math.random() * 0.2 + 0.05;
    this.opacity = Math.random() * 0.3 + 0.05;
    this.phase = Math.random() * Math.PI * 2;
    this.wobble = Math.random() * 0.3;
  }
  update(t) {
    this.opacity = 0.05 + Math.sin(t * 0.001 + this.phase) * 0.15;
    this.y -= this.speed;
    this.x += Math.sin(t * 0.0005 + this.phase) * this.wobble;
    if (this.y < -5) { this.y = CS.canvas ? CS.canvas.height / (window.devicePixelRatio || 1) + 5 : 800; this.x = Math.random() * (CS.canvas ? CS.canvas.width / (window.devicePixelRatio || 1) : 400); }
  }
  draw(ctx) { ctx.globalAlpha = Math.max(0, this.opacity); ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; }
}

// ===== CANVAS INIT =====
function initCanvas(el) {
  const container = document.createElement('div');
  container.style.cssText = 'position:relative;width:100%;height:100%;min-height:100dvh;background:linear-gradient(180deg,#0a0a14 0%,#0f0f1f 50%,#0a0a14 100%)';
  const canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:1';
  container.appendChild(canvas);
  const ui = document.createElement('div');
  ui.id = 'casino-ui';
  ui.style.cssText = 'position:relative;z-index:2;padding:16px;padding-bottom:100px';
  container.appendChild(ui);
  el.appendChild(container);
  CS.canvas = canvas; CS._shockwave = null;
  const resize = () => { const dpr = window.devicePixelRatio || 1; canvas.width = container.offsetWidth * dpr; canvas.height = container.offsetHeight * dpr; CS.ctx = canvas.getContext('2d'); CS.ctx.scale(dpr, dpr); canvas.style.width = container.offsetWidth + 'px'; canvas.style.height = container.offsetHeight + 'px'; };
  resize();
  window._csResize = resize; window.addEventListener('resize', resize);
  CS.sparkles = [];
  for (let i = 0; i < 50; i++) CS.sparkles.push(new Sparkle(container.offsetWidth, container.offsetHeight));
  return ui;
}

function animLoop(t) {
  if (!CS.canvas || !CS.ctx) return;
  const ctx = CS.ctx;
  const w = CS.canvas.width / (window.devicePixelRatio || 1);
  const h = CS.canvas.height / (window.devicePixelRatio || 1);
  ctx.clearRect(0, 0, w, h);
  // Sparkle bg
  CS.sparkles.forEach(s => { s.update(t); s.draw(ctx); });
  // Shockwave ring
  if (CS._shockwave) {
    const sw = CS._shockwave;
    sw.radius += 4;
    sw.alpha -= 0.015;
    if (sw.alpha > 0) {
      ctx.beginPath(); ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.strokeStyle = sw.color; ctx.globalAlpha = sw.alpha; ctx.lineWidth = 3;
      ctx.stroke(); ctx.globalAlpha = 1;
    } else { CS._shockwave = null; }
  }
  // Particles
  CS.particles = CS.particles.filter(p => p.life > 0);
  CS.particles.forEach(p => { p.update(); p.draw(ctx); });
  CS.animId = requestAnimationFrame(animLoop);
}

function csStopAnimation() {
  if (CS.animId) { cancelAnimationFrame(CS.animId); CS.animId = null; }
  if (window._csResize) window.removeEventListener('resize', window._csResize);
  CS.particles = []; CS.sparkles = []; CS._shockwave = null;
}

// ===== UTILITY =====
function csBtn(text, onclick, style = '') {
  return `<button onclick="${onclick}" style="padding:12px 24px;border-radius:12px;font-weight:700;font-size:14px;border:none;cursor:pointer;transition:all 0.2s ease;${style}" onmousedown="this.style.transform='scale(0.95)'" onmouseup="this.style.transform=''" ontouchstart="this.style.transform='scale(0.95)'" ontouchend="this.style.transform=''">${text}</button>`;
}

function csCoinDisplay() {
  return `<div style="display:flex;align-items:center;gap:6px;background:rgba(212,160,23,0.15);border:1px solid rgba(212,160,23,0.3);border-radius:20px;padding:6px 14px;font-size:13px;font-weight:700;color:${GOLD}"><i class="fas fa-coins" style="font-size:11px"></i><span id="cs-coins">${CS.coins}</span></div>`;
}

function csBetSelector() {
  const bets = [5, 10, 25, 50, 100];
  return `<div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap">${bets.map(b => `<button onclick="csSetBet(${b})" class="cs-bet-btn" data-bet="${b}" style="padding:8px 16px;border-radius:20px;font-size:12px;font-weight:700;border:1px solid ${CS.bet === b ? GOLD : 'rgba(255,255,255,0.1)'};background:${CS.bet === b ? 'rgba(212,160,23,0.2)' : 'rgba(255,255,255,0.03)'};color:${CS.bet === b ? GOLD : 'rgba(255,255,255,0.5)'};cursor:pointer;transition:all 0.3s">${b}</button>`).join('')}</div>`;
}

function csSetBet(amount) {
  CS.bet = amount;
  document.querySelectorAll('.cs-bet-btn').forEach(btn => {
    const b = parseInt(btn.dataset.bet);
    btn.style.border = `1px solid ${b === amount ? GOLD : 'rgba(255,255,255,0.1)'}`;
    btn.style.background = b === amount ? 'rgba(212,160,23,0.2)' : 'rgba(255,255,255,0.03)';
    btn.style.color = b === amount ? GOLD : 'rgba(255,255,255,0.5)';
  });
}

async function csPlaceBet(game, result, winAmount) {
  const res = await fetch('/api/casino/bet', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
    body: JSON.stringify({ game, bet_amount: CS.bet, result, win_amount: winAmount })
  }).then(r => r.json());
  if (res.success) {
    CS.coins = res.new_balance;
    const el = document.getElementById('cs-coins');
    if (el) { el.textContent = CS.coins; el.style.animation = 'none'; el.offsetHeight; el.style.animation = 'coin-pulse 0.4s ease'; }
  }
  return res;
}

async function loadCoins() {
  const res = await fetch('/api/coins', { credentials: 'same-origin' }).then(r => r.json());
  CS.coins = res.coins || 0;
}

// ===== ANIMATED NUMBER DISPLAY =====
function animateNumber(el, from, to, duration = 600) {
  const start = performance.now();
  const diff = to - from;
  function tick(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    el.textContent = Math.round(from + diff * eased);
    if (progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

// ===== CASINO LOBBY =====
function pageCasino(el) {
  el.innerHTML = '';
  el.className = 'page-container';
  const ui = initCanvas(el);
  loadCoins().then(() => renderLobby(ui));
  CS.animId = requestAnimationFrame(animLoop);
}

function renderLobby(ui) {
  const lang = window.__LANG__ || 'ja';
  const ja = lang === 'ja';
  const games = [
    { id: 'blackjack', icon: 'fa-cards', name: ja ? 'ブラックジャック' : 'Blackjack', desc: ja ? '21に近づけ!' : 'Get close to 21!', color: GREEN, gradient: 'linear-gradient(135deg,#059669,#10b981)' },
    { id: 'roulette', icon: 'fa-circle-dot', name: ja ? 'ルーレット' : 'Roulette', desc: ja ? '運命の回転' : 'Spin of fate!', color: RED, gradient: 'linear-gradient(135deg,#dc2626,#ef4444)' },
    { id: 'crash', icon: 'fa-rocket', name: ja ? 'クラッシュ' : 'Crash', desc: ja ? '限界まで待て!' : 'Hold your nerve!', color: PURPLE, gradient: 'linear-gradient(135deg,#7c3aed,#a855f7)' },
    { id: 'sicbo', icon: 'fa-dice', name: ja ? 'シックボー' : 'Sic Bo', desc: ja ? 'サイコロ勝負' : 'Dice showdown!', color: CYAN, gradient: 'linear-gradient(135deg,#0891b2,#06b6d4)' },
    { id: 'craps', icon: 'fa-dice-five', name: ja ? 'クラップス' : 'Craps', desc: ja ? '7を出せ!' : 'Roll the 7!', color: '#f59e0b', gradient: 'linear-gradient(135deg,#d97706,#f59e0b)' },
    { id: 'twoup', icon: 'fa-coins', name: ja ? 'ツーアップ' : 'Two-Up', desc: ja ? 'コイン投げ' : 'Flip coins!', color: '#ec4899', gradient: 'linear-gradient(135deg,#db2777,#ec4899)' },
    { id: 'wheel', icon: 'fa-dharmachakra', name: ja ? 'マネーホイール' : 'Money Wheel', desc: ja ? '大当たり!' : 'Big win!', color: GOLD, gradient: `linear-gradient(135deg,#b8860b,${GOLD})` },
  ];

  ui.innerHTML = `
    <div style="text-align:center;margin-bottom:24px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <button onclick="navigate('/')" style="width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px"><i class="fas fa-arrow-left"></i></button>
        <div style="font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:700;color:${GOLD};letter-spacing:-0.02em;text-shadow:0 0 30px rgba(212,160,23,0.3)">
          <i class="fas fa-crown" style="margin-right:8px;font-size:22px"></i>CASINO
        </div>
        ${csCoinDisplay()}
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px">
      ${games.map((g,i) => `
        <div onclick="csOpenGame('${g.id}')" style="background:${g.gradient};border-radius:16px;padding:20px 16px;cursor:pointer;transition:all 0.3s ease;position:relative;overflow:hidden;min-height:110px;opacity:0;animation:casino-card-in 0.4s ease ${i*0.06}s forwards" ontouchstart="this.style.transform='scale(0.96)'" ontouchend="this.style.transform=''">
          <div style="position:absolute;top:-15px;right:-15px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,0.08)"></div>
          <div style="position:absolute;bottom:-20px;left:-10px;width:50px;height:50px;border-radius:50%;background:rgba(255,255,255,0.05)"></div>
          <i class="fas ${g.icon}" style="font-size:26px;color:rgba(255,255,255,0.9);margin-bottom:10px;display:block;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.3))"></i>
          <div style="font-weight:700;font-size:14px;color:white;margin-bottom:3px;text-shadow:0 1px 2px rgba(0,0,0,0.2)">${g.name}</div>
          <div style="font-size:11px;color:rgba(255,255,255,0.7)">${g.desc}</div>
        </div>
      `).join('')}
    </div>
    <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:10px"><i class="fas fa-trophy" style="margin-right:6px;color:${GOLD}"></i>${ja ? 'リーダーボード' : 'Leaderboard'}</div>
      <div id="cs-leaderboard" style="font-size:13px;color:rgba(255,255,255,0.5)"><div style="text-align:center;padding:12px"><div class="spinner" style="width:16px;height:16px;border-top-color:${GOLD};margin:0 auto"></div></div></div>
    </div>
    <div class="mobile-nav-spacer"></div>`;
  
  loadLeaderboard();
}

async function loadLeaderboard() {
  const res = await fetch('/api/casino/leaderboard', { credentials: 'same-origin' }).then(r => r.json());
  const el = document.getElementById('cs-leaderboard');
  if (!el) return;
  const lb = res.leaderboard || [];
  if (lb.length === 0) { el.innerHTML = `<div style="text-align:center;padding:8px;color:rgba(255,255,255,0.3)">${window.__LANG__ === 'ja' ? 'まだ記録がありません' : 'No records yet'}</div>`; return; }
  el.innerHTML = lb.slice(0, 8).map((u, i) => `
    <div style="display:flex;align-items:center;gap:10px;padding:8px 4px;${i < lb.length - 1 ? 'border-bottom:1px solid rgba(255,255,255,0.04)' : ''}">
      <span style="width:22px;font-weight:700;font-size:12px;color:${i < 3 ? GOLD : 'rgba(255,255,255,0.3)'}">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i+1)}</span>
      <span style="flex:1;font-weight:600;color:rgba(255,255,255,0.8);font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${u.display_name || u.username}</span>
      <span style="font-weight:700;font-size:12px;color:${(u.net_profit || 0) >= 0 ? GREEN : RED}">${(u.net_profit || 0) >= 0 ? '+' : ''}${u.net_profit || 0}</span>
    </div>
  `).join('');
}

function csOpenGame(gameId) {
  CS.game = gameId;
  const ui = document.getElementById('casino-ui');
  if (!ui) return;
  switch (gameId) {
    case 'blackjack': initBlackjack(ui); break;
    case 'roulette': initRoulette(ui); break;
    case 'crash': initCrash(ui); break;
    case 'sicbo': initSicBo(ui); break;
    case 'craps': initCraps(ui); break;
    case 'twoup': initTwoUp(ui); break;
    case 'wheel': initWheel(ui); break;
  }
}

function csBack() {
  CS.game = null; CS.running = false;
  const el = document.getElementById('page');
  if (el) { el.innerHTML = ''; pageCasino(el); }
}

// ===== BLACKJACK (realistic: standard 6-deck shoe, dealer stands on soft 17) =====
const SUITS = ['♠', '♥', '♦', '♣'], RANKS = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
function newShoe(decks = 6) {
  const shoe = [];
  for (let d = 0; d < decks; d++) SUITS.forEach(s => RANKS.forEach(r => shoe.push({ suit: s, rank: r })));
  // Fisher-Yates shuffle
  for (let i = shoe.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [shoe[i], shoe[j]] = [shoe[j], shoe[i]]; }
  return shoe;
}
function cardVal(card) { if (card.rank === 'A') return 11; if (['K','Q','J'].includes(card.rank)) return 10; return parseInt(card.rank); }
function handVal(hand) {
  let v = 0, aces = 0;
  hand.forEach(c => { v += cardVal(c); if (c.rank === 'A') aces++; });
  while (v > 21 && aces > 0) { v -= 10; aces--; }
  return v;
}
function isSoft(hand) {
  let v = 0, aces = 0;
  hand.forEach(c => { v += cardVal(c); if (c.rank === 'A') aces++; });
  while (v > 21 && aces > 0) { v -= 10; aces--; }
  return aces > 0; // still counting an ace as 11
}
function renderCard(c, hidden = false, delay = 0) {
  if (hidden) return `<div style="width:60px;height:84px;border-radius:8px;background:linear-gradient(135deg,#1e40af,#3b82f6);border:2px solid rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;color:white;font-size:18px;box-shadow:0 4px 12px rgba(0,0,0,0.4);animation:card-deal 0.4s ease-out ${delay}s both"><i class="fas fa-question"></i></div>`;
  const isRed = c.suit === '♥' || c.suit === '♦';
  return `<div style="width:60px;height:84px;border-radius:8px;background:linear-gradient(135deg,#fafaf8,#f0f0e8);border:1px solid rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:center;justify-content:center;color:${isRed ? '#dc2626' : '#1a1a2e'};font-weight:700;box-shadow:0 4px 12px rgba(0,0,0,0.3);animation:card-deal 0.4s ease-out ${delay}s both"><div style="font-size:16px;line-height:1">${c.rank}</div><div style="font-size:20px;line-height:1">${c.suit}</div></div>`;
}

let bjDeck, bjPlayer, bjDealer, bjState;
function initBlackjack(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:${GREEN}"><i class="fas fa-cards" style="margin-right:6px"></i>${ja ? 'ブラックジャック' : 'Blackjack'}</div>
      ${csCoinDisplay()}
    </div>
    <div id="bj-area" style="min-height:300px">
      <div style="text-align:center;padding:16px;margin-bottom:16px">
        <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:12px">${ja ? 'ベット額' : 'BET AMOUNT'}</div>
        ${csBetSelector()}
      </div>
      <div style="text-align:center">
        ${csBtn(`<i class="fas fa-play" style="margin-right:6px"></i>${ja ? 'ディール' : 'Deal'}`, 'bjDeal()', `background:${GREEN};color:white;font-size:16px;padding:14px 40px`)}
      </div>
    </div>
    <div class="mobile-nav-spacer"></div>`;
}

function bjDeal() {
  if (CS.bet > CS.coins) { alert(window.__LANG__ === 'ja' ? 'コイン不足' : 'Not enough coins'); return; }
  bjDeck = newShoe(6); // Realistic 6-deck shoe
  bjPlayer = [bjDeck.pop(), bjDeck.pop()]; bjDealer = [bjDeck.pop(), bjDeck.pop()]; bjState = 'playing';
  renderBJ(true);
  // Natural blackjack check
  if (handVal(bjPlayer) === 21) {
    bjState = 'standing';
    setTimeout(() => bjStand(), 500);
  }
}

function renderBJ(dealerHidden) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  const pVal = handVal(bjPlayer), dVal = dealerHidden ? '?' : handVal(bjDealer);
  const area = document.getElementById('bj-area'); if (!area) return;
  area.innerHTML = `
    <div style="text-align:center;margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:8px">${ja ? 'ディーラー' : 'DEALER'} <span style="color:${GOLD}">${dVal}</span></div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">${bjDealer.map((c, i) => renderCard(c, dealerHidden && i > 0, i * 0.15)).join('')}</div>
    </div>
    <div style="width:60%;height:1px;background:linear-gradient(90deg,transparent,rgba(212,160,23,0.3),transparent);margin:16px auto"></div>
    <div style="text-align:center;margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:8px">${ja ? 'あなた' : 'YOU'} <span style="color:${pVal > 21 ? RED : pVal === 21 ? GREEN : 'white'};font-size:16px;font-weight:800">${pVal}</span></div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">${bjPlayer.map((c,i) => renderCard(c, false, i * 0.15)).join('')}</div>
    </div>
    ${bjState === 'playing' ? `<div style="display:flex;gap:10px;justify-content:center;margin-top:16px">
      ${csBtn(`<i class="fas fa-plus" style="margin-right:4px"></i>${ja ? 'ヒット' : 'Hit'}`, 'bjHit()', `background:${GREEN};color:white`)}
      ${csBtn(`<i class="fas fa-hand" style="margin-right:4px"></i>${ja ? 'スタンド' : 'Stand'}`, 'bjStand()', 'background:rgba(255,255,255,0.1);color:rgba(255,255,255,0.8);border:1px solid rgba(255,255,255,0.15)')}
      ${bjPlayer.length === 2 && CS.coins >= CS.bet * 2 ? csBtn(`<i class="fas fa-arrow-down" style="margin-right:4px"></i>${ja ? 'ダブル' : 'Double'}`, 'bjDouble()', 'background:rgba(255,215,0,0.15);color:' + GOLD + ';border:1px solid rgba(255,215,0,0.3)') : ''}
    </div>` : ''}
    <div id="bj-result" style="text-align:center;margin-top:16px"></div>`;
}

function bjHit() {
  if (bjState !== 'playing') return;
  bjPlayer.push(bjDeck.pop());
  const pVal = handVal(bjPlayer);
  if (pVal > 21) { bjState = 'bust'; renderBJ(false); bjResult('lose', `BUST! -${CS.bet}`); return; }
  if (pVal === 21) bjStand();
  else renderBJ(true);
}

function bjDouble() {
  if (bjState !== 'playing' || bjPlayer.length !== 2) return;
  CS.bet *= 2; // Double the bet for this hand
  bjPlayer.push(bjDeck.pop());
  const pVal = handVal(bjPlayer);
  if (pVal > 21) { bjState = 'bust'; renderBJ(false); bjResult('lose', `BUST! -${CS.bet}`); CS.bet /= 2; return; }
  bjStand();
  CS.bet /= 2; // Reset bet
}

function bjStand() {
  bjState = 'standing';
  // Dealer must hit on soft 17 (realistic casino rule)
  while (handVal(bjDealer) < 17 || (handVal(bjDealer) === 17 && isSoft(bjDealer))) bjDealer.push(bjDeck.pop());
  renderBJ(false);
  const pVal = handVal(bjPlayer), dVal = handVal(bjDealer);
  const isNatural = bjPlayer.length === 2 && pVal === 21;
  if (dVal > 21) bjResult('win', `${window.__LANG__ === 'ja' ? 'ディーラーバスト!' : 'Dealer bust!'} +${CS.bet}`);
  else if (pVal > dVal) bjResult('win', isNatural ? `BLACKJACK! +${Math.floor(CS.bet * 1.5)}` : `WIN! +${CS.bet}`);
  else if (pVal < dVal) bjResult('lose', `LOSE! -${CS.bet}`);
  else bjResult('push', `PUSH! ${window.__LANG__ === 'ja' ? '引き分け' : 'Tie'}`);
}

async function bjResult(outcome, msg) {
  const isWin = outcome === 'win';
  const isPush = outcome === 'push';
  const isNatural = bjPlayer.length === 2 && handVal(bjPlayer) === 21 && isWin;
  const winAmount = isWin ? (isNatural ? Math.floor(CS.bet * 2.5) : CS.bet * 2) : isPush ? CS.bet : 0;
  await csPlaceBet('blackjack', outcome, winAmount);
  const resEl = document.getElementById('bj-result'); if (!resEl) return;
  if (isWin && CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
  haptic(isWin ? 'success' : 'error');
  resEl.innerHTML = `
    <div style="font-size:22px;font-weight:800;color:${isWin ? GREEN : isPush ? GOLD : RED};margin-bottom:12px;animation:result-pop 0.5s ease">${msg}</div>
    ${csBtn(`<i class="fas fa-redo" style="margin-right:6px"></i>${window.__LANG__ === 'ja' ? 'もう一度' : 'Again'}`, 'bjDeal()', `background:${GREEN};color:white`)}`;
}

// ===== ROULETTE (realistic: European single-zero, proper payouts) =====
let rlBetType = 'red', rlSpinning = false;
const RL_NUMS = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const RL_REDS = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
// European roulette: 37 numbers (0-36), house edge 2.7%

function initRoulette(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:${RED}"><i class="fas fa-circle-dot" style="margin-right:6px"></i>${ja ? 'ルーレット' : 'Roulette'}</div>
      ${csCoinDisplay()}
    </div>
    <div id="rl-wheel" style="margin:20px auto;width:220px;height:220px;border-radius:50%;background:conic-gradient(${generateRouletteGrad()});border:6px solid ${GOLD};box-shadow:0 0 40px rgba(212,160,23,0.3),inset 0 0 20px rgba(0,0,0,0.4);position:relative;transition:transform 5s cubic-bezier(0.15,0.6,0.1,1)">
      <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:${DARK};border:3px solid ${GOLD};display:flex;align-items:center;justify-content:center;font-size:13px;color:${GOLD};font-weight:800;z-index:2" id="rl-number">?</div>
    </div>
    <div style="text-align:center;margin-bottom:4px"><div style="width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-top:16px solid ${GOLD};margin:0 auto;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.5))"></div></div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:10px">${ja ? 'ベット' : 'BET ON'}</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:12px">
        ${['red','black','odd','even','1-18','19-36'].map(t => `<button onclick="rlBetType='${t}';document.querySelectorAll('.rl-type-btn').forEach(b=>b.style.opacity='0.4');this.style.opacity='1'" class="rl-type-btn" style="padding:8px 14px;border-radius:10px;font-size:12px;font-weight:700;border:1px solid ${t==='red'?RED:t==='black'?'#444':'rgba(255,255,255,0.15)'};background:${t==='red'?'rgba(230,57,70,0.2)':t==='black'?'rgba(68,68,68,0.3)':'rgba(255,255,255,0.05)'};color:${t==='red'?RED:t==='black'?'#aaa':'rgba(255,255,255,0.7)'};cursor:pointer;opacity:${t===rlBetType?'1':'0.4'};transition:opacity 0.2s">${t==='red'?(ja?'赤':'Red'):t==='black'?(ja?'黒':'Black'):t==='odd'?(ja?'奇数':'Odd'):t==='even'?(ja?'偶数':'Even'):t}</button>`).join('')}
      </div>
      ${csBetSelector()}
    </div>
    <div style="text-align:center">${csBtn(`<i class="fas fa-circle-notch" style="margin-right:6px"></i>${ja ? 'スピン' : 'SPIN'}`, 'rlSpin()', `background:${RED};color:white;font-size:16px;padding:14px 40px`)}</div>
    <div id="rl-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
}

function generateRouletteGrad() {
  const colors = [];
  const step = 360 / RL_NUMS.length;
  RL_NUMS.forEach((n, i) => { const c = n === 0 ? GREEN : RL_REDS.includes(n) ? RED : '#1a1a2e'; colors.push(`${c} ${i * step}deg ${(i + 1) * step}deg`); });
  return colors.join(',');
}

function rlSpin() {
  if (rlSpinning || CS.bet > CS.coins) return;
  rlSpinning = true;
  haptic('medium');
  const wheel = document.getElementById('rl-wheel'); if (!wheel) return;
  const numEl = document.getElementById('rl-number');
  // Truly random result from all 37 numbers (0-36)
  const result = RL_NUMS[Math.floor(Math.random() * RL_NUMS.length)];
  const idx = RL_NUMS.indexOf(result);
  const step = 360 / RL_NUMS.length;
  const targetAngle = 360 * 7 + (360 - idx * step - step / 2);
  wheel.style.transform = `rotate(${targetAngle}deg)`;
  if (numEl) numEl.textContent = '...';
  setTimeout(async () => {
    rlSpinning = false;
    if (numEl) numEl.textContent = result;
    const isRed = RL_REDS.includes(result);
    let win = false;
    if (rlBetType === 'red' && isRed) win = true;
    else if (rlBetType === 'black' && !isRed && result !== 0) win = true;
    else if (rlBetType === 'odd' && result % 2 === 1 && result !== 0) win = true;
    else if (rlBetType === 'even' && result % 2 === 0 && result !== 0) win = true;
    else if (rlBetType === '1-18' && result >= 1 && result <= 18) win = true;
    else if (rlBetType === '19-36' && result >= 19 && result <= 36) win = true;
    const winAmount = win ? CS.bet * 2 : 0;
    await csPlaceBet('roulette', `${result}(${isRed ? 'red' : result === 0 ? 'green' : 'black'})`, winAmount);
    if (win && CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 150);
    haptic(win ? 'success' : 'error');
    const resEl = document.getElementById('rl-result');
    if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${win ? GREEN : RED};animation:result-pop 0.5s ease">${win ? `WIN! +${CS.bet}` : `${result} - LOSE`}</div>`;
    setTimeout(() => { wheel.style.transition = 'none'; wheel.style.transform = 'rotate(0deg)'; setTimeout(() => { wheel.style.transition = 'transform 5s cubic-bezier(0.15,0.6,0.1,1)'; }, 50); }, 2000);
  }, 5300);
}

// ===== CRASH (realistic: house edge ~3%, exponential distribution) =====
let crashMultiplier = 1, crashTarget = 0, crashTimer = null, crashCashedOut = false;
function initCrash(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:${PURPLE}"><i class="fas fa-rocket" style="margin-right:6px"></i>${ja ? 'クラッシュ' : 'Crash'}</div>
      ${csCoinDisplay()}
    </div>
    <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:16px;padding:30px;text-align:center;margin-bottom:20px;position:relative;overflow:hidden">
      <canvas id="crash-graph" width="300" height="120" style="width:100%;height:120px;margin-bottom:10px;border-radius:8px"></canvas>
      <div id="crash-multi" style="font-size:52px;font-weight:800;color:${PURPLE};position:relative;z-index:1;font-family:monospace;text-shadow:0 0 30px rgba(139,92,246,0.4)">1.00x</div>
      <div id="crash-status" style="font-size:13px;color:rgba(255,255,255,0.4);margin-top:8px;position:relative;z-index:1">${ja ? '開始を待っています...' : 'Waiting...'}</div>
    </div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:10px">${ja ? 'ベット額' : 'BET AMOUNT'}</div>
      ${csBetSelector()}
    </div>
    <div style="display:flex;gap:10px;justify-content:center" id="crash-btns">
      ${csBtn(`<i class="fas fa-rocket" style="margin-right:6px"></i>${ja ? '開始' : 'Start'}`, 'crashStart()', `background:${PURPLE};color:white;font-size:16px;padding:14px 36px`)}
    </div>
    <div id="crash-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
}

// Crash point using exponential distribution with 3% house edge (realistic)
function generateCrashPoint() {
  const e = 0.97; // 97% payout (3% house edge)
  const r = Math.random();
  if (r < 0.01) return 1.0; // 1% instant crash
  return Math.max(1, Math.floor(100 / (1 - r) * e) / 100);
}

let crashGraphData = [];
function drawCrashGraph(multiplier, crashed = false) {
  const canvas = document.getElementById('crash-graph');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  canvas.width = canvas.offsetWidth * dpr;
  canvas.height = 120 * dpr;
  ctx.scale(dpr, dpr);
  const w = canvas.offsetWidth, h = 120;
  ctx.clearRect(0, 0, w, h);
  // Grid
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(0, h - h * i / 4); ctx.lineTo(w, h - h * i / 4); ctx.stroke(); }
  crashGraphData.push(multiplier);
  if (crashGraphData.length > 200) crashGraphData = crashGraphData.slice(-200);
  // Draw curve
  const maxM = Math.max(2, ...crashGraphData);
  ctx.beginPath();
  crashGraphData.forEach((m, i) => {
    const x = (i / Math.max(1, crashGraphData.length - 1)) * w;
    const y = h - ((m - 1) / (maxM - 1)) * (h - 10);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  const grad = ctx.createLinearGradient(0, h, 0, 0);
  if (crashed) { grad.addColorStop(0, 'rgba(230,57,70,0.1)'); grad.addColorStop(1, 'rgba(230,57,70,0.4)'); ctx.strokeStyle = RED; }
  else { grad.addColorStop(0, 'rgba(139,92,246,0.1)'); grad.addColorStop(1, 'rgba(46,196,134,0.3)'); ctx.strokeStyle = multiplier > 3 ? GREEN : PURPLE; }
  ctx.lineWidth = 2.5; ctx.stroke();
  // Fill area
  const lastX = ((crashGraphData.length - 1) / Math.max(1, crashGraphData.length - 1)) * w;
  ctx.lineTo(lastX, h); ctx.lineTo(0, h); ctx.closePath();
  ctx.fillStyle = grad; ctx.fill();
}

function crashStart() {
  if (CS.running || CS.bet > CS.coins) return;
  CS.running = true; crashMultiplier = 1; crashCashedOut = false; crashGraphData = [];
  // Use realistic exponential distribution
  crashTarget = generateCrashPoint();
  const ja = (window.__LANG__ || 'ja') === 'ja';
  document.getElementById('crash-btns').innerHTML = csBtn(`<i class="fas fa-hand" style="margin-right:6px"></i>${ja ? 'キャッシュアウト' : 'Cash Out'}`, 'crashCashout()', `background:${GREEN};color:white;font-size:16px;padding:14px 36px;animation:pulse-glow 1s infinite`);
  document.getElementById('crash-result').innerHTML = '';
  haptic('medium');
  crashTimer = setInterval(() => {
    if (crashCashedOut) return;
    crashMultiplier += 0.01 + crashMultiplier * 0.005;
    crashMultiplier = Math.round(crashMultiplier * 100) / 100;
    const el = document.getElementById('crash-multi');
    const st = document.getElementById('crash-status');
    if (el) { el.textContent = crashMultiplier.toFixed(2) + 'x'; el.style.color = crashMultiplier > 3 ? GREEN : crashMultiplier > 2 ? GOLD : PURPLE; }
    if (st) st.textContent = `${ja ? '上昇中...' : 'Rising...'}`;
    drawCrashGraph(crashMultiplier);
    if (crashMultiplier >= crashTarget) { clearInterval(crashTimer); CS.running = false; crashBust(); }
  }, 60);
}

function crashCashout() {
  if (!CS.running || crashCashedOut) return;
  crashCashedOut = true; clearInterval(crashTimer); CS.running = false;
  const winAmount = Math.floor(CS.bet * crashMultiplier);
  csPlaceBet('crash', `${crashMultiplier.toFixed(2)}x_cashout`, winAmount);
  if (CS.canvas) emitCoinBurst(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
  haptic('success');
  const ja = (window.__LANG__ || 'ja') === 'ja';
  document.getElementById('crash-result').innerHTML = `<div style="font-size:22px;font-weight:800;color:${GREEN};animation:result-pop 0.5s ease">CASH OUT ${crashMultiplier.toFixed(2)}x! +${winAmount - CS.bet}</div>`;
  document.getElementById('crash-btns').innerHTML = csBtn(`<i class="fas fa-redo" style="margin-right:6px"></i>${ja ? 'もう一度' : 'Again'}`, 'crashStart()', `background:${PURPLE};color:white`);
}

function crashBust() {
  const el = document.getElementById('crash-multi');
  if (el) { el.textContent = `${crashTarget.toFixed(2)}x`; el.style.color = RED; }
  drawCrashGraph(crashTarget, true);
  const st = document.getElementById('crash-status'); if (st) st.textContent = 'CRASHED!';
  csPlaceBet('crash', `${crashTarget.toFixed(2)}x_bust`, 0);
  if (CS.canvas) emitParticles(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 180, 25, [RED, '#ff6b6b'], { speed: 8, size: 2 });
  haptic('error');
  const ja = (window.__LANG__ || 'ja') === 'ja';
  document.getElementById('crash-result').innerHTML = `<div style="font-size:22px;font-weight:800;color:${RED};animation:result-pop 0.5s ease">CRASHED @${crashTarget.toFixed(2)}x! -${CS.bet}</div>`;
  document.getElementById('crash-btns').innerHTML = csBtn(`<i class="fas fa-redo" style="margin-right:6px"></i>${ja ? 'もう一度' : 'Again'}`, 'crashStart()', `background:${PURPLE};color:white`);
}

// ===== SIC BO (realistic: 3 dice, proper probabilities) =====
// Big/Small: ~48.61% win (excludes triples), Triple: 2.78% chance (1/36)
function initSicBo(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:${CYAN}"><i class="fas fa-dice" style="margin-right:6px"></i>${ja ? 'シックボー' : 'Sic Bo'}</div>
      ${csCoinDisplay()}
    </div>
    <div id="sb-dice" style="display:flex;gap:16px;justify-content:center;margin:20px 0;min-height:64px"></div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:10px">${ja ? 'ベット' : 'BET ON'}</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:12px">
        ${['big','small','odd','even','triple'].map(t => `<button onclick="window._sbBet='${t}';document.querySelectorAll('.sb-btn').forEach(b=>b.style.opacity='0.4');this.style.opacity='1'" class="sb-btn" style="padding:8px 16px;border-radius:10px;font-size:12px;font-weight:700;border:1px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.7);cursor:pointer;opacity:${t==='big'?'1':'0.4'};transition:opacity 0.2s">${t==='big'?(ja?'大 (11-17)':'Big'):t==='small'?(ja?'小 (4-10)':'Small'):t==='odd'?(ja?'奇数':'Odd'):t==='even'?(ja?'偶数':'Even'):t==='triple'?(ja?'ゾロ目 x30':'Triple x30'):t}</button>`).join('')}
      </div>
      ${csBetSelector()}
    </div>
    <div style="text-align:center">${csBtn(`<i class="fas fa-dice" style="margin-right:6px"></i>${ja ? '振る' : 'Roll'}`, 'sbRoll()', `background:${CYAN};color:white;font-size:16px;padding:14px 40px`)}</div>
    <div id="sb-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
  window._sbBet = 'big';
}

const DICE_FACES = {
  1: [[1,1]], 2: [[0,0],[2,2]], 3: [[0,0],[1,1],[2,2]],
  4: [[0,0],[0,2],[2,0],[2,2]], 5: [[0,0],[0,2],[1,1],[2,0],[2,2]],
  6: [[0,0],[0,2],[1,0],[1,2],[2,0],[2,2]]
};
function renderDice3D(val, delay = 0) {
  const dots = DICE_FACES[val] || [];
  let dotHTML = '';
  dots.forEach(([r,c]) => {
    const top = 10 + r * 18, left = 10 + c * 18;
    dotHTML += `<div style="position:absolute;top:${top}px;left:${left}px;width:10px;height:10px;border-radius:50%;background:#1a1a2e"></div>`;
  });
  return `<div style="width:64px;height:64px;border-radius:12px;background:linear-gradient(145deg,#fafaf8,#e8e8e0);position:relative;box-shadow:0 6px 20px rgba(0,0,0,0.4),inset 0 1px 0 rgba(255,255,255,0.6);animation:dice-bounce 0.6s ease ${delay}s both">${dotHTML}</div>`;
}

async function sbRoll() {
  if (CS.bet > CS.coins) return;
  haptic('medium');
  const d1 = Math.ceil(Math.random() * 6), d2 = Math.ceil(Math.random() * 6), d3 = Math.ceil(Math.random() * 6);
  const total = d1 + d2 + d3;
  const isTriple = d1 === d2 && d2 === d3;
  const diceEl = document.getElementById('sb-dice');
  if (diceEl) diceEl.innerHTML = [d1, d2, d3].map((d,i) => renderDice3D(d, i * 0.15)).join('');
  const bet = window._sbBet;
  let win = false, mult = 2;
  if (bet === 'big' && total >= 11 && total <= 17 && !isTriple) win = true;
  else if (bet === 'small' && total >= 4 && total <= 10 && !isTriple) win = true;
  else if (bet === 'odd' && total % 2 === 1 && !isTriple) win = true;
  else if (bet === 'even' && total % 2 === 0 && !isTriple) win = true;
  else if (bet === 'triple' && isTriple) { win = true; mult = 30; } // 30:1 for any triple
  const winAmount = win ? CS.bet * mult : 0;
  await csPlaceBet('sicbo', `${d1}-${d2}-${d3}(${bet})`, winAmount);
  if (win && CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
  haptic(win ? 'success' : 'error');
  const resEl = document.getElementById('sb-result');
  if (resEl) resEl.innerHTML = `<div style="font-size:13px;color:rgba(255,255,255,0.5);margin-bottom:4px">Total: ${total}${isTriple?' (Triple!)':''}</div><div style="font-size:22px;font-weight:800;color:${win ? GREEN : RED};animation:result-pop 0.5s ease">${win ? (isTriple ? `TRIPLE! +${winAmount - CS.bet}` : `WIN! +${CS.bet}`) : `LOSE -${CS.bet}`}</div>`;
}

// ===== CRAPS (realistic: come-out + point phase, proper odds) =====
function initCraps(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:#f59e0b"><i class="fas fa-dice-five" style="margin-right:6px"></i>${ja ? 'クラップス' : 'Craps'}</div>
      ${csCoinDisplay()}
    </div>
    <div id="cr-dice" style="display:flex;gap:16px;justify-content:center;margin:20px 0;min-height:64px"></div>
    <div id="cr-info" style="text-align:center;font-size:13px;color:rgba(255,255,255,0.5);margin-bottom:16px">${ja ? 'Come-out: 7か11で勝ち、2・3・12で負け' : 'Come-out: 7/11 wins, 2/3/12 loses'}</div>
    <div style="text-align:center;margin-bottom:16px">${csBetSelector()}</div>
    <div style="text-align:center" id="cr-btns">${csBtn(`<i class="fas fa-dice-five" style="margin-right:6px"></i>${ja ? '振る' : 'Roll'}`, 'crRoll()', 'background:#f59e0b;color:#1a1a2e;font-size:16px;padding:14px 40px')}</div>
    <div id="cr-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
  window._crPoint = 0;
}

async function crRoll() {
  if (CS.bet > CS.coins && window._crPoint === 0) return;
  haptic('medium');
  const d1 = Math.ceil(Math.random() * 6), d2 = Math.ceil(Math.random() * 6), total = d1 + d2;
  const ja = (window.__LANG__ || 'ja') === 'ja';
  document.getElementById('cr-dice').innerHTML = [d1, d2].map((d,i) => renderDice3D(d, i * 0.1)).join('');
  const info = document.getElementById('cr-info');
  const resEl = document.getElementById('cr-result');
  if (window._crPoint === 0) {
    if (total === 7 || total === 11) {
      await csPlaceBet('craps', `comeout_${total}_win`, CS.bet * 2);
      if (CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
      haptic('success');
      if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${GREEN};animation:result-pop 0.5s ease">${total === 7 ? 'SEVEN!' : 'ELEVEN!'} WIN +${CS.bet}</div>`;
    } else if ([2, 3, 12].includes(total)) {
      await csPlaceBet('craps', `comeout_${total}_craps`, 0);
      haptic('error');
      if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${RED};animation:result-pop 0.5s ease">CRAPS ${total}! LOSE -${CS.bet}</div>`;
    } else {
      window._crPoint = total;
      if (info) info.innerHTML = `<span style="color:${GOLD};font-weight:700">POINT: ${total}</span> — ${ja ? `${total}を出せば勝ち、7が出れば負け` : `Hit ${total} to win, 7 loses`}`;
      if (resEl) resEl.innerHTML = `<div style="font-size:16px;color:${GOLD};animation:result-pop 0.3s ease">${ja ? 'ポイント設定:' : 'Point set:'} ${total}</div>`;
    }
  } else {
    if (total === window._crPoint) {
      await csPlaceBet('craps', `point_${total}_hit`, CS.bet * 2);
      if (CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
      haptic('success');
      if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${GREEN};animation:result-pop 0.5s ease">POINT HIT! WIN +${CS.bet}</div>`;
      window._crPoint = 0;
      if (info) info.innerHTML = ja ? 'Come-out: 7か11で勝ち、2・3・12で負け' : 'Come-out: 7/11 wins, 2/3/12 loses';
    } else if (total === 7) {
      await csPlaceBet('craps', `seven_out`, 0);
      haptic('error');
      if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${RED};animation:result-pop 0.5s ease">SEVEN OUT! LOSE -${CS.bet}</div>`;
      window._crPoint = 0;
      if (info) info.innerHTML = ja ? 'Come-out: 7か11で勝ち、2・3・12で負け' : 'Come-out: 7/11 wins, 2/3/12 loses';
    } else {
      if (resEl) resEl.innerHTML = `<div style="font-size:14px;color:rgba(255,255,255,0.5)">${total} — ${ja ? 'もう一度!' : 'Roll again!'} (${ja?'ポイント':'Point'}: ${window._crPoint})</div>`;
    }
  }
}

// ===== TWO-UP (realistic: 50% heads, 50% tails per coin) =====
function initTwoUp(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:#ec4899"><i class="fas fa-coins" style="margin-right:6px"></i>${ja ? 'ツーアップ' : 'Two-Up'}</div>
      ${csCoinDisplay()}
    </div>
    <div id="tu-coins" style="display:flex;gap:24px;justify-content:center;margin:30px 0;height:90px"></div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:10px">${ja ? 'ベット' : 'BET ON'}</div>
      <div style="display:flex;gap:10px;justify-content:center;margin-bottom:12px">
        ${['heads','tails'].map(t => `<button onclick="window._tuBet='${t}';document.querySelectorAll('.tu-btn').forEach(b=>b.style.opacity='0.4');this.style.opacity='1'" class="tu-btn" style="padding:10px 28px;border-radius:12px;font-size:14px;font-weight:700;border:1px solid rgba(255,255,255,0.15);background:${t==='heads'?'rgba(236,72,153,0.15)':'rgba(212,160,23,0.15)'};color:${t==='heads'?'#ec4899':GOLD};cursor:pointer;opacity:${t==='heads'?'1':'0.4'};transition:opacity 0.2s">${t==='heads'?(ja?'表':'Heads'):(ja?'裏':'Tails')}</button>`).join('')}
      </div>
      ${csBetSelector()}
    </div>
    <div style="text-align:center">${csBtn(`<i class="fas fa-coins" style="margin-right:6px"></i>${ja ? '投げる' : 'Flip'}`, 'tuFlip()', 'background:#ec4899;color:white;font-size:16px;padding:14px 40px')}</div>
    <div id="tu-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
  window._tuBet = 'heads';
}

function renderCoin(isHeads, delay = 0) {
  return `<div style="width:72px;height:72px;border-radius:50%;background:${isHeads ? 'linear-gradient(145deg,#fbbf24,#f59e0b)' : 'linear-gradient(145deg,#94a3b8,#64748b)'};display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:800;color:${isHeads ? '#78350f' : '#1e293b'};box-shadow:0 6px 20px rgba(0,0,0,0.4),inset 0 1px 0 rgba(255,255,255,0.3);animation:coin-flip 0.8s ease ${delay}s both">${isHeads ? 'H' : 'T'}</div>`;
}

async function tuFlip() {
  if (CS.bet > CS.coins) return;
  haptic('medium');
  // Each coin is independent: 50/50 (realistic)
  const c1 = Math.random() < 0.5, c2 = Math.random() < 0.5;
  const bothHeads = c1 && c2, bothTails = !c1 && !c2;
  document.getElementById('tu-coins').innerHTML = renderCoin(c1, 0) + renderCoin(c2, 0.15);
  const outcome = bothHeads ? 'heads' : bothTails ? 'tails' : 'odds';
  // Odds (one head, one tail) = push: 50% chance, each matching pair = 25%
  let win = (window._tuBet === 'heads' && bothHeads) || (window._tuBet === 'tails' && bothTails);
  const isPush = outcome === 'odds';
  const winAmount = win ? CS.bet * 2 : isPush ? CS.bet : 0;
  await csPlaceBet('twoup', outcome, winAmount);
  if (win && CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
  haptic(win ? 'success' : isPush ? 'light' : 'error');
  const ja = (window.__LANG__ || 'ja') === 'ja';
  const resEl = document.getElementById('tu-result');
  if (resEl) resEl.innerHTML = `<div style="font-size:14px;color:rgba(255,255,255,0.5);margin-bottom:4px">${outcome === 'odds' ? (ja ? 'バラバラ — 引き分け' : 'Odds — Push') : (bothHeads ? (ja ? '両方表' : 'Both Heads') : (ja ? '両方裏' : 'Both Tails'))}</div><div style="font-size:22px;font-weight:800;color:${win ? GREEN : outcome === 'odds' ? GOLD : RED};animation:result-pop 0.5s ease">${win ? `WIN! +${CS.bet}` : outcome === 'odds' ? 'PUSH' : `LOSE -${CS.bet}`}</div>`;
}

// ===== MONEY WHEEL (realistic: proper segment probabilities) =====
// Segments: 24 total, probabilities match real casino wheels
// 1x: 11/24 = 45.8%, 2x: 7/24 = 29.2%, 5x: 3/24 = 12.5%, 10x: 1/24 = 4.2%, 20x: 1/24 = 4.2%, 40x: 1/24 = 4.2%
function initWheel(ui) {
  const ja = (window.__LANG__ || 'ja') === 'ja';
  const segs = [1, 2, 5, 1, 2, 10, 1, 2, 5, 1, 20, 2, 1, 5, 2, 1, 2, 40, 1, 2, 1, 2, 1, 2];
  const colors = { 1: '#3b82f6', 2: '#10b981', 5: '#f59e0b', 10: '#ef4444', 20: '#8b5cf6', 40: '#ec4899' };
  ui.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
      <button onclick="csBack()" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;cursor:pointer"><i class="fas fa-arrow-left"></i></button>
      <div style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;color:${GOLD}"><i class="fas fa-dharmachakra" style="margin-right:6px"></i>${ja ? 'マネーホイール' : 'Money Wheel'}</div>
      ${csCoinDisplay()}
    </div>
    <div style="text-align:center;margin:20px 0">
      <div style="width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-top:16px solid ${GOLD};margin:0 auto 4px;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.5))"></div>
      <div id="mw-wheel" style="width:200px;height:200px;border-radius:50%;margin:0 auto;background:conic-gradient(${segs.map((s, i) => `${colors[s]} ${i / segs.length * 360}deg ${(i + 1) / segs.length * 360}deg`).join(',')});border:5px solid ${GOLD};box-shadow:0 0 30px rgba(212,160,23,0.3);transition:transform 5s cubic-bezier(0.15,0.6,0.1,1);display:flex;align-items:center;justify-content:center">
        <div style="width:40px;height:40px;border-radius:50%;background:${DARK};border:3px solid ${GOLD};display:flex;align-items:center;justify-content:center;font-size:12px;color:${GOLD};font-weight:800" id="mw-val">?</div>
      </div>
    </div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;margin-bottom:10px">${ja ? 'ベット倍率' : 'BET ON'}</div>
      <div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-bottom:12px">
        ${[1,2,5,10,20,40].map(n => `<button onclick="window._mwBet=${n};document.querySelectorAll('.mw-btn').forEach(b=>b.style.opacity='0.4');this.style.opacity='1'" class="mw-btn" style="padding:8px 14px;border-radius:10px;font-size:13px;font-weight:700;border:1px solid ${colors[n]};background:${colors[n]}22;color:${colors[n]};cursor:pointer;opacity:${n===1?'1':'0.4'};transition:opacity 0.2s">x${n}</button>`).join('')}
      </div>
      ${csBetSelector()}
    </div>
    <div style="text-align:center">${csBtn(`<i class="fas fa-dharmachakra" style="margin-right:6px"></i>${ja ? '回す' : 'Spin'}`, 'mwSpin()', `background:${GOLD};color:#1a1a2e;font-size:16px;padding:14px 40px`)}</div>
    <div id="mw-result" style="text-align:center;margin-top:16px"></div>
    <div class="mobile-nav-spacer"></div>`;
  window._mwBet = 1;
  window._mwSpinning = false;
}

function mwSpin() {
  if (window._mwSpinning || CS.bet > CS.coins) return;
  window._mwSpinning = true;
  haptic('medium');
  const segs = [1, 2, 5, 1, 2, 10, 1, 2, 5, 1, 20, 2, 1, 5, 2, 1, 2, 40, 1, 2, 1, 2, 1, 2];
  const idx = Math.floor(Math.random() * segs.length);
  const result = segs[idx];
  const wheel = document.getElementById('mw-wheel');
  const valEl = document.getElementById('mw-val');
  if (!wheel) return;
  const step = 360 / segs.length;
  const targetAngle = 360 * 8 + (360 - idx * step - step / 2);
  wheel.style.transform = `rotate(${targetAngle}deg)`;
  if (valEl) valEl.textContent = '...';
  setTimeout(async () => {
    window._mwSpinning = false;
    if (valEl) valEl.textContent = 'x' + result;
    const win = result === window._mwBet;
    const winAmount = win ? CS.bet * result : 0;
    await csPlaceBet('wheel', `${result}x(bet:${window._mwBet}x)`, winAmount);
    if (win && CS.canvas) emitWinExplosion(CS.canvas.width / (window.devicePixelRatio || 1) / 2, 200);
    haptic(win ? 'success' : 'error');
    const resEl = document.getElementById('mw-result');
    if (resEl) resEl.innerHTML = `<div style="font-size:22px;font-weight:800;color:${win ? GREEN : RED};animation:result-pop 0.5s ease">${win ? `x${result} WIN! +${winAmount - CS.bet}` : `x${result} — LOSE`}</div>`;
    setTimeout(() => { wheel.style.transition = 'none'; wheel.style.transform = 'rotate(0deg)'; setTimeout(() => { wheel.style.transition = 'transform 5s cubic-bezier(0.15,0.6,0.1,1)'; }, 50); }, 2000);
  }, 5300);
}

// ===== CSS INJECTION =====
(function injectCSS() {
  if (document.getElementById('casino-css')) return;
  const style = document.createElement('style');
  style.id = 'casino-css';
  style.textContent = `
@keyframes card-deal{from{opacity:0;transform:translateY(-30px) rotateY(90deg) scale(0.8)}to{opacity:1;transform:translateY(0) rotateY(0) scale(1)}}
@keyframes dice-bounce{0%{opacity:0;transform:translateY(-40px) rotate(720deg) scale(0.3)}40%{transform:translateY(5px) rotate(0) scale(1.1)}60%{transform:translateY(-3px) scale(0.98)}100%{opacity:1;transform:translateY(0) rotate(0) scale(1)}}
@keyframes coin-flip{0%{transform:rotateY(0) scale(0.3);opacity:0}30%{opacity:1}50%{transform:rotateY(540deg) scale(1.15)}70%{transform:rotateY(680deg) scale(1.02)}100%{transform:rotateY(720deg) scale(1)}}
@keyframes coin-pulse{0%{transform:scale(1)}50%{transform:scale(1.15);color:#f5c842}100%{transform:scale(1)}}
@keyframes result-pop{0%{opacity:0;transform:scale(0.3) translateY(15px)}50%{transform:scale(1.08) translateY(-4px)}100%{opacity:1;transform:scale(1) translateY(0)}}
@keyframes pulse-glow{0%,100%{box-shadow:0 0 10px rgba(46,196,134,0.3)}50%{box-shadow:0 0 25px rgba(46,196,134,0.6)}}
@keyframes casino-card-in{from{opacity:0;transform:translateY(20px) scale(0.95)}to{opacity:1;transform:translateY(0) scale(1)}}
`;
  document.head.appendChild(style);
})();

// ===== EXPORTS =====
window.pageCasino = pageCasino;
window.csStopAnimation = csStopAnimation;
window.csOpenGame = csOpenGame;
window.csBack = csBack;
window.csSetBet = csSetBet;
// Game functions
window.bjDeal = bjDeal; window.bjHit = bjHit; window.bjStand = bjStand; window.bjDouble = bjDouble;
window.rlSpin = rlSpin;
window.crashStart = crashStart; window.crashCashout = crashCashout;
window.sbRoll = sbRoll;
window.crRoll = crRoll;
window.tuFlip = tuFlip;
window.mwSpin = mwSpin;
