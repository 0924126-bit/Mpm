// ===== shop.js - Coin Shop, Gacha, Inventory =====
// Depends on: app.js (S, $, $$, h, esc, t, api, avatar, navigate, toast)
// ===== COIN SHOP (Enhanced) =====
async function pageShop(el) {
  if (!S.user) return navigate('/login');
  el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="history.back()"><i class="fas fa-arrow-left"></i></button><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700"><i class="fas fa-store" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'ショップ':'Shop'}</span><span class="coin-badge" style="margin-left:auto" id="shop-coins"><i class="fas fa-coins" style="font-size:10px"></i>${S.user.coins||0}</span></div><div class="tab-bar" id="shop-tabs" style="padding:0 24px"><div class="tab-item active" onclick="switchShopTab('shop',this)">${S.lang==='ja'?'ストア':'Store'}</div><div class="tab-item" onclick="switchShopTab('inventory',this)">${S.lang==='ja'?'インベントリ':'Inventory'}</div><div class="tab-item" onclick="switchShopTab('gacha',this)">${S.lang==='ja'?'ガチャ':'Gacha'}</div><div class="tab-indicator" id="shop-tab-indicator"></div></div><div id="shop-content"><div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div><div class="mobile-nav-spacer"></div>`;
  requestAnimationFrame(() => { const ind = $('#shop-tab-indicator'), active = $('#shop-tabs .tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } });
  loadShopStore();
}

let shopCurrentTab = 'shop';
function switchShopTab(tab, el) {
  shopCurrentTab = tab;
  $$('#shop-tabs .tab-item').forEach(t2 => t2.classList.remove('active'));
  if (el) el.classList.add('active');
  requestAnimationFrame(() => { const ind = $('#shop-tab-indicator'), active = $('#shop-tabs .tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } });
  if (tab === 'shop') loadShopStore();
  else if (tab === 'inventory') loadShopInventory();
  else if (tab === 'gacha') loadShopGacha();
}

async function loadShopStore() {
  const [res, invRes] = await Promise.all([api('/api/shop/items'), api('/api/shop/inventory')]);
  const items = res.items || [];
  const ownedItems = new Set((invRes.inventory || []).map(i => i.item_type + ':' + i.item_value));
  const el2 = $('#shop-content');
  if (!el2) return;
  const lastBonus = localStorage.getItem('lastDailyBonus');
  const today = new Date().toISOString().split('T')[0];
  const showDailyBonus = lastBonus !== today;
  el2.innerHTML = `${showDailyBonus ? `<div id="daily-bonus-banner" style="padding:16px 24px;background:linear-gradient(135deg,rgba(200,85,61,0.1),rgba(107,143,113,0.1));border-bottom:1px solid var(--border);cursor:pointer;animation:shopItemIn 0.4s ease-out" onclick="claimDailyBonus()"><div style="display:flex;align-items:center;gap:14px" class="anim-fade-up"><div style="font-size:36px;animation:float 2s ease-in-out infinite">\ud83c\udf81</div><div style="flex:1"><div style="font-weight:700;font-size:15px;margin-bottom:2px">${S.lang==='ja'?'デイリーログインボーナス':'Daily Login Bonus'}</div><div style="font-size:13px;color:var(--text-secondary)">${S.lang==='ja'?'タップして5コインを獲得！':'Tap to claim 5 coins!'}</div></div><div class="coin-badge" style="font-size:14px;animation:pulse 2s infinite"><i class="fas fa-coins" style="font-size:12px"></i>+5</div></div></div>` : ''}<div style="padding:16px 24px;background:linear-gradient(135deg,rgba(200,85,61,0.06),rgba(194,178,128,0.08));border-bottom:1px solid var(--border)">
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap" class="anim-fade-up">
      <div style="flex:1;min-width:140px">
        <div style="font-size:11px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px">${S.lang==='ja'?'保有コイン':'Your Coins'}</div>
        <div style="font-size:28px;font-weight:700;color:var(--accent);font-family:'Cormorant Garamond',serif"><i class="fas fa-coins" style="font-size:20px;margin-right:6px;color:var(--sand)"></i>${S.user.coins||0}</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary btn-xs" onclick="switchShopTab('inventory',$$('#shop-tabs .tab-item')[1])"><i class="fas fa-box-open" style="margin-right:4px"></i>${S.lang==='ja'?'所有品':'Owned'}: ${(invRes.inventory||[]).length}</button>
        <button class="btn btn-primary btn-xs" style="border-radius:var(--radius-full)" onclick="switchShopTab('gacha',$$('#shop-tabs .tab-item')[2])"><i class="fas fa-dice" style="margin-right:4px"></i>${S.lang==='ja'?'ガチャ':'Gacha'}</button>
      </div>
    </div>
  </div>` + items.map((cat, ci) => `
    <div style="padding:20px 24px;border-bottom:1px solid var(--border)" class="anim-fade-up stagger-${Math.min(ci+1,3)}">
      <h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:14px"><i class="fas ${cat.type==='name_color'?'fa-palette':cat.type==='bg_color'?'fa-image':'fa-award'}" style="margin-right:6px;color:var(--accent)"></i>${cat.label}<span style="font-size:11px;font-weight:500;margin-left:8px;color:var(--sage)">${S.lang==='ja'?'永久所有':'Own Forever'}</span></h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px">
        ${cat.options.map((opt, oi) => {
          const owned = ownedItems.has(cat.type + ':' + opt.value);
          const equipped = S.user[cat.type] === opt.value;
          let previewStyle = '';
          if (cat.type === 'name_color') {
            previewStyle = opt.value === 'rainbow' ? 'background:linear-gradient(90deg,#c8553d,#c2b280,#6b8f71,#5b8fa8,#8b7eb8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-size:200% 100%;animation:shimmer 2s linear infinite' : `color:${opt.value}`;
          } else if (cat.type === 'bg_color') {
            previewStyle = `background:var(--${opt.value.replace('gradient-','')}-bg, var(--accent-bg));border-radius:8px;padding:4px 8px`;
          }
          return `<div class="shop-item-card" style="--delay:${oi*0.06}s;animation:shopItemIn 0.4s cubic-bezier(0.22,1,0.36,1) calc(var(--delay)) both;padding:16px;border:2px solid ${equipped?'var(--accent)':owned?'var(--sage)':'var(--border)'};border-radius:var(--radius-lg);background:var(--bg-secondary);text-align:center;transition:all 0.35s cubic-bezier(0.22,1,0.36,1);cursor:pointer;position:relative;overflow:hidden" onclick="${owned ? `equipShopItem('${cat.type}','${opt.value}')` : `buyShopItem('${cat.type}','${opt.value}',${opt.cost})`}" onmouseenter="this.style.transform='translateY(-4px) scale(1.02)';this.style.boxShadow='0 12px 30px rgba(0,0,0,0.1)'" onmouseleave="this.style.transform='';this.style.boxShadow=''">
            ${equipped ? '<div style="position:absolute;top:6px;right:6px;width:22px;height:22px;background:var(--accent);border-radius:50%;display:flex;align-items:center;justify-content:center;animation:pulse 2s infinite"><i class="fas fa-check" style="font-size:10px;color:white"></i></div>' : ''}
            ${owned && !equipped ? '<div style="position:absolute;top:6px;right:6px;font-size:10px;color:var(--sage);font-weight:700"><i class="fas fa-box-open"></i></div>' : ''}
            <div style="font-size:18px;font-weight:700;margin-bottom:8px;transition:transform 0.3s;${previewStyle}">${opt.label}</div>
            ${owned ? `<div style="font-size:11px;color:${equipped?'var(--accent)':'var(--sage)'};font-weight:700;display:flex;align-items:center;justify-content:center;gap:4px"><i class="fas ${equipped?'fa-check-circle':'fa-hand-pointer'}" style="font-size:10px"></i>${equipped?(S.lang==='ja'?'装備中':'Equipped'):(S.lang==='ja'?'タップで装備':'Tap to equip')}</div>` : `<div class="coin-badge" style="font-size:11px"><i class="fas fa-coins" style="font-size:9px"></i>${opt.cost}</div>`}
          </div>`;
        }).join('')}
      </div>
    </div>
  `).join('');
}

async function loadShopInventory() {
  const el2 = $('#shop-content');
  if (!el2) return;
  el2.innerHTML = '<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>';
  const res = await api('/api/shop/inventory');
  const items = res.inventory || [];
  if (items.length === 0) {
    el2.innerHTML = `<div style="padding:60px 24px;text-align:center;color:var(--text-tertiary)" class="anim-fade-up"><i class="fas fa-box-open" style="font-size:48px;margin-bottom:16px;opacity:0.3"></i><p style="font-family:'Cormorant Garamond',serif;font-size:20px;margin-bottom:8px">${S.lang==='ja'?'アイテムがありません':'No items yet'}</p><p style="font-size:13px">${S.lang==='ja'?'ストアでアイテムを購入しましょう':'Visit the store to buy items'}</p></div>`;
    return;
  }
  const typeLabels = { name_color: S.lang==='ja'?'名前カラー':'Name Color', bg_color: S.lang==='ja'?'プロフィール背景':'Profile BG', badge: S.lang==='ja'?'バッジ':'Badge' };
  el2.innerHTML = `<div style="padding:20px 24px"><h3 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:16px">${S.lang==='ja'?'所有アイテム':'OWNED ITEMS'} (${items.length})</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">${items.map((item, i) => {
    const equipped = S.user[item.item_type] === item.item_value;
    return `<div class="anim-fade-up" style="animation-delay:${i*0.04}s;padding:14px;border:2px solid ${equipped?'var(--accent)':'var(--border)'};border-radius:var(--radius-lg);background:var(--bg-secondary);text-align:center;cursor:pointer;transition:all 0.3s" onclick="equipShopItem('${item.item_type}','${item.item_value}')" onmouseenter="this.style.transform='scale(1.03)'" onmouseleave="this.style.transform=''">
      <div style="font-size:10px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:6px">${typeLabels[item.item_type]||item.item_type}</div>
      <div style="font-size:15px;font-weight:700;margin-bottom:6px">${item.item_value}</div>
      <div style="font-size:11px;color:${equipped?'var(--accent)':'var(--sage)'};font-weight:600">${equipped?(S.lang==='ja'?'装備中':'Equipped'):(S.lang==='ja'?'装備する':'Equip')}</div>
    </div>`;
  }).join('')}</div></div>`;
}

async function loadShopGacha() {
  const el2 = $('#shop-content');
  if (!el2) return;
  el2.innerHTML = `<div style="padding:24px;text-align:center" class="anim-fade-up">
    <canvas id="gacha-canvas" width="360" height="400" style="width:100%;max-width:360px;border-radius:var(--radius-lg);margin-bottom:16px;background:radial-gradient(ellipse at center, #1a0a2e 0%, #0d0520 50%, #050210 100%)"></canvas>
    <h2 style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700;margin-bottom:12px">${S.lang==='ja'?'コインガチャ':'Coin Gacha'}</h2>
    <p style="font-size:14px;color:var(--text-tertiary);margin-bottom:20px;line-height:1.6">${S.lang==='ja'?'30コインでランダムアイテムをゲット！':'Spend 30 coins for a random item!'}</p>
    <button id="gacha-spin-btn" class="btn btn-primary" style="padding:16px 40px;font-size:16px;border-radius:var(--radius-full);position:relative;overflow:hidden;background:linear-gradient(135deg,#c8553d,#e6388e);border:none;box-shadow:0 4px 20px rgba(200,85,61,0.4)" onclick="spinGacha()">
      <i class="fas fa-dice" style="margin-right:8px"></i>${S.lang==='ja'?'30コインでガチャ':'Spin (30 coins)'}
    </button>
    <div id="gacha-result" style="margin-top:20px"></div>
    <div style="margin-top:24px;padding:16px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-lg);text-align:left">
      <h4 style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:10px">${S.lang==='ja'?'排出率':'Drop Rates'}</h4>
      <div style="display:flex;flex-direction:column;gap:6px;font-size:13px">
        <div style="display:flex;justify-content:space-between"><span>⭐ ${S.lang==='ja'?'コモン（名前カラー）':'Common (Name Color)'}</span><span style="color:var(--text-tertiary)">50%</span></div>
        <div style="display:flex;justify-content:space-between"><span>💎 ${S.lang==='ja'?'レア（背景）':'Rare (Background)'}</span><span style="color:var(--text-tertiary)">30%</span></div>
        <div style="display:flex;justify-content:space-between"><span>👑 ${S.lang==='ja'?'超レア（バッジ）':'Super Rare (Badge)'}</span><span style="color:var(--text-tertiary)">15%</span></div>
        <div style="display:flex;justify-content:space-between"><span>🌈 ${S.lang==='ja'?'ウルトラレア':'Ultra Rare'}</span><span style="color:var(--text-tertiary)">5%</span></div>
      </div>
    </div>
  </div>`;
  // Initialize idle animation on canvas
  initGachaCanvas();
}

let _gachaAnimId = null;
function initGachaCanvas() {
  const canvas = document.getElementById('gacha-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  // Particle system for idle state
  const particles = [];
  for (let i = 0; i < 50; i++) {
    particles.push({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 2 + 0.5, vx: (Math.random() - 0.5) * 0.3, vy: -Math.random() * 0.5 - 0.2,
      alpha: Math.random() * 0.6 + 0.2, color: ['#c8553d','#c2b280','#5b8fa8','#8b7eb8','#e6388e','#6b8f71'][Math.floor(Math.random()*6)]
    });
  }
  function drawIdle() {
    ctx.clearRect(0, 0, W, H);
    // Draw glowing orb in center
    const grd = ctx.createRadialGradient(W/2, H/2, 20, W/2, H/2, 120);
    grd.addColorStop(0, 'rgba(200,85,61,0.15)');
    grd.addColorStop(0.5, 'rgba(139,126,184,0.08)');
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, W, H);
    // Draw floating particles
    for (const p of particles) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color.replace(')', `,${p.alpha})`).replace('rgb','rgba').replace('#', '');
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.fill();
      p.x += p.vx; p.y += p.vy;
      if (p.y < -5) { p.y = H + 5; p.x = Math.random() * W; }
      if (p.x < -5) p.x = W + 5;
      if (p.x > W + 5) p.x = -5;
    }
    ctx.globalAlpha = 1;
    // Draw gacha capsule
    const t = Date.now() / 1000;
    const bobY = Math.sin(t * 1.5) * 8;
    ctx.save();
    ctx.translate(W/2, H/2 + bobY);
    // Capsule glow
    ctx.shadowColor = '#c8553d';
    ctx.shadowBlur = 30 + Math.sin(t * 3) * 10;
    // Capsule body
    ctx.beginPath();
    ctx.arc(0, 0, 40, 0, Math.PI, true);
    ctx.fillStyle = '#e8443a';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(0, 0, 40, 0, Math.PI, false);
    ctx.fillStyle = '#f5f5f5';
    ctx.fill();
    // Center line
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-42, 0);
    ctx.lineTo(42, 0);
    ctx.stroke();
    // Center button
    ctx.beginPath();
    ctx.arc(0, 0, 8, 0, Math.PI * 2);
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#999';
    ctx.lineWidth = 2;
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.restore();
    // Draw text
    ctx.font = 'bold 14px sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.textAlign = 'center';
    ctx.fillText(S.lang==='ja'?'タップしてガチャを回す':'Tap to Spin', W/2, H - 30);
    _gachaAnimId = requestAnimationFrame(drawIdle);
  }
  if (_gachaAnimId) cancelAnimationFrame(_gachaAnimId);
  drawIdle();
}

function runGachaAnimation(canvas, rarity, callback) {
  if (_gachaAnimId) cancelAnimationFrame(_gachaAnimId);
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const rarityColors = {
    common: { main: '#c2b280', glow: 'rgba(194,178,128,0.6)', particles: ['#c2b280','#d4c99a','#b8a870'] },
    rare: { main: '#5b8fa8', glow: 'rgba(91,143,168,0.6)', particles: ['#5b8fa8','#7ab4cc','#4a7d96'] },
    superrare: { main: '#8b7eb8', glow: 'rgba(139,126,184,0.7)', particles: ['#8b7eb8','#a698d4','#7568a2'] },
    ultrarare: { main: '#e6388e', glow: 'rgba(230,56,142,0.8)', particles: ['#e6388e','#ff6bb5','#c8553d','#c2b280','#5b8fa8','#8b7eb8'] }
  };
  const rc = rarityColors[rarity] || rarityColors.common;
  const startTime = Date.now();
  const duration = rarity === 'ultrarare' ? 3500 : rarity === 'superrare' ? 3000 : rarity === 'rare' ? 2500 : 2000;
  // Explosion particles
  const explosionParticles = [];
  let phase = 'spin'; // spin -> crack -> explode -> reveal
  let shakeIntensity = 0;
  
  function drawFrame() {
    const elapsed = Date.now() - startTime;
    const progress = Math.min(elapsed / duration, 1);
    ctx.clearRect(0, 0, W, H);
    
    // Dark background
    ctx.fillStyle = '#050210';
    ctx.fillRect(0, 0, W, H);
    
    // Phase transitions
    if (progress < 0.4) phase = 'spin';
    else if (progress < 0.6) phase = 'crack';
    else if (progress < 0.75) phase = 'explode';
    else phase = 'reveal';
    
    const t = elapsed / 1000;
    
    if (phase === 'spin') {
      // Spinning capsule with increasing speed
      const speed = progress / 0.4;
      const angle = t * (2 + speed * 15);
      shakeIntensity = speed * 3;
      const sx = (Math.random() - 0.5) * shakeIntensity;
      const sy = (Math.random() - 0.5) * shakeIntensity;
      // Energy rings
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        const ringR = 60 + i * 20 + Math.sin(t * 4 + i) * 10;
        ctx.arc(W/2 + sx, H/2 + sy, ringR, angle + i * 0.5, angle + i * 0.5 + Math.PI * 1.2);
        ctx.strokeStyle = rc.main;
        ctx.globalAlpha = 0.3 - i * 0.08;
        ctx.lineWidth = 3 - i * 0.5;
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      // Capsule
      ctx.save();
      ctx.translate(W/2 + sx, H/2 + sy);
      ctx.rotate(Math.sin(angle * 0.3) * 0.2);
      ctx.shadowColor = rc.glow;
      ctx.shadowBlur = 20 + speed * 30;
      ctx.beginPath(); ctx.arc(0, 0, 40, 0, Math.PI, true); ctx.fillStyle = '#e8443a'; ctx.fill();
      ctx.beginPath(); ctx.arc(0, 0, 40, 0, Math.PI, false); ctx.fillStyle = '#f5f5f5'; ctx.fill();
      ctx.strokeStyle = '#333'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-42,0); ctx.lineTo(42,0); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI*2); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#999'; ctx.lineWidth = 2; ctx.fill(); ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (phase === 'crack') {
      // Shaking and cracking
      const crackProgress = (progress - 0.4) / 0.2;
      shakeIntensity = 5 + crackProgress * 15;
      const sx = (Math.random() - 0.5) * shakeIntensity;
      const sy = (Math.random() - 0.5) * shakeIntensity;
      // Flash effect
      if (Math.random() < crackProgress * 0.3) {
        ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.15})`;
        ctx.fillRect(0, 0, W, H);
      }
      // Capsule with crack lines
      ctx.save();
      ctx.translate(W/2 + sx, H/2 + sy);
      ctx.shadowColor = rc.glow;
      ctx.shadowBlur = 40;
      ctx.beginPath(); ctx.arc(0, 0, 40, 0, Math.PI, true); ctx.fillStyle = '#e8443a'; ctx.fill();
      ctx.beginPath(); ctx.arc(0, 0, 40, 0, Math.PI, false); ctx.fillStyle = '#f5f5f5'; ctx.fill();
      // Crack lines
      ctx.strokeStyle = rc.main;
      ctx.lineWidth = 2;
      for (let i = 0; i < Math.floor(crackProgress * 6); i++) {
        ctx.beginPath();
        const a = (i / 6) * Math.PI * 2;
        ctx.moveTo(Math.cos(a) * 10, Math.sin(a) * 10);
        ctx.lineTo(Math.cos(a) * (25 + crackProgress * 20), Math.sin(a) * (25 + crackProgress * 20));
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
      ctx.restore();
      // Spawn particles for explosion
      if (crackProgress > 0.8 && explosionParticles.length < 80) {
        for (let i = 0; i < 5; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = 2 + Math.random() * 6;
          explosionParticles.push({
            x: W/2, y: H/2, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
            r: Math.random() * 4 + 2, life: 1, color: rc.particles[Math.floor(Math.random() * rc.particles.length)],
            decay: 0.008 + Math.random() * 0.015
          });
        }
      }
    } else if (phase === 'explode') {
      // Full explosion
      const explodeProgress = (progress - 0.6) / 0.15;
      // White flash
      if (explodeProgress < 0.3) {
        ctx.fillStyle = `rgba(255,255,255,${(0.3 - explodeProgress) * 2})`;
        ctx.fillRect(0, 0, W, H);
      }
      // Spawn more particles
      if (explosionParticles.length < 150) {
        for (let i = 0; i < 10; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = 1 + Math.random() * 8;
          explosionParticles.push({
            x: W/2, y: H/2, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed - 2,
            r: Math.random() * 5 + 1, life: 1, color: rc.particles[Math.floor(Math.random() * rc.particles.length)],
            decay: 0.005 + Math.random() * 0.02
          });
        }
      }
      // Shockwave ring
      const ringRadius = explodeProgress * 180;
      ctx.beginPath();
      ctx.arc(W/2, H/2, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = rc.main;
      ctx.globalAlpha = Math.max(0, 1 - explodeProgress);
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.globalAlpha = 1;
    } else {
      // Reveal phase - show rarity glow
      const revealProgress = (progress - 0.75) / 0.25;
      // Rarity glow
      const grd = ctx.createRadialGradient(W/2, H/2, 10, W/2, H/2, 100 + revealProgress * 80);
      grd.addColorStop(0, rc.glow);
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, W, H);
      // Rarity star/icon
      const scale = Math.min(revealProgress * 1.5, 1);
      ctx.save();
      ctx.translate(W/2, H/2);
      ctx.scale(scale, scale);
      ctx.font = 'bold 64px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = rc.main;
      ctx.shadowBlur = 30;
      const icons = { common: '⭐', rare: '💎', superrare: '👑', ultrarare: '🌈' };
      ctx.fillText(icons[rarity] || '⭐', 0, -10);
      ctx.shadowBlur = 0;
      ctx.restore();
      // Rarity label
      if (revealProgress > 0.3) {
        const labelAlpha = Math.min((revealProgress - 0.3) / 0.3, 1);
        ctx.globalAlpha = labelAlpha;
        ctx.font = 'bold 18px sans-serif';
        ctx.fillStyle = rc.main;
        ctx.textAlign = 'center';
        const labels = { common: 'COMMON', rare: 'RARE!', superrare: 'SUPER RARE!!', ultrarare: '★ ULTRA RARE ★' };
        ctx.fillText(labels[rarity] || '', W/2, H/2 + 50);
        ctx.globalAlpha = 1;
      }
    }
    // Draw all particles
    for (let i = explosionParticles.length - 1; i >= 0; i--) {
      const p = explosionParticles[i];
      p.x += p.vx; p.y += p.vy; p.vy += 0.05; p.life -= p.decay;
      if (p.life <= 0) { explosionParticles.splice(i, 1); continue; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    if (progress < 1) {
      _gachaAnimId = requestAnimationFrame(drawFrame);
    } else {
      // Animation done
      callback();
    }
  }
  drawFrame();
  // Also play haptic during animation
  setTimeout(() => haptic('medium'), 300);
  setTimeout(() => haptic('medium'), 800);
  setTimeout(() => haptic('heavy'), duration * 0.6);
  setTimeout(() => haptic('heavy'), duration * 0.75);
}

async function spinGacha() {
  if (!S.user || S.user.coins < 30) { toast(S.lang==='ja'?'コインが足りません（30コイン必要）':'Not enough coins (need 30)','error'); return; }
  const btn = document.getElementById('gacha-spin-btn');
  if (btn) { btn.disabled = true; btn.style.opacity = '0.5'; }
  const resultEl = $('#gacha-result');
  if (resultEl) resultEl.innerHTML = '';
  // Random gacha logic
  const roll = Math.random();
  let type, value, label, rarity, rarityKey;
  if (roll < 0.05) {
    type = 'name_color'; value = 'rainbow'; label = '🌈 レインボー'; rarity = S.lang==='ja'?'ウルトラレア！':'ULTRA RARE!'; rarityKey = 'ultrarare';
  } else if (roll < 0.20) {
    const badges = [['star','⭐ スター'],['fire','🔥 ファイア'],['diamond','💎 ダイヤ'],['crown','👑 クラウン'],['heart','❤️ ハート'],['lightning','⚡ ライトニング']];
    const pick = badges[Math.floor(Math.random()*badges.length)];
    type = 'badge'; value = pick[0]; label = pick[1]; rarity = S.lang==='ja'?'超レア！':'SUPER RARE!'; rarityKey = 'superrare';
  } else if (roll < 0.50) {
    const bgs = [['gradient-sunset','🌅 サンセット'],['gradient-ocean','🌊 オーシャン'],['gradient-forest','🌲 フォレスト'],['gradient-galaxy','🌌 ギャラクシー'],['gradient-aurora','🌈 オーロラ'],['gradient-sakura','🌸 さくら']];
    const pick = bgs[Math.floor(Math.random()*bgs.length)];
    type = 'bg_color'; value = pick[0]; label = pick[1]; rarity = S.lang==='ja'?'レア！':'RARE!'; rarityKey = 'rare';
  } else {
    const colors = [['#c8553d','レッド'],['#5b8fa8','ブルー'],['#6b8f71','グリーン'],['#c2b280','ゴールド'],['#8b7eb8','パープル'],['#e6388e','ピンク'],['#ff6b35','オレンジ']];
    const pick = colors[Math.floor(Math.random()*colors.length)];
    type = 'name_color'; value = pick[0]; label = pick[1]; rarity = S.lang==='ja'?'コモン':'Common'; rarityKey = 'common';
  }
  const cost = 30;
  // Start Canvas animation first
  const canvas = document.getElementById('gacha-canvas');
  if (canvas) {
    runGachaAnimation(canvas, rarityKey, async () => {
      // Animation done, now call API
      const res = await api('/api/shop/buy', { method: 'POST', body: { item_type: type, item_value: value, cost } });
      if (res.success) {
        S.user.coins = res.new_balance;
        const coinBadge = $('#shop-coins');
        if (coinBadge) coinBadge.innerHTML = `<i class="fas fa-coins" style="font-size:10px"></i>${S.user.coins}`;
        if (resultEl) {
          const rarityBg = { common: 'var(--sand)', rare: 'var(--sky)', superrare: 'var(--violet)', ultrarare: 'var(--accent)' };
          resultEl.innerHTML = `<div class="anim-fade-up" style="padding:24px;background:var(--bg-secondary);border:2px solid ${rarityBg[rarityKey]||'var(--border)'};border-radius:var(--radius-lg);box-shadow:0 8px 32px rgba(0,0,0,0.15)">
            <div style="font-size:14px;font-weight:700;color:${rarityBg[rarityKey]};text-transform:uppercase;letter-spacing:0.12em;margin-bottom:8px">${rarity}</div>
            <div style="font-size:32px;margin-bottom:8px">${label}</div>
            <div style="font-size:13px;color:var(--text-tertiary)">${S.lang==='ja'?'インベントリに追加されました':'Added to your inventory'}</div>
          </div>`;
        }
        haptic('success');
      } else {
        toast(res.error || 'Error', 'error');
        if (resultEl) resultEl.innerHTML = '';
      }
      if (btn) { btn.disabled = false; btn.style.opacity = '1'; }
      // Restart idle animation after a delay
      setTimeout(() => initGachaCanvas(), 3000);
    });
  } else {
    // Fallback if no canvas
    const res = await api('/api/shop/buy', { method: 'POST', body: { item_type: type, item_value: value, cost } });
    if (res.success) {
      S.user.coins = res.new_balance;
      const coinBadge = $('#shop-coins');
      if (coinBadge) coinBadge.innerHTML = `<i class="fas fa-coins" style="font-size:10px"></i>${S.user.coins}`;
      if (resultEl) resultEl.innerHTML = `<div class="anim-fade-up" style="padding:24px;background:var(--bg-secondary);border:2px solid var(--accent);border-radius:var(--radius-lg)"><div style="font-size:12px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:8px">${rarity}</div><div style="font-size:28px;margin-bottom:8px">${label}</div><div style="font-size:13px;color:var(--text-tertiary)">${S.lang==='ja'?'インベントリに追加されました':'Added to your inventory'}</div></div>`;
      haptic('heavy');
    } else { toast(res.error || 'Error', 'error'); if (resultEl) resultEl.innerHTML = ''; }
    if (btn) { btn.disabled = false; btn.style.opacity = '1'; }
  }
}

async function equipShopItem(type, value) {
  const res = await api('/api/shop/equip', { method: 'POST', body: { item_type: type, item_value: S.user[type] === value ? '' : value } });
  if (res.success) {
    S.user[type] = S.user[type] === value ? '' : value;
    toast(S.lang==='ja'?'装備を変更しました':'Equipment changed');
    if (shopCurrentTab === 'shop') loadShopStore();
    else loadShopInventory();
  } else toast(res.error || 'Error', 'error');
}
async function buyShopItem(type, value, cost) {
  if (!S.user) return;
  if (S.user.coins < cost) { toast(S.lang==='ja'?'コインが足りません':'Not enough coins','error'); return; }
  confirmDialog(`${S.lang==='ja'?`${cost}コインで購入しますか？\n購入したアイテムは永久に所有できます。`:`Buy for ${cost} coins?\nPurchased items are yours forever.`}`, async () => {
    const res = await api('/api/shop/buy', { method: 'POST', body: { item_type: type, item_value: value, cost } });
    if (res.success) {
      S.user.coins = res.new_balance;
      S.user[type] = value;
      const coinBadge = $('#shop-coins');
      if (coinBadge) coinBadge.innerHTML = `<i class="fas fa-coins" style="font-size:10px"></i>${S.user.coins}`;
      haptic('heavy');
      showPurchaseSuccess(type, value);
      setTimeout(() => { if (shopCurrentTab === 'shop') loadShopStore(); }, 1200);
    } else toast(res.error||'Error','error');
  });
}

function showPurchaseSuccess(type, value) {
  const ov = document.createElement('div');
  ov.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.5);backdrop-filter:blur(6px);animation:fade-in 0.2s ease';
  ov.innerHTML = `<div style="text-align:center;animation:shopPurchasePop 0.5s cubic-bezier(0.175,0.885,0.32,1.275)">
    <div style="font-size:56px;margin-bottom:16px;animation:coinSpin 0.8s ease-out">\ud83c\udf89</div>
    <div style="font-size:20px;font-weight:700;color:white;margin-bottom:8px;text-shadow:0 2px 8px rgba(0,0,0,0.3)">${S.lang==='ja'?'購入成功！':'Purchase Complete!'}</div>
    <div style="font-size:14px;color:rgba(255,255,255,0.8);margin-bottom:4px">${S.lang==='ja'?'インベントリに追加されました':'Added to your inventory'}</div>
    <div style="font-size:12px;color:#6b8f71;font-weight:600;margin-top:8px">${S.lang==='ja'?'永久に所有できます':'Yours forever'}</div>
  </div>`;
  document.body.appendChild(ov);
  setTimeout(() => { ov.style.opacity = '0'; ov.style.transition = 'opacity 0.3s'; setTimeout(() => ov.remove(), 300); }, 1200);
}

async function claimDailyBonus() {
  const banner = $('#daily-bonus-banner');
  if (!banner) return;
  banner.style.pointerEvents = 'none';
  const res = await api('/api/daily-bonus', { method: 'POST' });
  if (res.success) {
    S.user.coins = res.new_balance;
    localStorage.setItem('lastDailyBonus', new Date().toISOString().split('T')[0]);
    const coinBadge = $('#shop-coins');
    if (coinBadge) coinBadge.innerHTML = `<i class="fas fa-coins" style="font-size:10px"></i>${S.user.coins}`;
    haptic('heavy');
    banner.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;gap:10px;padding:8px" class="anim-fade-up"><div style="font-size:24px">\u2728</div><div style="font-weight:700;color:var(--sage)">${S.lang==='ja'?'+5コイン獲得！':'Got +5 coins!'}</div></div>`;
    setTimeout(() => { banner.style.height = '0'; banner.style.overflow = 'hidden'; banner.style.padding = '0'; banner.style.transition = 'all 0.3s ease'; setTimeout(() => banner.remove(), 300); }, 1500);
  } else {
    if (res.error && res.error.includes('already')) {
      localStorage.setItem('lastDailyBonus', new Date().toISOString().split('T')[0]);
      banner.remove();
    } else toast(res.error || 'Error', 'error');
  }
}

