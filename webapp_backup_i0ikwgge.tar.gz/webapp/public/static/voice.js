// ===== voice.js - Voice Rooms, VR Detail, Whiteboard, Floating Bubble =====
// Depends on: app.js (S, $, $$, h, esc, t, api, avatar, navigate, toast, haptic, tagHTML, formatContent, timeAgo)
// ===== VOICE ROOMS =====
function pageVoice(el) {
  const tags = ['','recruit','sleep','game','chat','music','study'];
  const tagNames = { '': S.lang==='ja'?'すべて':'All', recruit:t('tag.recruit'), sleep:t('tag.sleep'), game:t('tag.game'), chat:t('tag.chat'), music:t('tag.music'), study:t('tag.study') };
  el.innerHTML = `<div class="page-header" style="padding:20px 24px"><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px"><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${t('voice.rooms')}</span>${S.user ? `<button class="btn btn-primary btn-sm" onclick="showCreateRoomModal()"><i class="fas fa-plus" style="margin-right:5px"></i>${t('voice.create')}</button>` : ''}</div><div style="display:flex;gap:7px;overflow-x:auto;padding-bottom:4px" class="no-scrollbar">${tags.map(tg => `<button class="pill ${tg===''?'active':''}" data-tag="${tg}" onclick="filterVoiceRooms('${tg}',this)">${tagNames[tg]}</button>`).join('')}</div></div><div id="vr-current-bar" style="display:none"></div><div style="padding:24px"><div id="voice-rooms-list" style="display:flex;flex-direction:column;gap:12px"></div></div><div class="mobile-nav-spacer"></div>`;
  loadVoiceRooms(); if (S.user) checkMyVoiceRoom();
}
let vrCurrentTag = '';
function filterVoiceRooms(tag) { vrCurrentTag = tag; $$('.pill').forEach(p => p.classList.toggle('active', p.dataset.tag === tag)); loadVoiceRooms(tag); }
async function loadVoiceRooms(tag) { const list = $('#voice-rooms-list'); if (!list) return; list.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`; const res = await api(`/api/voice-rooms${(tag||vrCurrentTag) ? '?tag='+(tag||vrCurrentTag) : ''}`); if (!res.rooms || res.rooms.length === 0) { list.innerHTML = `<div style="padding:60px 20px;text-align:center;color:var(--text-tertiary)"><p style="font-family:'Cormorant Garamond',serif;font-size:20px;margin-bottom:6px">${S.lang==='ja'?'静かです':'Quiet here'}</p></div>`; return; } list.innerHTML = res.rooms.map((r, i) => `<div class="vr-card anim-fade-up stagger-${Math.min(i+1,5)}" onclick="navigate('/voice/${r.id}')"><div style="display:flex;align-items:center;justify-content:space-between"><div style="display:flex;align-items:center;gap:14px;flex:1;min-width:0"><div style="position:relative">${avatar(r.owner_avatar_url, r.owner_display_name, 44)}<div class="live-dot" style="position:absolute;bottom:-1px;right:-1px"></div></div><div style="min-width:0"><div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:3px">${r.name ? `<span style="font-weight:600;font-size:15px">${esc(r.name)}</span>` : ''}${tagHTML(r.tag)}</div><div style="font-size:13px;color:var(--text-tertiary)">${esc(r.owner_display_name)} · ${r.member_count}/${r.max_members||20}${t('voice.members')}</div></div></div><div class="voice-wave"><span></span><span></span><span></span><span></span><span></span></div></div></div>`).join(''); }

function showCreateRoomModal() {
  if (!S.user) return navigate('/login');
  const tags = ['recruit','sleep','game','chat','music','study'];
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:18px">${t('voice.create')}</h3><div style="margin-bottom:16px"><input type="text" id="cr-name" class="input" placeholder="${t('voice.name_placeholder')}" maxlength="50"></div><div style="margin-bottom:22px"><div style="display:flex;flex-wrap:wrap;gap:7px" id="cr-tags">${tags.map(tg => `<button class="pill" data-tag="${tg}" onclick="this.classList.toggle('active');$$('#cr-tags .pill').forEach(p=>p!==this&&p.classList.remove('active'))">${t('tag.'+tg)}</button>`).join('')}</div></div><div style="display:flex;gap:12px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="createVoiceRoom()">${t('voice.create')}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function createVoiceRoom() { const name = $('#cr-name')?.value.trim(); const activeTag = $('#cr-tags .pill.active'); const tag = activeTag ? activeTag.dataset.tag : ''; const res = await api('/api/voice-rooms', { method: 'POST', body: { name, tag } }); if (res.success) { $('.modal-overlay')?.remove(); navigate('/voice/' + res.room_id); } else toast(res.error || 'Error', 'error'); }
async function checkMyVoiceRoom() { const res = await api('/api/my-voice-room'); if (res.room) { S.voiceRoomId = res.room.id; const bar = $('#vr-current-bar'); if (bar) { bar.style.display = 'block'; bar.innerHTML = `<div style="margin:14px 24px;padding:16px;border-radius:var(--radius-md);background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);display:flex;align-items:center;justify-content:space-between" class="anim-fade-up"><div style="display:flex;align-items:center;gap:12px"><div class="voice-wave"><span></span><span></span><span></span></div><div><div style="font-size:14px;font-weight:600">${res.room.name?esc(res.room.name):t('voice.in_room')}</div><div style="font-size:12px;color:var(--text-tertiary)">${res.room.member_count}${t('voice.members')}</div></div></div><a href="/voice/${res.room.id}" class="btn btn-primary btn-sm">${S.lang==='ja'?'戻る':'Return'}</a></div>`; } } }

// ===== Voice Room Detail with WebSocket Chat + Whiteboard =====
let vrActivePanel = 'chat';
async function pageVoiceRoom(el, id) {
  el.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`;
  const res = await api(`/api/voice-rooms/${id}`);
  if (res.error || !res.room) { el.innerHTML = `<div style="padding:60px 24px;text-align:center;color:var(--text-tertiary)"><p style="font-family:'Cormorant Garamond',serif;font-size:22px;margin-bottom:8px">${S.lang==='ja'?'ルームが終了しました':'Room ended'}</p><a href="/voice" class="btn btn-secondary" style="margin-top:16px">${t('voice.rooms')}</a></div>`; return; }
  renderVoiceRoomUI(el, id, res.room, res.members || []);
  if (S.voicePollId) clearInterval(S.voicePollId);
  S.voicePollId = setInterval(async () => {
    if (S.currentPage !== 'voiceRoom') { clearInterval(S.voicePollId); return; }
    try { const r = await api(`/api/voice-rooms/${id}`); if (r.room && r.members) { updateVoiceMembers(r.members, r.room); if (S.peer && S.voiceStream) connectToNewPeers(r.members); } } catch(e) {}
  }, 2000);
}

function renderVoiceRoomUI(el, id, room, members) {
  const isIn = S.user && members.some(m => m.id === S.user.id);
  const myMember = isIn ? members.find(m => m.id === S.user.id) : null;
  const maxM = room.max_members || 20;
  const isOwnerOrSub = myMember && (myMember.role === 'owner' || myMember.role === 'sub_owner');
  el.innerHTML = `
    <div style="display:flex;flex-direction:column;height:100dvh">
      <div class="page-header" style="padding:12px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0"><button class="btn-icon" onclick="navigate('/voice')" style="width:36px;height:36px"><i class="fas fa-arrow-left"></i></button><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:15px">${room.name ? esc(room.name) : (S.lang==='ja'?'無題':'Untitled')}</div><div style="font-size:11px;color:var(--text-tertiary);display:flex;align-items:center;gap:5px"><div class="live-dot" style="width:6px;height:6px"></div><span id="vr-count">${members.length}</span>/${maxM}</div></div>${S.user ? (isIn ? `<button class="btn btn-danger btn-xs" onclick="leaveVoiceRoom('${id}')">${t('voice.leave')}</button>` : `<button class="btn btn-primary btn-sm" onclick="joinVoiceRoom('${id}')">${t('voice.join')}</button>`) : ''}</div>
      <div style="padding:16px;flex-shrink:0" class="anim-fade-up"><div id="voice-members" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(76px,1fr));gap:14px;justify-items:center">${renderVoiceMembersList(members, room, isIn, isOwnerOrSub)}</div></div>
      ${isIn ? `
      <div style="display:flex;align-items:center;justify-content:center;gap:14px;padding:10px;border-top:1px solid var(--border);flex-shrink:0">
        <button id="vr-mute-btn" class="btn-icon" style="width:48px;height:48px;background:${myMember?.is_muted?'rgba(200,85,61,0.06)':'var(--bg-elevated)'};border:1px solid ${myMember?.is_muted?'rgba(200,85,61,0.1)':'var(--border)'}" onclick="toggleVoiceMute('${id}')"><i class="fas ${myMember?.is_muted?'fa-microphone-slash':'fa-microphone'}" style="font-size:17px;color:${myMember?.is_muted?'var(--accent)':'var(--text-primary)'}"></i></button>
        <button class="btn-icon" style="width:48px;height:48px;background:rgba(200,85,61,0.06);border:1px solid rgba(200,85,61,0.1)" onclick="leaveVoiceRoom('${id}')"><i class="fas fa-phone-slash" style="font-size:15px;color:var(--accent)"></i></button>
      </div>
      <div class="vr-panel-tabs" style="flex-shrink:0"><div class="vr-panel-tab ${vrActivePanel==='chat'?'active':''}" onclick="switchVRPanel('chat','${id}')">${t('voice.chat')}</div><div class="vr-panel-tab ${vrActivePanel==='whiteboard'?'active':''}" onclick="switchVRPanel('whiteboard','${id}')">${t('voice.whiteboard')}</div><div class="vr-panel-tab ${vrActivePanel==='music'?'active':''}" onclick="switchVRPanel('music','${id}')">${t('voice.music')}</div></div>
      <div id="vr-panel-content" style="flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden"></div>
      ` : `<div style="flex:1"></div>`}
      <div id="remote-audio-container" style="display:none"></div>
    </div>`;
  if (isIn) { S.voiceRoomId = id; initVoiceWebRTC(id, members); switchVRPanel(vrActivePanel, id); }
}

function switchVRPanel(panel, roomId) {
  vrActivePanel = panel;
  $$('.vr-panel-tab').forEach((t2, i) => t2.classList.toggle('active', (panel === 'chat' && i === 0) || (panel === 'whiteboard' && i === 1) || (panel === 'music' && i === 2)));
  const content = $('#vr-panel-content'); if (!content) return;
  if (S.vrChatPoll) { clearInterval(S.vrChatPoll); S.vrChatPoll = null; }
  disconnectWS();
  if (panel === 'chat') renderVRChat(content, roomId);
  else if (panel === 'whiteboard') renderVRWhiteboard(content, roomId);
  else if (panel === 'music') renderVRMusic(content, roomId);
}

// VR Chat - WebSocket powered
let lastVRChatTs = null;
function renderVRChat(container, roomId) {
  container.innerHTML = `<div class="vr-chat-area" id="vr-chat-msgs" style="flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:4px"></div><div class="vr-chat-input" style="padding:10px 12px;display:flex;gap:8px;align-items:flex-end;border-top:1px solid var(--border)"><textarea id="vr-chat-input" class="input" style="flex:1;min-height:36px;max-height:80px;padding:8px 14px;font-size:13px;border-radius:20px" placeholder="${S.lang==='ja'?'メッセージ...':'Message...'}" rows="1"></textarea><button class="btn btn-primary" style="width:36px;height:36px;border-radius:50%;padding:0" onclick="sendVRChat('${roomId}')"><i class="fas fa-paper-plane" style="font-size:11px"></i></button></div>`;
  loadVRChat(roomId);
  connectWS('vr:' + roomId);
  const input = $('#vr-chat-input');
  if (input) input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendVRChat(roomId); } });
  // Fallback polling (slow, only if WS fails)
  S.vrChatPoll = setInterval(() => { if (!S.ws || S.ws.readyState !== 1) pollVRChat(roomId); }, 3000);
}
async function loadVRChat(roomId) { const msgsEl = $('#vr-chat-msgs'); if (!msgsEl) return; const res = await api(`/api/voice-rooms/${roomId}/messages`); const msgs = res.messages || []; lastVRChatTs = msgs.length > 0 ? msgs[msgs.length - 1].created_at : null; msgsEl.innerHTML = msgs.map(m => renderVRChatMsg(m)).join('') || `<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-tertiary);font-size:13px">${S.lang==='ja'?'チャットを始めよう':'Start chatting'}</div>`; msgsEl.scrollTop = msgsEl.scrollHeight; }
function renderVRChatMsg(m) { const mine = m.sender_id === S.user?.id; const isOfficial = m.sender_is_official || (mine && S.user?.is_official); const officialMark = isOfficial ? '<span class="official-badge" style="font-size:10px;margin-left:3px" title="Official"><i class="fas fa-check-circle"></i></span>' : ''; return `<div style="display:flex;gap:8px;padding:4px 0;animation:msg-pop 0.2s ease-out"><div style="flex-shrink:0">${avatar(m.sender_avatar_url, m.sender_display_name, 24)}</div><div style="min-width:0"><span style="font-size:12px;font-weight:600;color:${mine?'var(--accent)':'var(--text-primary)'};margin-right:3px">${esc(m.sender_display_name)}</span>${officialMark}<span style="font-size:13px;color:var(--text-secondary);margin-left:4px">${esc(m.content)}</span></div></div>`; }
function appendVRChatMessage(m) { const msgsEl = $('#vr-chat-msgs'); if (!msgsEl) return; if (msgsEl.querySelector('div[style*="justify-content:center"]')) msgsEl.innerHTML = ''; const div = h('div', '', renderVRChatMsg(m)); msgsEl.appendChild(div.firstElementChild); msgsEl.scrollTop = msgsEl.scrollHeight; if (m.created_at > (lastVRChatTs || '')) lastVRChatTs = m.created_at; }
async function sendVRChat(roomId) {
  const input = $('#vr-chat-input'); const content = input?.value.trim(); if (!content) return; input.value = '';
  requestAnimationFrame(() => { if (input) input.focus(); });
  const now = new Date().toISOString();
  // Optimistic UI update
  appendVRChatMessage({ sender_id: S.user.id, sender_display_name: S.user.display_name, sender_avatar_url: S.user.avatar_url, sender_is_official: S.user.is_official || 0, content, created_at: now });
  lastVRChatTs = now;
  // Send via WebSocket if available, otherwise API
  if (!sendWS({ type: 'chat', content })) {
    await api(`/api/voice-rooms/${roomId}/messages`, { method: 'POST', body: { content } });
  }
}
async function pollVRChat(roomId) { if (S.currentPage !== 'voiceRoom' || vrActivePanel !== 'chat' || !lastVRChatTs) return; try { const res = await api(`/api/sse/vr/${roomId}?after=${encodeURIComponent(lastVRChatTs)}`); if (res.messages) res.messages.forEach(m => { if (m.sender_id !== S.user.id) appendVRChatMessage(m); }); } catch {} }

// ===== VR Whiteboard with Zoom/Pan + WebSocket =====
let wbCanvas, wbCtx, wbDrawing = false, wbColor = '#c8553d', wbWidth = 3, wbTool = 'pen', wbLastX, wbLastY, wbCurrentStroke = [];
function renderVRWhiteboard(container, roomId) {
  S.wbZoom = 1; S.wbPanX = 0; S.wbPanY = 0;
  container.innerHTML = `<div class="wb-toolbar">
    <div class="wb-tool ${wbTool==='pen'?'active':''}" onclick="setWBTool('pen')"><i class="fas fa-pen"></i></div>
    <div class="wb-tool ${wbTool==='eraser'?'active':''}" onclick="setWBTool('eraser')"><i class="fas fa-eraser"></i></div>
    <div class="wb-tool" onclick="setWBTool('pan')" id="wb-pan-tool"><i class="fas fa-arrows-up-down-left-right"></i></div>
    ${['#c8553d','#5b8fa8','#6b8f71','#c2b280','#8b7eb8','#1a1a2e','#ffffff'].map(c => `<div class="wb-tool" style="background:${c};width:20px;height:20px;border-radius:50%;border:2px solid ${wbColor===c?'var(--text-primary)':'var(--border)'}" onclick="setWBColor('${c}',this)"></div>`).join('')}
    <select onchange="wbWidth=+this.value" style="background:var(--bg-elevated);color:var(--text-primary);border:1px solid var(--border);border-radius:var(--radius-sm);padding:3px 8px;font-size:12px;margin-left:auto"><option value="2">${S.lang==='ja'?'細':'Thin'}</option><option value="3" selected>${S.lang==='ja'?'普通':'Med'}</option><option value="6">${S.lang==='ja'?'太':'Thick'}</option><option value="10">${S.lang==='ja'?'極太':'Bold'}</option></select>
    <div style="display:flex;gap:2px;margin-left:4px"><button class="wb-tool" onclick="wbZoomIn()" title="Zoom In"><i class="fas fa-search-plus" style="font-size:12px"></i></button><button class="wb-tool" onclick="wbZoomOut()" title="Zoom Out"><i class="fas fa-search-minus" style="font-size:12px"></i></button><button class="wb-tool" onclick="wbResetView()" title="Reset"><i class="fas fa-expand" style="font-size:12px"></i></button></div>
    <button class="wb-tool" onclick="clearWhiteboard('${roomId}')" title="Clear"><i class="fas fa-trash" style="color:var(--accent)"></i></button>
  </div>
  <div style="flex:1;overflow:hidden;position:relative;background:#faf5ef" id="wb-container"><canvas id="wb-canvas" style="cursor:crosshair;touch-action:none;transform-origin:0 0"></canvas></div>
  <div style="padding:4px 10px;font-size:11px;color:var(--text-tertiary);display:flex;justify-content:space-between;border-top:1px solid var(--border)"><span id="wb-zoom-label">100%</span><span>${S.lang==='ja'?'ピンチ操作/スクロールでズーム':'Pinch/scroll to zoom'}</span></div>`;
  setTimeout(() => initWhiteboard(roomId), 100);
}

function initWhiteboard(roomId) {
  wbCanvas = document.getElementById('wb-canvas'); if (!wbCanvas) return;
  const container = document.getElementById('wb-container');
  const dpr = window.devicePixelRatio || 1;
  // Use a large virtual canvas
  const vw = 1600, vh = 1200;
  wbCanvas.width = vw * dpr;
  wbCanvas.height = vh * dpr;
  wbCanvas.style.width = vw + 'px';
  wbCanvas.style.height = vh + 'px';
  wbCtx = wbCanvas.getContext('2d');
  wbCtx.scale(dpr, dpr);
  wbCtx.lineCap = 'round'; wbCtx.lineJoin = 'round';
  applyWBTransform();
  
  // Connect WebSocket for whiteboard
  connectWS('wb:' + roomId);
  
  // Load existing strokes
  api(`/api/voice-rooms/${roomId}/whiteboard`).then(res => { (res.strokes || []).forEach(s => { try { drawStroke(JSON.parse(s.stroke_data), s.color, s.width, s.tool); } catch(e){} }); });
  
  const getPos = e => {
    const r = wbCanvas.getBoundingClientRect();
    const t2 = e.touches ? e.touches[0] : e;
    // Account for zoom and pan
    return { x: (t2.clientX - r.left) / S.wbZoom, y: (t2.clientY - r.top) / S.wbZoom };
  };
  
  let panStartX, panStartY, panStartPanX, panStartPanY;
  
  const start = e => {
    if (wbTool === 'pan') {
      S.wbIsPanning = true;
      const t2 = e.touches ? e.touches[0] : e;
      panStartX = t2.clientX; panStartY = t2.clientY;
      panStartPanX = S.wbPanX; panStartPanY = S.wbPanY;
      e.preventDefault(); return;
    }
    e.preventDefault(); wbDrawing = true; const p = getPos(e); wbLastX = p.x; wbLastY = p.y; wbCurrentStroke = [p];
  };
  const move = e => {
    if (S.wbIsPanning) {
      const t2 = e.touches ? e.touches[0] : e;
      S.wbPanX = panStartPanX + (t2.clientX - panStartX);
      S.wbPanY = panStartPanY + (t2.clientY - panStartY);
      applyWBTransform(); e.preventDefault(); return;
    }
    if (!wbDrawing) return; e.preventDefault();
    const p = getPos(e);
    wbCtx.strokeStyle = wbTool === 'eraser' ? '#faf5ef' : wbColor;
    wbCtx.lineWidth = wbTool === 'eraser' ? wbWidth * 4 : wbWidth;
    wbCtx.beginPath(); wbCtx.moveTo(wbLastX, wbLastY); wbCtx.lineTo(p.x, p.y); wbCtx.stroke();
    wbLastX = p.x; wbLastY = p.y; wbCurrentStroke.push(p);
  };
  const end = () => {
    if (S.wbIsPanning) { S.wbIsPanning = false; return; }
    if (!wbDrawing) return; wbDrawing = false;
    if (wbCurrentStroke.length > 1) {
      const strokeData = JSON.stringify(wbCurrentStroke);
      // Send via WebSocket
      if (!sendWS({ type: 'stroke', stroke_data: strokeData, color: wbColor, width: wbWidth, tool: wbTool })) {
        api(`/api/voice-rooms/${roomId}/whiteboard`, { method: 'POST', body: { stroke_data: strokeData, color: wbColor, width: wbWidth, tool: wbTool } });
      }
    }
    wbCurrentStroke = [];
  };
  
  wbCanvas.addEventListener('mousedown', start); wbCanvas.addEventListener('mousemove', move);
  wbCanvas.addEventListener('mouseup', end); wbCanvas.addEventListener('mouseleave', end);
  wbCanvas.addEventListener('touchstart', start, { passive: false });
  wbCanvas.addEventListener('touchmove', move, { passive: false });
  wbCanvas.addEventListener('touchend', end);
  
  // Wheel zoom
  container.addEventListener('wheel', e => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    S.wbZoom = Math.max(0.25, Math.min(3, S.wbZoom + delta));
    applyWBTransform();
  }, { passive: false });
  
  // Pinch zoom
  let lastPinchDist = 0;
  container.addEventListener('touchstart', e => { if (e.touches.length === 2) { lastPinchDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); } }, { passive: true });
  container.addEventListener('touchmove', e => {
    if (e.touches.length === 2) {
      e.preventDefault();
      const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      if (lastPinchDist > 0) {
        const scale = dist / lastPinchDist;
        S.wbZoom = Math.max(0.25, Math.min(3, S.wbZoom * scale));
        applyWBTransform();
      }
      lastPinchDist = dist;
    }
  }, { passive: false });
}

function applyWBTransform() {
  if (!wbCanvas) return;
  wbCanvas.style.transform = `translate(${S.wbPanX}px, ${S.wbPanY}px) scale(${S.wbZoom})`;
  const label = $('#wb-zoom-label');
  if (label) label.textContent = Math.round(S.wbZoom * 100) + '%';
}
function wbZoomIn() { S.wbZoom = Math.min(3, S.wbZoom + 0.2); applyWBTransform(); }
function wbZoomOut() { S.wbZoom = Math.max(0.25, S.wbZoom - 0.2); applyWBTransform(); }
function wbResetView() { S.wbZoom = 1; S.wbPanX = 0; S.wbPanY = 0; applyWBTransform(); }

function drawStroke(points, color, width, tool) {
  if (!wbCtx || !points || points.length < 2) return;
  wbCtx.strokeStyle = tool === 'eraser' ? '#faf5ef' : color;
  wbCtx.lineWidth = tool === 'eraser' ? width * 4 : width;
  wbCtx.beginPath(); wbCtx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) wbCtx.lineTo(points[i].x, points[i].y);
  wbCtx.stroke();
}
function setWBTool(tool) { wbTool = tool; $$('.wb-tool').forEach((t2, i) => { if (i < 3) t2.classList.toggle('active', (tool === 'pen' && i === 0) || (tool === 'eraser' && i === 1) || (tool === 'pan' && i === 2)); }); wbCanvas && (wbCanvas.style.cursor = tool === 'pan' ? 'grab' : 'crosshair'); }
function setWBColor(c) { wbColor = c; wbTool = 'pen'; setWBTool('pen'); }
async function clearWhiteboard(roomId) { if (!wbCtx) return; const dpr = window.devicePixelRatio || 1; wbCtx.clearRect(0, 0, wbCanvas.width / dpr, wbCanvas.height / dpr); sendWS({ type: 'wb_clear' }); await api(`/api/voice-rooms/${roomId}/whiteboard`, { method: 'DELETE' }); }

// VR Music
function renderVRMusic(container, roomId) { container.innerHTML = `<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;text-align:center"><i class="fas fa-music" style="font-size:40px;color:var(--accent);margin-bottom:16px;opacity:0.5"></i><p style="font-size:15px;font-weight:600;margin-bottom:20px">${S.lang==='ja'?'音楽を再生':'Play Music'}</p><label class="btn btn-primary btn-sm" style="cursor:pointer"><i class="fas fa-folder-open" style="margin-right:6px"></i>${S.lang==='ja'?'MP3を選択':'Select MP3'}<input type="file" accept="audio/*" style="display:none" onchange="loadMusicFile(this,'${roomId}')"></label><div id="music-player-area" style="width:100%;margin-top:20px;display:none"><div id="music-title" style="font-size:13px;font-weight:600;margin-bottom:10px"></div><div style="display:flex;align-items:center;gap:12px"><button id="music-play-btn" onclick="toggleMusic()" class="btn-icon" style="width:42px;height:42px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.1)"><i class="fas fa-play" style="color:var(--accent)"></i></button><div style="flex:1"><input type="range" id="music-volume" min="0" max="100" value="50" oninput="setMusicVolume(this.value)" style="width:100%"></div><span id="music-vol-label" style="font-size:12px;color:var(--text-tertiary);min-width:28px">50%</span></div></div></div>`; }
function loadMusicFile(input) { const f = input.files[0]; if (!f) return; const url = URL.createObjectURL(f); if (S.musicAudio) S.musicAudio.pause(); S.musicAudio = new Audio(url); S.musicAudio.volume = 0.5; S.musicAudio.loop = true; S.musicPlaying = false; const area = $('#music-player-area'); if (area) area.style.display = 'block'; const title = $('#music-title'); if (title) title.textContent = f.name; }
function toggleMusic() { if (!S.musicAudio) return; if (S.musicPlaying) { S.musicAudio.pause(); S.musicPlaying = false; } else { S.musicAudio.play().catch(()=>{}); S.musicPlaying = true; } const btn = $('#music-play-btn'); if (btn) btn.innerHTML = `<i class="fas ${S.musicPlaying?'fa-pause':'fa-play'}" style="color:var(--accent)"></i>`; }
function setMusicVolume(val) { if (S.musicAudio) S.musicAudio.volume = val / 100; const label = $('#music-vol-label'); if (label) label.textContent = val + '%'; }

// Voice members
function renderVoiceMembersList(members, room, isIn, isOwnerOrSub) { return members.map(m => { const roleIcon = m.role === 'owner' ? '<i class="fas fa-crown" style="font-size:8px;color:var(--sand)"></i>' : m.role === 'sub_owner' ? '<i class="fas fa-shield-halved" style="font-size:8px;color:var(--sky)"></i>' : ''; const ctx = isOwnerOrSub && m.id !== S.user?.id && m.role !== 'owner' ? `onclick="event.stopPropagation();showMemberMenu('${room.id}','${m.id}','${m.role}','${esc(m.display_name)}')"` : ''; return `<div style="display:flex;flex-direction:column;align-items:center;gap:4px;cursor:${ctx?'pointer':'default'}" ${ctx}><div style="position:relative"><div class="${!m.is_muted && isIn?'speaking':''}" style="border-radius:50%">${avatar(m.avatar_url, m.display_name, 48)}</div>${m.is_muted ? `<div style="position:absolute;bottom:-2px;right:-2px;width:18px;height:18px;border-radius:50%;background:var(--bg-secondary);display:flex;align-items:center;justify-content:center"><i class="fas fa-microphone-slash" style="font-size:8px;color:var(--accent)"></i></div>` : ''}${roleIcon ? `<div style="position:absolute;top:-2px;right:-2px;width:18px;height:18px;border-radius:50%;background:var(--bg-secondary);display:flex;align-items:center;justify-content:center">${roleIcon}</div>` : ''}</div><span style="font-size:11px;color:var(--text-secondary);max-width:76px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.display_name)}</span></div>`; }).join(''); }
function showMemberMenu(roomId, userId, currentRole, displayName) { const ov = h('div', 'modal-overlay'); ov.innerHTML = `<div class="modal-content" style="padding:20px;max-width:300px" onclick="event.stopPropagation()"><h3 style="font-weight:600;font-size:15px;margin-bottom:14px">${esc(displayName)}</h3><div style="display:flex;flex-direction:column;gap:6px"><button class="btn btn-secondary" style="width:100%;text-align:left" onclick="forceMuteUser('${roomId}','${userId}');this.closest('.modal-overlay').remove()">${S.lang==='ja'?'強制ミュート':'Force Mute'}</button><button class="btn btn-danger" style="width:100%;text-align:left" onclick="forceKickUser('${roomId}','${userId}');this.closest('.modal-overlay').remove()">${S.lang==='ja'?'強制退出':'Kick'}</button>${currentRole !== 'sub_owner' ? `<button class="btn btn-secondary" style="width:100%;text-align:left" onclick="setUserRole('${roomId}','${userId}','sub_owner');this.closest('.modal-overlay').remove()">${S.lang==='ja'?'サブオーナーに昇格':'Sub-Owner'}</button>` : `<button class="btn btn-secondary" style="width:100%;text-align:left" onclick="setUserRole('${roomId}','${userId}','member');this.closest('.modal-overlay').remove()">${S.lang==='ja'?'メンバーに降格':'Demote'}</button>`}<button class="btn btn-secondary" style="width:100%;text-align:left" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button></div></div>`; ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov); }
async function forceMuteUser(roomId, userId) { await api(`/api/voice-rooms/${roomId}/force-mute`, { method: 'POST', body: { target_user_id: userId } }); toast(S.lang==='ja'?'ミュートしました':'Muted'); }
async function forceKickUser(roomId, userId) { await api(`/api/voice-rooms/${roomId}/force-kick`, { method: 'POST', body: { target_user_id: userId } }); toast(S.lang==='ja'?'退出させました':'Kicked'); }
async function setUserRole(roomId, userId, role) { await api(`/api/voice-rooms/${roomId}/set-role`, { method: 'POST', body: { target_user_id: userId, role } }); toast(S.lang==='ja'?'ロール変更':'Role changed'); }
async function requestUnmute(roomId) { const res = await api(`/api/voice-rooms/${roomId}/unmute-request`, { method: 'POST' }); if (res.success) toast(S.lang==='ja'?'リクエスト送信':'Request sent', 'info'); else toast(res.error || 'Error', 'error'); }
function updateVoiceMembers(members, room) { const el = $('#voice-members'); if (!el) return; const isIn = S.user && members.some(m => m.id === S.user.id); const myM = isIn ? members.find(m => m.id === S.user.id) : null; const isOwnerOrSub = myM && (myM.role === 'owner' || myM.role === 'sub_owner'); el.innerHTML = renderVoiceMembersList(members, room, isIn, isOwnerOrSub); const countEl = $('#vr-count'); if (countEl) countEl.textContent = members.length; if (S.voiceRoomId === room.id && !isIn && S.voiceStream) { cleanupVoice(); S.voiceRoomId = null; toast(S.lang==='ja'?'退出させられました':'Kicked', 'error'); playLeaveSound(); navigate('/voice'); } }

// WebRTC Voice
async function initVoiceWebRTC(roomId, existingMembers) {
  cleanupVoice(); playJoinSound();
  try { const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); S.voiceStream = stream; if (vrMuted) stream.getAudioTracks().forEach(t2 => t2.enabled = false); const myPeerId = 'sat_' + S.user.id + '_' + Date.now(); S.peer = new Peer(myPeerId, { config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] } }); S.peer.on('open', async (id) => { await api(`/api/voice-rooms/${roomId}/peer`, { method: 'POST', body: { peer_id: id } }); connectToNewPeers(existingMembers); }); S.peer.on('call', (call) => { call.answer(stream); handleRemoteStream(call); }); S.peer.on('error', () => {}); } catch { toast(S.lang==='ja'?'マイクアクセスが拒否されました':'Mic denied', 'error'); }
}
function connectToNewPeers(members) { if (!S.peer || !S.voiceStream) return; members.forEach(m => { if (m.id === S.user.id || !m.peer_id || S.peerConnections[m.peer_id]) return; const call = S.peer.call(m.peer_id, S.voiceStream); if (call) handleRemoteStream(call); }); }
function handleRemoteStream(call) { S.peerConnections[call.peer] = call; call.on('stream', (rs) => { if (S.remoteAudios[call.peer]) { S.remoteAudios[call.peer].srcObject = rs; return; } const audio = document.createElement('audio'); audio.srcObject = rs; audio.autoplay = true; audio.playsInline = true; S.remoteAudios[call.peer] = audio; const container = $('#remote-audio-container'); if (container) container.appendChild(audio); audio.play().catch(() => {}); }); call.on('close', () => { if (S.remoteAudios[call.peer]) { S.remoteAudios[call.peer].remove(); delete S.remoteAudios[call.peer]; } delete S.peerConnections[call.peer]; }); }
function cleanupVoice() { if (S.voiceStream) { S.voiceStream.getTracks().forEach(t2 => t2.stop()); S.voiceStream = null; } Object.values(S.peerConnections).forEach(c => { try { c.close(); } catch{} }); S.peerConnections = {}; Object.values(S.remoteAudios).forEach(a => { try { a.remove(); } catch{} }); S.remoteAudios = {}; if (S.peer) { try { S.peer.destroy(); } catch{} S.peer = null; } if (S.musicAudio) { S.musicAudio.pause(); S.musicAudio = null; S.musicPlaying = false; } }
async function joinVoiceRoom(id) { if (!S.user) return navigate('/login'); const res = await api(`/api/voice-rooms/${id}/join`, { method: 'POST' }); if (res.success) { S.voiceRoomId = id; pageVoiceRoom($('#page'), id); } else toast(res.error || 'Error', 'error'); }
async function leaveVoiceRoom(id) { cleanupVoice(); playLeaveSound(); cleanupPolling(); disconnectWS(); await api(`/api/voice-rooms/${id}/leave`, { method: 'POST' }); S.voiceRoomId = null; S.voiceBubbleVisible = false; removeVoiceBubble(); navigate('/voice'); }

// ===== FLOATING VOICE BUBBLE =====
function showVoiceBubble(roomId, roomName) {
  S.voiceBubbleVisible = true;
  let bubble = document.getElementById('voice-bubble');
  if (!bubble) {
    bubble = document.createElement('div');
    bubble.id = 'voice-bubble';
    bubble.className = 'voice-bubble anim-scale-in';
    document.body.appendChild(bubble);
  }
  bubble.innerHTML = `
    <div class="voice-bubble-inner" onclick="navigate('/voice/${roomId}')">
      <div class="voice-bubble-wave"><span></span><span></span><span></span></div>
      <div class="voice-bubble-info">
        <div style="font-size:11px;font-weight:700;max-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(roomName || (S.lang==='ja'?'通話中':'In Call'))}</div>
      </div>
    </div>
    <button class="voice-bubble-close" onclick="event.stopPropagation();leaveVoiceRoom('${roomId}')"><i class="fas fa-phone-slash" style="font-size:10px"></i></button>
  `;
  // Make draggable
  makeDraggable(bubble);
}
function removeVoiceBubble() {
  const bubble = document.getElementById('voice-bubble');
  if (bubble) { bubble.style.animation = 'scale-out 0.2s ease forwards'; setTimeout(() => bubble.remove(), 200); }
  S.voiceBubbleVisible = false;
}
function makeDraggable(el) {
  let startX, startY, startLeft, startTop, dragging = false;
  el.addEventListener('touchstart', (e) => {
    if (e.target.closest('.voice-bubble-close')) return;
    const t = e.touches[0];
    startX = t.clientX; startY = t.clientY;
    const rect = el.getBoundingClientRect();
    startLeft = rect.left; startTop = rect.top;
    dragging = true;
  }, { passive: true });
  el.addEventListener('touchmove', (e) => {
    if (!dragging) return;
    const t = e.touches[0];
    const dx = t.clientX - startX, dy = t.clientY - startY;
    el.style.left = (startLeft + dx) + 'px';
    el.style.top = (startTop + dy) + 'px';
    el.style.right = 'auto';
    el.style.bottom = 'auto';
  }, { passive: true });
  el.addEventListener('touchend', () => { dragging = false; }, { passive: true });
}
let vrMuted = false;
async function toggleVoiceMute(id) { vrMuted = !vrMuted; const btn = $('#vr-mute-btn'); if (btn) { btn.style.background = vrMuted ? 'rgba(200,85,61,0.06)' : 'var(--bg-elevated)'; btn.innerHTML = `<i class="fas ${vrMuted?'fa-microphone-slash':'fa-microphone'}" style="font-size:17px;color:${vrMuted?'var(--accent)':'var(--text-primary)'}"></i>`; } if (S.voiceStream) S.voiceStream.getAudioTracks().forEach(t2 => t2.enabled = !vrMuted); await api(`/api/voice-rooms/${id}/mute`, { method: 'POST', body: { muted: vrMuted } }); }

