const CACHE_VER = 'v12';
const STATIC_CACHE = 'smog-static-' + CACHE_VER;
const SHELL_CACHE = 'smog-shell-' + CACHE_VER;
const DATA_CACHE = 'smog-data-' + CACHE_VER;
const LAZY_CACHE = 'smog-lazy-' + CACHE_VER;

const PRECACHE = [
  '/static/styles.css',
  '/static/app.js',
  '/static/icon-192.png'
];

const OFFLINE_HTML = `<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#fafaf8"><title>さとっち - オフライン</title><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#fafaf8;color:#1a1a2e;font-family:system-ui,sans-serif;min-height:100dvh;display:flex;align-items:center;justify-content:center;padding:32px}.c{text-align:center;max-width:360px;animation:f .6s ease both}.i{width:88px;height:88px;border-radius:24px;background:rgba(200,85,61,.06);display:flex;align-items:center;justify-content:center;margin:0 auto 28px}h1{font-size:28px;font-weight:700;margin-bottom:10px}p{font-size:15px;color:rgba(26,26,46,.45);line-height:1.7;margin-bottom:28px}button{background:#c8553d;color:#fff;border:none;padding:14px 36px;border-radius:9999px;font-size:15px;font-weight:600;cursor:pointer}@keyframes f{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}</style></head><body><div class="c"><div class="i"><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#c8553d" stroke-width="1.8"><path d="M1 1l22 22"/><path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"/><path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"/><path d="M10.71 5.05A16 16 0 0 1 22.56 9"/><path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg></div><h1>オフラインです</h1><p>接続を確認してもう一度お試しください。</p><button onclick="location.reload()">再試行</button></div></body></html>`;

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(STATIC_CACHE).then(async (c) => {
      await c.addAll(PRECACHE);
      await c.put('/offline', new Response(OFFLINE_HTML, { headers: { 'Content-Type': 'text/html' } }));
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k.startsWith('smog-') && k !== STATIC_CACHE && k !== SHELL_CACHE && k !== DATA_CACHE && k !== LAZY_CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);

  // Static JS/CSS: stale-while-revalidate (instant from cache + background update)
  if (url.pathname.startsWith('/static/') && (url.pathname.endsWith('.js') || url.pathname.endsWith('.css'))) {
    e.respondWith(
      caches.match(e.request).then(cached => {
        const fetchPromise = fetch(e.request).then(res => {
          if (res.ok) { const clone = res.clone(); caches.open(STATIC_CACHE).then(c => c.put(e.request, clone)); }
          return res;
        }).catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Static images/sounds: cache-first (immutable)
  if (url.pathname.startsWith('/static/')) {
    e.respondWith(
      caches.match(e.request).then(r => r || fetch(e.request).then(res => {
        if (res.ok) { const clone = res.clone(); caches.open(STATIC_CACHE).then(c => c.put(e.request, clone)); }
        return res;
      }).catch(() => caches.match('/offline')))
    );
    return;
  }

  // CDN/fonts: cache-first with background update
  if (url.hostname.includes('cdn.') || url.hostname.includes('fonts.') || url.hostname.includes('unpkg.com')) {
    e.respondWith(
      caches.match(e.request).then(cached => {
        const fetchPromise = fetch(e.request).then(res => {
          if (res.ok) { const clone = res.clone(); caches.open(SHELL_CACHE).then(c => c.put(e.request, clone)); }
          return res;
        }).catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Manifest
  if (url.pathname === '/manifest.json') {
    e.respondWith(
      caches.match(e.request).then(cached => {
        const fetchPromise = fetch(e.request).then(res => {
          if (res.ok) { const clone = res.clone(); caches.open(SHELL_CACHE).then(c => c.put(e.request, clone)); }
          return res;
        }).catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  // SPA pages: network-first with 3s timeout, fallback to cached shell
  if (url.pathname === '/' || (!url.pathname.startsWith('/api/') && !url.pathname.startsWith('/static/') && !url.pathname.includes('.'))) {
    e.respondWith(
      Promise.race([
        fetch(e.request).then(res => {
          if (res.ok) { const clone = res.clone(); caches.open(SHELL_CACHE).then(c => c.put('/', clone)); }
          return res;
        }),
        new Promise((_, reject) => setTimeout(reject, 3000))
      ]).catch(() => caches.match('/').then(r => r || caches.match('/offline')))
    );
    return;
  }

  // API: network-first with offline fallback
  if (url.pathname.startsWith('/api/') && !url.pathname.includes('/ws') && !url.pathname.includes('/sse/')) {
    const cacheable = ['/api/me', '/api/posts', '/api/notifications', '/api/voice-rooms', '/api/crews', '/api/casino/leaderboard'];
    const shouldCache = cacheable.some(p => url.pathname.startsWith(p));
    e.respondWith(
      fetch(e.request).then(res => {
        if (res.ok && shouldCache) { const clone = res.clone(); caches.open(DATA_CACHE).then(c => c.put(e.request, clone)); }
        return res;
      }).catch(() => shouldCache ? caches.match(e.request) : new Response(JSON.stringify({error:'offline'}), {headers:{'Content-Type':'application/json'}}))
    );
    return;
  }
});
