-- Add music metadata columns to posts
ALTER TABLE posts ADD COLUMN music_title TEXT DEFAULT '';
ALTER TABLE posts ADD COLUMN music_artist TEXT DEFAULT '';
ALTER TABLE posts ADD COLUMN music_thumb TEXT DEFAULT '';
ALTER TABLE posts ADD COLUMN music_start INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN music_end INTEGER DEFAULT 15;
