-- Voice post support
ALTER TABLE posts ADD COLUMN voice_url TEXT DEFAULT '';

-- Ensure trending_cache table exists with updated_at
CREATE TABLE IF NOT EXISTS trending_cache (
  topic TEXT PRIMARY KEY,
  post_count INTEGER DEFAULT 0,
  trending_score REAL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
