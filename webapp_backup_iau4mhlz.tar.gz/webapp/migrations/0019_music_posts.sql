-- Add music_url column to posts for YouTube music embeds
ALTER TABLE posts ADD COLUMN music_url TEXT DEFAULT '';
