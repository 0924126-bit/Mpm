// ===== social.js - Profile, DM, Crew, Crew Admin, Notifications =====
// Depends on: app.js (S, $, $$, h, esc, t, api, avatar, navigate, toast, haptic, formatContent, timeAgo)
// ===== PROFILE =====
async function pageProfile(el, username) {
  // Show skeleton loading with animation instead of plain spinner
  el.innerHTML = `<div class="anim-fade-up" style="overflow:hidden">
    <div class="profile-cover" style="background:var(--bg-tertiary)">
      <div class="skeleton" style="width:100%;height:100%"></div>
    </div>
    <div style="padding:0 24px;margin-top:-40px;position:relative;z-index:1">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:16px">
        <div class="skeleton" style="width:80px;height:80px;border-radius:50%;border:3px solid var(--bg-primary)"></div>
        <div class="skeleton" style="width:80px;height:34px;border-radius:var(--radius-full)"></div>
      </div>
      <div class="skeleton" style="width:160px;height:24px;margin-bottom:8px;border-radius:var(--radius-sm)"></div>
      <div class="skeleton" style="width:100px;height:16px;margin-bottom:12px;border-radius:var(--radius-sm)"></div>
      <div class="skeleton" style="width:100%;height:40px;margin-bottom:12px;border-radius:var(--radius-sm)"></div>
      <div style="display:flex;gap:24px;margin-bottom:16px">
        <div class="skeleton" style="width:80px;height:18px;border-radius:var(--radius-sm)"></div>
        <div class="skeleton" style="width:80px;height:18px;border-radius:var(--radius-sm)"></div>
      </div>
    </div>
    <div style="border-top:1px solid var(--border);padding:24px">
      ${[1,2,3].map(() => `<div style="display:flex;gap:14px;padding:16px 0;border-bottom:1px solid var(--border)"><div class="skeleton" style="width:42px;height:42px;border-radius:50%;flex-shrink:0"></div><div style="flex:1"><div class="skeleton" style="width:120px;height:14px;margin-bottom:8px;border-radius:var(--radius-sm)"></div><div class="skeleton" style="width:100%;height:40px;border-radius:var(--radius-sm)"></div></div></div>`).join('')}
    </div>
  </div>`;
  const [profileRes, postsRes] = await Promise.all([api(`/api/users/${username}`), api(`/api/users/${username}/posts`)]);
  if (profileRes.error) { el.innerHTML = `<div style="padding:60px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'ユーザーが見つかりません':'User not found'}</div>`; return; }
  const u = profileRes.user, posts = postsRes.posts || [], media = profileRes.media || [];
  const isMe = S.user && S.user.id === u.id, isFollowing = u.is_following > 0;
  const followStatusBadge = !isMe && isFollowing ? `<div class="follow-status-badge"><i class="fas fa-user-check"></i><span>${S.lang==='ja'?'フォロー中':'Following'}</span></div>` : (!isMe && u.follows_me > 0 ? `<div class="follow-status-badge follow-status-follows-you"><i class="fas fa-user-plus"></i><span>${S.lang==='ja'?'フォローされています':'Follows you'}</span></div>` : '');
  const bgGradients = {'gradient-sunset':'linear-gradient(135deg,#ff6b35,#f72585,#7209b7)','gradient-ocean':'linear-gradient(135deg,#0077b6,#00b4d8,#90e0ef)','gradient-forest':'linear-gradient(135deg,#2d6a4f,#52b788,#95d5b2)','gradient-galaxy':'linear-gradient(135deg,#240046,#3c096c,#7b2cbf,#c77dff)','gradient-aurora':'linear-gradient(135deg,#5390d9,#48bfe3,#56cfe1,#72efdd)','gradient-sakura':'linear-gradient(135deg,#ffafcc,#ffc8dd,#cdb4db,#a2d2ff)'};
  const coverStyle = u.banner_url ? `background-image:url('${esc(u.banner_url)}');background-size:cover;background-position:center` : (u.bg_color && bgGradients[u.bg_color] ? `background:${bgGradients[u.bg_color]}` : '');
  // Smooth transition: crossfade from skeleton to real content
  el.style.transition = 'opacity 0.25s ease';
  el.style.opacity = '0';
  requestAnimationFrame(() => {
    el.innerHTML = `<div class="anim-fade-up">
      <div class="profile-cover" style="${coverStyle}">
        ${isMe ? `<label style="position:absolute;bottom:12px;right:12px;cursor:pointer"><div class="btn btn-sm" style="background:rgba(0,0,0,0.4);color:white;backdrop-filter:blur(4px);font-size:12px"><i class="fas fa-camera"></i></div><input type="file" accept="image/*" style="display:none" onchange="changeBanner(this)"></label>` : ''}
        ${!isMe && S.user ? `<button class="btn btn-sm" style="position:absolute;top:12px;right:12px;background:rgba(0,0,0,0.4);color:white;backdrop-filter:blur(4px);font-size:12px;min-width:36px;height:36px;padding:0 10px" onclick="showProfileContextMenu('${u.id}','${esc(u.display_name)}','${esc(u.username)}')"><i class="fas fa-ellipsis"></i></button>` : ''}
      </div>
      <div style="padding:0 24px;margin-top:-40px;position:relative;z-index:1">
        <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:16px">
          <div style="position:relative;border:3px solid var(--bg-primary);border-radius:50%;background:var(--bg-primary)">
            ${avatar(u.avatar_url, u.display_name, 80)}
            ${isMe ? `<label style="position:absolute;bottom:0;right:0;cursor:pointer;width:26px;height:26px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;border:2px solid var(--bg-primary)"><i class="fas fa-camera" style="font-size:10px;color:white"></i><input type="file" accept="image/*" style="display:none" onchange="changeAvatar(this)"></label>` : ''}
          </div>
          <div style="display:flex;gap:8px">${S.user && !isMe ? `<button class="btn btn-secondary btn-sm" onclick="startDM('${u.id}')"><i class="fas fa-paper-plane"></i></button><button class="btn btn-secondary btn-sm" onclick="showCoinThrowModal('${u.id}','${esc(u.display_name)}')"><i class="fas fa-coins" style="color:var(--sand)"></i></button>` : ''}${isMe ? `<button class="btn btn-secondary btn-sm" onclick="showProfileMenu()" title="${S.lang==='ja'?'メニュー':'Menu'}"><i class="fas fa-ellipsis"></i></button><button class="btn btn-primary btn-sm" onclick="showEditProfileModal()">${t('profile.edit')}</button>` : S.user ? `<button class="btn ${isFollowing?'btn-secondary':'btn-primary'} btn-sm" id="follow-btn" data-fol="${isFollowing}" onclick="toggleFollow('${u.id}',this)">${isFollowing?t('profile.unfollow'):t('profile.follow')}</button>` : ''}</div></div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><h2 style="font-family:'Cormorant Garamond',serif;font-size:26px;font-weight:700;${u.name_color ? (u.name_color === 'rainbow' ? 'background:linear-gradient(90deg,#c8553d,#c2b280,#6b8f71,#5b8fa8,#8b7eb8);-webkit-background-clip:text;-webkit-text-fill-color:transparent' : 'color:'+u.name_color) : ''}">${esc(u.display_name)}</h2>${u.is_official ? '<span class="official-badge" style="font-size:16px" title="Official"><i class="fas fa-check-circle"></i></span>' : ''}${u.badge ? `<span class="user-badge" style="font-size:18px">${{'star':'&#11088;','fire':'&#128293;','diamond':'&#128142;','crown':'&#128081;','heart':'&#10084;','lightning':'&#9889;'}[u.badge]||''}</span>` : ''}</div>
        <p style="font-size:14px;color:var(--text-tertiary);margin-bottom:8px">@${esc(u.username)} ${u.role && u.role !== 'user' ? `<span class="role-badge role-${u.role}" style="margin-left:4px">${u.role}</span>` : ''} ${followStatusBadge}</p>
        ${u.bio ? `<p style="font-size:15px;color:var(--text-secondary);line-height:1.7;margin-bottom:12px">${esc(u.bio)}</p>` : ''}
        ${u.profile_url ? `<a href="${esc(u.profile_url)}" data-external target="_blank" style="font-size:13px;color:var(--accent);display:flex;align-items:center;gap:4px;margin-bottom:12px"><i class="fas fa-link"></i>${esc(u.profile_url.replace(/^https?:\/\//,'').substring(0,40))}</a>` : ''}
        <div style="display:flex;gap:24px;margin-bottom:16px"><button onclick="showUserList('${u.username}','following')" style="font-size:14px"><span style="font-weight:700">${u.following_count}</span> <span style="color:var(--text-tertiary)">${t('profile.following')}</span></button><button onclick="showUserList('${u.username}','followers')" style="font-size:14px"><span style="font-weight:700">${u.follower_count}</span> <span style="color:var(--text-tertiary)">${t('profile.followers')}</span></button>${u.coins !== undefined ? `<span class="coin-badge"><i class="fas fa-coins" style="font-size:10px"></i>${u.coins}</span>` : ''}</div>
        ${media.length > 0 ? `<div style="margin-bottom:16px"><div style="font-size:12px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px">MEDIA</div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px">${media.map(m => `<img src="${esc(m.image_url)}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--radius-sm);cursor:pointer" onclick="viewImage('${esc(m.image_url)}')">`).join('')}</div></div>` : ''}
      </div>
      <div id="profile-pinned"></div>
      <div style="border-top:1px solid var(--border)"><div id="profile-posts">${posts.length ? posts.map((p,i) => renderPostHTML(p,i)).join('') : `<div style="padding:60px 24px;text-align:center;color:var(--text-tertiary);font-size:14px">${t('post.empty')}</div>`}</div><div id="profile-loader" style="display:none;padding:24px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div>
    </div>${isMe ? `<div class="fab" onclick="showQuickPost()"><i class="fas fa-pen"></i></div>` : ''}<div class="mobile-nav-spacer"></div>`;
    // Fade in after DOM update
    requestAnimationFrame(() => { el.style.opacity = '1'; });
    // Load pinned posts after DOM is ready
    loadPinnedPosts(u.username);
  });
  // Setup infinite scroll for profile posts
  S._profileUsername = u.username;
  S._profileCursor = postsRes.next_cursor || null;
  S._profileLoading = false;
  if (S._profileCursor) {
    const scrollHandler = () => {
      if (S.currentPage !== 'profile' || S._profileLoading || !S._profileCursor) return;
      if (document.documentElement.scrollHeight - (window.innerHeight + window.scrollY) < 600) loadMoreProfilePosts();
    };
    window.addEventListener('scroll', scrollHandler, { passive: true });
    // Cleanup on page change
    const origCleanup = cleanupPolling;
    cleanupPolling = function() { window.removeEventListener('scroll', scrollHandler); origCleanup(); };
  }
}
async function loadPinnedPosts(username) {
  const el = $('#profile-pinned'); if (!el) return;
  const res = await api(`/api/users/${username}/pinned`);
  const pins = res.pins || [];
  if (pins.length === 0) return;
  el.innerHTML = `<div style="border-top:1px solid var(--border);padding:0"><div style="padding:12px 24px 4px;display:flex;align-items:center;gap:6px"><i class="fas fa-thumbtack" style="font-size:11px;color:var(--accent)"></i><span style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.06em">${S.lang==='ja'?'ピン留め':'PINNED'}</span></div>${pins.map((p,i) => renderPostHTML(p,i)).join('')}</div>`;
}

async function loadMoreProfilePosts() {
  if (!S._profileUsername || !S._profileCursor || S._profileLoading) return;
  S._profileLoading = true;
  const loader = $('#profile-loader');
  if (loader) loader.style.display = 'block';
  const res = await api(`/api/users/${S._profileUsername}/posts?cursor=${encodeURIComponent(S._profileCursor)}`);
  if (loader) loader.style.display = 'none';
  S._profileLoading = false;
  const posts = res.posts || [];
  if (posts.length === 0) { S._profileCursor = null; return; }
  S._profileCursor = res.next_cursor || null;
  const container = $('#profile-posts');
  if (!container) return;
  const fragment = document.createDocumentFragment();
  posts.forEach((p, i) => {
    const wrapper = h('div', '');
    wrapper.innerHTML = renderPostHTML(p, i);
    fragment.appendChild(wrapper.firstElementChild);
  });
  container.appendChild(fragment);
}

function showCoinThrowModal(userId, displayName) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px"><i class="fas fa-coins" style="color:var(--sand);margin-right:8px"></i>${S.lang==='ja'?'コインを送る':'Send Coins'}</h3><p style="font-size:14px;color:var(--text-secondary);margin-bottom:16px">${S.lang==='ja'?`${displayName}にコインを送ります`:`Send coins to ${displayName}`}</p><div style="margin-bottom:16px"><input type="number" id="coin-amount" class="input" placeholder="${S.lang==='ja'?'枚数':'Amount'}" min="1" max="1000" value="10"></div><div style="margin-bottom:16px"><input type="text" id="coin-msg" class="input" placeholder="${S.lang==='ja'?'メッセージ（任意）':'Message (optional)'}" maxlength="100"></div><div style="display:flex;gap:12px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="sendCoins('${userId}')">${S.lang==='ja'?'送る':'Send'}</button></div></div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov);
}
async function sendCoins(userId) { const amount = parseInt($('#coin-amount')?.value || '0'); const message = $('#coin-msg')?.value || ''; if (amount < 1) return toast(S.lang==='ja'?'1枚以上':'Min 1','error'); const res = await api('/api/coins/send', { method: 'POST', body: { target_user_id: userId, amount, message } }); if (res.success) { $('.modal-overlay')?.remove(); toast(`${amount} ${S.lang==='ja'?'コイン送信！':'coins sent!'}`); if (S.user) S.user.coins = res.new_balance; } else toast(res.error || 'Error', 'error'); }

async function changeAvatar(input) { const f = input.files[0]; if (!f || f.size > 2*1024*1024) { toast(S.lang==='ja'?'2MB以下':'Max 2MB','error'); return; } const r = new FileReader(); r.onload = (e) => { showImageCropModal(e.target.result, async (croppedData) => { await api('/api/profile', { method: 'PUT', body: { avatar_url: croppedData } }); S.user.avatar_url = croppedData; toast(S.lang==='ja'?'アイコン更新':'Avatar updated'); shellRendered = false; renderShell(); pageProfile($('#page'), S.user.username); }, 1); }; r.readAsDataURL(f); }

function showQuickPost() { const ov = h('div', 'modal-overlay'); ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:16px">${t('post.submit')}</h3><textarea id="quick-post-input" class="input" style="min-height:100px;font-size:15px" placeholder="${t('post.placeholder')}" maxlength="500"></textarea><div style="display:flex;gap:12px;margin-top:16px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="quickPostSubmit()">${t('post.submit')}</button></div></div>`; ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov); }
async function quickPostSubmit() { const input = $('#quick-post-input'); let content = input?.value.trim(); if (!content) return; content = sanitizeContent(content); if (!content) { toast(S.lang==='ja'?'内容を入力':'Content needed','error'); return; } const res = await api('/api/posts', { method: 'POST', body: { content } }); if (res.success && res.post) { if (S.user) { res.post.is_official = S.user.is_official || 0; res.post.name_color = S.user.name_color || ''; res.post.badge = S.user.badge || ''; } $('.modal-overlay')?.remove(); toast(S.lang==='ja'?'投稿しました':'Posted'); } else toast(res.error||'Error','error'); }

async function toggleFollow(userId, btn) { if (!S.user) return navigate('/login'); const isFol = btn.dataset.fol === 'true'; btn.dataset.fol = String(!isFol); btn.textContent = isFol ? t('profile.follow') : t('profile.unfollow'); btn.className = `btn ${isFol?'btn-primary':'btn-secondary'} btn-sm`; await api(`/api/follow/${userId}`, { method: isFol ? 'DELETE' : 'POST' }); }

// Profile context menu (for non-own profiles: block + account details)
function showProfileContextMenu(userId, displayName, username) {
  const ov = h('div', 'bottom-sheet-overlay');
  ov.innerHTML = `<div class="bottom-sheet" onclick="event.stopPropagation()">
    <div class="bottom-sheet-handle"></div>
    <div class="bottom-sheet-items">
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showAccountDetails('${username}')"><i class="fas fa-circle-info" style="color:var(--sky)"></i><span>${S.lang==='ja'?'アカウント詳細':'Account Details'}</span></button>
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showBlockOptions('${userId}','${esc(displayName)}')"><i class="fas fa-ban" style="color:var(--accent)"></i><span>${S.lang==='ja'?'ブロック':'Block'}</span></button>
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showReportModal('user','${userId}')"><i class="far fa-flag" style="color:var(--text-tertiary)"></i><span>${S.lang==='ja'?'通報':'Report'}</span></button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeBottomSheet(ov); });
  document.body.appendChild(ov);
  requestAnimationFrame(() => { ov.classList.add('active'); ov.querySelector('.bottom-sheet').classList.add('active'); });
}

function showBlockOptions(userId, displayName) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;max-width:380px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700;margin-bottom:8px"><i class="fas fa-ban" style="color:var(--accent);margin-right:8px"></i>${S.lang==='ja'?'ブロック':'Block'}</h3>
    <p style="font-size:14px;color:var(--text-secondary);margin-bottom:20px;line-height:1.6">${S.lang==='ja'?`${displayName}をブロックしますか？ブロックすると相手の投稿が非表示になります。`:`Block ${displayName}? Their posts will be hidden.`}</p>
    <div style="display:flex;flex-direction:column;gap:10px">
      <button class="btn btn-primary" style="background:var(--accent)" onclick="blockUser('${userId}',false);this.closest('.modal-overlay').remove()"><i class="fas fa-ban" style="margin-right:6px"></i>${S.lang==='ja'?'ブロック':'Block'}</button>
      <button class="btn btn-secondary" style="border-color:var(--violet);color:var(--violet)" onclick="blockUser('${userId}',true);this.closest('.modal-overlay').remove()"><i class="fas fa-ghost" style="margin-right:6px"></i>${S.lang==='ja'?'ゴーストブロック':'Ghost Block'}</button>
      <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">${S.lang==='ja'?'キャンセル':'Cancel'}</button>
    </div>
    <p style="font-size:11px;color:var(--text-tertiary);margin-top:12px;line-height:1.5">${S.lang==='ja'?'ゴーストブロック：相手に気づかれずにブロックします':'Ghost Block: Blocks without notifying them'}</p>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}

async function showAccountDetails(username) {
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px;max-width:400px" onclick="event.stopPropagation()">
    <div style="text-align:center;padding:20px"><div class="spinner" style="margin:0 auto"></div></div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
  try {
    const res = await api('/api/users/' + username + '/details');
    const d = res.details || {};
    const modal = ov.querySelector('.modal-content');
    modal.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
        <h3 style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700"><i class="fas fa-circle-info" style="color:var(--sky);margin-right:8px"></i>${S.lang==='ja'?'アカウント詳細':'Account Details'}</h3>
        <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()"><i class="fas fa-times"></i></button>
      </div>
      <div style="display:flex;flex-direction:column;gap:14px">
        <div style="display:flex;align-items:center;gap:12px;padding:12px;background:var(--bg-card);border-radius:var(--radius-md)">
          <i class="fas fa-calendar-plus" style="color:var(--accent);font-size:16px;width:24px;text-align:center"></i>
          <div>
            <div style="font-size:12px;color:var(--text-tertiary);font-weight:600">${S.lang==='ja'?'アカウント作成日':'Created'}</div>
            <div style="font-size:15px;font-weight:600">${d.created_at ? new Date(d.created_at).toLocaleDateString(S.lang==='ja'?'ja-JP':'en-US',{year:'numeric',month:'long',day:'numeric'}) : '-'}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;padding:12px;background:var(--bg-card);border-radius:var(--radius-md)">
          <i class="fas fa-id-badge" style="color:var(--violet);font-size:16px;width:24px;text-align:center"></i>
          <div>
            <div style="font-size:12px;color:var(--text-tertiary);font-weight:600">${S.lang==='ja'?'ユーザーID':'User ID'}</div>
            <div style="font-size:15px;font-weight:600">@${esc(d.username || username)}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;padding:12px;background:var(--bg-card);border-radius:var(--radius-md)">
          <i class="fas fa-repeat" style="color:var(--sand);font-size:16px;width:24px;text-align:center"></i>
          <div>
            <div style="font-size:12px;color:var(--text-tertiary);font-weight:600">${S.lang==='ja'?'ID変更回数':'ID Changes'}</div>
            <div style="font-size:15px;font-weight:600">${d.username_changes ?? 0}${S.lang==='ja'?'回':' times'}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;padding:12px;background:var(--bg-card);border-radius:var(--radius-md)">
          <i class="fas fa-pen-to-square" style="color:var(--sage);font-size:16px;width:24px;text-align:center"></i>
          <div>
            <div style="font-size:12px;color:var(--text-tertiary);font-weight:600">${S.lang==='ja'?'投稿数':'Posts'}</div>
            <div style="font-size:15px;font-weight:600">${d.post_count ?? 0}</div>
          </div>
        </div>
      </div>
    `;
  } catch(e) {
    ov.querySelector('.modal-content').innerHTML = `<div style="padding:20px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'読み込みエラー':'Load error'}</div>`;
  }
}

async function blockUser(userId, isGhost) {
  try {
    const res = await api('/api/blocks', { method: 'POST', body: { blocked_id: userId, is_ghost: isGhost } });
    if (res.success) {
      toast(S.lang==='ja'?'ブロックしました':'Blocked');
      // Optionally reload the page
      if (S.currentPage === 'profile') route();
    } else {
      toast(res.error || 'Error', 'error');
    }
  } catch(e) {
    toast(S.lang==='ja'?'エラー':'Error', 'error');
  }
}


function showProfileMenu() {
  const ov = h('div', 'bottom-sheet-overlay');
  ov.innerHTML = `<div class="bottom-sheet" onclick="event.stopPropagation()">
    <div class="bottom-sheet-handle"></div>
    <div class="bottom-sheet-items">
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));navigate('/settings')"><i class="fas fa-gear"></i><span>${S.lang==='ja'?'設定':'Settings'}</span></button>
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));navigate('/shop')"><i class="fas fa-store" style="color:var(--sand)"></i><span>${S.lang==='ja'?'ショップ':'Shop'}</span></button>
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showBookmarks()"><i class="fas fa-bookmark" style="color:var(--sky)"></i><span>${S.lang==='ja'?'ブックマーク':'Bookmarks'}</span></button>
      <button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showQRModal(location.origin+'/profile/'+S.user.username, S.lang==='ja'?'プロフィール':'Profile')"><i class="fas fa-qrcode"></i><span>${S.lang==='ja'?'QRコード':'QR Code'}</span></button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeBottomSheet(ov); });
  document.body.appendChild(ov);
  requestAnimationFrame(() => { ov.classList.add('active'); ov.querySelector('.bottom-sheet').classList.add('active'); });
}
async function changeBanner(input) { const f = input.files[0]; if (!f || f.size > 5*1024*1024) return; const r = new FileReader(); r.onload = async (e) => { await api('/api/profile', { method: 'PUT', body: { banner_url: e.target.result } }); S.user.banner_url = e.target.result; toast(S.lang==='ja'?'更新しました':'Updated'); pageProfile($('#page'), S.user.username); }; r.readAsDataURL(f); }
function showEditProfileModal() { const ov = h('div', 'modal-overlay'); ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:18px">${t('profile.edit')}</h3><div style="margin-bottom:14px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">${t('auth.display_name')}</label><input type="text" id="edit-name" class="input" value="${esc(S.user.display_name)}" maxlength="30"></div><div style="margin-bottom:14px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">USER ID</label><div style="display:flex;gap:8px;align-items:center"><span style="font-size:14px;color:var(--text-tertiary)">@</span><input type="text" id="edit-username" class="input" value="${esc(S.user.username)}" maxlength="20" pattern="[a-zA-Z0-9_]+" style="flex:1" oninput="this.value=this.value.replace(/[^a-zA-Z0-9_]/g,'')"></div><div style="font-size:10px;color:var(--text-tertiary);margin-top:3px">${S.lang==='ja'?'英数字と_のみ・24時間に1回変更可':'Alphanumeric & _ only. Once per 24h.'}</div></div><div style="margin-bottom:14px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">${t('profile.bio')}</label><textarea id="edit-bio" class="input" style="height:80px" maxlength="200">${esc(S.user.bio||'')}</textarea></div><div style="margin-bottom:18px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">URL</label><input type="url" id="edit-url" class="input" value="${esc(S.user.profile_url||'')}" placeholder="https://..."></div><div style="display:flex;gap:12px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('profile.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="saveProfile()">${t('profile.save')}</button></div></div>`; ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov); }
async function saveProfile() {
  const display_name = $('#edit-name')?.value.trim(), bio = $('#edit-bio')?.value.trim(), profile_url = $('#edit-url')?.value.trim();
  const newUsername = $('#edit-username')?.value.trim().toLowerCase();
  if (!display_name) return;
  // Save profile fields
  await api('/api/profile', { method: 'PUT', body: { display_name, bio, profile_url } });
  S.user.display_name = display_name; S.user.bio = bio; S.user.profile_url = profile_url;
  // Change username if different
  if (newUsername && newUsername !== S.user.username) {
    const res = await api('/api/profile/username', { method: 'PUT', body: { username: newUsername } });
    if (res.success) {
      S.user.username = res.username;
      toast(S.lang==='ja'?'ユーザーID変更完了':'Username changed');
    } else {
      toast(res.error || 'Error', 'error');
    }
  }
  $('.modal-overlay')?.remove(); toast(S.lang==='ja'?'保存しました':'Saved'); shellRendered = false; pageProfile($('#page'), S.user.username);
}
async function showUserList(username, type) { const res = await api(`/api/users/${username}/${type}`); const users = res.users || []; const ov = h('div', 'modal-overlay'); ov.innerHTML = `<div class="modal-content" onclick="event.stopPropagation()" style="max-height:70vh;display:flex;flex-direction:column"><div style="padding:18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between"><span style="font-weight:700">${type==='followers'?t('profile.followers'):t('profile.following')}</span><button class="btn-icon" onclick="this.closest('.modal-overlay').remove()"><i class="fas fa-times"></i></button></div><div style="overflow-y:auto;padding:12px">${users.length ? users.map(u => `<a href="/profile/${esc(u.username)}" onclick="this.closest('.modal-overlay').remove()" style="display:flex;align-items:center;gap:12px;padding:10px">${avatar(u.avatar_url, u.display_name, 40)}<div><div style="font-weight:600">${esc(u.display_name)}</div><div style="font-size:13px;color:var(--text-tertiary)">@${esc(u.username)}</div></div></a>`).join('') : `<div style="padding:30px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'まだいません':'No one yet'}</div>`}</div></div>`; ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov); }

// ===== DM - WebSocket powered =====
function pageDM(el) { if (!S.user) return navigate('/login'); el.innerHTML = `<div class="page-header" style="padding:20px 24px"><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${t('nav.dm')}</span></div><div id="dm-list"></div><div class="mobile-nav-spacer"></div>`; loadConversations(); }
async function loadConversations() { const list = $('#dm-list'); if (!list) return; list.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`; const res = await api('/api/conversations'); const convs = res.conversations || []; if (convs.length === 0) { list.innerHTML = `<div style="padding:80px 24px;text-align:center;color:var(--text-tertiary)"><p style="font-family:'Cormorant Garamond',serif;font-size:20px;margin-bottom:6px">${S.lang==='ja'?'まだ何もない':'Nothing yet'}</p></div>`; return; } list.innerHTML = convs.map((c, i) => `<a href="/dm/${c.id}" class="anim-fade-up stagger-${Math.min(i+1,5)}" style="display:flex;align-items:center;gap:14px;padding:18px 24px;border-bottom:1px solid var(--border);transition:background var(--t-fast)" onmouseenter="this.style.background='var(--bg-card)'" onmouseleave="this.style.background=''">${avatar(c.other_avatar_url, c.other_display_name, 46)}<div style="flex:1;min-width:0"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px"><span style="font-weight:600;font-size:15px">${esc(c.other_display_name)}</span><span style="font-size:12px;color:var(--text-tertiary)">${c.last_message_at ? timeAgo(c.last_message_at) : ''}</span></div><div style="display:flex;align-items:center;gap:7px"><span style="font-size:14px;color:var(--text-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">${c.last_message ? esc(c.last_message).substring(0,50) : ''}</span>${c.unread_count > 0 ? `<span class="unread-badge">${c.unread_count}</span>` : ''}</div></div></a>`).join(''); }
async function startDM(userId) { const res = await api('/api/conversations', { method: 'POST', body: { user_id: userId } }); if (res.conversation) navigate('/dm/' + res.conversation.id); }

// DM Chat - WebSocket + Fallback
let lastDmTs = null;
async function pageDMChat(el, convId) {
  if (!S.user) return navigate('/login'); updateNav();
  el.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`;
  const [msgsRes, convsRes] = await Promise.all([api(`/api/conversations/${convId}/messages`), api('/api/conversations')]);
  const msgs = msgsRes.messages || [], conv = convsRes.conversations?.find(c => c.id === convId);
  const otherName = conv ? conv.other_display_name : '', otherAvatar = conv ? conv.other_avatar_url : '', otherUsername = conv ? conv.other_username : '', otherIsOfficial = conv ? conv.other_is_official : 0;
  lastDmTs = msgs.length > 0 ? msgs[msgs.length - 1].created_at : null;
  el.className = 'page-container dm-fullscreen';
  el.innerHTML = `<div class="dm-chat-layout"><div class="dm-chat-header"><button class="btn-icon" onclick="navigate('/dm')"><i class="fas fa-arrow-left"></i></button><a href="/profile/${esc(otherUsername)}" style="display:flex;align-items:center;gap:10px">${avatar(otherAvatar, otherName, 36)}<div><span style="font-weight:600;font-size:15px">${esc(otherName)}</span>${otherIsOfficial ? '<span class="official-badge" style="font-size:12px;margin-left:4px" title="Official"><i class="fas fa-check-circle"></i></span>' : ''}</div></a><div style="margin-left:auto;display:flex;align-items:center;gap:6px"><div id="ws-status" style="width:8px;height:8px;border-radius:50%;background:var(--text-tertiary);transition:background 0.3s" title="Connecting..."></div></div></div><div class="dm-chat-messages" id="dm-msgs">${msgs.map(m => renderDMMsg(m)).join('')}</div><div id="typing-indicator" style="display:none;padding:4px 20px 0"></div><div class="dm-chat-input"><textarea id="dm-input" class="input" style="flex:1;min-height:42px;max-height:120px;padding:10px 16px;font-size:15px;border-radius:22px" placeholder="${S.lang==='ja'?'メッセージ...':'Message...'}" rows="1"></textarea><button class="btn btn-primary dm-send-btn" onmousedown="event.preventDefault()" ontouchstart="event.preventDefault()" onclick="sendDM('${convId}')"><i class="fas fa-paper-plane" style="font-size:13px"></i></button></div></div>`;
  const msgsEl = $('#dm-msgs'); if (msgsEl) msgsEl.scrollTop = msgsEl.scrollHeight;
  
  // Connect WebSocket
  connectWS('dm:' + convId);
  
  const input = $('#dm-input');
  if (input) {
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendDM(convId);
      }
    });
    input.addEventListener('input', () => {
      input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px';
      sendTypingIndicator(); // Send typing indicator via WS
    });
  }
  // Fallback polling only if WS isn't connected (with shorter interval)
  if (S.dmPoll) clearInterval(S.dmPoll);
  S.dmPoll = setInterval(() => { if (!S.ws || S.ws.readyState !== 1) pollDMMessages(convId); }, 1500);
}

function renderDMMsg(m) { const mine = m.sender_id === S.user?.id; return `<div class="dm-msg-row ${mine?'dm-msg-mine':'dm-msg-other'}" style="animation:msg-pop 0.2s ease-out"><div class="dm-bubble ${mine?'dm-mine':'dm-other'}">${esc(m.content)}<div class="dm-time">${timeAgo(m.created_at)}</div></div></div>`; }
function appendDMMessage(m) { const msgsEl = $('#dm-msgs'); if (!msgsEl) return; const div = h('div', '', renderDMMsg(m)); msgsEl.appendChild(div.firstElementChild); msgsEl.scrollTop = msgsEl.scrollHeight; if (m.created_at > (lastDmTs || '')) lastDmTs = m.created_at; }
async function sendDM(convId) {
  const input = $('#dm-input'); const content = input?.value.trim(); if (!content) return;
  input.value = ''; input.style.height = 'auto';
  // CRITICAL: Do NOT blur - keep keyboard open by maintaining focus
  // Use requestAnimationFrame to ensure focus stays after DOM updates
  requestAnimationFrame(() => { if (input) input.focus(); });
  const now = new Date().toISOString();
  // Optimistic UI update
  appendDMMessage({ sender_id: S.user.id, content, created_at: now });
  lastDmTs = now;
  // Send via WebSocket if available
  if (!sendWS({ type: 'chat', content })) {
    await api(`/api/conversations/${convId}/messages`, { method: 'POST', body: { content } });
  }
}
async function pollDMMessages(convId) { if (S.currentPage !== 'dmChat') return; if (!lastDmTs) return; try { const res = await api(`/api/sse/dm/${convId}?after=${encodeURIComponent(lastDmTs)}`); if (res.messages) { let added = false; res.messages.forEach(m => { if (m.sender_id !== S.user.id) { appendDMMessage(m); added = true; } }); } } catch {} }

// ===== CREW =====
function pageCrew(el) {
  if (!S.user) return navigate('/login');
  el.innerHTML = `<div class="page-header" style="padding:20px 24px"><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px"><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${t('crew.title')}</span><button class="btn btn-primary btn-sm" onclick="showCreateCrewModal()"><i class="fas fa-plus" style="margin-right:5px"></i>${t('crew.create')}</button></div><div class="tab-bar" id="crew-tabs"><div class="tab-item active" onclick="switchCrewTab('mine',this)">${t('crew.my_crews')}</div><div class="tab-item" onclick="switchCrewTab('discover',this)">${t('crew.discover')}</div><div class="tab-indicator" id="crew-tab-indicator"></div></div></div><div id="crew-list"></div><div class="mobile-nav-spacer"></div>`;
  loadMyCrews();
  requestAnimationFrame(() => { const ind = $('#crew-tab-indicator'), active = $('#crew-tabs .tab-item.active'); if (ind && active) { ind.style.left = active.offsetLeft + 'px'; ind.style.width = active.offsetWidth + 'px'; } });
}
let crewTab = 'mine';
function switchCrewTab(tab, el) { crewTab = tab; $$('#crew-tabs .tab-item').forEach(t2 => t2.classList.remove('active')); el.classList.add('active'); requestAnimationFrame(() => { const ind = $('#crew-tab-indicator'); if (ind && el) { ind.style.left = el.offsetLeft + 'px'; ind.style.width = el.offsetWidth + 'px'; } }); if (tab === 'mine') loadMyCrews(); else loadDiscoverCrews(); }
async function loadMyCrews() { const list = $('#crew-list'); if (!list) return; list.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`; const res = await api('/api/crews'); const crews = res.crews || []; if (crews.length === 0) { list.innerHTML = `<div style="padding:60px 24px;text-align:center;color:var(--text-tertiary)">${t('crew.empty')}</div>`; return; } list.innerHTML = `<div style="padding:16px 24px">${crews.map((c, i) => renderCrewCard(c, i)).join('')}</div>`; }
async function loadDiscoverCrews() { const list = $('#crew-list'); if (!list) return; list.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`; const res = await api('/api/crews/discover'); const crews = res.crews || []; list.innerHTML = `<div style="padding:16px 24px">${crews.length ? crews.map((c, i) => renderCrewCard(c, i, true)).join('') : `<div style="padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'なし':'None'}</div>`}</div>`; }
function renderCrewCard(c, i, showJoin = false) { const iconBg = c.icon_url ? `<img src="${esc(c.icon_url)}" style="width:100%;height:100%;object-fit:cover">` : `<span style="color:var(--accent)">${(c.name||'C')[0].toUpperCase()}</span>`; return `<a href="/crew/${c.id}" class="anim-fade-up stagger-${Math.min(i+1,5)}" style="display:flex;align-items:center;gap:14px;padding:16px;border-radius:var(--radius-lg);border:1px solid var(--border);margin-bottom:10px;transition:all var(--t-fast);background:var(--bg-secondary)" onmouseenter="this.style.borderColor='var(--border-hover)'" onmouseleave="this.style.borderColor='var(--border)'"><div class="crew-icon" style="background:var(--accent-bg)">${iconBg}</div><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:15px;margin-bottom:2px">${esc(c.name)}</div><div style="font-size:13px;color:var(--text-tertiary)">${c.member_count||0} ${t('crew.members')}</div></div>${showJoin && !c.is_member ? `<button class="btn btn-primary btn-xs" onclick="event.preventDefault();event.stopPropagation();joinCrew('${c.id}',this)">${t('crew.join')}</button>` : ''}</a>`; }
function showCreateCrewModal() { if (S.crewCreating) return; const ov = h('div', 'modal-overlay'); ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()"><h3 style="font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:700;margin-bottom:18px">${t('crew.create')}</h3><div style="margin-bottom:16px"><input type="text" id="cc-name" class="input" placeholder="${S.lang==='ja'?'クルー名':'Crew name'}" maxlength="50"></div><div style="margin-bottom:18px"><textarea id="cc-desc" class="input" style="height:60px" placeholder="${S.lang==='ja'?'説明（任意）':'Description'}" maxlength="200"></textarea></div><div style="display:flex;gap:12px"><button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${t('general.cancel')}</button><button class="btn btn-primary" style="flex:1" onclick="createCrew()">${t('crew.create')}</button></div></div>`; ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); }); document.body.appendChild(ov); }
async function createCrew() { if (S.crewCreating) return; S.crewCreating = true; const name = $('#cc-name')?.value.trim(), description = $('#cc-desc')?.value.trim(); if (!name) { toast(S.lang==='ja'?'名前が必要':'Name required','error'); S.crewCreating = false; return; } const res = await api('/api/crews', { method: 'POST', body: { name, description } }); S.crewCreating = false; if (res.success) { $('.modal-overlay')?.remove(); navigate('/crew/' + res.crew_id); } else toast(res.error||'Error','error'); }
async function joinCrew(id, btn) { btn.disabled = true; const res = await api(`/api/crews/${id}/join`, { method: 'POST' }); if (res.success) { btn.textContent = '✓'; toast(S.lang==='ja'?'参加しました':'Joined'); } else { toast(res.error||'Error','error'); btn.disabled = false; } }

// Crew Detail - WebSocket powered
async function pageCrewDetail(el, crewId, channelId) {
  updateNav();
  el.innerHTML = `<div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div>`;
  const res = await api(`/api/crews/${crewId}`);
  if (res.error || !res.crew) { el.innerHTML = `<div style="padding:50px;text-align:center;color:var(--text-tertiary)">Not found</div>`; return; }
  const crew = res.crew, channels = res.channels || [], members = res.members || [], isMember = crew.is_member > 0;
  window._crewMyRole = crew.my_role || 'member';
  window._crewId = crewId;
  const textChannels = channels.filter(c => c.type === 'text'), voiceChannels = channels.filter(c => c.type === 'voice');
  const selectedChannel = channelId ? channels.find(c => c.id === channelId) : textChannels[0];
  const isVoiceChannel = selectedChannel?.type === 'voice';
  el.className = 'page-container crew-fullscreen';
  if (!isMember) { el.innerHTML = `<div class="page-header" style="padding:14px 24px;display:flex;align-items:center;gap:12px"><button class="btn-icon" onclick="navigate('/crew')"><i class="fas fa-arrow-left"></i></button><span style="font-weight:600;font-size:17px">${esc(crew.name)}</span><button class="btn btn-primary btn-sm" style="margin-left:auto" onclick="joinCrewAndReload('${crewId}')">${t('crew.join')}</button></div><div style="padding:24px">${crew.description ? `<p style="font-size:15px;color:var(--text-secondary);margin-bottom:18px">${esc(crew.description)}</p>` : ''}<div style="font-size:14px;font-weight:600;margin-bottom:10px">${crew.member_count} ${t('crew.members')}</div></div>`; return; }
  el.innerHTML = `<div class="crew-detail-layout"><div class="crew-detail-header"><button class="btn-icon crew-back-btn" onclick="navigate('/crew')"><i class="fas fa-arrow-left"></i></button><button class="btn-icon crew-sidebar-toggle" onclick="toggleCrewSidebar()"><i class="fas fa-bars"></i></button><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:14px">${esc(crew.name)}</div><div style="font-size:11px;color:var(--text-tertiary)">${selectedChannel ? (isVoiceChannel ? '🔊' : '#') + esc(selectedChannel.name) : ''}</div></div>${crewRoleLvl(crew.my_role||'member')>=2?`<button class="btn-icon" onclick="showCrewAdminModal('${crewId}')" title="${S.lang==='ja'?'管理':'Admin'}"><i class="fas fa-shield-halved" style="font-size:14px"></i></button>`:''}<button class="btn-icon" onclick="showCrewDetailMenu('${crewId}','${crew.my_role||'member'}','${esc(crew.name)}','${esc(crew.description||'')}')" title="${S.lang==='ja'?'メニュー':'Menu'}"><i class="fas fa-ellipsis-v" style="font-size:14px"></i></button></div><div class="crew-detail-body"><div class="crew-detail-sidebar" id="crew-sidebar"><div class="crew-sidebar-section">${S.lang==='ja'?'テキスト':'TEXT'}</div>${textChannels.map(ch => `<div class="crew-channel ${selectedChannel?.id === ch.id ? 'active' : ''}" onclick="switchCrewChannel('${crewId}','${ch.id}')"><i class="fas fa-hashtag" style="font-size:12px;opacity:0.3"></i><span>${esc(ch.name)}</span></div>`).join('')}${voiceChannels.length > 0 ? `<div class="crew-sidebar-section" style="margin-top:8px">${S.lang==='ja'?'ボイス':'VOICE'}</div>` : ''}${voiceChannels.map(ch => `<div class="crew-channel ${selectedChannel?.id === ch.id ? 'active' : ''}" onclick="switchCrewChannel('${crewId}','${ch.id}')"><i class="fas fa-volume-high" style="font-size:11px;opacity:0.3"></i><span>${esc(ch.name)}</span></div>`).join('')}</div><div class="crew-detail-main">${isVoiceChannel ? `<div class="crew-voice-area" style="padding:24px"><div id="crew-voice-members" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(70px,1fr));gap:14px;justify-items:center"></div><div style="display:flex;gap:10px;justify-content:center;margin-top:20px"><button id="cv-join-btn" class="btn btn-primary btn-sm" onclick="joinCrewVoice('${selectedChannel.id}')">${t('voice.join')}</button><button id="cv-leave-btn" class="btn btn-danger btn-sm" style="display:none" onclick="leaveCrewVoice('${selectedChannel.id}')">${t('voice.leave')}</button><button id="cv-mute-btn" class="btn-icon" style="display:none;width:40px;height:40px" onclick="toggleCrewVoiceMute('${selectedChannel.id}')"><i class="fas fa-microphone"></i></button></div></div><div id="crew-remote-audio" style="display:none"></div>` : `<div class="crew-channel-header"><i class="fas fa-hashtag" style="opacity:0.3"></i>${selectedChannel ? esc(selectedChannel.name) : ''}</div><div class="crew-messages-area" id="crew-msgs"></div><div class="crew-input-area"><textarea id="crew-msg-input" class="input" style="flex:1;min-height:36px;max-height:80px;padding:8px 14px;font-size:14px;border-radius:20px" placeholder="${S.lang==='ja'?'メッセージ...':'Message...'}" rows="1"></textarea><button class="btn btn-primary" style="width:36px;height:36px;border-radius:50%;padding:0" onclick="sendCrewMessage('${selectedChannel?.id}')"><i class="fas fa-paper-plane" style="font-size:11px"></i></button></div>`}</div></div></div>`;
  if (isMember && selectedChannel) {
    if (isVoiceChannel) { loadCrewVoiceMembers(selectedChannel.id); if (S.crewVoicePoll) clearInterval(S.crewVoicePoll); S.crewVoicePoll = setInterval(() => loadCrewVoiceMembers(selectedChannel.id), 2000); }
    else {
      loadCrewMessages(selectedChannel.id);
      connectWS('crew:' + selectedChannel.id);
      const input = $('#crew-msg-input');
      if (input) {
        input.addEventListener('keydown', e => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendCrewMessage(selectedChannel.id);
          }
        });
        input.addEventListener('input', () => { sendTypingIndicator(); });
      }
      if (S.crewPoll) clearInterval(S.crewPoll);
      S.crewPoll = setInterval(() => { if (!S.ws || S.ws.readyState !== 1) pollCrewMessages(selectedChannel.id); }, 1500);
    }
  }
}
function toggleCrewSidebar() { const sidebar = $('#crew-sidebar'); if (sidebar) sidebar.classList.toggle('open'); }

function showCrewDetailMenu(crewId, myRole, crewName, crewDesc) {
  const ja = S.lang === 'ja';
  const isOwnerOrAdmin = crewRoleLvl(myRole) >= 3;
  const isOwner = myRole === 'owner';
  const ov = h('div', 'bottom-sheet-overlay');
  ov.innerHTML = `<div class="bottom-sheet" onclick="event.stopPropagation()">
    <div class="bottom-sheet-handle"></div>
    <div class="bottom-sheet-items">
      ${isOwnerOrAdmin ? `<button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showCrewSettingsModal('${crewId}','${esc(crewName)}','${esc(crewDesc)}')"><i class="fas fa-gear"></i><span>${ja?'クルー設定':'Crew Settings'}</span></button>` : ''}
      ${isOwnerOrAdmin ? `<button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showCrewAdminModal('${crewId}')"><i class="fas fa-shield-halved" style="color:var(--accent)"></i><span>${ja?'メンバー管理':'Member Admin'}</span></button>` : ''}
      ${!isOwner ? `<button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));leaveCrew('${crewId}')" style="color:var(--accent)"><i class="fas fa-right-from-bracket" style="color:var(--accent)"></i><span>${ja?'退出する':'Leave Crew'}</span></button>` : ''}
      ${isOwner ? `<button onclick="closeBottomSheet(this.closest('.bottom-sheet-overlay'));showDeleteCrewConfirm('${crewId}')" style="color:#ef4444"><i class="fas fa-trash" style="color:#ef4444"></i><span>${ja?'クルーを削除':'Delete Crew'}</span></button>` : ''}
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeBottomSheet(ov); });
  document.body.appendChild(ov);
  requestAnimationFrame(() => { ov.classList.add('active'); ov.querySelector('.bottom-sheet').classList.add('active'); });
}
async function loadCrewVoiceMembers(channelId) { try { const res = await api(`/api/crew-voice/${channelId}`); const members = res.members || []; const el = $('#crew-voice-members'); if (!el) return; const isIn = members.some(m => m.id === S.user?.id); el.innerHTML = members.length ? members.map(m => `<div style="display:flex;flex-direction:column;align-items:center;gap:4px"><div style="border-radius:50%">${avatar(m.avatar_url, m.display_name, 46)}</div><span style="font-size:11px;color:var(--text-secondary);max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.display_name)}</span></div>`).join('') : `<div style="grid-column:1/-1;padding:40px;text-align:center;color:var(--text-tertiary)">${S.lang==='ja'?'誰もいません':'Empty'}</div>`; const joinBtn = $('#cv-join-btn'), leaveBtn = $('#cv-leave-btn'), muteBtn = $('#cv-mute-btn'); if (joinBtn) joinBtn.style.display = isIn ? 'none' : ''; if (leaveBtn) leaveBtn.style.display = isIn ? '' : 'none'; if (muteBtn) muteBtn.style.display = isIn ? '' : 'none'; } catch{} }
async function joinCrewVoice(channelId) { playJoinSound(); const res = await api(`/api/crew-voice/${channelId}/join`, { method: 'POST' }); if (!res.success) { toast(res.error||'Error','error'); return; } S.crewVoiceChannelId = channelId; try { const stream = await navigator.mediaDevices.getUserMedia({ audio: true }); S.crewVoiceStream = stream; const myPeerId = 'crew_' + S.user.id + '_' + Date.now(); S.crewVoicePeer = new Peer(myPeerId, { config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] } }); S.crewVoicePeer.on('open', async (id) => { await api(`/api/crew-voice/${channelId}/peer`, { method: 'POST', body: { peer_id: id } }); }); S.crewVoicePeer.on('call', (call) => { call.answer(stream); handleCrewVoiceStream(call); }); } catch{ toast(S.lang==='ja'?'マイク拒否':'Mic denied','error'); } }
function handleCrewVoiceStream(call) { S.crewVoiceConns[call.peer] = call; call.on('stream', (rs) => { if (S.crewVoiceAudios[call.peer]) return; const audio = document.createElement('audio'); audio.srcObject = rs; audio.autoplay = true; S.crewVoiceAudios[call.peer] = audio; const c = $('#crew-remote-audio'); if (c) c.appendChild(audio); audio.play().catch(()=>{}); }); call.on('close', () => { delete S.crewVoiceConns[call.peer]; if (S.crewVoiceAudios[call.peer]) { S.crewVoiceAudios[call.peer].remove(); delete S.crewVoiceAudios[call.peer]; } }); }
async function leaveCrewVoice(channelId) { cleanupCrewVoice(); playLeaveSound(); await api(`/api/crew-voice/${channelId}/leave`, { method: 'POST' }); S.crewVoiceChannelId = null; }
function cleanupCrewVoice() { if (S.crewVoiceStream) { S.crewVoiceStream.getTracks().forEach(t2 => t2.stop()); S.crewVoiceStream = null; } Object.values(S.crewVoiceConns).forEach(c => { try { c.close(); } catch{} }); S.crewVoiceConns = {}; Object.values(S.crewVoiceAudios).forEach(a => { try { a.remove(); } catch{} }); S.crewVoiceAudios = {}; if (S.crewVoicePeer) { try { S.crewVoicePeer.destroy(); } catch{} S.crewVoicePeer = null; } }
let crewVoiceMuted = false;
async function toggleCrewVoiceMute(channelId) { crewVoiceMuted = !crewVoiceMuted; const btn = $('#cv-mute-btn'); if (btn) btn.innerHTML = `<i class="fas ${crewVoiceMuted?'fa-microphone-slash':'fa-microphone'}" style="font-size:15px;color:${crewVoiceMuted?'var(--accent)':'var(--text-primary)'}"></i>`; if (S.crewVoiceStream) S.crewVoiceStream.getAudioTracks().forEach(t2 => t2.enabled = !crewVoiceMuted); await api(`/api/crew-voice/${channelId}/mute`, { method: 'POST', body: { muted: crewVoiceMuted } }); }

let lastCrewTs = null;
async function loadCrewMessages(channelId) { const msgsEl = $('#crew-msgs'); if (!msgsEl) return; const res = await api(`/api/channels/${channelId}/messages`); const msgs = res.messages || []; lastCrewTs = msgs.length > 0 ? msgs[msgs.length - 1].created_at : null; msgsEl.innerHTML = msgs.map(m => renderCrewMsg(m)).join('') || `<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-tertiary)">${S.lang==='ja'?'メッセージなし':'No messages'}</div>`; msgsEl.scrollTop = msgsEl.scrollHeight; }
function renderCrewMsg(m) { const mine = m.sender_id === S.user?.id; const isOfficial = m.sender_is_official || (mine && S.user?.is_official); const officialMark = isOfficial ? '<span class="official-badge" style="font-size:10px;margin-left:3px" title="Official"><i class="fas fa-check-circle"></i></span>' : ''; const canDelete = mine || (window._crewMyRole && crewRoleLvl(window._crewMyRole) >= 2); const roleBadge = m.sender_role && m.sender_role !== 'member' ? `<span style="font-size:9px;padding:1px 5px;border-radius:4px;background:${m.sender_role==='owner'?'var(--accent-bg)':m.sender_role==='admin'?'rgba(139,92,246,0.1)':'rgba(6,182,212,0.1)'};color:${m.sender_role==='owner'?'var(--accent)':m.sender_role==='admin'?'#8b5cf6':'#06b6d4'};font-weight:700;text-transform:uppercase">${m.sender_role}</span>` : ''; return `<div class="crew-msg" data-msg-id="${m.id||''}" style="display:flex;gap:10px;padding:4px 0;position:relative" ${canDelete && m.id ? `oncontextmenu="event.preventDefault();showCrewMsgMenu(event,'${m.id}')" ontouchstart="window._cmLong=setTimeout(()=>{showCrewMsgMenu(event,'${m.id}')},500)" ontouchend="clearTimeout(window._cmLong)" ontouchmove="clearTimeout(window._cmLong)"` : ''}><a href="/profile/${esc(m.sender_username)}" style="flex-shrink:0" onclick="event.stopPropagation()">${avatar(m.sender_avatar_url, m.sender_display_name, 30)}</a><div style="min-width:0;flex:1"><div style="display:flex;align-items:baseline;gap:6px;flex-wrap:wrap"><span style="font-size:13px;font-weight:600;color:${mine?'var(--accent)':'var(--text-primary)'}">${esc(m.sender_display_name)}</span>${roleBadge}${officialMark}<span style="font-size:11px;color:var(--text-tertiary)">${timeAgo(m.created_at)}</span></div><div style="font-size:14px;color:var(--text-secondary);line-height:1.5;word-break:break-word">${formatContent(m.content)}</div></div></div>`; }
function crewRoleLvl(r) { return r==='owner'?4:r==='admin'?3:r==='moderator'?2:1; }
function showCrewMsgMenu(e, msgId) {
  e.preventDefault(); e.stopPropagation(); haptic('light');
  document.querySelectorAll('.crew-msg-menu').forEach(m => m.remove());
  const menu = document.createElement('div'); menu.className = 'crew-msg-menu anim-scale-in';
  menu.style.cssText = 'position:fixed;z-index:1000;background:var(--bg-primary);border:1px solid var(--border);border-radius:var(--radius-md);padding:4px;box-shadow:0 8px 30px rgba(0,0,0,0.15);min-width:140px';
  menu.innerHTML = `<button style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;color:var(--text-primary);font-size:13px;cursor:pointer;border-radius:var(--radius-sm)" onclick="deleteCrewMsg('${msgId}');this.closest('.crew-msg-menu').remove()"><i class="fas fa-trash" style="color:var(--accent);font-size:11px"></i>${S.lang==='ja'?'削除':'Delete'}</button>`;
  document.body.appendChild(menu);
  const touch = e.touches?.[0]||e; const x = Math.min(touch.clientX||touch.pageX,window.innerWidth-160); const y = Math.min(touch.clientY||touch.pageY,window.innerHeight-50);
  menu.style.left = x+'px'; menu.style.top = y+'px';
  setTimeout(()=>{const cl=ev=>{if(!ev.target.closest('.crew-msg-menu')){menu.remove();document.removeEventListener('click',cl);}};document.addEventListener('click',cl);},50);
}
async function deleteCrewMsg(msgId) {
  const res = await api(`/api/crew-messages/${msgId}`, { method: 'DELETE' });
  if (res.success) { const el = document.querySelector(`[data-msg-id="${msgId}"]`); if (el) el.remove(); toast(S.lang==='ja'?'削除しました':'Deleted'); }
  else toast(res.error||'Error','error');
}
function appendCrewMessage(m) { const msgsEl = $('#crew-msgs'); if (!msgsEl) return; if (msgsEl.querySelector('div[style*="justify-content:center"]')) msgsEl.innerHTML = ''; const div = h('div', '', renderCrewMsg(m)); msgsEl.appendChild(div.firstElementChild); msgsEl.scrollTop = msgsEl.scrollHeight; if (m.created_at > (lastCrewTs || '')) lastCrewTs = m.created_at; }
async function sendCrewMessage(channelId) {
  if (!channelId) return; const input = $('#crew-msg-input'); const content = input?.value.trim(); if (!content) return;
  input.value = '';
  // CRITICAL: Keep keyboard open - use requestAnimationFrame for reliable focus
  requestAnimationFrame(() => { if (input) input.focus(); });
  const now = new Date().toISOString();
  appendCrewMessage({ sender_id: S.user.id, sender_username: S.user.username, sender_display_name: S.user.display_name, sender_avatar_url: S.user.avatar_url, sender_is_official: S.user.is_official || 0, content, created_at: now });
  lastCrewTs = now;
  if (!sendWS({ type: 'chat', content })) {
    await api(`/api/channels/${channelId}/messages`, { method: 'POST', body: { content } });
  }
}
async function pollCrewMessages(channelId) { if (S.currentPage !== 'crewDetail') return; if (!lastCrewTs) return; try { const res = await api(`/api/sse/channel/${channelId}?after=${encodeURIComponent(lastCrewTs)}`); if (res.messages) res.messages.forEach(m => { if (m.sender_id !== S.user.id) appendCrewMessage(m); }); } catch {} }
function switchCrewChannel(crewId, channelId) { cleanupPolling(); disconnectWS(); history.replaceState(null, '', `/crew/${crewId}/${channelId}`); S.currentParams = { id: crewId, channelId }; pageCrewDetail($('#page'), crewId, channelId); }
async function leaveCrew(id) { confirmDialog(S.lang==='ja'?'退出しますか？':'Leave?', async () => { await api(`/api/crews/${id}/leave`, { method: 'POST' }); navigate('/crew'); }); }
async function joinCrewAndReload(id) { const res = await api(`/api/crews/${id}/join`, { method: 'POST' }); if (res.error) { toast(res.error, 'error'); return; } if (res.success) pageCrewDetail($('#page'), id); }

// ===== CREW ADMIN (Discord-like) =====
function showCrewAdminModal(crewId) {
  const ja = S.lang === 'ja';
  const isOwner = window._crewMyRole === 'owner';
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:0;max-height:85vh;overflow:hidden;display:flex;flex-direction:column" onclick="event.stopPropagation()">
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <span style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700"><i class="fas fa-shield-halved" style="margin-right:8px;color:var(--accent)"></i>${ja?'サーバー管理':'Server Admin'}</span>
      <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()"><i class="fas fa-times"></i></button>
    </div>
    <div style="display:flex;border-bottom:1px solid var(--border);overflow-x:auto;flex-shrink:0">
      <button class="crew-admin-tab active" onclick="switchCrewAdminTab('members','${crewId}',this)">${ja?'メンバー':'Members'}</button>
      <button class="crew-admin-tab" onclick="switchCrewAdminTab('bans','${crewId}',this)">${ja?'BAN一覧':'Bans'}</button>
      <button class="crew-admin-tab" onclick="switchCrewAdminTab('log','${crewId}',this)">${ja?'監査ログ':'Audit Log'}</button>
      ${isOwner ? `<button class="crew-admin-tab" onclick="switchCrewAdminTab('settings','${crewId}',this)">${ja?'設定':'Settings'}</button>` : ''}
    </div>
    <div id="crew-admin-content" style="flex:1;overflow-y:auto;padding:16px"></div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
  loadCrewAdminMembers(crewId);
}
function switchCrewAdminTab(tab, crewId, el) {
  document.querySelectorAll('.crew-admin-tab').forEach(t2 => t2.classList.remove('active')); el.classList.add('active');
  if (tab === 'members') loadCrewAdminMembers(crewId);
  else if (tab === 'bans') loadCrewAdminBans(crewId);
  else if (tab === 'log') loadCrewAdminLog(crewId);
  else if (tab === 'settings') loadCrewAdminSettings(crewId);
}
async function loadCrewAdminMembers(crewId) {
  const el = document.getElementById('crew-admin-content'); if (!el) return;
  el.innerHTML = '<div style="text-align:center;padding:20px"><div class="spinner" style="margin:0 auto"></div></div>';
  const res = await api(`/api/crews/${crewId}`);
  const members = res.members || [];
  const myRole = res.crew?.my_role || 'member';
  const ja = S.lang === 'ja';
  const roleIcons = { owner: '👑', admin: '🛡️', moderator: '⚔️', member: '' };
  const roleColors = { owner: 'var(--accent)', admin: '#8b5cf6', moderator: '#06b6d4', member: 'var(--text-tertiary)' };
  el.innerHTML = members.map(m => `
    <div style="display:flex;align-items:center;gap:12px;padding:10px;border-radius:var(--radius-md);border:1px solid var(--border);margin-bottom:8px;background:var(--bg-secondary)">
      ${avatar(m.avatar_url, m.display_name, 36)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:14px;display:flex;align-items:center;gap:6px">${esc(m.display_name)} ${m.is_official?'<i class="fas fa-check-circle" style="color:var(--sky);font-size:11px"></i>':''}</div>
        <div style="font-size:12px;color:${roleColors[m.role]||roleColors.member};font-weight:600">${roleIcons[m.role]||''} ${m.role?.toUpperCase()||'MEMBER'}</div>
      </div>
      ${m.user_id !== S.user?.id && crewRoleLvl(myRole) > crewRoleLvl(m.role) ? `
        <div style="display:flex;gap:4px;flex-shrink:0">
          <button class="btn btn-secondary btn-xs" onclick="showCrewMemberActions('${crewId}','${m.user_id}','${esc(m.display_name)}','${m.role}','${myRole}')" title="${ja?'管理':'Manage'}"><i class="fas fa-ellipsis-v"></i></button>
        </div>
      ` : ''}
    </div>
  `).join('') || `<div style="text-align:center;color:var(--text-tertiary)">${ja?'メンバーなし':'No members'}</div>`;
}
function showCrewMemberActions(crewId, userId, name, userRole, myRole) {
  const ja = S.lang === 'ja';
  const ov = h('div', 'modal-overlay');
  ov.style.zIndex = '10001';
  let roleButtons = '';
  if (myRole === 'owner') {
    roleButtons = `<button class="btn btn-secondary btn-sm" style="width:100%" onclick="crewSetRole('${crewId}','${userId}','admin')"><i class="fas fa-shield" style="margin-right:6px;color:#8b5cf6"></i>${ja?'管理者に設定':'Set Admin'}</button>`;
  }
  if (crewRoleLvl(myRole) >= 3) {
    roleButtons += `<button class="btn btn-secondary btn-sm" style="width:100%" onclick="crewSetRole('${crewId}','${userId}','moderator')"><i class="fas fa-gavel" style="margin-right:6px;color:#06b6d4"></i>${ja?'モデレーターに設定':'Set Moderator'}</button>`;
    roleButtons += `<button class="btn btn-secondary btn-sm" style="width:100%" onclick="crewSetRole('${crewId}','${userId}','member')"><i class="fas fa-user" style="margin-right:6px"></i>${ja?'メンバーに降格':'Demote to Member'}</button>`;
  }
  ov.innerHTML = `<div class="modal-content" style="padding:20px;max-width:340px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700;margin-bottom:16px">${esc(name)}</h3>
    <div style="display:flex;flex-direction:column;gap:8px">
      ${roleButtons}
      <hr style="border:none;border-top:1px solid var(--border);margin:4px 0">
      <button class="btn btn-secondary btn-sm" style="width:100%" onclick="showCrewTimeout('${crewId}','${userId}','${esc(name)}')"><i class="fas fa-clock" style="margin-right:6px;color:#f59e0b"></i>${ja?'タイムアウト':'Timeout'}</button>
      <button class="btn btn-secondary btn-sm" style="width:100%" onclick="crewKick('${crewId}','${userId}','${esc(name)}')"><i class="fas fa-right-from-bracket" style="margin-right:6px;color:#ef4444"></i>${ja?'キック':'Kick'}</button>
      <button class="btn btn-sm" style="width:100%;background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)" onclick="crewBan('${crewId}','${userId}','${esc(name)}')"><i class="fas fa-ban" style="margin-right:6px"></i>${ja?'BAN':'Ban'}</button>
      <button class="btn btn-secondary btn-sm" style="width:100%;margin-top:4px" onclick="this.closest('.modal-overlay').remove()">${ja?'閉じる':'Close'}</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}
async function crewSetRole(crewId, userId, role) {
  const res = await api(`/api/crews/${crewId}/set-member-role`, { method: 'POST', body: { target_user_id: userId, role } });
  if (res.success) { toast(S.lang==='ja'?'更新しました':'Updated'); document.querySelectorAll('.modal-overlay').forEach(o => o.remove()); showCrewAdminModal(crewId); }
  else toast(res.error||'Error','error');
}
function crewKick(crewId, userId, name) {
  confirmDialog(`${S.lang==='ja'?'キック':'Kick'}: ${name}?`, async () => {
    const res = await api(`/api/crews/${crewId}/kick`, { method: 'POST', body: { target_user_id: userId } });
    if (res.success) { toast(S.lang==='ja'?'キックしました':'Kicked'); document.querySelectorAll('.modal-overlay').forEach(o => o.remove()); }
    else toast(res.error||'Error','error');
  });
}
function crewBan(crewId, userId, name) {
  const ja = S.lang === 'ja';
  confirmDialog(`${ja?'BAN':'Ban'}: ${name}?`, async () => {
    const reason = prompt(ja?'理由（任意）':'Reason (optional)') || '';
    const res = await api(`/api/crews/${crewId}/ban`, { method: 'POST', body: { target_user_id: userId, reason } });
    if (res.success) { toast(ja?'BANしました':'Banned'); document.querySelectorAll('.modal-overlay').forEach(o => o.remove()); }
    else toast(res.error||'Error','error');
  });
}
function showCrewTimeout(crewId, userId, name) {
  const ja = S.lang === 'ja';
  const ov2 = h('div', 'modal-overlay');
  ov2.style.zIndex = '10002';
  ov2.innerHTML = `<div class="modal-content" style="padding:20px;max-width:320px" onclick="event.stopPropagation()">
    <h3 style="font-size:16px;font-weight:700;margin-bottom:12px"><i class="fas fa-clock" style="margin-right:6px;color:#f59e0b"></i>${ja?'タイムアウト':'Timeout'}: ${esc(name)}</h3>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px">
      ${[5,10,30,60,1440,10080].map(m => `<button class="btn btn-secondary btn-xs" onclick="crewTimeout('${crewId}','${userId}',${m},'');document.querySelectorAll('.modal-overlay').forEach(o=>o.remove())">${m < 60 ? m+'min' : m < 1440 ? (m/60)+'h' : (m/1440)+'d'}</button>`).join('')}
    </div>
    <button class="btn btn-secondary btn-sm" style="width:100%" onclick="this.closest('.modal-overlay').remove()">${ja?'閉じる':'Cancel'}</button>
  </div>`;
  ov2.addEventListener('click', e => { if (e.target === ov2) ov2.remove(); });
  document.body.appendChild(ov2);
}
async function crewTimeout(crewId, userId, mins, reason) {
  const res = await api(`/api/crews/${crewId}/timeout`, { method: 'POST', body: { target_user_id: userId, duration_minutes: mins, reason } });
  if (res.success) toast(S.lang==='ja'?`${mins}分タイムアウトしました`:`Timed out for ${mins}min`);
  else toast(res.error||'Error','error');
}
async function loadCrewAdminBans(crewId) {
  const el = document.getElementById('crew-admin-content'); if (!el) return;
  el.innerHTML = '<div style="text-align:center;padding:20px"><div class="spinner" style="margin:0 auto"></div></div>';
  const res = await api(`/api/crews/${crewId}/bans`);
  const bans = res.bans || [];
  const ja = S.lang === 'ja';
  if (bans.length === 0) { el.innerHTML = `<div style="text-align:center;padding:40px;color:var(--text-tertiary)">${ja?'BAN中のユーザーなし':'No banned users'}</div>`; return; }
  el.innerHTML = bans.map(b => `
    <div style="display:flex;align-items:center;gap:12px;padding:10px;border-radius:var(--radius-md);border:1px solid var(--border);margin-bottom:8px">
      ${avatar(b.avatar_url, b.display_name, 36)}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:14px">${esc(b.display_name)}</div>
        <div style="font-size:12px;color:var(--text-tertiary)">${b.reason ? esc(b.reason) : (ja?'理由なし':'No reason')} · by @${esc(b.banned_by_username)}</div>
      </div>
      <button class="btn btn-secondary btn-xs" onclick="crewUnban('${crewId}','${b.user_id}')"><i class="fas fa-unlock" style="margin-right:4px"></i>${ja?'解除':'Unban'}</button>
    </div>
  `).join('');
}
async function crewUnban(crewId, userId) {
  const res = await api(`/api/crews/${crewId}/unban`, { method: 'POST', body: { target_user_id: userId } });
  if (res.success) { toast(S.lang==='ja'?'解除しました':'Unbanned'); loadCrewAdminBans(crewId); }
  else toast(res.error||'Error','error');
}
async function loadCrewAdminLog(crewId) {
  const el = document.getElementById('crew-admin-content'); if (!el) return;
  el.innerHTML = '<div style="text-align:center;padding:20px"><div class="spinner" style="margin:0 auto"></div></div>';
  const res = await api(`/api/crews/${crewId}/audit-log`);
  const logs = res.logs || [];
  const ja = S.lang === 'ja';
  if (logs.length === 0) { el.innerHTML = `<div style="text-align:center;padding:40px;color:var(--text-tertiary)">${ja?'ログなし':'No logs'}</div>`; return; }
  const actionLabels = { set_role: ja?'ロール変更':'Role change', kick: ja?'キック':'Kick', ban: 'BAN', unban: ja?'BAN解除':'Unban', timeout: ja?'タイムアウト':'Timeout' };
  const actionIcons = { set_role: 'fa-user-tag', kick: 'fa-right-from-bracket', ban: 'fa-ban', unban: 'fa-unlock', timeout: 'fa-clock' };
  const actionColors = { set_role: '#8b5cf6', kick: '#f59e0b', ban: '#ef4444', unban: '#22c55e', timeout: '#f59e0b' };
  el.innerHTML = logs.map(l => `
    <div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
      <i class="fas ${actionIcons[l.action]||'fa-circle'}" style="color:${actionColors[l.action]||'var(--text-tertiary)'};margin-top:3px;font-size:12px;width:18px;text-align:center"></i>
      <div style="flex:1;min-width:0">
        <div style="font-size:13px"><strong>${esc(l.actor_display_name)}</strong> → ${actionLabels[l.action]||l.action} → <strong>${l.target_display_name ? esc(l.target_display_name) : ''}</strong></div>
        ${l.details ? `<div style="font-size:12px;color:var(--text-tertiary)">${esc(l.details)}</div>` : ''}
        <div style="font-size:11px;color:var(--text-tertiary)">${timeAgo(l.created_at)}</div>
      </div>
    </div>
  `).join('');
}

async function loadCrewAdminSettings(crewId) {
  const el = document.getElementById('crew-admin-content'); if (!el) return;
  el.innerHTML = '<div style="text-align:center;padding:20px"><div class="spinner" style="margin:0 auto"></div></div>';
  const res = await api(`/api/crews/${crewId}`);
  const crew = res.crew || {};
  const channels = res.channels || [];
  const ja = S.lang === 'ja';
  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h4 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:12px">${ja?'基本設定':'GENERAL'}</h4>
      <div style="margin-bottom:12px"><label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:4px">${ja?'クルー名':'Name'}</label><input type="text" id="cs-name" class="input" value="${esc(crew.name||'')}" maxlength="50"></div>
      <div style="margin-bottom:12px"><label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:4px">${ja?'説明':'Description'}</label><textarea id="cs-desc" class="input" style="height:60px" maxlength="200">${esc(crew.description||'')}</textarea></div>
      <button class="btn btn-primary btn-sm" onclick="saveCrewSettings('${crewId}')">${ja?'保存':'Save'}</button>
    </div>
    <div style="margin-bottom:20px">
      <h4 style="font-size:13px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:12px">${ja?'チャンネル管理':'CHANNELS'}</h4>
      ${channels.map(ch => `
        <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:6px;background:var(--bg-secondary)">
          <i class="fas ${ch.type==='voice'?'fa-volume-high':'fa-hashtag'}" style="font-size:12px;color:var(--text-tertiary)"></i>
          <span style="flex:1;font-size:14px;font-weight:500">${esc(ch.name)}</span>
          <span style="font-size:11px;color:var(--text-tertiary)">${ch.type}</span>
          ${channels.filter(c => c.type === ch.type).length > 1 || ch.type === 'voice' ? `<button class="btn btn-danger btn-xs" onclick="deleteCrewChannel('${crewId}','${ch.id}');document.querySelector('.modal-overlay')?.remove()"><i class="fas fa-trash" style="font-size:10px"></i></button>` : ''}
        </div>
      `).join('')}
      <button class="btn btn-secondary btn-sm" style="margin-top:8px" onclick="showAddChannelModal('${crewId}')"><i class="fas fa-plus" style="margin-right:4px"></i>${ja?'チャンネル追加':'Add Channel'}</button>
    </div>
    <div style="border-top:1px solid var(--border);padding-top:16px">
      <h4 style="font-size:13px;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:12px">${ja?'危険ゾーン':'DANGER ZONE'}</h4>
      <button class="btn btn-sm" style="width:100%;background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)" onclick="showDeleteCrewConfirm('${crewId}');document.querySelector('.modal-overlay')?.remove()"><i class="fas fa-trash" style="margin-right:6px"></i>${ja?'クルーを完全に削除':'Permanently Delete Crew'}</button>
    </div>
  `;
}

function showAddChannelModal(crewId) {
  const ja = S.lang === 'ja';
  const ov2 = h('div', 'modal-overlay');
  ov2.style.zIndex = '10001';
  ov2.innerHTML = `<div class="modal-content" style="padding:20px;max-width:340px" onclick="event.stopPropagation()">
    <h3 style="font-size:16px;font-weight:700;margin-bottom:12px">${ja?'チャンネル追加':'Add Channel'}</h3>
    <input type="text" id="new-ch-name" class="input" placeholder="${ja?'チャンネル名':'Channel name'}" maxlength="30" style="margin-bottom:10px">
    <div style="display:flex;gap:8px;margin-bottom:16px">
      <button class="pill active" id="ch-type-text" onclick="window._newChType='text';this.classList.add('active');$('#ch-type-voice').classList.remove('active')">Text</button>
      <button class="pill" id="ch-type-voice" onclick="window._newChType='voice';this.classList.add('active');$('#ch-type-text').classList.remove('active')">Voice</button>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-secondary btn-sm" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${ja?'キャンセル':'Cancel'}</button>
      <button class="btn btn-primary btn-sm" style="flex:1" onclick="addCrewChannel('${crewId}')">${ja?'追加':'Add'}</button>
    </div>
  </div>`;
  window._newChType = 'text';
  ov2.addEventListener('click', e => { if (e.target === ov2) ov2.remove(); });
  document.body.appendChild(ov2);
}
async function addCrewChannel(crewId) {
  const name = $('#new-ch-name')?.value.trim();
  if (!name) return toast(S.lang==='ja'?'名前を入力':'Name required','error');
  const res = await api(`/api/crews/${crewId}/channels`, { method: 'POST', body: { name, type: window._newChType || 'text' } });
  if (res.success) { toast(S.lang==='ja'?'追加しました':'Added'); document.querySelectorAll('.modal-overlay').forEach(o => o.remove()); showCrewAdminModal(crewId); /* reopen admin */ }
  else toast(res.error||'Error','error');
}

// ===== CREW DELETE / SETTINGS =====
function showDeleteCrewConfirm(crewId) {
  const ja = S.lang === 'ja';
  confirmDialog(ja ? 'このクルーを完全に削除しますか？この操作は取り消せません。' : 'Permanently delete this crew? This cannot be undone.', async () => {
    const res = await api(`/api/crews/${crewId}`, { method: 'DELETE' });
    if (res.success) { toast(ja ? 'クルーを削除しました' : 'Crew deleted'); navigate('/crew'); }
    else toast(res.error || 'Error', 'error');
  });
}
async function deleteCrew(crewId) { showDeleteCrewConfirm(crewId); }
async function deleteCrewChannel(crewId, channelId) {
  const ja = S.lang === 'ja';
  confirmDialog(ja ? 'このチャンネルを削除しますか？' : 'Delete this channel?', async () => {
    const res = await api(`/api/crews/${crewId}/channels/${channelId}`, { method: 'DELETE' });
    if (res.success) { toast(ja ? '削除しました' : 'Deleted'); pageCrewDetail($('#page'), crewId); }
    else toast(res.error || 'Error', 'error');
  });
}
function showCrewSettingsModal(crewId, currentName, currentDesc) {
  const ja = S.lang === 'ja';
  const ov = h('div', 'modal-overlay');
  ov.innerHTML = `<div class="modal-content" style="padding:24px" onclick="event.stopPropagation()">
    <h3 style="font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:700;margin-bottom:16px"><i class="fas fa-gear" style="margin-right:8px;color:var(--accent)"></i>${ja?'クルー設定':'Crew Settings'}</h3>
    <div style="margin-bottom:14px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">${ja?'クルー名':'Crew Name'}</label><input type="text" id="crew-set-name" class="input" value="${esc(currentName)}" maxlength="50"></div>
    <div style="margin-bottom:14px"><label style="font-size:11px;color:var(--text-tertiary);font-weight:700;display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.06em">${ja?'説明':'Description'}</label><textarea id="crew-set-desc" class="input" style="height:60px" maxlength="200">${esc(currentDesc||'')}</textarea></div>
    <div style="display:flex;gap:12px;margin-bottom:16px">
      <button class="btn btn-secondary" style="flex:1" onclick="this.closest('.modal-overlay').remove()">${ja?'キャンセル':'Cancel'}</button>
      <button class="btn btn-primary" style="flex:1" onclick="saveCrewSettings('${crewId}')">${ja?'保存':'Save'}</button>
    </div>
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <button class="btn btn-sm" style="width:100%;background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)" onclick="showDeleteCrewConfirm('${crewId}');this.closest('.modal-overlay').remove()"><i class="fas fa-trash" style="margin-right:6px"></i>${ja?'クルーを削除':'Delete Crew'}</button>
  </div>`;
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
}
async function saveCrewSettings(crewId) {
  const name = $('#crew-set-name')?.value.trim();
  const description = $('#crew-set-desc')?.value.trim();
  if (!name) { toast(S.lang==='ja'?'名前が必要':'Name required','error'); return; }
  const res = await api(`/api/crews/${crewId}`, { method: 'PUT', body: { name, description } });
  if (res.success) { document.querySelector('.modal-overlay')?.remove(); toast(S.lang==='ja'?'保存しました':'Saved'); pageCrewDetail($('#page'), crewId); }
  else toast(res.error||'Error','error');
}

// ===== NOTIFICATIONS =====
async function pageNotifications(el) {
  if (!S.user) return navigate('/login');
  el.innerHTML = `<div class="page-header" style="padding:20px 24px;display:flex;align-items:center;justify-content:space-between"><span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700">${t('notif.title')}</span><button class="btn btn-secondary btn-xs" onclick="markAllNotifRead()">${t('notif.mark_read')}</button></div><div id="notif-announcements"></div><div id="notif-list"><div style="padding:40px;text-align:center"><div class="spinner" style="margin:0 auto"></div></div></div><div class="mobile-nav-spacer"></div>`;
  // Load announcements in notifications
  loadNotifAnnouncements();
  const res = await api('/api/notifications'); const notifs = res.notifications || []; const list = $('#notif-list');
  if (notifs.length === 0) { list.innerHTML = `<div style="padding:80px;text-align:center;color:var(--text-tertiary)">${t('notif.empty')}</div>`; return; }
  list.innerHTML = `<div style="padding:12px 16px;display:flex;flex-direction:column;gap:8px">${notifs.map((n, i) => {
    const isUnread = !n.read_at;
    let icon = 'fa-bell', text = '', href = '';
    if (n.type === 'follow') { icon = 'fa-user-plus'; text = S.lang==='ja'?'あなたをフォローしました':'followed you'; href = `/profile/${n.actor_username}`; }
    else if (n.type === 'like') { icon = 'fa-heart'; text = S.lang==='ja'?'あなたの投稿にいいねしました':'liked your post'; href = `/post/${n.target_id}`; }
    else if (n.type === 'reply') { icon = 'fa-reply'; text = S.lang==='ja'?'あなたの投稿に返信しました':'replied to your post'; href = `/post/${n.target_id}`; }
    else if (n.type === 'koremite') { icon = 'fa-retweet'; text = S.lang==='ja'?'あなたの投稿をコレミテしました':'quoted your post'; href = `/post/${n.target_id}`; }
    else if (n.type === 'coin') { icon = 'fa-coins'; text = `${n.target_id} ${S.lang==='ja'?'コインを送りました':'coins sent'}`; href = '/settings'; }
    return `<a href="${href}" class="notif-card ${isUnread ? 'unread' : ''} anim-fade-up stagger-${Math.min(i+1,5)}"><div style="display:flex;align-items:center;gap:14px">${avatar(n.actor_avatar_url, n.actor_display_name, 44)}<div style="flex:1;min-width:0"><div style="font-size:14px;display:flex;align-items:center;gap:6px;flex-wrap:wrap"><span style="font-weight:600">${esc(n.actor_display_name)}</span><span style="font-size:12px;color:var(--text-tertiary)">@${esc(n.actor_username)}</span></div><div style="font-size:13px;color:var(--text-secondary);margin-top:2px"><i class="fas ${icon}" style="margin-right:5px;font-size:11px;color:var(--accent)"></i>${text}</div><div style="font-size:12px;color:var(--text-tertiary);margin-top:2px">${timeAgo(n.created_at)}</div></div></div></a>`;
  }).join('')}</div>`;
  api('/api/notifications/read', { method: 'POST' });
}
async function markAllNotifRead() { await api('/api/notifications/read', { method: 'POST' }); $$('.notif-card.unread').forEach(el => el.classList.remove('unread')); toast(S.lang==='ja'?'既読にしました':'Done'); }
async function loadNotifAnnouncements() {
  const el = $('#notif-announcements'); if (!el) return;
  const res = await api('/api/admin/announcements');
  const anns = (res.announcements || []).slice(0, 3);
  if (anns.length === 0) return;
  el.innerHTML = `<div style="padding:12px 16px"><h3 style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px"><i class="fas fa-bullhorn" style="margin-right:5px"></i>${S.lang==='ja'?'運営からのお知らせ':'ANNOUNCEMENTS'}</h3>${anns.map(a => `<div style="padding:12px 14px;background:var(--accent-bg);border:1px solid rgba(200,85,61,0.08);border-radius:var(--radius-md);margin-bottom:6px"><div style="font-weight:700;font-size:13px;margin-bottom:3px">${esc(a.title)}</div><div style="font-size:12px;color:var(--text-secondary);line-height:1.5">${esc(a.content).substring(0,100)}</div><div style="font-size:10px;color:var(--text-tertiary);margin-top:4px">${timeAgo(a.created_at)}</div></div>`).join('')}</div>`;
}

